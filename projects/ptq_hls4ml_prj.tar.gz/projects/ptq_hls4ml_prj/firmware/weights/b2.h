//Numpy array shape [4]
//Min -0.388792812824
//Max 0.196674510837
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
conv1_bias_t b2[4];
#else
conv1_bias_t b2[4] = {0.1966745108, 0.0387865193, -0.3887928128, -0.0539331697};
#endif

#endif
