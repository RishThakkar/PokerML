//Numpy array shape [4]
//Min -0.343750000000
//Max 0.062500000000
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[4];
#else
bias2_t b2[4] = {-0.15625, -0.28125, 0.06250, -0.34375};
#endif

#endif
