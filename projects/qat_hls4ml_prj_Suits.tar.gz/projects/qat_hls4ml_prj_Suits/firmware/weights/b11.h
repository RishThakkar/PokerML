//Numpy array shape [4]
//Min -0.062500000000
//Max 0.093750000000
//Number of zeros 2

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[4];
#else
bias11_t b11[4] = {0.00000, 0.09375, -0.06250, 0.00000};
#endif

#endif
