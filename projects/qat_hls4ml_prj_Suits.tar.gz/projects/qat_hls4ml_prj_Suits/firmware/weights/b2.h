//Numpy array shape [4]
//Min -0.156250000000
//Max 0.187500000000
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[4];
#else
bias2_t b2[4] = {-0.15625, 0.12500, 0.18750, 0.06250};
#endif

#endif
