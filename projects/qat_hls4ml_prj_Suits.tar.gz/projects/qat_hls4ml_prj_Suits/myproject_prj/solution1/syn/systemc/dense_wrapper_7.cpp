#include "dense_wrapper.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper::thread_select_ln56_673_fu_38580_p3() {
    select_ln56_673_fu_38580_p3 = (!or_ln56_172_fu_33304_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_172_fu_33304_p2.read()[0].to_bool())? select_ln56_563_fu_37708_p3.read(): select_ln56_564_fu_37716_p3.read());
}

void dense_wrapper::thread_select_ln56_674_fu_38588_p3() {
    select_ln56_674_fu_38588_p3 = (!or_ln56_174_fu_33332_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_174_fu_33332_p2.read()[0].to_bool())? select_ln56_565_fu_37724_p3.read(): select_ln56_566_fu_37732_p3.read());
}

void dense_wrapper::thread_select_ln56_675_fu_38596_p3() {
    select_ln56_675_fu_38596_p3 = (!or_ln56_176_fu_33360_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_176_fu_33360_p2.read()[0].to_bool())? select_ln56_567_fu_37740_p3.read(): select_ln56_568_fu_37748_p3.read());
}

void dense_wrapper::thread_select_ln56_676_fu_38604_p3() {
    select_ln56_676_fu_38604_p3 = (!or_ln56_178_fu_33388_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_178_fu_33388_p2.read()[0].to_bool())? select_ln56_569_fu_37756_p3.read(): select_ln56_570_fu_37764_p3.read());
}

void dense_wrapper::thread_select_ln56_677_fu_38612_p3() {
    select_ln56_677_fu_38612_p3 = (!or_ln56_180_fu_33416_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_180_fu_33416_p2.read()[0].to_bool())? select_ln56_571_fu_37772_p3.read(): select_ln56_572_fu_37780_p3.read());
}

void dense_wrapper::thread_select_ln56_678_fu_38620_p3() {
    select_ln56_678_fu_38620_p3 = (!or_ln56_182_fu_33444_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_182_fu_33444_p2.read()[0].to_bool())? select_ln56_573_fu_37788_p3.read(): select_ln56_574_fu_37796_p3.read());
}

void dense_wrapper::thread_select_ln56_679_fu_38628_p3() {
    select_ln56_679_fu_38628_p3 = (!or_ln56_184_fu_33472_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_184_fu_33472_p2.read()[0].to_bool())? select_ln56_575_fu_37804_p3.read(): select_ln56_576_fu_37812_p3.read());
}

void dense_wrapper::thread_select_ln56_67_fu_31826_p3() {
    select_ln56_67_fu_31826_p3 = (!icmp_ln56_256_fu_30078_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_256_fu_30078_p2.read()[0].to_bool())? ap_phi_mux_data_648_V_read662_s_phi_fu_26580_p4.read(): ap_phi_mux_data_647_V_read661_s_phi_fu_26567_p4.read());
}

void dense_wrapper::thread_select_ln56_680_fu_38636_p3() {
    select_ln56_680_fu_38636_p3 = (!or_ln56_186_fu_33500_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_186_fu_33500_p2.read()[0].to_bool())? select_ln56_577_fu_37820_p3.read(): select_ln56_578_fu_37828_p3.read());
}

void dense_wrapper::thread_select_ln56_681_fu_38644_p3() {
    select_ln56_681_fu_38644_p3 = (!or_ln56_188_fu_33528_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_188_fu_33528_p2.read()[0].to_bool())? select_ln56_579_fu_37836_p3.read(): select_ln56_580_fu_37844_p3.read());
}

void dense_wrapper::thread_select_ln56_682_fu_38652_p3() {
    select_ln56_682_fu_38652_p3 = (!or_ln56_190_fu_33556_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_190_fu_33556_p2.read()[0].to_bool())? select_ln56_581_fu_37852_p3.read(): select_ln56_582_fu_37860_p3.read());
}

void dense_wrapper::thread_select_ln56_683_fu_38660_p3() {
    select_ln56_683_fu_38660_p3 = (!or_ln56_192_fu_33584_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_192_fu_33584_p2.read()[0].to_bool())? select_ln56_583_fu_37868_p3.read(): select_ln56_584_fu_37876_p3.read());
}

void dense_wrapper::thread_select_ln56_684_fu_38668_p3() {
    select_ln56_684_fu_38668_p3 = (!or_ln56_194_fu_33612_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_194_fu_33612_p2.read()[0].to_bool())? select_ln56_585_fu_37884_p3.read(): select_ln56_586_fu_28412_p3.read());
}

void dense_wrapper::thread_select_ln56_685_fu_38676_p3() {
    select_ln56_685_fu_38676_p3 = (!or_ln56_195_fu_33634_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_195_fu_33634_p2.read()[0].to_bool())? select_ln56_587_fu_37892_p3.read(): select_ln56_588_fu_37900_p3.read());
}

void dense_wrapper::thread_select_ln56_686_fu_38684_p3() {
    select_ln56_686_fu_38684_p3 = (!or_ln56_197_fu_33662_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_197_fu_33662_p2.read()[0].to_bool())? select_ln56_589_fu_37908_p3.read(): select_ln56_590_fu_37916_p3.read());
}

void dense_wrapper::thread_select_ln56_687_fu_38692_p3() {
    select_ln56_687_fu_38692_p3 = (!or_ln56_199_fu_33690_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_199_fu_33690_p2.read()[0].to_bool())? select_ln56_591_fu_37924_p3.read(): select_ln56_592_fu_37932_p3.read());
}

void dense_wrapper::thread_select_ln56_688_fu_38700_p3() {
    select_ln56_688_fu_38700_p3 = (!or_ln56_201_fu_33718_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_201_fu_33718_p2.read()[0].to_bool())? select_ln56_593_fu_37940_p3.read(): select_ln56_594_fu_37948_p3.read());
}

void dense_wrapper::thread_select_ln56_689_fu_38708_p3() {
    select_ln56_689_fu_38708_p3 = (!or_ln56_203_fu_33746_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_203_fu_33746_p2.read()[0].to_bool())? select_ln56_595_fu_37956_p3.read(): select_ln56_596_fu_37964_p3.read());
}

void dense_wrapper::thread_select_ln56_68_fu_31840_p3() {
    select_ln56_68_fu_31840_p3 = (!icmp_ln56_254_fu_30066_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_254_fu_30066_p2.read()[0].to_bool())? ap_phi_mux_data_646_V_read660_s_phi_fu_26554_p4.read(): ap_phi_mux_data_645_V_read659_s_phi_fu_26541_p4.read());
}

void dense_wrapper::thread_select_ln56_690_fu_38716_p3() {
    select_ln56_690_fu_38716_p3 = (!or_ln56_205_fu_33774_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_205_fu_33774_p2.read()[0].to_bool())? select_ln56_597_fu_37972_p3.read(): select_ln56_598_fu_37980_p3.read());
}

void dense_wrapper::thread_select_ln56_691_fu_38724_p3() {
    select_ln56_691_fu_38724_p3 = (!or_ln56_207_fu_33802_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_207_fu_33802_p2.read()[0].to_bool())? select_ln56_599_fu_37988_p3.read(): select_ln56_600_fu_37996_p3.read());
}

void dense_wrapper::thread_select_ln56_692_fu_38732_p3() {
    select_ln56_692_fu_38732_p3 = (!or_ln56_209_fu_33830_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_209_fu_33830_p2.read()[0].to_bool())? select_ln56_601_fu_38004_p3.read(): select_ln56_602_fu_38012_p3.read());
}

void dense_wrapper::thread_select_ln56_693_fu_38740_p3() {
    select_ln56_693_fu_38740_p3 = (!or_ln56_211_fu_33858_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_211_fu_33858_p2.read()[0].to_bool())? select_ln56_603_fu_38020_p3.read(): select_ln56_604_fu_38028_p3.read());
}

void dense_wrapper::thread_select_ln56_694_fu_38748_p3() {
    select_ln56_694_fu_38748_p3 = (!or_ln56_213_fu_33886_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_213_fu_33886_p2.read()[0].to_bool())? select_ln56_605_fu_38036_p3.read(): select_ln56_606_fu_38044_p3.read());
}

void dense_wrapper::thread_select_ln56_695_fu_38756_p3() {
    select_ln56_695_fu_38756_p3 = (!or_ln56_215_fu_33914_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_215_fu_33914_p2.read()[0].to_bool())? select_ln56_607_fu_38052_p3.read(): select_ln56_608_fu_38060_p3.read());
}

void dense_wrapper::thread_select_ln56_696_fu_38764_p3() {
    select_ln56_696_fu_38764_p3 = (!or_ln56_217_fu_33942_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_217_fu_33942_p2.read()[0].to_bool())? select_ln56_609_fu_38068_p3.read(): select_ln56_610_fu_38076_p3.read());
}

void dense_wrapper::thread_select_ln56_697_fu_38772_p3() {
    select_ln56_697_fu_38772_p3 = (!or_ln56_219_fu_33970_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_219_fu_33970_p2.read()[0].to_bool())? select_ln56_611_fu_38084_p3.read(): select_ln56_612_fu_38092_p3.read());
}

void dense_wrapper::thread_select_ln56_698_fu_38780_p3() {
    select_ln56_698_fu_38780_p3 = (!or_ln56_221_fu_33998_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_221_fu_33998_p2.read()[0].to_bool())? select_ln56_613_fu_38100_p3.read(): select_ln56_614_fu_38108_p3.read());
}

void dense_wrapper::thread_select_ln56_699_fu_38788_p3() {
    select_ln56_699_fu_38788_p3 = (!or_ln56_223_fu_34026_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_223_fu_34026_p2.read()[0].to_bool())? select_ln56_615_fu_38116_p3.read(): select_ln56_616_fu_38124_p3.read());
}

void dense_wrapper::thread_select_ln56_69_fu_31854_p3() {
    select_ln56_69_fu_31854_p3 = (!icmp_ln56_252_fu_30054_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_252_fu_30054_p2.read()[0].to_bool())? ap_phi_mux_data_644_V_read658_s_phi_fu_26528_p4.read(): ap_phi_mux_data_643_V_read657_s_phi_fu_26515_p4.read());
}

void dense_wrapper::thread_select_ln56_6_fu_30972_p3() {
    select_ln56_6_fu_30972_p3 = (!icmp_ln56_378_fu_30810_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_378_fu_30810_p2.read()[0].to_bool())? ap_phi_mux_data_770_V_read784_s_phi_fu_28166_p4.read(): ap_phi_mux_data_769_V_read783_s_phi_fu_28153_p4.read());
}

void dense_wrapper::thread_select_ln56_700_fu_38796_p3() {
    select_ln56_700_fu_38796_p3 = (!or_ln56_225_fu_34054_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_225_fu_34054_p2.read()[0].to_bool())? select_ln56_617_fu_38132_p3.read(): select_ln56_618_fu_38140_p3.read());
}

void dense_wrapper::thread_select_ln56_701_fu_38804_p3() {
    select_ln56_701_fu_38804_p3 = (!or_ln56_227_fu_34082_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_227_fu_34082_p2.read()[0].to_bool())? select_ln56_619_fu_38148_p3.read(): select_ln56_620_fu_38156_p3.read());
}

void dense_wrapper::thread_select_ln56_702_fu_38812_p3() {
    select_ln56_702_fu_38812_p3 = (!or_ln56_229_fu_34110_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_229_fu_34110_p2.read()[0].to_bool())? select_ln56_621_fu_38164_p3.read(): select_ln56_622_fu_38172_p3.read());
}

void dense_wrapper::thread_select_ln56_703_fu_38820_p3() {
    select_ln56_703_fu_38820_p3 = (!or_ln56_231_fu_34138_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_231_fu_34138_p2.read()[0].to_bool())? select_ln56_623_fu_38180_p3.read(): select_ln56_624_fu_38188_p3.read());
}

void dense_wrapper::thread_select_ln56_704_fu_38828_p3() {
    select_ln56_704_fu_38828_p3 = (!or_ln56_233_fu_34166_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_233_fu_34166_p2.read()[0].to_bool())? select_ln56_625_fu_38196_p3.read(): select_ln56_626_fu_38204_p3.read());
}

void dense_wrapper::thread_select_ln56_705_fu_38836_p3() {
    select_ln56_705_fu_38836_p3 = (!or_ln56_235_fu_34194_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_235_fu_34194_p2.read()[0].to_bool())? select_ln56_627_fu_38212_p3.read(): select_ln56_628_fu_38220_p3.read());
}

void dense_wrapper::thread_select_ln56_706_fu_38844_p3() {
    select_ln56_706_fu_38844_p3 = (!or_ln56_237_fu_34222_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_237_fu_34222_p2.read()[0].to_bool())? select_ln56_629_fu_38228_p3.read(): select_ln56_630_fu_38236_p3.read());
}

void dense_wrapper::thread_select_ln56_707_fu_38852_p3() {
    select_ln56_707_fu_38852_p3 = (!or_ln56_239_fu_34250_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_239_fu_34250_p2.read()[0].to_bool())? select_ln56_631_fu_38244_p3.read(): select_ln56_632_fu_38252_p3.read());
}

void dense_wrapper::thread_select_ln56_708_fu_38860_p3() {
    select_ln56_708_fu_38860_p3 = (!or_ln56_241_fu_34278_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_241_fu_34278_p2.read()[0].to_bool())? select_ln56_633_fu_38260_p3.read(): select_ln56_634_fu_38268_p3.read());
}

void dense_wrapper::thread_select_ln56_709_fu_38868_p3() {
    select_ln56_709_fu_38868_p3 = (!or_ln56_243_fu_34306_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_243_fu_34306_p2.read()[0].to_bool())? select_ln56_635_fu_38276_p3.read(): select_ln56_636_fu_38284_p3.read());
}

void dense_wrapper::thread_select_ln56_70_fu_31868_p3() {
    select_ln56_70_fu_31868_p3 = (!icmp_ln56_250_fu_30042_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_250_fu_30042_p2.read()[0].to_bool())? ap_phi_mux_data_642_V_read656_s_phi_fu_26502_p4.read(): ap_phi_mux_data_641_V_read655_s_phi_fu_26489_p4.read());
}

void dense_wrapper::thread_select_ln56_710_fu_38876_p3() {
    select_ln56_710_fu_38876_p3 = (!or_ln56_245_fu_34334_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_245_fu_34334_p2.read()[0].to_bool())? select_ln56_637_fu_38292_p3.read(): select_ln56_638_fu_38300_p3.read());
}

void dense_wrapper::thread_select_ln56_711_fu_38884_p3() {
    select_ln56_711_fu_38884_p3 = (!or_ln56_247_fu_34362_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_247_fu_34362_p2.read()[0].to_bool())? select_ln56_639_fu_38308_p3.read(): select_ln56_640_fu_38316_p3.read());
}

void dense_wrapper::thread_select_ln56_712_fu_38892_p3() {
    select_ln56_712_fu_38892_p3 = (!or_ln56_249_fu_34390_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_249_fu_34390_p2.read()[0].to_bool())? select_ln56_641_fu_38324_p3.read(): select_ln56_642_fu_38332_p3.read());
}

void dense_wrapper::thread_select_ln56_713_fu_38900_p3() {
    select_ln56_713_fu_38900_p3 = (!or_ln56_251_fu_34418_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_251_fu_34418_p2.read()[0].to_bool())? select_ln56_643_fu_38340_p3.read(): select_ln56_644_fu_38348_p3.read());
}

void dense_wrapper::thread_select_ln56_714_fu_38908_p3() {
    select_ln56_714_fu_38908_p3 = (!or_ln56_253_fu_34446_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_253_fu_34446_p2.read()[0].to_bool())? select_ln56_645_fu_38356_p3.read(): select_ln56_646_fu_38364_p3.read());
}

void dense_wrapper::thread_select_ln56_715_fu_38916_p3() {
    select_ln56_715_fu_38916_p3 = (!or_ln56_255_fu_34474_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_255_fu_34474_p2.read()[0].to_bool())? select_ln56_647_fu_38372_p3.read(): select_ln56_648_fu_38380_p3.read());
}

void dense_wrapper::thread_select_ln56_716_fu_38924_p3() {
    select_ln56_716_fu_38924_p3 = (!or_ln56_257_fu_34502_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_257_fu_34502_p2.read()[0].to_bool())? select_ln56_649_fu_38388_p3.read(): select_ln56_650_fu_38396_p3.read());
}

void dense_wrapper::thread_select_ln56_717_fu_38932_p3() {
    select_ln56_717_fu_38932_p3 = (!or_ln56_259_fu_34530_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_259_fu_34530_p2.read()[0].to_bool())? select_ln56_651_fu_38404_p3.read(): select_ln56_652_fu_38412_p3.read());
}

void dense_wrapper::thread_select_ln56_718_fu_38940_p3() {
    select_ln56_718_fu_38940_p3 = (!or_ln56_261_fu_34558_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_261_fu_34558_p2.read()[0].to_bool())? select_ln56_653_fu_38420_p3.read(): select_ln56_654_fu_38428_p3.read());
}

void dense_wrapper::thread_select_ln56_719_fu_38948_p3() {
    select_ln56_719_fu_38948_p3 = (!or_ln56_263_fu_34586_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_263_fu_34586_p2.read()[0].to_bool())? select_ln56_655_fu_38436_p3.read(): select_ln56_656_fu_38444_p3.read());
}

void dense_wrapper::thread_select_ln56_71_fu_31882_p3() {
    select_ln56_71_fu_31882_p3 = (!icmp_ln56_248_fu_30030_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_248_fu_30030_p2.read()[0].to_bool())? ap_phi_mux_data_640_V_read654_s_phi_fu_26476_p4.read(): ap_phi_mux_data_639_V_read653_s_phi_fu_26463_p4.read());
}

void dense_wrapper::thread_select_ln56_720_fu_38956_p3() {
    select_ln56_720_fu_38956_p3 = (!or_ln56_265_fu_34614_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_265_fu_34614_p2.read()[0].to_bool())? select_ln56_657_fu_38452_p3.read(): select_ln56_658_fu_38460_p3.read());
}

void dense_wrapper::thread_select_ln56_721_fu_38964_p3() {
    select_ln56_721_fu_38964_p3 = (!or_ln56_267_fu_34642_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_267_fu_34642_p2.read()[0].to_bool())? select_ln56_659_fu_38468_p3.read(): select_ln56_660_fu_38476_p3.read());
}

void dense_wrapper::thread_select_ln56_722_fu_38972_p3() {
    select_ln56_722_fu_38972_p3 = (!or_ln56_269_fu_34670_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_269_fu_34670_p2.read()[0].to_bool())? select_ln56_661_fu_38484_p3.read(): select_ln56_662_fu_38492_p3.read());
}

void dense_wrapper::thread_select_ln56_723_fu_38980_p3() {
    select_ln56_723_fu_38980_p3 = (!or_ln56_271_fu_34698_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_271_fu_34698_p2.read()[0].to_bool())? select_ln56_663_fu_38500_p3.read(): select_ln56_664_fu_38508_p3.read());
}

void dense_wrapper::thread_select_ln56_724_fu_38988_p3() {
    select_ln56_724_fu_38988_p3 = (!or_ln56_273_fu_34726_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_273_fu_34726_p2.read()[0].to_bool())? select_ln56_665_fu_38516_p3.read(): select_ln56_666_fu_38524_p3.read());
}

void dense_wrapper::thread_select_ln56_725_fu_38996_p3() {
    select_ln56_725_fu_38996_p3 = (!or_ln56_275_fu_34754_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_275_fu_34754_p2.read()[0].to_bool())? select_ln56_667_fu_38532_p3.read(): select_ln56_668_fu_38540_p3.read());
}

void dense_wrapper::thread_select_ln56_726_fu_39004_p3() {
    select_ln56_726_fu_39004_p3 = (!or_ln56_277_fu_34782_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_277_fu_34782_p2.read()[0].to_bool())? select_ln56_669_fu_38548_p3.read(): select_ln56_670_fu_38556_p3.read());
}

void dense_wrapper::thread_select_ln56_727_fu_39012_p3() {
    select_ln56_727_fu_39012_p3 = (!or_ln56_279_fu_34810_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_279_fu_34810_p2.read()[0].to_bool())? select_ln56_671_fu_38564_p3.read(): select_ln56_672_fu_38572_p3.read());
}

void dense_wrapper::thread_select_ln56_728_fu_39020_p3() {
    select_ln56_728_fu_39020_p3 = (!or_ln56_281_fu_34838_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_281_fu_34838_p2.read()[0].to_bool())? select_ln56_673_fu_38580_p3.read(): select_ln56_674_fu_38588_p3.read());
}

void dense_wrapper::thread_select_ln56_729_fu_39028_p3() {
    select_ln56_729_fu_39028_p3 = (!or_ln56_283_fu_34866_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_283_fu_34866_p2.read()[0].to_bool())? select_ln56_675_fu_38596_p3.read(): select_ln56_676_fu_38604_p3.read());
}

void dense_wrapper::thread_select_ln56_72_fu_31896_p3() {
    select_ln56_72_fu_31896_p3 = (!icmp_ln56_246_fu_30018_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_246_fu_30018_p2.read()[0].to_bool())? ap_phi_mux_data_638_V_read652_s_phi_fu_26450_p4.read(): ap_phi_mux_data_637_V_read651_s_phi_fu_26437_p4.read());
}

void dense_wrapper::thread_select_ln56_730_fu_39036_p3() {
    select_ln56_730_fu_39036_p3 = (!or_ln56_285_fu_34894_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_285_fu_34894_p2.read()[0].to_bool())? select_ln56_677_fu_38612_p3.read(): select_ln56_678_fu_38620_p3.read());
}

void dense_wrapper::thread_select_ln56_731_fu_39044_p3() {
    select_ln56_731_fu_39044_p3 = (!or_ln56_287_fu_34922_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_287_fu_34922_p2.read()[0].to_bool())? select_ln56_679_fu_38628_p3.read(): select_ln56_680_fu_38636_p3.read());
}

void dense_wrapper::thread_select_ln56_732_fu_39052_p3() {
    select_ln56_732_fu_39052_p3 = (!or_ln56_289_fu_34950_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_289_fu_34950_p2.read()[0].to_bool())? select_ln56_681_fu_38644_p3.read(): select_ln56_682_fu_38652_p3.read());
}

void dense_wrapper::thread_select_ln56_733_fu_39060_p3() {
    select_ln56_733_fu_39060_p3 = (!or_ln56_291_fu_34978_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_291_fu_34978_p2.read()[0].to_bool())? select_ln56_683_fu_38660_p3.read(): select_ln56_684_fu_38668_p3.read());
}

void dense_wrapper::thread_select_ln56_734_fu_39068_p3() {
    select_ln56_734_fu_39068_p3 = (!or_ln56_292_fu_35000_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_292_fu_35000_p2.read()[0].to_bool())? select_ln56_685_fu_38676_p3.read(): select_ln56_686_fu_38684_p3.read());
}

void dense_wrapper::thread_select_ln56_735_fu_39076_p3() {
    select_ln56_735_fu_39076_p3 = (!or_ln56_294_fu_35028_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_294_fu_35028_p2.read()[0].to_bool())? select_ln56_687_fu_38692_p3.read(): select_ln56_688_fu_38700_p3.read());
}

void dense_wrapper::thread_select_ln56_736_fu_39084_p3() {
    select_ln56_736_fu_39084_p3 = (!or_ln56_296_fu_35056_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_296_fu_35056_p2.read()[0].to_bool())? select_ln56_689_fu_38708_p3.read(): select_ln56_690_fu_38716_p3.read());
}

void dense_wrapper::thread_select_ln56_737_fu_39092_p3() {
    select_ln56_737_fu_39092_p3 = (!or_ln56_298_fu_35084_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_298_fu_35084_p2.read()[0].to_bool())? select_ln56_691_fu_38724_p3.read(): select_ln56_692_fu_38732_p3.read());
}

void dense_wrapper::thread_select_ln56_738_fu_39100_p3() {
    select_ln56_738_fu_39100_p3 = (!or_ln56_300_fu_35112_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_300_fu_35112_p2.read()[0].to_bool())? select_ln56_693_fu_38740_p3.read(): select_ln56_694_fu_38748_p3.read());
}

void dense_wrapper::thread_select_ln56_739_fu_39108_p3() {
    select_ln56_739_fu_39108_p3 = (!or_ln56_302_fu_35140_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_302_fu_35140_p2.read()[0].to_bool())? select_ln56_695_fu_38756_p3.read(): select_ln56_696_fu_38764_p3.read());
}

void dense_wrapper::thread_select_ln56_73_fu_31910_p3() {
    select_ln56_73_fu_31910_p3 = (!icmp_ln56_244_fu_30006_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_244_fu_30006_p2.read()[0].to_bool())? ap_phi_mux_data_636_V_read650_s_phi_fu_26424_p4.read(): ap_phi_mux_data_635_V_read649_s_phi_fu_26411_p4.read());
}

void dense_wrapper::thread_select_ln56_740_fu_39116_p3() {
    select_ln56_740_fu_39116_p3 = (!or_ln56_304_fu_35168_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_304_fu_35168_p2.read()[0].to_bool())? select_ln56_697_fu_38772_p3.read(): select_ln56_698_fu_38780_p3.read());
}

void dense_wrapper::thread_select_ln56_741_fu_39124_p3() {
    select_ln56_741_fu_39124_p3 = (!or_ln56_306_fu_35196_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_306_fu_35196_p2.read()[0].to_bool())? select_ln56_699_fu_38788_p3.read(): select_ln56_700_fu_38796_p3.read());
}

void dense_wrapper::thread_select_ln56_742_fu_39132_p3() {
    select_ln56_742_fu_39132_p3 = (!or_ln56_308_fu_35224_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_308_fu_35224_p2.read()[0].to_bool())? select_ln56_701_fu_38804_p3.read(): select_ln56_702_fu_38812_p3.read());
}

void dense_wrapper::thread_select_ln56_743_fu_39140_p3() {
    select_ln56_743_fu_39140_p3 = (!or_ln56_310_fu_35252_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_310_fu_35252_p2.read()[0].to_bool())? select_ln56_703_fu_38820_p3.read(): select_ln56_704_fu_38828_p3.read());
}

void dense_wrapper::thread_select_ln56_744_fu_39148_p3() {
    select_ln56_744_fu_39148_p3 = (!or_ln56_312_fu_35280_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_312_fu_35280_p2.read()[0].to_bool())? select_ln56_705_fu_38836_p3.read(): select_ln56_706_fu_38844_p3.read());
}

void dense_wrapper::thread_select_ln56_745_fu_39156_p3() {
    select_ln56_745_fu_39156_p3 = (!or_ln56_314_fu_35308_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_314_fu_35308_p2.read()[0].to_bool())? select_ln56_707_fu_38852_p3.read(): select_ln56_708_fu_38860_p3.read());
}

void dense_wrapper::thread_select_ln56_746_fu_39164_p3() {
    select_ln56_746_fu_39164_p3 = (!or_ln56_316_fu_35336_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_316_fu_35336_p2.read()[0].to_bool())? select_ln56_709_fu_38868_p3.read(): select_ln56_710_fu_38876_p3.read());
}

void dense_wrapper::thread_select_ln56_747_fu_39172_p3() {
    select_ln56_747_fu_39172_p3 = (!or_ln56_318_fu_35364_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_318_fu_35364_p2.read()[0].to_bool())? select_ln56_711_fu_38884_p3.read(): select_ln56_712_fu_38892_p3.read());
}

void dense_wrapper::thread_select_ln56_748_fu_39180_p3() {
    select_ln56_748_fu_39180_p3 = (!or_ln56_320_fu_35392_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_320_fu_35392_p2.read()[0].to_bool())? select_ln56_713_fu_38900_p3.read(): select_ln56_714_fu_38908_p3.read());
}

void dense_wrapper::thread_select_ln56_749_fu_39188_p3() {
    select_ln56_749_fu_39188_p3 = (!or_ln56_322_fu_35420_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_322_fu_35420_p2.read()[0].to_bool())? select_ln56_715_fu_38916_p3.read(): select_ln56_716_fu_38924_p3.read());
}

void dense_wrapper::thread_select_ln56_74_fu_31924_p3() {
    select_ln56_74_fu_31924_p3 = (!icmp_ln56_242_fu_29994_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_242_fu_29994_p2.read()[0].to_bool())? ap_phi_mux_data_634_V_read648_s_phi_fu_26398_p4.read(): ap_phi_mux_data_633_V_read647_s_phi_fu_26385_p4.read());
}

void dense_wrapper::thread_select_ln56_750_fu_39196_p3() {
    select_ln56_750_fu_39196_p3 = (!or_ln56_324_fu_35448_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_324_fu_35448_p2.read()[0].to_bool())? select_ln56_717_fu_38932_p3.read(): select_ln56_718_fu_38940_p3.read());
}

void dense_wrapper::thread_select_ln56_751_fu_39204_p3() {
    select_ln56_751_fu_39204_p3 = (!or_ln56_326_fu_35476_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_326_fu_35476_p2.read()[0].to_bool())? select_ln56_719_fu_38948_p3.read(): select_ln56_720_fu_38956_p3.read());
}

void dense_wrapper::thread_select_ln56_752_fu_39212_p3() {
    select_ln56_752_fu_39212_p3 = (!or_ln56_328_fu_35504_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_328_fu_35504_p2.read()[0].to_bool())? select_ln56_721_fu_38964_p3.read(): select_ln56_722_fu_38972_p3.read());
}

void dense_wrapper::thread_select_ln56_753_fu_39220_p3() {
    select_ln56_753_fu_39220_p3 = (!or_ln56_330_fu_35532_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_330_fu_35532_p2.read()[0].to_bool())? select_ln56_723_fu_38980_p3.read(): select_ln56_724_fu_38988_p3.read());
}

void dense_wrapper::thread_select_ln56_754_fu_39228_p3() {
    select_ln56_754_fu_39228_p3 = (!or_ln56_332_fu_35560_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_332_fu_35560_p2.read()[0].to_bool())? select_ln56_725_fu_38996_p3.read(): select_ln56_726_fu_39004_p3.read());
}

void dense_wrapper::thread_select_ln56_755_fu_39236_p3() {
    select_ln56_755_fu_39236_p3 = (!or_ln56_334_fu_35588_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_334_fu_35588_p2.read()[0].to_bool())? select_ln56_727_fu_39012_p3.read(): select_ln56_728_fu_39020_p3.read());
}

void dense_wrapper::thread_select_ln56_756_fu_39244_p3() {
    select_ln56_756_fu_39244_p3 = (!or_ln56_336_fu_35616_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_336_fu_35616_p2.read()[0].to_bool())? select_ln56_729_fu_39028_p3.read(): select_ln56_730_fu_39036_p3.read());
}

void dense_wrapper::thread_select_ln56_757_fu_39252_p3() {
    select_ln56_757_fu_39252_p3 = (!or_ln56_338_fu_35644_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_338_fu_35644_p2.read()[0].to_bool())? select_ln56_731_fu_39044_p3.read(): select_ln56_732_fu_39052_p3.read());
}

void dense_wrapper::thread_select_ln56_758_fu_39260_p3() {
    select_ln56_758_fu_39260_p3 = (!or_ln56_340_fu_35680_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_340_fu_35680_p2.read()[0].to_bool())? select_ln56_734_fu_39068_p3.read(): select_ln56_735_fu_39076_p3.read());
}

void dense_wrapper::thread_select_ln56_759_fu_39268_p3() {
    select_ln56_759_fu_39268_p3 = (!or_ln56_342_fu_35708_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_342_fu_35708_p2.read()[0].to_bool())? select_ln56_736_fu_39084_p3.read(): select_ln56_737_fu_39092_p3.read());
}

void dense_wrapper::thread_select_ln56_75_fu_31938_p3() {
    select_ln56_75_fu_31938_p3 = (!icmp_ln56_240_fu_29982_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_240_fu_29982_p2.read()[0].to_bool())? ap_phi_mux_data_632_V_read646_s_phi_fu_26372_p4.read(): ap_phi_mux_data_631_V_read645_s_phi_fu_26359_p4.read());
}

void dense_wrapper::thread_select_ln56_760_fu_39276_p3() {
    select_ln56_760_fu_39276_p3 = (!or_ln56_344_fu_35736_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_344_fu_35736_p2.read()[0].to_bool())? select_ln56_738_fu_39100_p3.read(): select_ln56_739_fu_39108_p3.read());
}

void dense_wrapper::thread_select_ln56_761_fu_39284_p3() {
    select_ln56_761_fu_39284_p3 = (!or_ln56_346_fu_35764_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_346_fu_35764_p2.read()[0].to_bool())? select_ln56_740_fu_39116_p3.read(): select_ln56_741_fu_39124_p3.read());
}

void dense_wrapper::thread_select_ln56_762_fu_39292_p3() {
    select_ln56_762_fu_39292_p3 = (!or_ln56_348_fu_35792_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_348_fu_35792_p2.read()[0].to_bool())? select_ln56_742_fu_39132_p3.read(): select_ln56_743_fu_39140_p3.read());
}

void dense_wrapper::thread_select_ln56_763_fu_39300_p3() {
    select_ln56_763_fu_39300_p3 = (!or_ln56_350_fu_35820_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_350_fu_35820_p2.read()[0].to_bool())? select_ln56_744_fu_39148_p3.read(): select_ln56_745_fu_39156_p3.read());
}

void dense_wrapper::thread_select_ln56_764_fu_39308_p3() {
    select_ln56_764_fu_39308_p3 = (!or_ln56_352_fu_35848_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_352_fu_35848_p2.read()[0].to_bool())? select_ln56_746_fu_39164_p3.read(): select_ln56_747_fu_39172_p3.read());
}

void dense_wrapper::thread_select_ln56_765_fu_39316_p3() {
    select_ln56_765_fu_39316_p3 = (!or_ln56_354_fu_35876_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_354_fu_35876_p2.read()[0].to_bool())? select_ln56_748_fu_39180_p3.read(): select_ln56_749_fu_39188_p3.read());
}

void dense_wrapper::thread_select_ln56_766_fu_39324_p3() {
    select_ln56_766_fu_39324_p3 = (!or_ln56_356_fu_35904_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_356_fu_35904_p2.read()[0].to_bool())? select_ln56_750_fu_39196_p3.read(): select_ln56_751_fu_39204_p3.read());
}

void dense_wrapper::thread_select_ln56_767_fu_39332_p3() {
    select_ln56_767_fu_39332_p3 = (!or_ln56_358_fu_35932_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_358_fu_35932_p2.read()[0].to_bool())? select_ln56_752_fu_39212_p3.read(): select_ln56_753_fu_39220_p3.read());
}

void dense_wrapper::thread_select_ln56_768_fu_39340_p3() {
    select_ln56_768_fu_39340_p3 = (!or_ln56_360_fu_35960_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_360_fu_35960_p2.read()[0].to_bool())? select_ln56_754_fu_39228_p3.read(): select_ln56_755_fu_39236_p3.read());
}

void dense_wrapper::thread_select_ln56_769_fu_39348_p3() {
    select_ln56_769_fu_39348_p3 = (!or_ln56_362_fu_35988_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_362_fu_35988_p2.read()[0].to_bool())? select_ln56_756_fu_39244_p3.read(): select_ln56_757_fu_39252_p3.read());
}

void dense_wrapper::thread_select_ln56_76_fu_31952_p3() {
    select_ln56_76_fu_31952_p3 = (!icmp_ln56_238_fu_29970_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_238_fu_29970_p2.read()[0].to_bool())? ap_phi_mux_data_630_V_read644_s_phi_fu_26346_p4.read(): ap_phi_mux_data_629_V_read643_s_phi_fu_26333_p4.read());
}

void dense_wrapper::thread_select_ln56_770_fu_39356_p3() {
    select_ln56_770_fu_39356_p3 = (!or_ln56_364_fu_36016_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_364_fu_36016_p2.read()[0].to_bool())? select_ln56_758_fu_39260_p3.read(): select_ln56_759_fu_39268_p3.read());
}

void dense_wrapper::thread_select_ln56_771_fu_39364_p3() {
    select_ln56_771_fu_39364_p3 = (!or_ln56_366_fu_36044_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_366_fu_36044_p2.read()[0].to_bool())? select_ln56_760_fu_39276_p3.read(): select_ln56_761_fu_39284_p3.read());
}

void dense_wrapper::thread_select_ln56_772_fu_39372_p3() {
    select_ln56_772_fu_39372_p3 = (!or_ln56_368_fu_36072_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_368_fu_36072_p2.read()[0].to_bool())? select_ln56_762_fu_39292_p3.read(): select_ln56_763_fu_39300_p3.read());
}

void dense_wrapper::thread_select_ln56_773_fu_39380_p3() {
    select_ln56_773_fu_39380_p3 = (!or_ln56_370_fu_36100_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_370_fu_36100_p2.read()[0].to_bool())? select_ln56_764_fu_39308_p3.read(): select_ln56_765_fu_39316_p3.read());
}

void dense_wrapper::thread_select_ln56_774_fu_39388_p3() {
    select_ln56_774_fu_39388_p3 = (!or_ln56_372_fu_36128_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_372_fu_36128_p2.read()[0].to_bool())? select_ln56_766_fu_39324_p3.read(): select_ln56_767_fu_39332_p3.read());
}

void dense_wrapper::thread_select_ln56_775_fu_39396_p3() {
    select_ln56_775_fu_39396_p3 = (!or_ln56_374_fu_36156_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_374_fu_36156_p2.read()[0].to_bool())? select_ln56_768_fu_39340_p3.read(): select_ln56_769_fu_39348_p3.read());
}

void dense_wrapper::thread_select_ln56_776_fu_39404_p3() {
    select_ln56_776_fu_39404_p3 = (!or_ln56_376_fu_36184_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_376_fu_36184_p2.read()[0].to_bool())? select_ln56_770_fu_39356_p3.read(): select_ln56_771_fu_39364_p3.read());
}

void dense_wrapper::thread_select_ln56_777_fu_39412_p3() {
    select_ln56_777_fu_39412_p3 = (!or_ln56_378_fu_36212_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_378_fu_36212_p2.read()[0].to_bool())? select_ln56_772_fu_39372_p3.read(): select_ln56_773_fu_39380_p3.read());
}

void dense_wrapper::thread_select_ln56_778_fu_39420_p3() {
    select_ln56_778_fu_39420_p3 = (!or_ln56_380_fu_36240_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_380_fu_36240_p2.read()[0].to_bool())? select_ln56_774_fu_39388_p3.read(): select_ln56_775_fu_39396_p3.read());
}

void dense_wrapper::thread_select_ln56_779_fu_39428_p3() {
    select_ln56_779_fu_39428_p3 = (!or_ln56_382_fu_36268_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_382_fu_36268_p2.read()[0].to_bool())? select_ln56_776_fu_39404_p3.read(): select_ln56_777_fu_39412_p3.read());
}

void dense_wrapper::thread_select_ln56_77_fu_31966_p3() {
    select_ln56_77_fu_31966_p3 = (!icmp_ln56_236_fu_29958_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_236_fu_29958_p2.read()[0].to_bool())? ap_phi_mux_data_628_V_read642_s_phi_fu_26320_p4.read(): ap_phi_mux_data_627_V_read641_s_phi_fu_26307_p4.read());
}

void dense_wrapper::thread_select_ln56_780_fu_39436_p3() {
    select_ln56_780_fu_39436_p3 = (!or_ln56_384_fu_36296_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_384_fu_36296_p2.read()[0].to_bool())? select_ln56_778_fu_39420_p3.read(): select_ln56_733_fu_39060_p3.read());
}

void dense_wrapper::thread_select_ln56_781_fu_39444_p3() {
    select_ln56_781_fu_39444_p3 = (!or_ln56_385_fu_36310_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_385_fu_36310_p2.read()[0].to_bool())? select_ln56_779_fu_39428_p3.read(): select_ln56_780_fu_39436_p3.read());
}

void dense_wrapper::thread_select_ln56_782_fu_28426_p3() {
    select_ln56_782_fu_28426_p3 = (!icmp_ln56_1_fu_28420_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_1_fu_28420_p2.read()[0].to_bool())? ap_phi_mux_data_1_V_read15_phi_phi_fu_18169_p4.read(): select_ln56_586_fu_28412_p3.read());
}

void dense_wrapper::thread_select_ln56_783_fu_28440_p3() {
    select_ln56_783_fu_28440_p3 = (!icmp_ln56_2_fu_28434_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_28434_p2.read()[0].to_bool())? ap_phi_mux_data_2_V_read16_phi_phi_fu_18182_p4.read(): select_ln56_782_fu_28426_p3.read());
}

void dense_wrapper::thread_select_ln56_784_fu_28454_p3() {
    select_ln56_784_fu_28454_p3 = (!icmp_ln56_3_fu_28448_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_3_fu_28448_p2.read()[0].to_bool())? ap_phi_mux_data_3_V_read17_phi_phi_fu_18195_p4.read(): select_ln56_783_fu_28440_p3.read());
}

void dense_wrapper::thread_select_ln56_785_fu_28468_p3() {
    select_ln56_785_fu_28468_p3 = (!icmp_ln56_4_fu_28462_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_28462_p2.read()[0].to_bool())? ap_phi_mux_data_4_V_read18_phi_phi_fu_18208_p4.read(): select_ln56_784_fu_28454_p3.read());
}

void dense_wrapper::thread_select_ln56_786_fu_28482_p3() {
    select_ln56_786_fu_28482_p3 = (!icmp_ln56_5_fu_28476_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_5_fu_28476_p2.read()[0].to_bool())? ap_phi_mux_data_5_V_read19_phi_phi_fu_18221_p4.read(): select_ln56_785_fu_28468_p3.read());
}

void dense_wrapper::thread_select_ln56_787_fu_28496_p3() {
    select_ln56_787_fu_28496_p3 = (!icmp_ln56_6_fu_28490_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_28490_p2.read()[0].to_bool())? ap_phi_mux_data_6_V_read20_phi_phi_fu_18234_p4.read(): select_ln56_786_fu_28482_p3.read());
}

void dense_wrapper::thread_select_ln56_788_fu_28510_p3() {
    select_ln56_788_fu_28510_p3 = (!icmp_ln56_7_fu_28504_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_7_fu_28504_p2.read()[0].to_bool())? ap_phi_mux_data_7_V_read21_phi_phi_fu_18247_p4.read(): select_ln56_787_fu_28496_p3.read());
}

void dense_wrapper::thread_select_ln56_789_fu_28524_p3() {
    select_ln56_789_fu_28524_p3 = (!icmp_ln56_8_fu_28518_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_28518_p2.read()[0].to_bool())? ap_phi_mux_data_8_V_read22_phi_phi_fu_18260_p4.read(): select_ln56_788_fu_28510_p3.read());
}

void dense_wrapper::thread_select_ln56_78_fu_31980_p3() {
    select_ln56_78_fu_31980_p3 = (!icmp_ln56_234_fu_29946_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_234_fu_29946_p2.read()[0].to_bool())? ap_phi_mux_data_626_V_read640_s_phi_fu_26294_p4.read(): ap_phi_mux_data_625_V_read639_s_phi_fu_26281_p4.read());
}

void dense_wrapper::thread_select_ln56_790_fu_28538_p3() {
    select_ln56_790_fu_28538_p3 = (!icmp_ln56_9_fu_28532_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_9_fu_28532_p2.read()[0].to_bool())? ap_phi_mux_data_9_V_read23_phi_phi_fu_18273_p4.read(): select_ln56_789_fu_28524_p3.read());
}

void dense_wrapper::thread_select_ln56_791_fu_28552_p3() {
    select_ln56_791_fu_28552_p3 = (!icmp_ln56_10_fu_28546_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_28546_p2.read()[0].to_bool())? ap_phi_mux_data_10_V_read24_ph_phi_fu_18286_p4.read(): select_ln56_790_fu_28538_p3.read());
}

void dense_wrapper::thread_select_ln56_792_fu_28566_p3() {
    select_ln56_792_fu_28566_p3 = (!icmp_ln56_11_fu_28560_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_11_fu_28560_p2.read()[0].to_bool())? ap_phi_mux_data_11_V_read25_ph_phi_fu_18299_p4.read(): select_ln56_791_fu_28552_p3.read());
}

void dense_wrapper::thread_select_ln56_793_fu_28580_p3() {
    select_ln56_793_fu_28580_p3 = (!icmp_ln56_12_fu_28574_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_28574_p2.read()[0].to_bool())? ap_phi_mux_data_12_V_read26_ph_phi_fu_18312_p4.read(): select_ln56_792_fu_28566_p3.read());
}

void dense_wrapper::thread_select_ln56_794_fu_28594_p3() {
    select_ln56_794_fu_28594_p3 = (!icmp_ln56_13_fu_28588_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_13_fu_28588_p2.read()[0].to_bool())? ap_phi_mux_data_13_V_read27_ph_phi_fu_18325_p4.read(): select_ln56_793_fu_28580_p3.read());
}

void dense_wrapper::thread_select_ln56_795_fu_28608_p3() {
    select_ln56_795_fu_28608_p3 = (!icmp_ln56_14_fu_28602_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_28602_p2.read()[0].to_bool())? ap_phi_mux_data_14_V_read28_ph_phi_fu_18338_p4.read(): select_ln56_794_fu_28594_p3.read());
}

void dense_wrapper::thread_select_ln56_796_fu_28622_p3() {
    select_ln56_796_fu_28622_p3 = (!icmp_ln56_15_fu_28616_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_15_fu_28616_p2.read()[0].to_bool())? ap_phi_mux_data_15_V_read29_ph_phi_fu_18351_p4.read(): select_ln56_795_fu_28608_p3.read());
}

void dense_wrapper::thread_select_ln56_797_fu_28636_p3() {
    select_ln56_797_fu_28636_p3 = (!icmp_ln56_16_fu_28630_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_16_fu_28630_p2.read()[0].to_bool())? ap_phi_mux_data_16_V_read30_ph_phi_fu_18364_p4.read(): select_ln56_796_fu_28622_p3.read());
}

void dense_wrapper::thread_select_ln56_798_fu_39458_p3() {
    select_ln56_798_fu_39458_p3 = (!icmp_ln56_17_reg_42562.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_17_reg_42562.read()[0].to_bool())? data_17_V_read31_ph_reg_18373.read(): select_ln56_797_reg_42557.read());
}

void dense_wrapper::thread_select_ln56_799_fu_39464_p3() {
    select_ln56_799_fu_39464_p3 = (!icmp_ln56_18_reg_42567.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_18_reg_42567.read()[0].to_bool())? data_18_V_read32_ph_reg_18386.read(): select_ln56_798_fu_39458_p3.read());
}

void dense_wrapper::thread_select_ln56_79_fu_31994_p3() {
    select_ln56_79_fu_31994_p3 = (!icmp_ln56_232_fu_29934_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_232_fu_29934_p2.read()[0].to_bool())? ap_phi_mux_data_624_V_read638_s_phi_fu_26268_p4.read(): ap_phi_mux_data_623_V_read637_s_phi_fu_26255_p4.read());
}

void dense_wrapper::thread_select_ln56_7_fu_30986_p3() {
    select_ln56_7_fu_30986_p3 = (!icmp_ln56_376_fu_30798_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_376_fu_30798_p2.read()[0].to_bool())? ap_phi_mux_data_768_V_read782_s_phi_fu_28140_p4.read(): ap_phi_mux_data_767_V_read781_s_phi_fu_28127_p4.read());
}

void dense_wrapper::thread_select_ln56_800_fu_39471_p3() {
    select_ln56_800_fu_39471_p3 = (!icmp_ln56_19_reg_42572.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_19_reg_42572.read()[0].to_bool())? data_19_V_read33_ph_reg_18399.read(): select_ln56_799_fu_39464_p3.read());
}

void dense_wrapper::thread_select_ln56_801_fu_39478_p3() {
    select_ln56_801_fu_39478_p3 = (!icmp_ln56_20_reg_42577.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_20_reg_42577.read()[0].to_bool())? data_20_V_read34_ph_reg_18412.read(): select_ln56_800_fu_39471_p3.read());
}

void dense_wrapper::thread_select_ln56_802_fu_39485_p3() {
    select_ln56_802_fu_39485_p3 = (!icmp_ln56_21_reg_42582.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_21_reg_42582.read()[0].to_bool())? data_21_V_read35_ph_reg_18425.read(): select_ln56_801_fu_39478_p3.read());
}

void dense_wrapper::thread_select_ln56_803_fu_39492_p3() {
    select_ln56_803_fu_39492_p3 = (!icmp_ln56_22_reg_42587.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_22_reg_42587.read()[0].to_bool())? data_22_V_read36_ph_reg_18438.read(): select_ln56_802_fu_39485_p3.read());
}

void dense_wrapper::thread_select_ln56_804_fu_39499_p3() {
    select_ln56_804_fu_39499_p3 = (!icmp_ln56_23_reg_42592.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_23_reg_42592.read()[0].to_bool())? data_23_V_read37_ph_reg_18451.read(): select_ln56_803_fu_39492_p3.read());
}

void dense_wrapper::thread_select_ln56_805_fu_39506_p3() {
    select_ln56_805_fu_39506_p3 = (!icmp_ln56_24_reg_42597.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_24_reg_42597.read()[0].to_bool())? data_24_V_read38_ph_reg_18464.read(): select_ln56_804_fu_39499_p3.read());
}

void dense_wrapper::thread_select_ln56_806_fu_39513_p3() {
    select_ln56_806_fu_39513_p3 = (!icmp_ln56_25_reg_42602.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_25_reg_42602.read()[0].to_bool())? data_25_V_read39_ph_reg_18477.read(): select_ln56_805_fu_39506_p3.read());
}

void dense_wrapper::thread_select_ln56_807_fu_39520_p3() {
    select_ln56_807_fu_39520_p3 = (!icmp_ln56_26_reg_42607.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_26_reg_42607.read()[0].to_bool())? data_26_V_read40_ph_reg_18490.read(): select_ln56_806_fu_39513_p3.read());
}

void dense_wrapper::thread_select_ln56_808_fu_39527_p3() {
    select_ln56_808_fu_39527_p3 = (!icmp_ln56_27_reg_42612.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_27_reg_42612.read()[0].to_bool())? data_27_V_read41_ph_reg_18503.read(): select_ln56_807_fu_39520_p3.read());
}

void dense_wrapper::thread_select_ln56_809_fu_39534_p3() {
    select_ln56_809_fu_39534_p3 = (!icmp_ln56_28_reg_42617.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_28_reg_42617.read()[0].to_bool())? data_28_V_read42_ph_reg_18516.read(): select_ln56_808_fu_39527_p3.read());
}

void dense_wrapper::thread_select_ln56_80_fu_32008_p3() {
    select_ln56_80_fu_32008_p3 = (!icmp_ln56_230_fu_29922_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_230_fu_29922_p2.read()[0].to_bool())? ap_phi_mux_data_622_V_read636_s_phi_fu_26242_p4.read(): ap_phi_mux_data_621_V_read635_s_phi_fu_26229_p4.read());
}

void dense_wrapper::thread_select_ln56_810_fu_39541_p3() {
    select_ln56_810_fu_39541_p3 = (!icmp_ln56_29_reg_42622.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_29_reg_42622.read()[0].to_bool())? data_29_V_read43_ph_reg_18529.read(): select_ln56_809_fu_39534_p3.read());
}

void dense_wrapper::thread_select_ln56_811_fu_39548_p3() {
    select_ln56_811_fu_39548_p3 = (!icmp_ln56_30_reg_42627.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_30_reg_42627.read()[0].to_bool())? data_30_V_read44_ph_reg_18542.read(): select_ln56_810_fu_39541_p3.read());
}

void dense_wrapper::thread_select_ln56_812_fu_39555_p3() {
    select_ln56_812_fu_39555_p3 = (!icmp_ln56_31_reg_42632.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_31_reg_42632.read()[0].to_bool())? data_31_V_read45_ph_reg_18555.read(): select_ln56_811_fu_39548_p3.read());
}

void dense_wrapper::thread_select_ln56_813_fu_39562_p3() {
    select_ln56_813_fu_39562_p3 = (!icmp_ln56_32_reg_42637.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_32_reg_42637.read()[0].to_bool())? data_32_V_read46_ph_reg_18568.read(): select_ln56_812_fu_39555_p3.read());
}

void dense_wrapper::thread_select_ln56_814_fu_39569_p3() {
    select_ln56_814_fu_39569_p3 = (!icmp_ln56_33_reg_42642.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_33_reg_42642.read()[0].to_bool())? data_33_V_read47_ph_reg_18581.read(): select_ln56_813_fu_39562_p3.read());
}

void dense_wrapper::thread_select_ln56_815_fu_39576_p3() {
    select_ln56_815_fu_39576_p3 = (!icmp_ln56_34_reg_42647.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_34_reg_42647.read()[0].to_bool())? data_34_V_read48_ph_reg_18594.read(): select_ln56_814_fu_39569_p3.read());
}

void dense_wrapper::thread_select_ln56_816_fu_39583_p3() {
    select_ln56_816_fu_39583_p3 = (!icmp_ln56_35_reg_42652.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_35_reg_42652.read()[0].to_bool())? data_35_V_read49_ph_reg_18607.read(): select_ln56_815_fu_39576_p3.read());
}

void dense_wrapper::thread_select_ln56_817_fu_39590_p3() {
    select_ln56_817_fu_39590_p3 = (!icmp_ln56_36_reg_42657.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_36_reg_42657.read()[0].to_bool())? data_36_V_read50_ph_reg_18620.read(): select_ln56_816_fu_39583_p3.read());
}

void dense_wrapper::thread_select_ln56_818_fu_39597_p3() {
    select_ln56_818_fu_39597_p3 = (!icmp_ln56_37_reg_42662.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_37_reg_42662.read()[0].to_bool())? data_37_V_read51_ph_reg_18633.read(): select_ln56_817_fu_39590_p3.read());
}

void dense_wrapper::thread_select_ln56_819_fu_39604_p3() {
    select_ln56_819_fu_39604_p3 = (!icmp_ln56_38_reg_42667.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_38_reg_42667.read()[0].to_bool())? data_38_V_read52_ph_reg_18646.read(): select_ln56_818_fu_39597_p3.read());
}

void dense_wrapper::thread_select_ln56_81_fu_32022_p3() {
    select_ln56_81_fu_32022_p3 = (!icmp_ln56_228_fu_29910_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_228_fu_29910_p2.read()[0].to_bool())? ap_phi_mux_data_620_V_read634_s_phi_fu_26216_p4.read(): ap_phi_mux_data_619_V_read633_s_phi_fu_26203_p4.read());
}

void dense_wrapper::thread_select_ln56_820_fu_39611_p3() {
    select_ln56_820_fu_39611_p3 = (!icmp_ln56_39_reg_42672.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_39_reg_42672.read()[0].to_bool())? data_39_V_read53_ph_reg_18659.read(): select_ln56_819_fu_39604_p3.read());
}

void dense_wrapper::thread_select_ln56_821_fu_39618_p3() {
    select_ln56_821_fu_39618_p3 = (!icmp_ln56_40_reg_42677.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_40_reg_42677.read()[0].to_bool())? data_40_V_read54_ph_reg_18672.read(): select_ln56_820_fu_39611_p3.read());
}

void dense_wrapper::thread_select_ln56_822_fu_39625_p3() {
    select_ln56_822_fu_39625_p3 = (!icmp_ln56_41_reg_42682_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_41_reg_42682_pp0_iter1_reg.read()[0].to_bool())? data_41_V_read55_ph_reg_18685_pp0_iter1_reg.read(): select_ln56_821_reg_44446.read());
}

void dense_wrapper::thread_select_ln56_823_fu_39631_p3() {
    select_ln56_823_fu_39631_p3 = (!icmp_ln56_42_reg_42687_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_42_reg_42687_pp0_iter1_reg.read()[0].to_bool())? data_42_V_read56_ph_reg_18698_pp0_iter1_reg.read(): select_ln56_822_fu_39625_p3.read());
}

void dense_wrapper::thread_select_ln56_824_fu_39638_p3() {
    select_ln56_824_fu_39638_p3 = (!icmp_ln56_43_reg_42692_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_43_reg_42692_pp0_iter1_reg.read()[0].to_bool())? data_43_V_read57_ph_reg_18711_pp0_iter1_reg.read(): select_ln56_823_fu_39631_p3.read());
}

void dense_wrapper::thread_select_ln56_825_fu_39645_p3() {
    select_ln56_825_fu_39645_p3 = (!icmp_ln56_44_reg_42697_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_44_reg_42697_pp0_iter1_reg.read()[0].to_bool())? data_44_V_read58_ph_reg_18724_pp0_iter1_reg.read(): select_ln56_824_fu_39638_p3.read());
}

void dense_wrapper::thread_select_ln56_826_fu_39652_p3() {
    select_ln56_826_fu_39652_p3 = (!icmp_ln56_45_reg_42702_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_45_reg_42702_pp0_iter1_reg.read()[0].to_bool())? data_45_V_read59_ph_reg_18737_pp0_iter1_reg.read(): select_ln56_825_fu_39645_p3.read());
}

void dense_wrapper::thread_select_ln56_827_fu_39659_p3() {
    select_ln56_827_fu_39659_p3 = (!icmp_ln56_46_reg_42707_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_46_reg_42707_pp0_iter1_reg.read()[0].to_bool())? data_46_V_read60_ph_reg_18750_pp0_iter1_reg.read(): select_ln56_826_fu_39652_p3.read());
}

void dense_wrapper::thread_select_ln56_828_fu_39666_p3() {
    select_ln56_828_fu_39666_p3 = (!icmp_ln56_47_reg_42712_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_47_reg_42712_pp0_iter1_reg.read()[0].to_bool())? data_47_V_read61_ph_reg_18763_pp0_iter1_reg.read(): select_ln56_827_fu_39659_p3.read());
}

void dense_wrapper::thread_select_ln56_829_fu_39673_p3() {
    select_ln56_829_fu_39673_p3 = (!icmp_ln56_48_reg_42717_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_48_reg_42717_pp0_iter1_reg.read()[0].to_bool())? data_48_V_read62_ph_reg_18776_pp0_iter1_reg.read(): select_ln56_828_fu_39666_p3.read());
}

void dense_wrapper::thread_select_ln56_82_fu_32036_p3() {
    select_ln56_82_fu_32036_p3 = (!icmp_ln56_226_fu_29898_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_226_fu_29898_p2.read()[0].to_bool())? ap_phi_mux_data_618_V_read632_s_phi_fu_26190_p4.read(): ap_phi_mux_data_617_V_read631_s_phi_fu_26177_p4.read());
}

void dense_wrapper::thread_select_ln56_830_fu_39680_p3() {
    select_ln56_830_fu_39680_p3 = (!icmp_ln56_49_reg_42722_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_49_reg_42722_pp0_iter1_reg.read()[0].to_bool())? data_49_V_read63_ph_reg_18789_pp0_iter1_reg.read(): select_ln56_829_fu_39673_p3.read());
}

void dense_wrapper::thread_select_ln56_831_fu_39687_p3() {
    select_ln56_831_fu_39687_p3 = (!icmp_ln56_50_reg_42727_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_50_reg_42727_pp0_iter1_reg.read()[0].to_bool())? data_50_V_read64_ph_reg_18802_pp0_iter1_reg.read(): select_ln56_830_fu_39680_p3.read());
}

void dense_wrapper::thread_select_ln56_832_fu_39694_p3() {
    select_ln56_832_fu_39694_p3 = (!icmp_ln56_51_reg_42732_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_51_reg_42732_pp0_iter1_reg.read()[0].to_bool())? data_51_V_read65_ph_reg_18815_pp0_iter1_reg.read(): select_ln56_831_fu_39687_p3.read());
}

void dense_wrapper::thread_select_ln56_833_fu_39701_p3() {
    select_ln56_833_fu_39701_p3 = (!icmp_ln56_52_reg_42737_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_52_reg_42737_pp0_iter1_reg.read()[0].to_bool())? data_52_V_read66_ph_reg_18828_pp0_iter1_reg.read(): select_ln56_832_fu_39694_p3.read());
}

void dense_wrapper::thread_select_ln56_834_fu_39708_p3() {
    select_ln56_834_fu_39708_p3 = (!icmp_ln56_53_reg_42742_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_53_reg_42742_pp0_iter1_reg.read()[0].to_bool())? data_53_V_read67_ph_reg_18841_pp0_iter1_reg.read(): select_ln56_833_fu_39701_p3.read());
}

void dense_wrapper::thread_select_ln56_835_fu_39715_p3() {
    select_ln56_835_fu_39715_p3 = (!icmp_ln56_54_reg_42747_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_54_reg_42747_pp0_iter1_reg.read()[0].to_bool())? data_54_V_read68_ph_reg_18854_pp0_iter1_reg.read(): select_ln56_834_fu_39708_p3.read());
}

void dense_wrapper::thread_select_ln56_836_fu_39722_p3() {
    select_ln56_836_fu_39722_p3 = (!icmp_ln56_55_reg_42752_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_55_reg_42752_pp0_iter1_reg.read()[0].to_bool())? data_55_V_read69_ph_reg_18867_pp0_iter1_reg.read(): select_ln56_835_fu_39715_p3.read());
}

void dense_wrapper::thread_select_ln56_837_fu_39729_p3() {
    select_ln56_837_fu_39729_p3 = (!icmp_ln56_56_reg_42757_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_56_reg_42757_pp0_iter1_reg.read()[0].to_bool())? data_56_V_read70_ph_reg_18880_pp0_iter1_reg.read(): select_ln56_836_fu_39722_p3.read());
}

void dense_wrapper::thread_select_ln56_838_fu_39736_p3() {
    select_ln56_838_fu_39736_p3 = (!icmp_ln56_57_reg_42762_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_57_reg_42762_pp0_iter1_reg.read()[0].to_bool())? data_57_V_read71_ph_reg_18893_pp0_iter1_reg.read(): select_ln56_837_fu_39729_p3.read());
}

void dense_wrapper::thread_select_ln56_839_fu_39743_p3() {
    select_ln56_839_fu_39743_p3 = (!icmp_ln56_58_reg_42767_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_58_reg_42767_pp0_iter1_reg.read()[0].to_bool())? data_58_V_read72_ph_reg_18906_pp0_iter1_reg.read(): select_ln56_838_fu_39736_p3.read());
}

void dense_wrapper::thread_select_ln56_83_fu_32050_p3() {
    select_ln56_83_fu_32050_p3 = (!icmp_ln56_224_fu_29886_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_224_fu_29886_p2.read()[0].to_bool())? ap_phi_mux_data_616_V_read630_s_phi_fu_26164_p4.read(): ap_phi_mux_data_615_V_read629_s_phi_fu_26151_p4.read());
}

void dense_wrapper::thread_select_ln56_840_fu_39750_p3() {
    select_ln56_840_fu_39750_p3 = (!icmp_ln56_59_reg_42772_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_59_reg_42772_pp0_iter1_reg.read()[0].to_bool())? data_59_V_read73_ph_reg_18919_pp0_iter1_reg.read(): select_ln56_839_fu_39743_p3.read());
}

void dense_wrapper::thread_select_ln56_841_fu_39757_p3() {
    select_ln56_841_fu_39757_p3 = (!icmp_ln56_60_reg_42777_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_60_reg_42777_pp0_iter1_reg.read()[0].to_bool())? data_60_V_read74_ph_reg_18932_pp0_iter1_reg.read(): select_ln56_840_fu_39750_p3.read());
}

void dense_wrapper::thread_select_ln56_842_fu_39764_p3() {
    select_ln56_842_fu_39764_p3 = (!icmp_ln56_61_reg_42782_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_61_reg_42782_pp0_iter1_reg.read()[0].to_bool())? data_61_V_read75_ph_reg_18945_pp0_iter1_reg.read(): select_ln56_841_fu_39757_p3.read());
}

void dense_wrapper::thread_select_ln56_843_fu_39771_p3() {
    select_ln56_843_fu_39771_p3 = (!icmp_ln56_62_reg_42787_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_62_reg_42787_pp0_iter1_reg.read()[0].to_bool())? data_62_V_read76_ph_reg_18958_pp0_iter1_reg.read(): select_ln56_842_fu_39764_p3.read());
}

void dense_wrapper::thread_select_ln56_844_fu_39778_p3() {
    select_ln56_844_fu_39778_p3 = (!icmp_ln56_63_reg_42792_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_63_reg_42792_pp0_iter1_reg.read()[0].to_bool())? data_63_V_read77_ph_reg_18971_pp0_iter1_reg.read(): select_ln56_843_fu_39771_p3.read());
}

void dense_wrapper::thread_select_ln56_845_fu_39785_p3() {
    select_ln56_845_fu_39785_p3 = (!icmp_ln56_64_reg_42797_pp0_iter1_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_64_reg_42797_pp0_iter1_reg.read()[0].to_bool())? data_64_V_read78_ph_reg_18984_pp0_iter1_reg.read(): select_ln56_844_fu_39778_p3.read());
}

void dense_wrapper::thread_select_ln56_846_fu_39792_p3() {
    select_ln56_846_fu_39792_p3 = (!icmp_ln56_65_reg_42802_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_65_reg_42802_pp0_iter2_reg.read()[0].to_bool())? data_65_V_read79_ph_reg_18997_pp0_iter2_reg.read(): select_ln56_845_reg_44451.read());
}

void dense_wrapper::thread_select_ln56_847_fu_39798_p3() {
    select_ln56_847_fu_39798_p3 = (!icmp_ln56_66_reg_42807_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_66_reg_42807_pp0_iter2_reg.read()[0].to_bool())? data_66_V_read80_ph_reg_19010_pp0_iter2_reg.read(): select_ln56_846_fu_39792_p3.read());
}

void dense_wrapper::thread_select_ln56_848_fu_39805_p3() {
    select_ln56_848_fu_39805_p3 = (!icmp_ln56_67_reg_42812_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_67_reg_42812_pp0_iter2_reg.read()[0].to_bool())? data_67_V_read81_ph_reg_19023_pp0_iter2_reg.read(): select_ln56_847_fu_39798_p3.read());
}

void dense_wrapper::thread_select_ln56_849_fu_39812_p3() {
    select_ln56_849_fu_39812_p3 = (!icmp_ln56_68_reg_42817_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_68_reg_42817_pp0_iter2_reg.read()[0].to_bool())? data_68_V_read82_ph_reg_19036_pp0_iter2_reg.read(): select_ln56_848_fu_39805_p3.read());
}

void dense_wrapper::thread_select_ln56_84_fu_32064_p3() {
    select_ln56_84_fu_32064_p3 = (!icmp_ln56_222_fu_29874_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_222_fu_29874_p2.read()[0].to_bool())? ap_phi_mux_data_614_V_read628_s_phi_fu_26138_p4.read(): ap_phi_mux_data_613_V_read627_s_phi_fu_26125_p4.read());
}

void dense_wrapper::thread_select_ln56_850_fu_39819_p3() {
    select_ln56_850_fu_39819_p3 = (!icmp_ln56_69_reg_42822_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_69_reg_42822_pp0_iter2_reg.read()[0].to_bool())? data_69_V_read83_ph_reg_19049_pp0_iter2_reg.read(): select_ln56_849_fu_39812_p3.read());
}

void dense_wrapper::thread_select_ln56_851_fu_39826_p3() {
    select_ln56_851_fu_39826_p3 = (!icmp_ln56_70_reg_42827_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_70_reg_42827_pp0_iter2_reg.read()[0].to_bool())? data_70_V_read84_ph_reg_19062_pp0_iter2_reg.read(): select_ln56_850_fu_39819_p3.read());
}

void dense_wrapper::thread_select_ln56_852_fu_39833_p3() {
    select_ln56_852_fu_39833_p3 = (!icmp_ln56_71_reg_42832_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_71_reg_42832_pp0_iter2_reg.read()[0].to_bool())? data_71_V_read85_ph_reg_19075_pp0_iter2_reg.read(): select_ln56_851_fu_39826_p3.read());
}

void dense_wrapper::thread_select_ln56_853_fu_39840_p3() {
    select_ln56_853_fu_39840_p3 = (!icmp_ln56_72_reg_42837_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_72_reg_42837_pp0_iter2_reg.read()[0].to_bool())? data_72_V_read86_ph_reg_19088_pp0_iter2_reg.read(): select_ln56_852_fu_39833_p3.read());
}

void dense_wrapper::thread_select_ln56_854_fu_39847_p3() {
    select_ln56_854_fu_39847_p3 = (!icmp_ln56_73_reg_42842_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_73_reg_42842_pp0_iter2_reg.read()[0].to_bool())? data_73_V_read87_ph_reg_19101_pp0_iter2_reg.read(): select_ln56_853_fu_39840_p3.read());
}

void dense_wrapper::thread_select_ln56_855_fu_39854_p3() {
    select_ln56_855_fu_39854_p3 = (!icmp_ln56_74_reg_42847_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_74_reg_42847_pp0_iter2_reg.read()[0].to_bool())? data_74_V_read88_ph_reg_19114_pp0_iter2_reg.read(): select_ln56_854_fu_39847_p3.read());
}

void dense_wrapper::thread_select_ln56_856_fu_39861_p3() {
    select_ln56_856_fu_39861_p3 = (!icmp_ln56_75_reg_42852_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_75_reg_42852_pp0_iter2_reg.read()[0].to_bool())? data_75_V_read89_ph_reg_19127_pp0_iter2_reg.read(): select_ln56_855_fu_39854_p3.read());
}

void dense_wrapper::thread_select_ln56_857_fu_39868_p3() {
    select_ln56_857_fu_39868_p3 = (!icmp_ln56_76_reg_42857_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_76_reg_42857_pp0_iter2_reg.read()[0].to_bool())? data_76_V_read90_ph_reg_19140_pp0_iter2_reg.read(): select_ln56_856_fu_39861_p3.read());
}

void dense_wrapper::thread_select_ln56_858_fu_39875_p3() {
    select_ln56_858_fu_39875_p3 = (!icmp_ln56_77_reg_42862_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_77_reg_42862_pp0_iter2_reg.read()[0].to_bool())? data_77_V_read91_ph_reg_19153_pp0_iter2_reg.read(): select_ln56_857_fu_39868_p3.read());
}

void dense_wrapper::thread_select_ln56_859_fu_39882_p3() {
    select_ln56_859_fu_39882_p3 = (!icmp_ln56_78_reg_42867_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_78_reg_42867_pp0_iter2_reg.read()[0].to_bool())? data_78_V_read92_ph_reg_19166_pp0_iter2_reg.read(): select_ln56_858_fu_39875_p3.read());
}

void dense_wrapper::thread_select_ln56_85_fu_32078_p3() {
    select_ln56_85_fu_32078_p3 = (!icmp_ln56_220_fu_29862_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_220_fu_29862_p2.read()[0].to_bool())? ap_phi_mux_data_612_V_read626_s_phi_fu_26112_p4.read(): ap_phi_mux_data_611_V_read625_s_phi_fu_26099_p4.read());
}

void dense_wrapper::thread_select_ln56_860_fu_39889_p3() {
    select_ln56_860_fu_39889_p3 = (!icmp_ln56_79_reg_42872_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_79_reg_42872_pp0_iter2_reg.read()[0].to_bool())? data_79_V_read93_ph_reg_19179_pp0_iter2_reg.read(): select_ln56_859_fu_39882_p3.read());
}

void dense_wrapper::thread_select_ln56_861_fu_39896_p3() {
    select_ln56_861_fu_39896_p3 = (!icmp_ln56_80_reg_42877_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_80_reg_42877_pp0_iter2_reg.read()[0].to_bool())? data_80_V_read94_ph_reg_19192_pp0_iter2_reg.read(): select_ln56_860_fu_39889_p3.read());
}

void dense_wrapper::thread_select_ln56_862_fu_39903_p3() {
    select_ln56_862_fu_39903_p3 = (!icmp_ln56_81_reg_42882_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_81_reg_42882_pp0_iter2_reg.read()[0].to_bool())? data_81_V_read95_ph_reg_19205_pp0_iter2_reg.read(): select_ln56_861_fu_39896_p3.read());
}

void dense_wrapper::thread_select_ln56_863_fu_39910_p3() {
    select_ln56_863_fu_39910_p3 = (!icmp_ln56_82_reg_42887_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_82_reg_42887_pp0_iter2_reg.read()[0].to_bool())? data_82_V_read96_ph_reg_19218_pp0_iter2_reg.read(): select_ln56_862_fu_39903_p3.read());
}

void dense_wrapper::thread_select_ln56_864_fu_39917_p3() {
    select_ln56_864_fu_39917_p3 = (!icmp_ln56_83_reg_42892_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_83_reg_42892_pp0_iter2_reg.read()[0].to_bool())? data_83_V_read97_ph_reg_19231_pp0_iter2_reg.read(): select_ln56_863_fu_39910_p3.read());
}

void dense_wrapper::thread_select_ln56_865_fu_39924_p3() {
    select_ln56_865_fu_39924_p3 = (!icmp_ln56_84_reg_42897_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_84_reg_42897_pp0_iter2_reg.read()[0].to_bool())? data_84_V_read98_ph_reg_19244_pp0_iter2_reg.read(): select_ln56_864_fu_39917_p3.read());
}

void dense_wrapper::thread_select_ln56_866_fu_39931_p3() {
    select_ln56_866_fu_39931_p3 = (!icmp_ln56_85_reg_42902_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_85_reg_42902_pp0_iter2_reg.read()[0].to_bool())? data_85_V_read99_ph_reg_19257_pp0_iter2_reg.read(): select_ln56_865_fu_39924_p3.read());
}

void dense_wrapper::thread_select_ln56_867_fu_39938_p3() {
    select_ln56_867_fu_39938_p3 = (!icmp_ln56_86_reg_42907_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_86_reg_42907_pp0_iter2_reg.read()[0].to_bool())? data_86_V_read100_p_reg_19270_pp0_iter2_reg.read(): select_ln56_866_fu_39931_p3.read());
}

void dense_wrapper::thread_select_ln56_868_fu_39945_p3() {
    select_ln56_868_fu_39945_p3 = (!icmp_ln56_87_reg_42912_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_87_reg_42912_pp0_iter2_reg.read()[0].to_bool())? data_87_V_read101_p_reg_19283_pp0_iter2_reg.read(): select_ln56_867_fu_39938_p3.read());
}

void dense_wrapper::thread_select_ln56_869_fu_39952_p3() {
    select_ln56_869_fu_39952_p3 = (!icmp_ln56_88_reg_42917_pp0_iter2_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_88_reg_42917_pp0_iter2_reg.read()[0].to_bool())? data_88_V_read102_p_reg_19296_pp0_iter2_reg.read(): select_ln56_868_fu_39945_p3.read());
}

void dense_wrapper::thread_select_ln56_86_fu_32092_p3() {
    select_ln56_86_fu_32092_p3 = (!icmp_ln56_218_fu_29850_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_218_fu_29850_p2.read()[0].to_bool())? ap_phi_mux_data_610_V_read624_s_phi_fu_26086_p4.read(): ap_phi_mux_data_609_V_read623_s_phi_fu_26073_p4.read());
}

void dense_wrapper::thread_select_ln56_870_fu_39959_p3() {
    select_ln56_870_fu_39959_p3 = (!icmp_ln56_89_reg_42922_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_89_reg_42922_pp0_iter3_reg.read()[0].to_bool())? data_89_V_read103_p_reg_19309_pp0_iter3_reg.read(): select_ln56_869_reg_44456.read());
}

void dense_wrapper::thread_select_ln56_871_fu_39965_p3() {
    select_ln56_871_fu_39965_p3 = (!icmp_ln56_90_reg_42927_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_90_reg_42927_pp0_iter3_reg.read()[0].to_bool())? data_90_V_read104_p_reg_19322_pp0_iter3_reg.read(): select_ln56_870_fu_39959_p3.read());
}

void dense_wrapper::thread_select_ln56_872_fu_39972_p3() {
    select_ln56_872_fu_39972_p3 = (!icmp_ln56_91_reg_42932_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_91_reg_42932_pp0_iter3_reg.read()[0].to_bool())? data_91_V_read105_p_reg_19335_pp0_iter3_reg.read(): select_ln56_871_fu_39965_p3.read());
}

void dense_wrapper::thread_select_ln56_873_fu_39979_p3() {
    select_ln56_873_fu_39979_p3 = (!icmp_ln56_92_reg_42937_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_92_reg_42937_pp0_iter3_reg.read()[0].to_bool())? data_92_V_read106_p_reg_19348_pp0_iter3_reg.read(): select_ln56_872_fu_39972_p3.read());
}

void dense_wrapper::thread_select_ln56_874_fu_39986_p3() {
    select_ln56_874_fu_39986_p3 = (!icmp_ln56_93_reg_42942_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_93_reg_42942_pp0_iter3_reg.read()[0].to_bool())? data_93_V_read107_p_reg_19361_pp0_iter3_reg.read(): select_ln56_873_fu_39979_p3.read());
}

void dense_wrapper::thread_select_ln56_875_fu_39993_p3() {
    select_ln56_875_fu_39993_p3 = (!icmp_ln56_94_reg_42947_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_94_reg_42947_pp0_iter3_reg.read()[0].to_bool())? data_94_V_read108_p_reg_19374_pp0_iter3_reg.read(): select_ln56_874_fu_39986_p3.read());
}

void dense_wrapper::thread_select_ln56_876_fu_40000_p3() {
    select_ln56_876_fu_40000_p3 = (!icmp_ln56_95_reg_42952_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_95_reg_42952_pp0_iter3_reg.read()[0].to_bool())? data_95_V_read109_p_reg_19387_pp0_iter3_reg.read(): select_ln56_875_fu_39993_p3.read());
}

void dense_wrapper::thread_select_ln56_877_fu_40007_p3() {
    select_ln56_877_fu_40007_p3 = (!icmp_ln56_96_reg_42957_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_96_reg_42957_pp0_iter3_reg.read()[0].to_bool())? data_96_V_read110_p_reg_19400_pp0_iter3_reg.read(): select_ln56_876_fu_40000_p3.read());
}

void dense_wrapper::thread_select_ln56_878_fu_40014_p3() {
    select_ln56_878_fu_40014_p3 = (!icmp_ln56_97_reg_42962_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_97_reg_42962_pp0_iter3_reg.read()[0].to_bool())? data_97_V_read111_p_reg_19413_pp0_iter3_reg.read(): select_ln56_877_fu_40007_p3.read());
}

void dense_wrapper::thread_select_ln56_879_fu_40021_p3() {
    select_ln56_879_fu_40021_p3 = (!icmp_ln56_98_reg_42967_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_98_reg_42967_pp0_iter3_reg.read()[0].to_bool())? data_98_V_read112_p_reg_19426_pp0_iter3_reg.read(): select_ln56_878_fu_40014_p3.read());
}

void dense_wrapper::thread_select_ln56_87_fu_32106_p3() {
    select_ln56_87_fu_32106_p3 = (!icmp_ln56_216_fu_29838_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_216_fu_29838_p2.read()[0].to_bool())? ap_phi_mux_data_608_V_read622_s_phi_fu_26060_p4.read(): ap_phi_mux_data_607_V_read621_s_phi_fu_26047_p4.read());
}

void dense_wrapper::thread_select_ln56_880_fu_40028_p3() {
    select_ln56_880_fu_40028_p3 = (!icmp_ln56_99_reg_42972_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_99_reg_42972_pp0_iter3_reg.read()[0].to_bool())? data_99_V_read113_p_reg_19439_pp0_iter3_reg.read(): select_ln56_879_fu_40021_p3.read());
}

void dense_wrapper::thread_select_ln56_881_fu_40035_p3() {
    select_ln56_881_fu_40035_p3 = (!icmp_ln56_100_reg_42977_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_100_reg_42977_pp0_iter3_reg.read()[0].to_bool())? data_100_V_read114_s_reg_19452_pp0_iter3_reg.read(): select_ln56_880_fu_40028_p3.read());
}

void dense_wrapper::thread_select_ln56_882_fu_40042_p3() {
    select_ln56_882_fu_40042_p3 = (!icmp_ln56_101_reg_42982_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_101_reg_42982_pp0_iter3_reg.read()[0].to_bool())? data_101_V_read115_s_reg_19465_pp0_iter3_reg.read(): select_ln56_881_fu_40035_p3.read());
}

void dense_wrapper::thread_select_ln56_883_fu_40049_p3() {
    select_ln56_883_fu_40049_p3 = (!icmp_ln56_102_reg_42987_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_102_reg_42987_pp0_iter3_reg.read()[0].to_bool())? data_102_V_read116_s_reg_19478_pp0_iter3_reg.read(): select_ln56_882_fu_40042_p3.read());
}

void dense_wrapper::thread_select_ln56_884_fu_40056_p3() {
    select_ln56_884_fu_40056_p3 = (!icmp_ln56_103_reg_42992_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_103_reg_42992_pp0_iter3_reg.read()[0].to_bool())? data_103_V_read117_s_reg_19491_pp0_iter3_reg.read(): select_ln56_883_fu_40049_p3.read());
}

void dense_wrapper::thread_select_ln56_885_fu_40063_p3() {
    select_ln56_885_fu_40063_p3 = (!icmp_ln56_104_reg_42997_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_104_reg_42997_pp0_iter3_reg.read()[0].to_bool())? data_104_V_read118_s_reg_19504_pp0_iter3_reg.read(): select_ln56_884_fu_40056_p3.read());
}

void dense_wrapper::thread_select_ln56_886_fu_40070_p3() {
    select_ln56_886_fu_40070_p3 = (!icmp_ln56_105_reg_43002_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_105_reg_43002_pp0_iter3_reg.read()[0].to_bool())? data_105_V_read119_s_reg_19517_pp0_iter3_reg.read(): select_ln56_885_fu_40063_p3.read());
}

void dense_wrapper::thread_select_ln56_887_fu_40077_p3() {
    select_ln56_887_fu_40077_p3 = (!icmp_ln56_106_reg_43007_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_106_reg_43007_pp0_iter3_reg.read()[0].to_bool())? data_106_V_read120_s_reg_19530_pp0_iter3_reg.read(): select_ln56_886_fu_40070_p3.read());
}

void dense_wrapper::thread_select_ln56_888_fu_40084_p3() {
    select_ln56_888_fu_40084_p3 = (!icmp_ln56_107_reg_43012_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_107_reg_43012_pp0_iter3_reg.read()[0].to_bool())? data_107_V_read121_s_reg_19543_pp0_iter3_reg.read(): select_ln56_887_fu_40077_p3.read());
}

void dense_wrapper::thread_select_ln56_889_fu_40091_p3() {
    select_ln56_889_fu_40091_p3 = (!icmp_ln56_108_reg_43017_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_108_reg_43017_pp0_iter3_reg.read()[0].to_bool())? data_108_V_read122_s_reg_19556_pp0_iter3_reg.read(): select_ln56_888_fu_40084_p3.read());
}

void dense_wrapper::thread_select_ln56_88_fu_32120_p3() {
    select_ln56_88_fu_32120_p3 = (!icmp_ln56_214_fu_29826_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_214_fu_29826_p2.read()[0].to_bool())? ap_phi_mux_data_606_V_read620_s_phi_fu_26034_p4.read(): ap_phi_mux_data_605_V_read619_s_phi_fu_26021_p4.read());
}

void dense_wrapper::thread_select_ln56_890_fu_40098_p3() {
    select_ln56_890_fu_40098_p3 = (!icmp_ln56_109_reg_43022_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_109_reg_43022_pp0_iter3_reg.read()[0].to_bool())? data_109_V_read123_s_reg_19569_pp0_iter3_reg.read(): select_ln56_889_fu_40091_p3.read());
}

void dense_wrapper::thread_select_ln56_891_fu_40105_p3() {
    select_ln56_891_fu_40105_p3 = (!icmp_ln56_110_reg_43027_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_110_reg_43027_pp0_iter3_reg.read()[0].to_bool())? data_110_V_read124_s_reg_19582_pp0_iter3_reg.read(): select_ln56_890_fu_40098_p3.read());
}

void dense_wrapper::thread_select_ln56_892_fu_40112_p3() {
    select_ln56_892_fu_40112_p3 = (!icmp_ln56_111_reg_43032_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_111_reg_43032_pp0_iter3_reg.read()[0].to_bool())? data_111_V_read125_s_reg_19595_pp0_iter3_reg.read(): select_ln56_891_fu_40105_p3.read());
}

void dense_wrapper::thread_select_ln56_893_fu_40119_p3() {
    select_ln56_893_fu_40119_p3 = (!icmp_ln56_112_reg_43037_pp0_iter3_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_112_reg_43037_pp0_iter3_reg.read()[0].to_bool())? data_112_V_read126_s_reg_19608_pp0_iter3_reg.read(): select_ln56_892_fu_40112_p3.read());
}

void dense_wrapper::thread_select_ln56_894_fu_40126_p3() {
    select_ln56_894_fu_40126_p3 = (!icmp_ln56_113_reg_43042_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_113_reg_43042_pp0_iter4_reg.read()[0].to_bool())? data_113_V_read127_s_reg_19621_pp0_iter4_reg.read(): select_ln56_893_reg_44461.read());
}

void dense_wrapper::thread_select_ln56_895_fu_40132_p3() {
    select_ln56_895_fu_40132_p3 = (!icmp_ln56_114_reg_43047_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_114_reg_43047_pp0_iter4_reg.read()[0].to_bool())? data_114_V_read128_s_reg_19634_pp0_iter4_reg.read(): select_ln56_894_fu_40126_p3.read());
}

void dense_wrapper::thread_select_ln56_896_fu_40139_p3() {
    select_ln56_896_fu_40139_p3 = (!icmp_ln56_115_reg_43052_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_115_reg_43052_pp0_iter4_reg.read()[0].to_bool())? data_115_V_read129_s_reg_19647_pp0_iter4_reg.read(): select_ln56_895_fu_40132_p3.read());
}

void dense_wrapper::thread_select_ln56_897_fu_40146_p3() {
    select_ln56_897_fu_40146_p3 = (!icmp_ln56_116_reg_43057_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_116_reg_43057_pp0_iter4_reg.read()[0].to_bool())? data_116_V_read130_s_reg_19660_pp0_iter4_reg.read(): select_ln56_896_fu_40139_p3.read());
}

void dense_wrapper::thread_select_ln56_898_fu_40153_p3() {
    select_ln56_898_fu_40153_p3 = (!icmp_ln56_117_reg_43062_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_117_reg_43062_pp0_iter4_reg.read()[0].to_bool())? data_117_V_read131_s_reg_19673_pp0_iter4_reg.read(): select_ln56_897_fu_40146_p3.read());
}

void dense_wrapper::thread_select_ln56_899_fu_40160_p3() {
    select_ln56_899_fu_40160_p3 = (!icmp_ln56_118_reg_43067_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_118_reg_43067_pp0_iter4_reg.read()[0].to_bool())? data_118_V_read132_s_reg_19686_pp0_iter4_reg.read(): select_ln56_898_fu_40153_p3.read());
}

void dense_wrapper::thread_select_ln56_89_fu_32134_p3() {
    select_ln56_89_fu_32134_p3 = (!icmp_ln56_212_fu_29814_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_212_fu_29814_p2.read()[0].to_bool())? ap_phi_mux_data_604_V_read618_s_phi_fu_26008_p4.read(): ap_phi_mux_data_603_V_read617_s_phi_fu_25995_p4.read());
}

void dense_wrapper::thread_select_ln56_8_fu_31000_p3() {
    select_ln56_8_fu_31000_p3 = (!icmp_ln56_374_fu_30786_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_374_fu_30786_p2.read()[0].to_bool())? ap_phi_mux_data_766_V_read780_s_phi_fu_28114_p4.read(): ap_phi_mux_data_765_V_read779_s_phi_fu_28101_p4.read());
}

void dense_wrapper::thread_select_ln56_900_fu_40167_p3() {
    select_ln56_900_fu_40167_p3 = (!icmp_ln56_119_reg_43072_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_119_reg_43072_pp0_iter4_reg.read()[0].to_bool())? data_119_V_read133_s_reg_19699_pp0_iter4_reg.read(): select_ln56_899_fu_40160_p3.read());
}

void dense_wrapper::thread_select_ln56_901_fu_40174_p3() {
    select_ln56_901_fu_40174_p3 = (!icmp_ln56_120_reg_43077_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_120_reg_43077_pp0_iter4_reg.read()[0].to_bool())? data_120_V_read134_s_reg_19712_pp0_iter4_reg.read(): select_ln56_900_fu_40167_p3.read());
}

void dense_wrapper::thread_select_ln56_902_fu_40181_p3() {
    select_ln56_902_fu_40181_p3 = (!icmp_ln56_121_reg_43082_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_121_reg_43082_pp0_iter4_reg.read()[0].to_bool())? data_121_V_read135_s_reg_19725_pp0_iter4_reg.read(): select_ln56_901_fu_40174_p3.read());
}

void dense_wrapper::thread_select_ln56_903_fu_40188_p3() {
    select_ln56_903_fu_40188_p3 = (!icmp_ln56_122_reg_43087_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_122_reg_43087_pp0_iter4_reg.read()[0].to_bool())? data_122_V_read136_s_reg_19738_pp0_iter4_reg.read(): select_ln56_902_fu_40181_p3.read());
}

void dense_wrapper::thread_select_ln56_904_fu_40195_p3() {
    select_ln56_904_fu_40195_p3 = (!icmp_ln56_123_reg_43092_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_123_reg_43092_pp0_iter4_reg.read()[0].to_bool())? data_123_V_read137_s_reg_19751_pp0_iter4_reg.read(): select_ln56_903_fu_40188_p3.read());
}

void dense_wrapper::thread_select_ln56_905_fu_40202_p3() {
    select_ln56_905_fu_40202_p3 = (!icmp_ln56_124_reg_43097_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_124_reg_43097_pp0_iter4_reg.read()[0].to_bool())? data_124_V_read138_s_reg_19764_pp0_iter4_reg.read(): select_ln56_904_fu_40195_p3.read());
}

void dense_wrapper::thread_select_ln56_906_fu_40209_p3() {
    select_ln56_906_fu_40209_p3 = (!icmp_ln56_125_reg_43102_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_125_reg_43102_pp0_iter4_reg.read()[0].to_bool())? data_125_V_read139_s_reg_19777_pp0_iter4_reg.read(): select_ln56_905_fu_40202_p3.read());
}

void dense_wrapper::thread_select_ln56_907_fu_40216_p3() {
    select_ln56_907_fu_40216_p3 = (!icmp_ln56_126_reg_43107_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_126_reg_43107_pp0_iter4_reg.read()[0].to_bool())? data_126_V_read140_s_reg_19790_pp0_iter4_reg.read(): select_ln56_906_fu_40209_p3.read());
}

void dense_wrapper::thread_select_ln56_908_fu_40223_p3() {
    select_ln56_908_fu_40223_p3 = (!icmp_ln56_127_reg_43112_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_127_reg_43112_pp0_iter4_reg.read()[0].to_bool())? data_127_V_read141_s_reg_19803_pp0_iter4_reg.read(): select_ln56_907_fu_40216_p3.read());
}

void dense_wrapper::thread_select_ln56_909_fu_40230_p3() {
    select_ln56_909_fu_40230_p3 = (!icmp_ln56_128_reg_43117_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_128_reg_43117_pp0_iter4_reg.read()[0].to_bool())? data_128_V_read142_s_reg_19816_pp0_iter4_reg.read(): select_ln56_908_fu_40223_p3.read());
}

void dense_wrapper::thread_select_ln56_90_fu_32148_p3() {
    select_ln56_90_fu_32148_p3 = (!icmp_ln56_210_fu_29802_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_210_fu_29802_p2.read()[0].to_bool())? ap_phi_mux_data_602_V_read616_s_phi_fu_25982_p4.read(): ap_phi_mux_data_601_V_read615_s_phi_fu_25969_p4.read());
}

void dense_wrapper::thread_select_ln56_910_fu_40237_p3() {
    select_ln56_910_fu_40237_p3 = (!icmp_ln56_129_reg_43122_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_129_reg_43122_pp0_iter4_reg.read()[0].to_bool())? data_129_V_read143_s_reg_19829_pp0_iter4_reg.read(): select_ln56_909_fu_40230_p3.read());
}

void dense_wrapper::thread_select_ln56_911_fu_40244_p3() {
    select_ln56_911_fu_40244_p3 = (!icmp_ln56_130_reg_43127_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_130_reg_43127_pp0_iter4_reg.read()[0].to_bool())? data_130_V_read144_s_reg_19842_pp0_iter4_reg.read(): select_ln56_910_fu_40237_p3.read());
}

void dense_wrapper::thread_select_ln56_912_fu_40251_p3() {
    select_ln56_912_fu_40251_p3 = (!icmp_ln56_131_reg_43132_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_131_reg_43132_pp0_iter4_reg.read()[0].to_bool())? data_131_V_read145_s_reg_19855_pp0_iter4_reg.read(): select_ln56_911_fu_40244_p3.read());
}

void dense_wrapper::thread_select_ln56_913_fu_40258_p3() {
    select_ln56_913_fu_40258_p3 = (!icmp_ln56_132_reg_43137_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_132_reg_43137_pp0_iter4_reg.read()[0].to_bool())? data_132_V_read146_s_reg_19868_pp0_iter4_reg.read(): select_ln56_912_fu_40251_p3.read());
}

void dense_wrapper::thread_select_ln56_914_fu_40265_p3() {
    select_ln56_914_fu_40265_p3 = (!icmp_ln56_133_reg_43142_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_133_reg_43142_pp0_iter4_reg.read()[0].to_bool())? data_133_V_read147_s_reg_19881_pp0_iter4_reg.read(): select_ln56_913_fu_40258_p3.read());
}

void dense_wrapper::thread_select_ln56_915_fu_40272_p3() {
    select_ln56_915_fu_40272_p3 = (!icmp_ln56_134_reg_43147_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_134_reg_43147_pp0_iter4_reg.read()[0].to_bool())? data_134_V_read148_s_reg_19894_pp0_iter4_reg.read(): select_ln56_914_fu_40265_p3.read());
}

void dense_wrapper::thread_select_ln56_916_fu_40279_p3() {
    select_ln56_916_fu_40279_p3 = (!icmp_ln56_135_reg_43152_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_135_reg_43152_pp0_iter4_reg.read()[0].to_bool())? data_135_V_read149_s_reg_19907_pp0_iter4_reg.read(): select_ln56_915_fu_40272_p3.read());
}

void dense_wrapper::thread_select_ln56_917_fu_40286_p3() {
    select_ln56_917_fu_40286_p3 = (!icmp_ln56_136_reg_43157_pp0_iter4_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_136_reg_43157_pp0_iter4_reg.read()[0].to_bool())? data_136_V_read150_s_reg_19920_pp0_iter4_reg.read(): select_ln56_916_fu_40279_p3.read());
}

void dense_wrapper::thread_select_ln56_918_fu_40293_p3() {
    select_ln56_918_fu_40293_p3 = (!icmp_ln56_137_reg_43162_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_137_reg_43162_pp0_iter5_reg.read()[0].to_bool())? data_137_V_read151_s_reg_19933_pp0_iter5_reg.read(): select_ln56_917_reg_44466.read());
}

void dense_wrapper::thread_select_ln56_919_fu_40299_p3() {
    select_ln56_919_fu_40299_p3 = (!icmp_ln56_138_reg_43167_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_138_reg_43167_pp0_iter5_reg.read()[0].to_bool())? data_138_V_read152_s_reg_19946_pp0_iter5_reg.read(): select_ln56_918_fu_40293_p3.read());
}

void dense_wrapper::thread_select_ln56_91_fu_32162_p3() {
    select_ln56_91_fu_32162_p3 = (!icmp_ln56_208_fu_29790_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_208_fu_29790_p2.read()[0].to_bool())? ap_phi_mux_data_600_V_read614_s_phi_fu_25956_p4.read(): ap_phi_mux_data_599_V_read613_s_phi_fu_25943_p4.read());
}

void dense_wrapper::thread_select_ln56_920_fu_40306_p3() {
    select_ln56_920_fu_40306_p3 = (!icmp_ln56_139_reg_43172_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_139_reg_43172_pp0_iter5_reg.read()[0].to_bool())? data_139_V_read153_s_reg_19959_pp0_iter5_reg.read(): select_ln56_919_fu_40299_p3.read());
}

void dense_wrapper::thread_select_ln56_921_fu_40313_p3() {
    select_ln56_921_fu_40313_p3 = (!icmp_ln56_140_reg_43177_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_140_reg_43177_pp0_iter5_reg.read()[0].to_bool())? data_140_V_read154_s_reg_19972_pp0_iter5_reg.read(): select_ln56_920_fu_40306_p3.read());
}

void dense_wrapper::thread_select_ln56_922_fu_40320_p3() {
    select_ln56_922_fu_40320_p3 = (!icmp_ln56_141_reg_43182_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_141_reg_43182_pp0_iter5_reg.read()[0].to_bool())? data_141_V_read155_s_reg_19985_pp0_iter5_reg.read(): select_ln56_921_fu_40313_p3.read());
}

void dense_wrapper::thread_select_ln56_923_fu_40327_p3() {
    select_ln56_923_fu_40327_p3 = (!icmp_ln56_142_reg_43187_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_142_reg_43187_pp0_iter5_reg.read()[0].to_bool())? data_142_V_read156_s_reg_19998_pp0_iter5_reg.read(): select_ln56_922_fu_40320_p3.read());
}

void dense_wrapper::thread_select_ln56_924_fu_40334_p3() {
    select_ln56_924_fu_40334_p3 = (!icmp_ln56_143_reg_43192_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_143_reg_43192_pp0_iter5_reg.read()[0].to_bool())? data_143_V_read157_s_reg_20011_pp0_iter5_reg.read(): select_ln56_923_fu_40327_p3.read());
}

void dense_wrapper::thread_select_ln56_925_fu_40341_p3() {
    select_ln56_925_fu_40341_p3 = (!icmp_ln56_144_reg_43197_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_144_reg_43197_pp0_iter5_reg.read()[0].to_bool())? data_144_V_read158_s_reg_20024_pp0_iter5_reg.read(): select_ln56_924_fu_40334_p3.read());
}

void dense_wrapper::thread_select_ln56_926_fu_40348_p3() {
    select_ln56_926_fu_40348_p3 = (!icmp_ln56_145_reg_43202_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_145_reg_43202_pp0_iter5_reg.read()[0].to_bool())? data_145_V_read159_s_reg_20037_pp0_iter5_reg.read(): select_ln56_925_fu_40341_p3.read());
}

void dense_wrapper::thread_select_ln56_927_fu_40355_p3() {
    select_ln56_927_fu_40355_p3 = (!icmp_ln56_146_reg_43207_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_146_reg_43207_pp0_iter5_reg.read()[0].to_bool())? data_146_V_read160_s_reg_20050_pp0_iter5_reg.read(): select_ln56_926_fu_40348_p3.read());
}

void dense_wrapper::thread_select_ln56_928_fu_40362_p3() {
    select_ln56_928_fu_40362_p3 = (!icmp_ln56_147_reg_43212_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_147_reg_43212_pp0_iter5_reg.read()[0].to_bool())? data_147_V_read161_s_reg_20063_pp0_iter5_reg.read(): select_ln56_927_fu_40355_p3.read());
}

void dense_wrapper::thread_select_ln56_929_fu_40369_p3() {
    select_ln56_929_fu_40369_p3 = (!icmp_ln56_148_reg_43217_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_148_reg_43217_pp0_iter5_reg.read()[0].to_bool())? data_148_V_read162_s_reg_20076_pp0_iter5_reg.read(): select_ln56_928_fu_40362_p3.read());
}

void dense_wrapper::thread_select_ln56_92_fu_32176_p3() {
    select_ln56_92_fu_32176_p3 = (!icmp_ln56_206_fu_29778_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_206_fu_29778_p2.read()[0].to_bool())? ap_phi_mux_data_598_V_read612_s_phi_fu_25930_p4.read(): ap_phi_mux_data_597_V_read611_s_phi_fu_25917_p4.read());
}

void dense_wrapper::thread_select_ln56_930_fu_40376_p3() {
    select_ln56_930_fu_40376_p3 = (!icmp_ln56_149_reg_43222_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_149_reg_43222_pp0_iter5_reg.read()[0].to_bool())? data_149_V_read163_s_reg_20089_pp0_iter5_reg.read(): select_ln56_929_fu_40369_p3.read());
}

void dense_wrapper::thread_select_ln56_931_fu_40383_p3() {
    select_ln56_931_fu_40383_p3 = (!icmp_ln56_150_reg_43227_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_150_reg_43227_pp0_iter5_reg.read()[0].to_bool())? data_150_V_read164_s_reg_20102_pp0_iter5_reg.read(): select_ln56_930_fu_40376_p3.read());
}

void dense_wrapper::thread_select_ln56_932_fu_40390_p3() {
    select_ln56_932_fu_40390_p3 = (!icmp_ln56_151_reg_43232_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_151_reg_43232_pp0_iter5_reg.read()[0].to_bool())? data_151_V_read165_s_reg_20115_pp0_iter5_reg.read(): select_ln56_931_fu_40383_p3.read());
}

void dense_wrapper::thread_select_ln56_933_fu_40397_p3() {
    select_ln56_933_fu_40397_p3 = (!icmp_ln56_152_reg_43237_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_152_reg_43237_pp0_iter5_reg.read()[0].to_bool())? data_152_V_read166_s_reg_20128_pp0_iter5_reg.read(): select_ln56_932_fu_40390_p3.read());
}

void dense_wrapper::thread_select_ln56_934_fu_40404_p3() {
    select_ln56_934_fu_40404_p3 = (!icmp_ln56_153_reg_43242_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_153_reg_43242_pp0_iter5_reg.read()[0].to_bool())? data_153_V_read167_s_reg_20141_pp0_iter5_reg.read(): select_ln56_933_fu_40397_p3.read());
}

void dense_wrapper::thread_select_ln56_935_fu_40411_p3() {
    select_ln56_935_fu_40411_p3 = (!icmp_ln56_154_reg_43247_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_154_reg_43247_pp0_iter5_reg.read()[0].to_bool())? data_154_V_read168_s_reg_20154_pp0_iter5_reg.read(): select_ln56_934_fu_40404_p3.read());
}

void dense_wrapper::thread_select_ln56_936_fu_40418_p3() {
    select_ln56_936_fu_40418_p3 = (!icmp_ln56_155_reg_43252_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_155_reg_43252_pp0_iter5_reg.read()[0].to_bool())? data_155_V_read169_s_reg_20167_pp0_iter5_reg.read(): select_ln56_935_fu_40411_p3.read());
}

void dense_wrapper::thread_select_ln56_937_fu_40425_p3() {
    select_ln56_937_fu_40425_p3 = (!icmp_ln56_156_reg_43257_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_156_reg_43257_pp0_iter5_reg.read()[0].to_bool())? data_156_V_read170_s_reg_20180_pp0_iter5_reg.read(): select_ln56_936_fu_40418_p3.read());
}

void dense_wrapper::thread_select_ln56_938_fu_40432_p3() {
    select_ln56_938_fu_40432_p3 = (!icmp_ln56_157_reg_43262_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_157_reg_43262_pp0_iter5_reg.read()[0].to_bool())? data_157_V_read171_s_reg_20193_pp0_iter5_reg.read(): select_ln56_937_fu_40425_p3.read());
}

void dense_wrapper::thread_select_ln56_939_fu_40439_p3() {
    select_ln56_939_fu_40439_p3 = (!icmp_ln56_158_reg_43267_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_158_reg_43267_pp0_iter5_reg.read()[0].to_bool())? data_158_V_read172_s_reg_20206_pp0_iter5_reg.read(): select_ln56_938_fu_40432_p3.read());
}

void dense_wrapper::thread_select_ln56_93_fu_32190_p3() {
    select_ln56_93_fu_32190_p3 = (!icmp_ln56_204_fu_29766_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_204_fu_29766_p2.read()[0].to_bool())? ap_phi_mux_data_596_V_read610_s_phi_fu_25904_p4.read(): ap_phi_mux_data_595_V_read609_s_phi_fu_25891_p4.read());
}

void dense_wrapper::thread_select_ln56_940_fu_40446_p3() {
    select_ln56_940_fu_40446_p3 = (!icmp_ln56_159_reg_43272_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_159_reg_43272_pp0_iter5_reg.read()[0].to_bool())? data_159_V_read173_s_reg_20219_pp0_iter5_reg.read(): select_ln56_939_fu_40439_p3.read());
}

void dense_wrapper::thread_select_ln56_941_fu_40453_p3() {
    select_ln56_941_fu_40453_p3 = (!icmp_ln56_160_reg_43277_pp0_iter5_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_160_reg_43277_pp0_iter5_reg.read()[0].to_bool())? data_160_V_read174_s_reg_20232_pp0_iter5_reg.read(): select_ln56_940_fu_40446_p3.read());
}

void dense_wrapper::thread_select_ln56_942_fu_40460_p3() {
    select_ln56_942_fu_40460_p3 = (!icmp_ln56_161_reg_43282_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_161_reg_43282_pp0_iter6_reg.read()[0].to_bool())? data_161_V_read175_s_reg_20245_pp0_iter6_reg.read(): select_ln56_941_reg_44471.read());
}

void dense_wrapper::thread_select_ln56_943_fu_40466_p3() {
    select_ln56_943_fu_40466_p3 = (!icmp_ln56_162_reg_43287_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_162_reg_43287_pp0_iter6_reg.read()[0].to_bool())? data_162_V_read176_s_reg_20258_pp0_iter6_reg.read(): select_ln56_942_fu_40460_p3.read());
}

void dense_wrapper::thread_select_ln56_944_fu_40473_p3() {
    select_ln56_944_fu_40473_p3 = (!icmp_ln56_163_reg_43292_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_163_reg_43292_pp0_iter6_reg.read()[0].to_bool())? data_163_V_read177_s_reg_20271_pp0_iter6_reg.read(): select_ln56_943_fu_40466_p3.read());
}

void dense_wrapper::thread_select_ln56_945_fu_40480_p3() {
    select_ln56_945_fu_40480_p3 = (!icmp_ln56_164_reg_43297_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_164_reg_43297_pp0_iter6_reg.read()[0].to_bool())? data_164_V_read178_s_reg_20284_pp0_iter6_reg.read(): select_ln56_944_fu_40473_p3.read());
}

void dense_wrapper::thread_select_ln56_946_fu_40487_p3() {
    select_ln56_946_fu_40487_p3 = (!icmp_ln56_165_reg_43302_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_165_reg_43302_pp0_iter6_reg.read()[0].to_bool())? data_165_V_read179_s_reg_20297_pp0_iter6_reg.read(): select_ln56_945_fu_40480_p3.read());
}

void dense_wrapper::thread_select_ln56_947_fu_40494_p3() {
    select_ln56_947_fu_40494_p3 = (!icmp_ln56_166_reg_43307_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_166_reg_43307_pp0_iter6_reg.read()[0].to_bool())? data_166_V_read180_s_reg_20310_pp0_iter6_reg.read(): select_ln56_946_fu_40487_p3.read());
}

void dense_wrapper::thread_select_ln56_948_fu_40501_p3() {
    select_ln56_948_fu_40501_p3 = (!icmp_ln56_167_reg_43312_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_167_reg_43312_pp0_iter6_reg.read()[0].to_bool())? data_167_V_read181_s_reg_20323_pp0_iter6_reg.read(): select_ln56_947_fu_40494_p3.read());
}

void dense_wrapper::thread_select_ln56_949_fu_40508_p3() {
    select_ln56_949_fu_40508_p3 = (!icmp_ln56_168_reg_43317_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_168_reg_43317_pp0_iter6_reg.read()[0].to_bool())? data_168_V_read182_s_reg_20336_pp0_iter6_reg.read(): select_ln56_948_fu_40501_p3.read());
}

void dense_wrapper::thread_select_ln56_94_fu_32204_p3() {
    select_ln56_94_fu_32204_p3 = (!icmp_ln56_202_fu_29754_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_202_fu_29754_p2.read()[0].to_bool())? ap_phi_mux_data_594_V_read608_s_phi_fu_25878_p4.read(): ap_phi_mux_data_593_V_read607_s_phi_fu_25865_p4.read());
}

void dense_wrapper::thread_select_ln56_950_fu_40515_p3() {
    select_ln56_950_fu_40515_p3 = (!icmp_ln56_169_reg_43322_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_169_reg_43322_pp0_iter6_reg.read()[0].to_bool())? data_169_V_read183_s_reg_20349_pp0_iter6_reg.read(): select_ln56_949_fu_40508_p3.read());
}

void dense_wrapper::thread_select_ln56_951_fu_40522_p3() {
    select_ln56_951_fu_40522_p3 = (!icmp_ln56_170_reg_43327_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_170_reg_43327_pp0_iter6_reg.read()[0].to_bool())? data_170_V_read184_s_reg_20362_pp0_iter6_reg.read(): select_ln56_950_fu_40515_p3.read());
}

void dense_wrapper::thread_select_ln56_952_fu_40529_p3() {
    select_ln56_952_fu_40529_p3 = (!icmp_ln56_171_reg_43332_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_171_reg_43332_pp0_iter6_reg.read()[0].to_bool())? data_171_V_read185_s_reg_20375_pp0_iter6_reg.read(): select_ln56_951_fu_40522_p3.read());
}

void dense_wrapper::thread_select_ln56_953_fu_40536_p3() {
    select_ln56_953_fu_40536_p3 = (!icmp_ln56_172_reg_43337_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_172_reg_43337_pp0_iter6_reg.read()[0].to_bool())? data_172_V_read186_s_reg_20388_pp0_iter6_reg.read(): select_ln56_952_fu_40529_p3.read());
}

void dense_wrapper::thread_select_ln56_954_fu_40543_p3() {
    select_ln56_954_fu_40543_p3 = (!icmp_ln56_173_reg_43342_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_173_reg_43342_pp0_iter6_reg.read()[0].to_bool())? data_173_V_read187_s_reg_20401_pp0_iter6_reg.read(): select_ln56_953_fu_40536_p3.read());
}

void dense_wrapper::thread_select_ln56_955_fu_40550_p3() {
    select_ln56_955_fu_40550_p3 = (!icmp_ln56_174_reg_43347_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_174_reg_43347_pp0_iter6_reg.read()[0].to_bool())? data_174_V_read188_s_reg_20414_pp0_iter6_reg.read(): select_ln56_954_fu_40543_p3.read());
}

void dense_wrapper::thread_select_ln56_956_fu_40557_p3() {
    select_ln56_956_fu_40557_p3 = (!icmp_ln56_175_reg_43352_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_175_reg_43352_pp0_iter6_reg.read()[0].to_bool())? data_175_V_read189_s_reg_20427_pp0_iter6_reg.read(): select_ln56_955_fu_40550_p3.read());
}

void dense_wrapper::thread_select_ln56_957_fu_40564_p3() {
    select_ln56_957_fu_40564_p3 = (!icmp_ln56_176_reg_43357_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_176_reg_43357_pp0_iter6_reg.read()[0].to_bool())? data_176_V_read190_s_reg_20440_pp0_iter6_reg.read(): select_ln56_956_fu_40557_p3.read());
}

void dense_wrapper::thread_select_ln56_958_fu_40571_p3() {
    select_ln56_958_fu_40571_p3 = (!icmp_ln56_177_reg_43362_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_177_reg_43362_pp0_iter6_reg.read()[0].to_bool())? data_177_V_read191_s_reg_20453_pp0_iter6_reg.read(): select_ln56_957_fu_40564_p3.read());
}

void dense_wrapper::thread_select_ln56_959_fu_40578_p3() {
    select_ln56_959_fu_40578_p3 = (!icmp_ln56_178_reg_43367_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_178_reg_43367_pp0_iter6_reg.read()[0].to_bool())? data_178_V_read192_s_reg_20466_pp0_iter6_reg.read(): select_ln56_958_fu_40571_p3.read());
}

void dense_wrapper::thread_select_ln56_95_fu_32218_p3() {
    select_ln56_95_fu_32218_p3 = (!icmp_ln56_200_fu_29742_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_200_fu_29742_p2.read()[0].to_bool())? ap_phi_mux_data_592_V_read606_s_phi_fu_25852_p4.read(): ap_phi_mux_data_591_V_read605_s_phi_fu_25839_p4.read());
}

void dense_wrapper::thread_select_ln56_960_fu_40585_p3() {
    select_ln56_960_fu_40585_p3 = (!icmp_ln56_179_reg_43372_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_179_reg_43372_pp0_iter6_reg.read()[0].to_bool())? data_179_V_read193_s_reg_20479_pp0_iter6_reg.read(): select_ln56_959_fu_40578_p3.read());
}

void dense_wrapper::thread_select_ln56_961_fu_40592_p3() {
    select_ln56_961_fu_40592_p3 = (!icmp_ln56_180_reg_43377_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_180_reg_43377_pp0_iter6_reg.read()[0].to_bool())? data_180_V_read194_s_reg_20492_pp0_iter6_reg.read(): select_ln56_960_fu_40585_p3.read());
}

void dense_wrapper::thread_select_ln56_962_fu_40599_p3() {
    select_ln56_962_fu_40599_p3 = (!icmp_ln56_181_reg_43382_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_181_reg_43382_pp0_iter6_reg.read()[0].to_bool())? data_181_V_read195_s_reg_20505_pp0_iter6_reg.read(): select_ln56_961_fu_40592_p3.read());
}

void dense_wrapper::thread_select_ln56_963_fu_40606_p3() {
    select_ln56_963_fu_40606_p3 = (!icmp_ln56_182_reg_43387_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_182_reg_43387_pp0_iter6_reg.read()[0].to_bool())? data_182_V_read196_s_reg_20518_pp0_iter6_reg.read(): select_ln56_962_fu_40599_p3.read());
}

void dense_wrapper::thread_select_ln56_964_fu_40613_p3() {
    select_ln56_964_fu_40613_p3 = (!icmp_ln56_183_reg_43392_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_183_reg_43392_pp0_iter6_reg.read()[0].to_bool())? data_183_V_read197_s_reg_20531_pp0_iter6_reg.read(): select_ln56_963_fu_40606_p3.read());
}

void dense_wrapper::thread_select_ln56_965_fu_40620_p3() {
    select_ln56_965_fu_40620_p3 = (!icmp_ln56_184_reg_43397_pp0_iter6_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_184_reg_43397_pp0_iter6_reg.read()[0].to_bool())? data_184_V_read198_s_reg_20544_pp0_iter6_reg.read(): select_ln56_964_fu_40613_p3.read());
}

void dense_wrapper::thread_select_ln56_966_fu_40627_p3() {
    select_ln56_966_fu_40627_p3 = (!icmp_ln56_185_reg_43402_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_185_reg_43402_pp0_iter7_reg.read()[0].to_bool())? data_185_V_read199_s_reg_20557_pp0_iter7_reg.read(): select_ln56_965_reg_44476.read());
}

void dense_wrapper::thread_select_ln56_967_fu_40633_p3() {
    select_ln56_967_fu_40633_p3 = (!icmp_ln56_186_reg_43407_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_186_reg_43407_pp0_iter7_reg.read()[0].to_bool())? data_186_V_read200_s_reg_20570_pp0_iter7_reg.read(): select_ln56_966_fu_40627_p3.read());
}

void dense_wrapper::thread_select_ln56_968_fu_40640_p3() {
    select_ln56_968_fu_40640_p3 = (!icmp_ln56_187_reg_43412_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_187_reg_43412_pp0_iter7_reg.read()[0].to_bool())? data_187_V_read201_s_reg_20583_pp0_iter7_reg.read(): select_ln56_967_fu_40633_p3.read());
}

void dense_wrapper::thread_select_ln56_969_fu_40647_p3() {
    select_ln56_969_fu_40647_p3 = (!icmp_ln56_188_reg_43417_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_188_reg_43417_pp0_iter7_reg.read()[0].to_bool())? data_188_V_read202_s_reg_20596_pp0_iter7_reg.read(): select_ln56_968_fu_40640_p3.read());
}

void dense_wrapper::thread_select_ln56_96_fu_32232_p3() {
    select_ln56_96_fu_32232_p3 = (!icmp_ln56_198_fu_29730_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_198_fu_29730_p2.read()[0].to_bool())? ap_phi_mux_data_590_V_read604_s_phi_fu_25826_p4.read(): ap_phi_mux_data_589_V_read603_s_phi_fu_25813_p4.read());
}

void dense_wrapper::thread_select_ln56_970_fu_40654_p3() {
    select_ln56_970_fu_40654_p3 = (!icmp_ln56_189_reg_43422_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_189_reg_43422_pp0_iter7_reg.read()[0].to_bool())? data_189_V_read203_s_reg_20609_pp0_iter7_reg.read(): select_ln56_969_fu_40647_p3.read());
}

void dense_wrapper::thread_select_ln56_971_fu_40661_p3() {
    select_ln56_971_fu_40661_p3 = (!icmp_ln56_190_reg_43427_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_190_reg_43427_pp0_iter7_reg.read()[0].to_bool())? data_190_V_read204_s_reg_20622_pp0_iter7_reg.read(): select_ln56_970_fu_40654_p3.read());
}

void dense_wrapper::thread_select_ln56_972_fu_40668_p3() {
    select_ln56_972_fu_40668_p3 = (!icmp_ln56_191_reg_43432_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_191_reg_43432_pp0_iter7_reg.read()[0].to_bool())? data_191_V_read205_s_reg_20635_pp0_iter7_reg.read(): select_ln56_971_fu_40661_p3.read());
}

void dense_wrapper::thread_select_ln56_973_fu_40675_p3() {
    select_ln56_973_fu_40675_p3 = (!icmp_ln56_192_reg_43437_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_192_reg_43437_pp0_iter7_reg.read()[0].to_bool())? data_192_V_read206_s_reg_20648_pp0_iter7_reg.read(): select_ln56_972_fu_40668_p3.read());
}

void dense_wrapper::thread_select_ln56_974_fu_40682_p3() {
    select_ln56_974_fu_40682_p3 = (!icmp_ln56_193_reg_43442_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_193_reg_43442_pp0_iter7_reg.read()[0].to_bool())? data_193_V_read207_s_reg_20661_pp0_iter7_reg.read(): select_ln56_973_fu_40675_p3.read());
}

void dense_wrapper::thread_select_ln56_975_fu_40689_p3() {
    select_ln56_975_fu_40689_p3 = (!icmp_ln56_194_reg_43447_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_194_reg_43447_pp0_iter7_reg.read()[0].to_bool())? data_194_V_read208_s_reg_20674_pp0_iter7_reg.read(): select_ln56_974_fu_40682_p3.read());
}

void dense_wrapper::thread_select_ln56_976_fu_40696_p3() {
    select_ln56_976_fu_40696_p3 = (!icmp_ln56_195_reg_43452_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_195_reg_43452_pp0_iter7_reg.read()[0].to_bool())? data_195_V_read209_s_reg_20687_pp0_iter7_reg.read(): select_ln56_975_fu_40689_p3.read());
}

void dense_wrapper::thread_select_ln56_977_fu_40703_p3() {
    select_ln56_977_fu_40703_p3 = (!icmp_ln56_196_reg_43457_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_196_reg_43457_pp0_iter7_reg.read()[0].to_bool())? data_196_V_read210_s_reg_20700_pp0_iter7_reg.read(): select_ln56_976_fu_40696_p3.read());
}

void dense_wrapper::thread_select_ln56_978_fu_40710_p3() {
    select_ln56_978_fu_40710_p3 = (!icmp_ln56_197_reg_43462_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_197_reg_43462_pp0_iter7_reg.read()[0].to_bool())? data_197_V_read211_s_reg_20713_pp0_iter7_reg.read(): select_ln56_977_fu_40703_p3.read());
}

void dense_wrapper::thread_select_ln56_979_fu_40717_p3() {
    select_ln56_979_fu_40717_p3 = (!icmp_ln56_198_reg_43467_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_198_reg_43467_pp0_iter7_reg.read()[0].to_bool())? data_198_V_read212_s_reg_20726_pp0_iter7_reg.read(): select_ln56_978_fu_40710_p3.read());
}

void dense_wrapper::thread_select_ln56_97_fu_32246_p3() {
    select_ln56_97_fu_32246_p3 = (!icmp_ln56_196_fu_29718_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_196_fu_29718_p2.read()[0].to_bool())? ap_phi_mux_data_588_V_read602_s_phi_fu_25800_p4.read(): ap_phi_mux_data_587_V_read601_s_phi_fu_25787_p4.read());
}

void dense_wrapper::thread_select_ln56_980_fu_40724_p3() {
    select_ln56_980_fu_40724_p3 = (!icmp_ln56_199_reg_43472_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_199_reg_43472_pp0_iter7_reg.read()[0].to_bool())? data_199_V_read213_s_reg_20739_pp0_iter7_reg.read(): select_ln56_979_fu_40717_p3.read());
}

void dense_wrapper::thread_select_ln56_981_fu_40731_p3() {
    select_ln56_981_fu_40731_p3 = (!icmp_ln56_200_reg_43477_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_200_reg_43477_pp0_iter7_reg.read()[0].to_bool())? data_200_V_read214_s_reg_20752_pp0_iter7_reg.read(): select_ln56_980_fu_40724_p3.read());
}

void dense_wrapper::thread_select_ln56_982_fu_40738_p3() {
    select_ln56_982_fu_40738_p3 = (!icmp_ln56_201_reg_43482_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_201_reg_43482_pp0_iter7_reg.read()[0].to_bool())? data_201_V_read215_s_reg_20765_pp0_iter7_reg.read(): select_ln56_981_fu_40731_p3.read());
}

void dense_wrapper::thread_select_ln56_983_fu_40745_p3() {
    select_ln56_983_fu_40745_p3 = (!icmp_ln56_202_reg_43487_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_202_reg_43487_pp0_iter7_reg.read()[0].to_bool())? data_202_V_read216_s_reg_20778_pp0_iter7_reg.read(): select_ln56_982_fu_40738_p3.read());
}

void dense_wrapper::thread_select_ln56_984_fu_40752_p3() {
    select_ln56_984_fu_40752_p3 = (!icmp_ln56_203_reg_43492_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_203_reg_43492_pp0_iter7_reg.read()[0].to_bool())? data_203_V_read217_s_reg_20791_pp0_iter7_reg.read(): select_ln56_983_fu_40745_p3.read());
}

void dense_wrapper::thread_select_ln56_985_fu_40759_p3() {
    select_ln56_985_fu_40759_p3 = (!icmp_ln56_204_reg_43497_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_204_reg_43497_pp0_iter7_reg.read()[0].to_bool())? data_204_V_read218_s_reg_20804_pp0_iter7_reg.read(): select_ln56_984_fu_40752_p3.read());
}

void dense_wrapper::thread_select_ln56_986_fu_40766_p3() {
    select_ln56_986_fu_40766_p3 = (!icmp_ln56_205_reg_43502_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_205_reg_43502_pp0_iter7_reg.read()[0].to_bool())? data_205_V_read219_s_reg_20817_pp0_iter7_reg.read(): select_ln56_985_fu_40759_p3.read());
}

void dense_wrapper::thread_select_ln56_987_fu_40773_p3() {
    select_ln56_987_fu_40773_p3 = (!icmp_ln56_206_reg_43507_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_206_reg_43507_pp0_iter7_reg.read()[0].to_bool())? data_206_V_read220_s_reg_20830_pp0_iter7_reg.read(): select_ln56_986_fu_40766_p3.read());
}

void dense_wrapper::thread_select_ln56_988_fu_40780_p3() {
    select_ln56_988_fu_40780_p3 = (!icmp_ln56_207_reg_43512_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_207_reg_43512_pp0_iter7_reg.read()[0].to_bool())? data_207_V_read221_s_reg_20843_pp0_iter7_reg.read(): select_ln56_987_fu_40773_p3.read());
}

void dense_wrapper::thread_select_ln56_989_fu_40787_p3() {
    select_ln56_989_fu_40787_p3 = (!icmp_ln56_208_reg_43517_pp0_iter7_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_208_reg_43517_pp0_iter7_reg.read()[0].to_bool())? data_208_V_read222_s_reg_20856_pp0_iter7_reg.read(): select_ln56_988_fu_40780_p3.read());
}

void dense_wrapper::thread_select_ln56_98_fu_32260_p3() {
    select_ln56_98_fu_32260_p3 = (!icmp_ln56_194_fu_29706_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_194_fu_29706_p2.read()[0].to_bool())? ap_phi_mux_data_586_V_read600_s_phi_fu_25774_p4.read(): ap_phi_mux_data_585_V_read599_s_phi_fu_25761_p4.read());
}

void dense_wrapper::thread_select_ln56_990_fu_40794_p3() {
    select_ln56_990_fu_40794_p3 = (!icmp_ln56_209_reg_43522_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_209_reg_43522_pp0_iter8_reg.read()[0].to_bool())? data_209_V_read223_s_reg_20869_pp0_iter8_reg.read(): select_ln56_989_reg_44481.read());
}

void dense_wrapper::thread_select_ln56_991_fu_40800_p3() {
    select_ln56_991_fu_40800_p3 = (!icmp_ln56_210_reg_43527_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_210_reg_43527_pp0_iter8_reg.read()[0].to_bool())? data_210_V_read224_s_reg_20882_pp0_iter8_reg.read(): select_ln56_990_fu_40794_p3.read());
}

void dense_wrapper::thread_select_ln56_992_fu_40807_p3() {
    select_ln56_992_fu_40807_p3 = (!icmp_ln56_211_reg_43532_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_211_reg_43532_pp0_iter8_reg.read()[0].to_bool())? data_211_V_read225_s_reg_20895_pp0_iter8_reg.read(): select_ln56_991_fu_40800_p3.read());
}

void dense_wrapper::thread_select_ln56_993_fu_40814_p3() {
    select_ln56_993_fu_40814_p3 = (!icmp_ln56_212_reg_43537_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_212_reg_43537_pp0_iter8_reg.read()[0].to_bool())? data_212_V_read226_s_reg_20908_pp0_iter8_reg.read(): select_ln56_992_fu_40807_p3.read());
}

void dense_wrapper::thread_select_ln56_994_fu_40821_p3() {
    select_ln56_994_fu_40821_p3 = (!icmp_ln56_213_reg_43542_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_213_reg_43542_pp0_iter8_reg.read()[0].to_bool())? data_213_V_read227_s_reg_20921_pp0_iter8_reg.read(): select_ln56_993_fu_40814_p3.read());
}

void dense_wrapper::thread_select_ln56_995_fu_40828_p3() {
    select_ln56_995_fu_40828_p3 = (!icmp_ln56_214_reg_43547_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_214_reg_43547_pp0_iter8_reg.read()[0].to_bool())? data_214_V_read228_s_reg_20934_pp0_iter8_reg.read(): select_ln56_994_fu_40821_p3.read());
}

void dense_wrapper::thread_select_ln56_996_fu_40835_p3() {
    select_ln56_996_fu_40835_p3 = (!icmp_ln56_215_reg_43552_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_215_reg_43552_pp0_iter8_reg.read()[0].to_bool())? data_215_V_read229_s_reg_20947_pp0_iter8_reg.read(): select_ln56_995_fu_40828_p3.read());
}

void dense_wrapper::thread_select_ln56_997_fu_40842_p3() {
    select_ln56_997_fu_40842_p3 = (!icmp_ln56_216_reg_43557_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_216_reg_43557_pp0_iter8_reg.read()[0].to_bool())? data_216_V_read230_s_reg_20960_pp0_iter8_reg.read(): select_ln56_996_fu_40835_p3.read());
}

void dense_wrapper::thread_select_ln56_998_fu_40849_p3() {
    select_ln56_998_fu_40849_p3 = (!icmp_ln56_217_reg_43562_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_217_reg_43562_pp0_iter8_reg.read()[0].to_bool())? data_217_V_read231_s_reg_20973_pp0_iter8_reg.read(): select_ln56_997_fu_40842_p3.read());
}

void dense_wrapper::thread_select_ln56_999_fu_40856_p3() {
    select_ln56_999_fu_40856_p3 = (!icmp_ln56_218_reg_43567_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_218_reg_43567_pp0_iter8_reg.read()[0].to_bool())? data_218_V_read232_s_reg_20986_pp0_iter8_reg.read(): select_ln56_998_fu_40849_p3.read());
}

void dense_wrapper::thread_select_ln56_99_fu_32274_p3() {
    select_ln56_99_fu_32274_p3 = (!icmp_ln56_192_fu_29694_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_192_fu_29694_p2.read()[0].to_bool())? ap_phi_mux_data_584_V_read598_s_phi_fu_25748_p4.read(): ap_phi_mux_data_583_V_read597_s_phi_fu_25735_p4.read());
}

void dense_wrapper::thread_select_ln56_9_fu_31014_p3() {
    select_ln56_9_fu_31014_p3 = (!icmp_ln56_372_fu_30774_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_372_fu_30774_p2.read()[0].to_bool())? ap_phi_mux_data_764_V_read778_s_phi_fu_28088_p4.read(): ap_phi_mux_data_763_V_read777_s_phi_fu_28075_p4.read());
}

void dense_wrapper::thread_select_ln56_fu_30888_p3() {
    select_ln56_fu_30888_p3 = (!icmp_ln56_390_fu_30882_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_390_fu_30882_p2.read()[0].to_bool())? ap_phi_mux_data_782_V_read796_s_phi_fu_28322_p4.read(): ap_phi_mux_data_781_V_read795_s_phi_fu_28309_p4.read());
}

void dense_wrapper::thread_sext_ln1116_1_fu_42086_p1() {
    sext_ln1116_1_fu_42086_p1 = esl_sext<22,16>(select_ln56_390_reg_44432_pp0_iter16_reg.read());
}

void dense_wrapper::thread_sext_ln1116_2_fu_42103_p1() {
    sext_ln1116_2_fu_42103_p1 = esl_sext<22,16>(select_ln56_781_reg_44437_pp0_iter16_reg.read());
}

void dense_wrapper::thread_sext_ln703_10_fu_42271_p1() {
    sext_ln703_10_fu_42271_p1 = esl_sext<24,23>(shl_ln728_3_fu_42264_p3.read());
}

void dense_wrapper::thread_sext_ln703_11_fu_42286_p1() {
    sext_ln703_11_fu_42286_p1 = esl_sext<32,24>(add_ln703_4_fu_42280_p2.read());
}

void dense_wrapper::thread_sext_ln703_12_fu_42315_p1() {
    sext_ln703_12_fu_42315_p1 = esl_sext<24,23>(shl_ln728_4_fu_42308_p3.read());
}

void dense_wrapper::thread_sext_ln703_13_fu_42335_p1() {
    sext_ln703_13_fu_42335_p1 = esl_sext<24,23>(shl_ln728_5_fu_42328_p3.read());
}

void dense_wrapper::thread_sext_ln703_14_fu_42350_p1() {
    sext_ln703_14_fu_42350_p1 = esl_sext<32,24>(add_ln703_8_fu_42344_p2.read());
}

void dense_wrapper::thread_sext_ln703_15_fu_42379_p1() {
    sext_ln703_15_fu_42379_p1 = esl_sext<24,23>(shl_ln728_6_fu_42372_p3.read());
}

void dense_wrapper::thread_sext_ln703_16_fu_42399_p1() {
    sext_ln703_16_fu_42399_p1 = esl_sext<24,23>(shl_ln728_7_fu_42392_p3.read());
}

void dense_wrapper::thread_sext_ln703_17_fu_42414_p1() {
    sext_ln703_17_fu_42414_p1 = esl_sext<32,24>(add_ln703_12_fu_42408_p2.read());
}

void dense_wrapper::thread_sext_ln703_7_fu_42207_p1() {
    sext_ln703_7_fu_42207_p1 = esl_sext<24,23>(shl_ln728_1_fu_42200_p3.read());
}

void dense_wrapper::thread_sext_ln703_8_fu_42222_p1() {
    sext_ln703_8_fu_42222_p1 = esl_sext<32,24>(add_ln703_fu_42216_p2.read());
}

void dense_wrapper::thread_sext_ln703_9_fu_42251_p1() {
    sext_ln703_9_fu_42251_p1 = esl_sext<24,23>(shl_ln728_2_fu_42244_p3.read());
}

void dense_wrapper::thread_sext_ln703_fu_42187_p1() {
    sext_ln703_fu_42187_p1 = esl_sext<24,23>(shl_ln_fu_42180_p3.read());
}

void dense_wrapper::thread_shl_ln703_1_fu_42211_p2() {
    shl_ln703_1_fu_42211_p2 = (!ap_const_lv22_1.is_01())? sc_lv<22>(): mul_ln1118_4_reg_44537.read() << (unsigned short)ap_const_lv22_1.to_uint();
}

void dense_wrapper::thread_shl_ln703_2_fu_42255_p2() {
    shl_ln703_2_fu_42255_p2 = (!ap_const_lv22_1.is_01())? sc_lv<22>(): mul_ln1118_5_reg_44543.read() << (unsigned short)ap_const_lv22_1.to_uint();
}

void dense_wrapper::thread_shl_ln703_3_fu_42275_p2() {
    shl_ln703_3_fu_42275_p2 = (!ap_const_lv22_1.is_01())? sc_lv<22>(): mul_ln1118_6_reg_44549.read() << (unsigned short)ap_const_lv22_1.to_uint();
}

void dense_wrapper::thread_shl_ln703_4_fu_42319_p2() {
    shl_ln703_4_fu_42319_p2 = (!ap_const_lv22_1.is_01())? sc_lv<22>(): mul_ln1118_7_reg_44555.read() << (unsigned short)ap_const_lv22_1.to_uint();
}

void dense_wrapper::thread_shl_ln703_5_fu_42339_p2() {
    shl_ln703_5_fu_42339_p2 = (!ap_const_lv22_1.is_01())? sc_lv<22>(): mul_ln1118_8_reg_44561.read() << (unsigned short)ap_const_lv22_1.to_uint();
}

void dense_wrapper::thread_shl_ln703_6_fu_42383_p2() {
    shl_ln703_6_fu_42383_p2 = (!ap_const_lv22_1.is_01())? sc_lv<22>(): mul_ln1118_9_reg_44567.read() << (unsigned short)ap_const_lv22_1.to_uint();
}

void dense_wrapper::thread_shl_ln703_7_fu_42403_p2() {
    shl_ln703_7_fu_42403_p2 = (!ap_const_lv22_1.is_01())? sc_lv<22>(): mul_ln1118_10_reg_44573.read() << (unsigned short)ap_const_lv22_1.to_uint();
}

void dense_wrapper::thread_shl_ln703_fu_42195_p2() {
    shl_ln703_fu_42195_p2 = (!ap_const_lv22_1.is_01())? sc_lv<22>(): mul_ln1118_reg_44531.read() << (unsigned short)ap_const_lv22_1.to_uint();
}

void dense_wrapper::thread_shl_ln728_1_fu_42200_p3() {
    shl_ln728_1_fu_42200_p3 = esl_concat<22,1>(mul_ln1118_4_reg_44537.read(), ap_const_lv1_0);
}

void dense_wrapper::thread_shl_ln728_2_fu_42244_p3() {
    shl_ln728_2_fu_42244_p3 = esl_concat<22,1>(mul_ln1118_5_reg_44543.read(), ap_const_lv1_0);
}

void dense_wrapper::thread_shl_ln728_3_fu_42264_p3() {
    shl_ln728_3_fu_42264_p3 = esl_concat<22,1>(mul_ln1118_6_reg_44549.read(), ap_const_lv1_0);
}

void dense_wrapper::thread_shl_ln728_4_fu_42308_p3() {
    shl_ln728_4_fu_42308_p3 = esl_concat<22,1>(mul_ln1118_7_reg_44555.read(), ap_const_lv1_0);
}

void dense_wrapper::thread_shl_ln728_5_fu_42328_p3() {
    shl_ln728_5_fu_42328_p3 = esl_concat<22,1>(mul_ln1118_8_reg_44561.read(), ap_const_lv1_0);
}

void dense_wrapper::thread_shl_ln728_6_fu_42372_p3() {
    shl_ln728_6_fu_42372_p3 = esl_concat<22,1>(mul_ln1118_9_reg_44567.read(), ap_const_lv1_0);
}

void dense_wrapper::thread_shl_ln728_7_fu_42392_p3() {
    shl_ln728_7_fu_42392_p3 = esl_concat<22,1>(mul_ln1118_10_reg_44573.read(), ap_const_lv1_0);
}

void dense_wrapper::thread_shl_ln_fu_42180_p3() {
    shl_ln_fu_42180_p3 = esl_concat<22,1>(mul_ln1118_reg_44531.read(), ap_const_lv1_0);
}

void dense_wrapper::thread_tmp_1_fu_42076_p4() {
    tmp_1_fu_42076_p4 = w11_V_q0.read().range(11, 6);
}

void dense_wrapper::thread_tmp_2_fu_42093_p4() {
    tmp_2_fu_42093_p4 = w11_V_q0.read().range(17, 12);
}

void dense_wrapper::thread_tmp_3_fu_42110_p4() {
    tmp_3_fu_42110_p4 = w11_V_q0.read().range(23, 18);
}

void dense_wrapper::thread_tmp_4_fu_42124_p4() {
    tmp_4_fu_42124_p4 = w11_V_q0.read().range(29, 24);
}

void dense_wrapper::thread_tmp_5_fu_42138_p4() {
    tmp_5_fu_42138_p4 = w11_V_q0.read().range(35, 30);
}

void dense_wrapper::thread_tmp_6_fu_42152_p4() {
    tmp_6_fu_42152_p4 = w11_V_q0.read().range(41, 36);
}

void dense_wrapper::thread_tmp_7_fu_42166_p4() {
    tmp_7_fu_42166_p4 = w11_V_q0.read().range(47, 42);
}

void dense_wrapper::thread_trunc_ln56_fu_42065_p1() {
    trunc_ln56_fu_42065_p1 = w11_V_q0.read().range(6-1, 0);
}

void dense_wrapper::thread_trunc_ln703_1_fu_42260_p1() {
    trunc_ln703_1_fu_42260_p1 = acc_V_1_06_reg_28372.read().range(22-1, 0);
}

void dense_wrapper::thread_trunc_ln703_2_fu_42324_p1() {
    trunc_ln703_2_fu_42324_p1 = acc_V_2_07_reg_28358.read().range(22-1, 0);
}

void dense_wrapper::thread_trunc_ln703_3_fu_42388_p1() {
    trunc_ln703_3_fu_42388_p1 = acc_V_3_08_reg_28344.read().range(22-1, 0);
}

void dense_wrapper::thread_trunc_ln703_fu_42191_p1() {
    trunc_ln703_fu_42191_p1 = acc_V_0_05_reg_28386.read().range(22-1, 0);
}

void dense_wrapper::thread_w11_V_address0() {
    w11_V_address0 =  (sc_lv<9>) (zext_ln56_fu_42060_p1.read());
}

void dense_wrapper::thread_w11_V_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter16.read()))) {
        w11_V_ce0 = ap_const_logic_1;
    } else {
        w11_V_ce0 = ap_const_logic_0;
    }
}

void dense_wrapper::thread_w_index_fu_28400_p2() {
    w_index_fu_28400_p2 = (!ap_const_lv9_1.is_01() || !ap_phi_mux_w_index13_phi_fu_18141_p6.read().is_01())? sc_lv<9>(): (sc_biguint<9>(ap_const_lv9_1) + sc_biguint<9>(ap_phi_mux_w_index13_phi_fu_18141_p6.read()));
}

void dense_wrapper::thread_zext_ln56_fu_42060_p1() {
    zext_ln56_fu_42060_p1 = esl_zext<64,9>(w_index13_reg_18137_pp0_iter15_reg.read());
}

}

