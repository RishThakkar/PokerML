#include "dense_wrapper.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper::thread_or_ln56_275_fu_34754_p2() {
    or_ln56_275_fu_34754_p2 = (or_ln56_160_fu_33136_p2.read() | or_ln56_161_fu_33150_p2.read());
}

void dense_wrapper::thread_or_ln56_276_fu_34768_p2() {
    or_ln56_276_fu_34768_p2 = (or_ln56_162_fu_33164_p2.read() | or_ln56_163_fu_33178_p2.read());
}

void dense_wrapper::thread_or_ln56_277_fu_34782_p2() {
    or_ln56_277_fu_34782_p2 = (or_ln56_164_fu_33192_p2.read() | or_ln56_165_fu_33206_p2.read());
}

void dense_wrapper::thread_or_ln56_278_fu_34796_p2() {
    or_ln56_278_fu_34796_p2 = (or_ln56_166_fu_33220_p2.read() | or_ln56_167_fu_33234_p2.read());
}

void dense_wrapper::thread_or_ln56_279_fu_34810_p2() {
    or_ln56_279_fu_34810_p2 = (or_ln56_168_fu_33248_p2.read() | or_ln56_169_fu_33262_p2.read());
}

void dense_wrapper::thread_or_ln56_27_fu_31274_p2() {
    or_ln56_27_fu_31274_p2 = (icmp_ln56_336_fu_30558_p2.read() | icmp_ln56_335_fu_30552_p2.read());
}

void dense_wrapper::thread_or_ln56_280_fu_34824_p2() {
    or_ln56_280_fu_34824_p2 = (or_ln56_170_fu_33276_p2.read() | or_ln56_171_fu_33290_p2.read());
}

void dense_wrapper::thread_or_ln56_281_fu_34838_p2() {
    or_ln56_281_fu_34838_p2 = (or_ln56_172_fu_33304_p2.read() | or_ln56_173_fu_33318_p2.read());
}

void dense_wrapper::thread_or_ln56_282_fu_34852_p2() {
    or_ln56_282_fu_34852_p2 = (or_ln56_174_fu_33332_p2.read() | or_ln56_175_fu_33346_p2.read());
}

void dense_wrapper::thread_or_ln56_283_fu_34866_p2() {
    or_ln56_283_fu_34866_p2 = (or_ln56_176_fu_33360_p2.read() | or_ln56_177_fu_33374_p2.read());
}

void dense_wrapper::thread_or_ln56_284_fu_34880_p2() {
    or_ln56_284_fu_34880_p2 = (or_ln56_178_fu_33388_p2.read() | or_ln56_179_fu_33402_p2.read());
}

void dense_wrapper::thread_or_ln56_285_fu_34894_p2() {
    or_ln56_285_fu_34894_p2 = (or_ln56_180_fu_33416_p2.read() | or_ln56_181_fu_33430_p2.read());
}

void dense_wrapper::thread_or_ln56_286_fu_34908_p2() {
    or_ln56_286_fu_34908_p2 = (or_ln56_182_fu_33444_p2.read() | or_ln56_183_fu_33458_p2.read());
}

void dense_wrapper::thread_or_ln56_287_fu_34922_p2() {
    or_ln56_287_fu_34922_p2 = (or_ln56_184_fu_33472_p2.read() | or_ln56_185_fu_33486_p2.read());
}

void dense_wrapper::thread_or_ln56_288_fu_34936_p2() {
    or_ln56_288_fu_34936_p2 = (or_ln56_186_fu_33500_p2.read() | or_ln56_187_fu_33514_p2.read());
}

void dense_wrapper::thread_or_ln56_289_fu_34950_p2() {
    or_ln56_289_fu_34950_p2 = (or_ln56_188_fu_33528_p2.read() | or_ln56_189_fu_33542_p2.read());
}

void dense_wrapper::thread_or_ln56_28_fu_31288_p2() {
    or_ln56_28_fu_31288_p2 = (icmp_ln56_334_fu_30546_p2.read() | icmp_ln56_333_fu_30540_p2.read());
}

void dense_wrapper::thread_or_ln56_290_fu_34964_p2() {
    or_ln56_290_fu_34964_p2 = (or_ln56_190_fu_33556_p2.read() | or_ln56_191_fu_33570_p2.read());
}

void dense_wrapper::thread_or_ln56_291_fu_34978_p2() {
    or_ln56_291_fu_34978_p2 = (or_ln56_192_fu_33584_p2.read() | or_ln56_193_fu_33598_p2.read());
}

void dense_wrapper::thread_or_ln56_292_fu_35000_p2() {
    or_ln56_292_fu_35000_p2 = (or_ln56_195_fu_33634_p2.read() | or_ln56_196_fu_33648_p2.read());
}

void dense_wrapper::thread_or_ln56_293_fu_35014_p2() {
    or_ln56_293_fu_35014_p2 = (or_ln56_197_fu_33662_p2.read() | or_ln56_198_fu_33676_p2.read());
}

void dense_wrapper::thread_or_ln56_294_fu_35028_p2() {
    or_ln56_294_fu_35028_p2 = (or_ln56_199_fu_33690_p2.read() | or_ln56_200_fu_33704_p2.read());
}

void dense_wrapper::thread_or_ln56_295_fu_35042_p2() {
    or_ln56_295_fu_35042_p2 = (or_ln56_201_fu_33718_p2.read() | or_ln56_202_fu_33732_p2.read());
}

void dense_wrapper::thread_or_ln56_296_fu_35056_p2() {
    or_ln56_296_fu_35056_p2 = (or_ln56_203_fu_33746_p2.read() | or_ln56_204_fu_33760_p2.read());
}

void dense_wrapper::thread_or_ln56_297_fu_35070_p2() {
    or_ln56_297_fu_35070_p2 = (or_ln56_205_fu_33774_p2.read() | or_ln56_206_fu_33788_p2.read());
}

void dense_wrapper::thread_or_ln56_298_fu_35084_p2() {
    or_ln56_298_fu_35084_p2 = (or_ln56_207_fu_33802_p2.read() | or_ln56_208_fu_33816_p2.read());
}

void dense_wrapper::thread_or_ln56_299_fu_35098_p2() {
    or_ln56_299_fu_35098_p2 = (or_ln56_209_fu_33830_p2.read() | or_ln56_210_fu_33844_p2.read());
}

void dense_wrapper::thread_or_ln56_29_fu_31302_p2() {
    or_ln56_29_fu_31302_p2 = (icmp_ln56_332_fu_30534_p2.read() | icmp_ln56_331_fu_30528_p2.read());
}

void dense_wrapper::thread_or_ln56_2_fu_30924_p2() {
    or_ln56_2_fu_30924_p2 = (icmp_ln56_386_fu_30858_p2.read() | icmp_ln56_385_fu_30852_p2.read());
}

void dense_wrapper::thread_or_ln56_300_fu_35112_p2() {
    or_ln56_300_fu_35112_p2 = (or_ln56_211_fu_33858_p2.read() | or_ln56_212_fu_33872_p2.read());
}

void dense_wrapper::thread_or_ln56_301_fu_35126_p2() {
    or_ln56_301_fu_35126_p2 = (or_ln56_213_fu_33886_p2.read() | or_ln56_214_fu_33900_p2.read());
}

void dense_wrapper::thread_or_ln56_302_fu_35140_p2() {
    or_ln56_302_fu_35140_p2 = (or_ln56_215_fu_33914_p2.read() | or_ln56_216_fu_33928_p2.read());
}

void dense_wrapper::thread_or_ln56_303_fu_35154_p2() {
    or_ln56_303_fu_35154_p2 = (or_ln56_217_fu_33942_p2.read() | or_ln56_218_fu_33956_p2.read());
}

void dense_wrapper::thread_or_ln56_304_fu_35168_p2() {
    or_ln56_304_fu_35168_p2 = (or_ln56_219_fu_33970_p2.read() | or_ln56_220_fu_33984_p2.read());
}

void dense_wrapper::thread_or_ln56_305_fu_35182_p2() {
    or_ln56_305_fu_35182_p2 = (or_ln56_221_fu_33998_p2.read() | or_ln56_222_fu_34012_p2.read());
}

void dense_wrapper::thread_or_ln56_306_fu_35196_p2() {
    or_ln56_306_fu_35196_p2 = (or_ln56_223_fu_34026_p2.read() | or_ln56_224_fu_34040_p2.read());
}

void dense_wrapper::thread_or_ln56_307_fu_35210_p2() {
    or_ln56_307_fu_35210_p2 = (or_ln56_225_fu_34054_p2.read() | or_ln56_226_fu_34068_p2.read());
}

void dense_wrapper::thread_or_ln56_308_fu_35224_p2() {
    or_ln56_308_fu_35224_p2 = (or_ln56_227_fu_34082_p2.read() | or_ln56_228_fu_34096_p2.read());
}

void dense_wrapper::thread_or_ln56_309_fu_35238_p2() {
    or_ln56_309_fu_35238_p2 = (or_ln56_229_fu_34110_p2.read() | or_ln56_230_fu_34124_p2.read());
}

void dense_wrapper::thread_or_ln56_30_fu_31316_p2() {
    or_ln56_30_fu_31316_p2 = (icmp_ln56_330_fu_30522_p2.read() | icmp_ln56_329_fu_30516_p2.read());
}

void dense_wrapper::thread_or_ln56_310_fu_35252_p2() {
    or_ln56_310_fu_35252_p2 = (or_ln56_231_fu_34138_p2.read() | or_ln56_232_fu_34152_p2.read());
}

void dense_wrapper::thread_or_ln56_311_fu_35266_p2() {
    or_ln56_311_fu_35266_p2 = (or_ln56_233_fu_34166_p2.read() | or_ln56_234_fu_34180_p2.read());
}

void dense_wrapper::thread_or_ln56_312_fu_35280_p2() {
    or_ln56_312_fu_35280_p2 = (or_ln56_235_fu_34194_p2.read() | or_ln56_236_fu_34208_p2.read());
}

void dense_wrapper::thread_or_ln56_313_fu_35294_p2() {
    or_ln56_313_fu_35294_p2 = (or_ln56_237_fu_34222_p2.read() | or_ln56_238_fu_34236_p2.read());
}

void dense_wrapper::thread_or_ln56_314_fu_35308_p2() {
    or_ln56_314_fu_35308_p2 = (or_ln56_239_fu_34250_p2.read() | or_ln56_240_fu_34264_p2.read());
}

void dense_wrapper::thread_or_ln56_315_fu_35322_p2() {
    or_ln56_315_fu_35322_p2 = (or_ln56_241_fu_34278_p2.read() | or_ln56_242_fu_34292_p2.read());
}

void dense_wrapper::thread_or_ln56_316_fu_35336_p2() {
    or_ln56_316_fu_35336_p2 = (or_ln56_243_fu_34306_p2.read() | or_ln56_244_fu_34320_p2.read());
}

void dense_wrapper::thread_or_ln56_317_fu_35350_p2() {
    or_ln56_317_fu_35350_p2 = (or_ln56_245_fu_34334_p2.read() | or_ln56_246_fu_34348_p2.read());
}

void dense_wrapper::thread_or_ln56_318_fu_35364_p2() {
    or_ln56_318_fu_35364_p2 = (or_ln56_247_fu_34362_p2.read() | or_ln56_248_fu_34376_p2.read());
}

void dense_wrapper::thread_or_ln56_319_fu_35378_p2() {
    or_ln56_319_fu_35378_p2 = (or_ln56_249_fu_34390_p2.read() | or_ln56_250_fu_34404_p2.read());
}

void dense_wrapper::thread_or_ln56_31_fu_31330_p2() {
    or_ln56_31_fu_31330_p2 = (icmp_ln56_328_fu_30510_p2.read() | icmp_ln56_327_fu_30504_p2.read());
}

void dense_wrapper::thread_or_ln56_320_fu_35392_p2() {
    or_ln56_320_fu_35392_p2 = (or_ln56_251_fu_34418_p2.read() | or_ln56_252_fu_34432_p2.read());
}

void dense_wrapper::thread_or_ln56_321_fu_35406_p2() {
    or_ln56_321_fu_35406_p2 = (or_ln56_253_fu_34446_p2.read() | or_ln56_254_fu_34460_p2.read());
}

void dense_wrapper::thread_or_ln56_322_fu_35420_p2() {
    or_ln56_322_fu_35420_p2 = (or_ln56_255_fu_34474_p2.read() | or_ln56_256_fu_34488_p2.read());
}

void dense_wrapper::thread_or_ln56_323_fu_35434_p2() {
    or_ln56_323_fu_35434_p2 = (or_ln56_257_fu_34502_p2.read() | or_ln56_258_fu_34516_p2.read());
}

void dense_wrapper::thread_or_ln56_324_fu_35448_p2() {
    or_ln56_324_fu_35448_p2 = (or_ln56_259_fu_34530_p2.read() | or_ln56_260_fu_34544_p2.read());
}

void dense_wrapper::thread_or_ln56_325_fu_35462_p2() {
    or_ln56_325_fu_35462_p2 = (or_ln56_261_fu_34558_p2.read() | or_ln56_262_fu_34572_p2.read());
}

void dense_wrapper::thread_or_ln56_326_fu_35476_p2() {
    or_ln56_326_fu_35476_p2 = (or_ln56_263_fu_34586_p2.read() | or_ln56_264_fu_34600_p2.read());
}

void dense_wrapper::thread_or_ln56_327_fu_35490_p2() {
    or_ln56_327_fu_35490_p2 = (or_ln56_265_fu_34614_p2.read() | or_ln56_266_fu_34628_p2.read());
}

void dense_wrapper::thread_or_ln56_328_fu_35504_p2() {
    or_ln56_328_fu_35504_p2 = (or_ln56_267_fu_34642_p2.read() | or_ln56_268_fu_34656_p2.read());
}

void dense_wrapper::thread_or_ln56_329_fu_35518_p2() {
    or_ln56_329_fu_35518_p2 = (or_ln56_269_fu_34670_p2.read() | or_ln56_270_fu_34684_p2.read());
}

void dense_wrapper::thread_or_ln56_32_fu_31344_p2() {
    or_ln56_32_fu_31344_p2 = (icmp_ln56_326_fu_30498_p2.read() | icmp_ln56_325_fu_30492_p2.read());
}

void dense_wrapper::thread_or_ln56_330_fu_35532_p2() {
    or_ln56_330_fu_35532_p2 = (or_ln56_271_fu_34698_p2.read() | or_ln56_272_fu_34712_p2.read());
}

void dense_wrapper::thread_or_ln56_331_fu_35546_p2() {
    or_ln56_331_fu_35546_p2 = (or_ln56_273_fu_34726_p2.read() | or_ln56_274_fu_34740_p2.read());
}

void dense_wrapper::thread_or_ln56_332_fu_35560_p2() {
    or_ln56_332_fu_35560_p2 = (or_ln56_275_fu_34754_p2.read() | or_ln56_276_fu_34768_p2.read());
}

void dense_wrapper::thread_or_ln56_333_fu_35574_p2() {
    or_ln56_333_fu_35574_p2 = (or_ln56_277_fu_34782_p2.read() | or_ln56_278_fu_34796_p2.read());
}

void dense_wrapper::thread_or_ln56_334_fu_35588_p2() {
    or_ln56_334_fu_35588_p2 = (or_ln56_279_fu_34810_p2.read() | or_ln56_280_fu_34824_p2.read());
}

void dense_wrapper::thread_or_ln56_335_fu_35602_p2() {
    or_ln56_335_fu_35602_p2 = (or_ln56_281_fu_34838_p2.read() | or_ln56_282_fu_34852_p2.read());
}

void dense_wrapper::thread_or_ln56_336_fu_35616_p2() {
    or_ln56_336_fu_35616_p2 = (or_ln56_283_fu_34866_p2.read() | or_ln56_284_fu_34880_p2.read());
}

void dense_wrapper::thread_or_ln56_337_fu_35630_p2() {
    or_ln56_337_fu_35630_p2 = (or_ln56_285_fu_34894_p2.read() | or_ln56_286_fu_34908_p2.read());
}

void dense_wrapper::thread_or_ln56_338_fu_35644_p2() {
    or_ln56_338_fu_35644_p2 = (or_ln56_287_fu_34922_p2.read() | or_ln56_288_fu_34936_p2.read());
}

void dense_wrapper::thread_or_ln56_339_fu_35658_p2() {
    or_ln56_339_fu_35658_p2 = (or_ln56_289_fu_34950_p2.read() | or_ln56_290_fu_34964_p2.read());
}

void dense_wrapper::thread_or_ln56_33_fu_31358_p2() {
    or_ln56_33_fu_31358_p2 = (icmp_ln56_324_fu_30486_p2.read() | icmp_ln56_323_fu_30480_p2.read());
}

void dense_wrapper::thread_or_ln56_340_fu_35680_p2() {
    or_ln56_340_fu_35680_p2 = (or_ln56_292_fu_35000_p2.read() | or_ln56_293_fu_35014_p2.read());
}

void dense_wrapper::thread_or_ln56_341_fu_35694_p2() {
    or_ln56_341_fu_35694_p2 = (or_ln56_294_fu_35028_p2.read() | or_ln56_295_fu_35042_p2.read());
}

void dense_wrapper::thread_or_ln56_342_fu_35708_p2() {
    or_ln56_342_fu_35708_p2 = (or_ln56_296_fu_35056_p2.read() | or_ln56_297_fu_35070_p2.read());
}

void dense_wrapper::thread_or_ln56_343_fu_35722_p2() {
    or_ln56_343_fu_35722_p2 = (or_ln56_298_fu_35084_p2.read() | or_ln56_299_fu_35098_p2.read());
}

void dense_wrapper::thread_or_ln56_344_fu_35736_p2() {
    or_ln56_344_fu_35736_p2 = (or_ln56_300_fu_35112_p2.read() | or_ln56_301_fu_35126_p2.read());
}

void dense_wrapper::thread_or_ln56_345_fu_35750_p2() {
    or_ln56_345_fu_35750_p2 = (or_ln56_302_fu_35140_p2.read() | or_ln56_303_fu_35154_p2.read());
}

void dense_wrapper::thread_or_ln56_346_fu_35764_p2() {
    or_ln56_346_fu_35764_p2 = (or_ln56_304_fu_35168_p2.read() | or_ln56_305_fu_35182_p2.read());
}

void dense_wrapper::thread_or_ln56_347_fu_35778_p2() {
    or_ln56_347_fu_35778_p2 = (or_ln56_306_fu_35196_p2.read() | or_ln56_307_fu_35210_p2.read());
}

void dense_wrapper::thread_or_ln56_348_fu_35792_p2() {
    or_ln56_348_fu_35792_p2 = (or_ln56_308_fu_35224_p2.read() | or_ln56_309_fu_35238_p2.read());
}

void dense_wrapper::thread_or_ln56_349_fu_35806_p2() {
    or_ln56_349_fu_35806_p2 = (or_ln56_310_fu_35252_p2.read() | or_ln56_311_fu_35266_p2.read());
}

void dense_wrapper::thread_or_ln56_34_fu_31372_p2() {
    or_ln56_34_fu_31372_p2 = (icmp_ln56_322_fu_30474_p2.read() | icmp_ln56_321_fu_30468_p2.read());
}

void dense_wrapper::thread_or_ln56_350_fu_35820_p2() {
    or_ln56_350_fu_35820_p2 = (or_ln56_312_fu_35280_p2.read() | or_ln56_313_fu_35294_p2.read());
}

void dense_wrapper::thread_or_ln56_351_fu_35834_p2() {
    or_ln56_351_fu_35834_p2 = (or_ln56_314_fu_35308_p2.read() | or_ln56_315_fu_35322_p2.read());
}

void dense_wrapper::thread_or_ln56_352_fu_35848_p2() {
    or_ln56_352_fu_35848_p2 = (or_ln56_316_fu_35336_p2.read() | or_ln56_317_fu_35350_p2.read());
}

void dense_wrapper::thread_or_ln56_353_fu_35862_p2() {
    or_ln56_353_fu_35862_p2 = (or_ln56_318_fu_35364_p2.read() | or_ln56_319_fu_35378_p2.read());
}

void dense_wrapper::thread_or_ln56_354_fu_35876_p2() {
    or_ln56_354_fu_35876_p2 = (or_ln56_320_fu_35392_p2.read() | or_ln56_321_fu_35406_p2.read());
}

void dense_wrapper::thread_or_ln56_355_fu_35890_p2() {
    or_ln56_355_fu_35890_p2 = (or_ln56_322_fu_35420_p2.read() | or_ln56_323_fu_35434_p2.read());
}

void dense_wrapper::thread_or_ln56_356_fu_35904_p2() {
    or_ln56_356_fu_35904_p2 = (or_ln56_324_fu_35448_p2.read() | or_ln56_325_fu_35462_p2.read());
}

void dense_wrapper::thread_or_ln56_357_fu_35918_p2() {
    or_ln56_357_fu_35918_p2 = (or_ln56_326_fu_35476_p2.read() | or_ln56_327_fu_35490_p2.read());
}

void dense_wrapper::thread_or_ln56_358_fu_35932_p2() {
    or_ln56_358_fu_35932_p2 = (or_ln56_328_fu_35504_p2.read() | or_ln56_329_fu_35518_p2.read());
}

void dense_wrapper::thread_or_ln56_359_fu_35946_p2() {
    or_ln56_359_fu_35946_p2 = (or_ln56_330_fu_35532_p2.read() | or_ln56_331_fu_35546_p2.read());
}

void dense_wrapper::thread_or_ln56_35_fu_31386_p2() {
    or_ln56_35_fu_31386_p2 = (icmp_ln56_320_fu_30462_p2.read() | icmp_ln56_319_fu_30456_p2.read());
}

void dense_wrapper::thread_or_ln56_360_fu_35960_p2() {
    or_ln56_360_fu_35960_p2 = (or_ln56_332_fu_35560_p2.read() | or_ln56_333_fu_35574_p2.read());
}

void dense_wrapper::thread_or_ln56_361_fu_35974_p2() {
    or_ln56_361_fu_35974_p2 = (or_ln56_334_fu_35588_p2.read() | or_ln56_335_fu_35602_p2.read());
}

void dense_wrapper::thread_or_ln56_362_fu_35988_p2() {
    or_ln56_362_fu_35988_p2 = (or_ln56_336_fu_35616_p2.read() | or_ln56_337_fu_35630_p2.read());
}

void dense_wrapper::thread_or_ln56_363_fu_36002_p2() {
    or_ln56_363_fu_36002_p2 = (or_ln56_338_fu_35644_p2.read() | or_ln56_339_fu_35658_p2.read());
}

void dense_wrapper::thread_or_ln56_364_fu_36016_p2() {
    or_ln56_364_fu_36016_p2 = (or_ln56_340_fu_35680_p2.read() | or_ln56_341_fu_35694_p2.read());
}

void dense_wrapper::thread_or_ln56_365_fu_36030_p2() {
    or_ln56_365_fu_36030_p2 = (or_ln56_342_fu_35708_p2.read() | or_ln56_343_fu_35722_p2.read());
}

void dense_wrapper::thread_or_ln56_366_fu_36044_p2() {
    or_ln56_366_fu_36044_p2 = (or_ln56_344_fu_35736_p2.read() | or_ln56_345_fu_35750_p2.read());
}

void dense_wrapper::thread_or_ln56_367_fu_36058_p2() {
    or_ln56_367_fu_36058_p2 = (or_ln56_346_fu_35764_p2.read() | or_ln56_347_fu_35778_p2.read());
}

void dense_wrapper::thread_or_ln56_368_fu_36072_p2() {
    or_ln56_368_fu_36072_p2 = (or_ln56_348_fu_35792_p2.read() | or_ln56_349_fu_35806_p2.read());
}

void dense_wrapper::thread_or_ln56_369_fu_36086_p2() {
    or_ln56_369_fu_36086_p2 = (or_ln56_350_fu_35820_p2.read() | or_ln56_351_fu_35834_p2.read());
}

void dense_wrapper::thread_or_ln56_36_fu_31400_p2() {
    or_ln56_36_fu_31400_p2 = (icmp_ln56_318_fu_30450_p2.read() | icmp_ln56_317_fu_30444_p2.read());
}

void dense_wrapper::thread_or_ln56_370_fu_36100_p2() {
    or_ln56_370_fu_36100_p2 = (or_ln56_352_fu_35848_p2.read() | or_ln56_353_fu_35862_p2.read());
}

void dense_wrapper::thread_or_ln56_371_fu_36114_p2() {
    or_ln56_371_fu_36114_p2 = (or_ln56_354_fu_35876_p2.read() | or_ln56_355_fu_35890_p2.read());
}

void dense_wrapper::thread_or_ln56_372_fu_36128_p2() {
    or_ln56_372_fu_36128_p2 = (or_ln56_356_fu_35904_p2.read() | or_ln56_357_fu_35918_p2.read());
}

void dense_wrapper::thread_or_ln56_373_fu_36142_p2() {
    or_ln56_373_fu_36142_p2 = (or_ln56_358_fu_35932_p2.read() | or_ln56_359_fu_35946_p2.read());
}

void dense_wrapper::thread_or_ln56_374_fu_36156_p2() {
    or_ln56_374_fu_36156_p2 = (or_ln56_360_fu_35960_p2.read() | or_ln56_361_fu_35974_p2.read());
}

void dense_wrapper::thread_or_ln56_375_fu_36170_p2() {
    or_ln56_375_fu_36170_p2 = (or_ln56_362_fu_35988_p2.read() | or_ln56_363_fu_36002_p2.read());
}

void dense_wrapper::thread_or_ln56_376_fu_36184_p2() {
    or_ln56_376_fu_36184_p2 = (or_ln56_364_fu_36016_p2.read() | or_ln56_365_fu_36030_p2.read());
}

void dense_wrapper::thread_or_ln56_377_fu_36198_p2() {
    or_ln56_377_fu_36198_p2 = (or_ln56_366_fu_36044_p2.read() | or_ln56_367_fu_36058_p2.read());
}

void dense_wrapper::thread_or_ln56_378_fu_36212_p2() {
    or_ln56_378_fu_36212_p2 = (or_ln56_368_fu_36072_p2.read() | or_ln56_369_fu_36086_p2.read());
}

void dense_wrapper::thread_or_ln56_379_fu_36226_p2() {
    or_ln56_379_fu_36226_p2 = (or_ln56_370_fu_36100_p2.read() | or_ln56_371_fu_36114_p2.read());
}

void dense_wrapper::thread_or_ln56_37_fu_31414_p2() {
    or_ln56_37_fu_31414_p2 = (icmp_ln56_316_fu_30438_p2.read() | icmp_ln56_315_fu_30432_p2.read());
}

void dense_wrapper::thread_or_ln56_380_fu_36240_p2() {
    or_ln56_380_fu_36240_p2 = (or_ln56_372_fu_36128_p2.read() | or_ln56_373_fu_36142_p2.read());
}

void dense_wrapper::thread_or_ln56_381_fu_36254_p2() {
    or_ln56_381_fu_36254_p2 = (or_ln56_374_fu_36156_p2.read() | or_ln56_375_fu_36170_p2.read());
}

void dense_wrapper::thread_or_ln56_382_fu_36268_p2() {
    or_ln56_382_fu_36268_p2 = (or_ln56_376_fu_36184_p2.read() | or_ln56_377_fu_36198_p2.read());
}

void dense_wrapper::thread_or_ln56_383_fu_36282_p2() {
    or_ln56_383_fu_36282_p2 = (or_ln56_378_fu_36212_p2.read() | or_ln56_379_fu_36226_p2.read());
}

void dense_wrapper::thread_or_ln56_384_fu_36296_p2() {
    or_ln56_384_fu_36296_p2 = (or_ln56_380_fu_36240_p2.read() | or_ln56_381_fu_36254_p2.read());
}

void dense_wrapper::thread_or_ln56_385_fu_36310_p2() {
    or_ln56_385_fu_36310_p2 = (or_ln56_382_fu_36268_p2.read() | or_ln56_383_fu_36282_p2.read());
}

void dense_wrapper::thread_or_ln56_38_fu_31428_p2() {
    or_ln56_38_fu_31428_p2 = (icmp_ln56_314_fu_30426_p2.read() | icmp_ln56_313_fu_30420_p2.read());
}

void dense_wrapper::thread_or_ln56_39_fu_31442_p2() {
    or_ln56_39_fu_31442_p2 = (icmp_ln56_312_fu_30414_p2.read() | icmp_ln56_311_fu_30408_p2.read());
}

void dense_wrapper::thread_or_ln56_3_fu_30938_p2() {
    or_ln56_3_fu_30938_p2 = (icmp_ln56_384_fu_30846_p2.read() | icmp_ln56_383_fu_30840_p2.read());
}

void dense_wrapper::thread_or_ln56_40_fu_31456_p2() {
    or_ln56_40_fu_31456_p2 = (icmp_ln56_310_fu_30402_p2.read() | icmp_ln56_309_fu_30396_p2.read());
}

void dense_wrapper::thread_or_ln56_41_fu_31470_p2() {
    or_ln56_41_fu_31470_p2 = (icmp_ln56_308_fu_30390_p2.read() | icmp_ln56_307_fu_30384_p2.read());
}

void dense_wrapper::thread_or_ln56_42_fu_31484_p2() {
    or_ln56_42_fu_31484_p2 = (icmp_ln56_306_fu_30378_p2.read() | icmp_ln56_305_fu_30372_p2.read());
}

void dense_wrapper::thread_or_ln56_43_fu_31498_p2() {
    or_ln56_43_fu_31498_p2 = (icmp_ln56_304_fu_30366_p2.read() | icmp_ln56_303_fu_30360_p2.read());
}

void dense_wrapper::thread_or_ln56_44_fu_31512_p2() {
    or_ln56_44_fu_31512_p2 = (icmp_ln56_302_fu_30354_p2.read() | icmp_ln56_301_fu_30348_p2.read());
}

void dense_wrapper::thread_or_ln56_45_fu_31526_p2() {
    or_ln56_45_fu_31526_p2 = (icmp_ln56_300_fu_30342_p2.read() | icmp_ln56_299_fu_30336_p2.read());
}

void dense_wrapper::thread_or_ln56_46_fu_31540_p2() {
    or_ln56_46_fu_31540_p2 = (icmp_ln56_298_fu_30330_p2.read() | icmp_ln56_297_fu_30324_p2.read());
}

void dense_wrapper::thread_or_ln56_47_fu_31554_p2() {
    or_ln56_47_fu_31554_p2 = (icmp_ln56_296_fu_30318_p2.read() | icmp_ln56_295_fu_30312_p2.read());
}

void dense_wrapper::thread_or_ln56_48_fu_31568_p2() {
    or_ln56_48_fu_31568_p2 = (icmp_ln56_294_fu_30306_p2.read() | icmp_ln56_293_fu_30300_p2.read());
}

void dense_wrapper::thread_or_ln56_49_fu_31582_p2() {
    or_ln56_49_fu_31582_p2 = (icmp_ln56_292_fu_30294_p2.read() | icmp_ln56_291_fu_30288_p2.read());
}

void dense_wrapper::thread_or_ln56_4_fu_30952_p2() {
    or_ln56_4_fu_30952_p2 = (icmp_ln56_382_fu_30834_p2.read() | icmp_ln56_381_fu_30828_p2.read());
}

void dense_wrapper::thread_or_ln56_50_fu_31596_p2() {
    or_ln56_50_fu_31596_p2 = (icmp_ln56_290_fu_30282_p2.read() | icmp_ln56_289_fu_30276_p2.read());
}

void dense_wrapper::thread_or_ln56_51_fu_31610_p2() {
    or_ln56_51_fu_31610_p2 = (icmp_ln56_288_fu_30270_p2.read() | icmp_ln56_287_fu_30264_p2.read());
}

void dense_wrapper::thread_or_ln56_52_fu_31624_p2() {
    or_ln56_52_fu_31624_p2 = (icmp_ln56_286_fu_30258_p2.read() | icmp_ln56_285_fu_30252_p2.read());
}

void dense_wrapper::thread_or_ln56_53_fu_31638_p2() {
    or_ln56_53_fu_31638_p2 = (icmp_ln56_284_fu_30246_p2.read() | icmp_ln56_283_fu_30240_p2.read());
}

void dense_wrapper::thread_or_ln56_54_fu_31652_p2() {
    or_ln56_54_fu_31652_p2 = (icmp_ln56_282_fu_30234_p2.read() | icmp_ln56_281_fu_30228_p2.read());
}

void dense_wrapper::thread_or_ln56_55_fu_31666_p2() {
    or_ln56_55_fu_31666_p2 = (icmp_ln56_280_fu_30222_p2.read() | icmp_ln56_279_fu_30216_p2.read());
}

void dense_wrapper::thread_or_ln56_56_fu_31680_p2() {
    or_ln56_56_fu_31680_p2 = (icmp_ln56_278_fu_30210_p2.read() | icmp_ln56_277_fu_30204_p2.read());
}

void dense_wrapper::thread_or_ln56_57_fu_31694_p2() {
    or_ln56_57_fu_31694_p2 = (icmp_ln56_276_fu_30198_p2.read() | icmp_ln56_275_fu_30192_p2.read());
}

void dense_wrapper::thread_or_ln56_58_fu_31708_p2() {
    or_ln56_58_fu_31708_p2 = (icmp_ln56_274_fu_30186_p2.read() | icmp_ln56_273_fu_30180_p2.read());
}

void dense_wrapper::thread_or_ln56_59_fu_31722_p2() {
    or_ln56_59_fu_31722_p2 = (icmp_ln56_272_fu_30174_p2.read() | icmp_ln56_271_fu_30168_p2.read());
}

void dense_wrapper::thread_or_ln56_5_fu_30966_p2() {
    or_ln56_5_fu_30966_p2 = (icmp_ln56_380_fu_30822_p2.read() | icmp_ln56_379_fu_30816_p2.read());
}

void dense_wrapper::thread_or_ln56_60_fu_31736_p2() {
    or_ln56_60_fu_31736_p2 = (icmp_ln56_270_fu_30162_p2.read() | icmp_ln56_269_fu_30156_p2.read());
}

void dense_wrapper::thread_or_ln56_61_fu_31750_p2() {
    or_ln56_61_fu_31750_p2 = (icmp_ln56_268_fu_30150_p2.read() | icmp_ln56_267_fu_30144_p2.read());
}

void dense_wrapper::thread_or_ln56_62_fu_31764_p2() {
    or_ln56_62_fu_31764_p2 = (icmp_ln56_266_fu_30138_p2.read() | icmp_ln56_265_fu_30132_p2.read());
}

void dense_wrapper::thread_or_ln56_63_fu_31778_p2() {
    or_ln56_63_fu_31778_p2 = (icmp_ln56_264_fu_30126_p2.read() | icmp_ln56_263_fu_30120_p2.read());
}

void dense_wrapper::thread_or_ln56_64_fu_31792_p2() {
    or_ln56_64_fu_31792_p2 = (icmp_ln56_262_fu_30114_p2.read() | icmp_ln56_261_fu_30108_p2.read());
}

void dense_wrapper::thread_or_ln56_65_fu_31806_p2() {
    or_ln56_65_fu_31806_p2 = (icmp_ln56_260_fu_30102_p2.read() | icmp_ln56_259_fu_30096_p2.read());
}

void dense_wrapper::thread_or_ln56_66_fu_31820_p2() {
    or_ln56_66_fu_31820_p2 = (icmp_ln56_258_fu_30090_p2.read() | icmp_ln56_257_fu_30084_p2.read());
}

void dense_wrapper::thread_or_ln56_67_fu_31834_p2() {
    or_ln56_67_fu_31834_p2 = (icmp_ln56_256_fu_30078_p2.read() | icmp_ln56_255_fu_30072_p2.read());
}

void dense_wrapper::thread_or_ln56_68_fu_31848_p2() {
    or_ln56_68_fu_31848_p2 = (icmp_ln56_254_fu_30066_p2.read() | icmp_ln56_253_fu_30060_p2.read());
}

void dense_wrapper::thread_or_ln56_69_fu_31862_p2() {
    or_ln56_69_fu_31862_p2 = (icmp_ln56_252_fu_30054_p2.read() | icmp_ln56_251_fu_30048_p2.read());
}

void dense_wrapper::thread_or_ln56_6_fu_30980_p2() {
    or_ln56_6_fu_30980_p2 = (icmp_ln56_378_fu_30810_p2.read() | icmp_ln56_377_fu_30804_p2.read());
}

void dense_wrapper::thread_or_ln56_70_fu_31876_p2() {
    or_ln56_70_fu_31876_p2 = (icmp_ln56_250_fu_30042_p2.read() | icmp_ln56_249_fu_30036_p2.read());
}

void dense_wrapper::thread_or_ln56_71_fu_31890_p2() {
    or_ln56_71_fu_31890_p2 = (icmp_ln56_248_fu_30030_p2.read() | icmp_ln56_247_fu_30024_p2.read());
}

void dense_wrapper::thread_or_ln56_72_fu_31904_p2() {
    or_ln56_72_fu_31904_p2 = (icmp_ln56_246_fu_30018_p2.read() | icmp_ln56_245_fu_30012_p2.read());
}

void dense_wrapper::thread_or_ln56_73_fu_31918_p2() {
    or_ln56_73_fu_31918_p2 = (icmp_ln56_244_fu_30006_p2.read() | icmp_ln56_243_fu_30000_p2.read());
}

void dense_wrapper::thread_or_ln56_74_fu_31932_p2() {
    or_ln56_74_fu_31932_p2 = (icmp_ln56_242_fu_29994_p2.read() | icmp_ln56_241_fu_29988_p2.read());
}

void dense_wrapper::thread_or_ln56_75_fu_31946_p2() {
    or_ln56_75_fu_31946_p2 = (icmp_ln56_240_fu_29982_p2.read() | icmp_ln56_239_fu_29976_p2.read());
}

void dense_wrapper::thread_or_ln56_76_fu_31960_p2() {
    or_ln56_76_fu_31960_p2 = (icmp_ln56_238_fu_29970_p2.read() | icmp_ln56_237_fu_29964_p2.read());
}

void dense_wrapper::thread_or_ln56_77_fu_31974_p2() {
    or_ln56_77_fu_31974_p2 = (icmp_ln56_236_fu_29958_p2.read() | icmp_ln56_235_fu_29952_p2.read());
}

void dense_wrapper::thread_or_ln56_78_fu_31988_p2() {
    or_ln56_78_fu_31988_p2 = (icmp_ln56_234_fu_29946_p2.read() | icmp_ln56_233_fu_29940_p2.read());
}

void dense_wrapper::thread_or_ln56_79_fu_32002_p2() {
    or_ln56_79_fu_32002_p2 = (icmp_ln56_232_fu_29934_p2.read() | icmp_ln56_231_fu_29928_p2.read());
}

void dense_wrapper::thread_or_ln56_7_fu_30994_p2() {
    or_ln56_7_fu_30994_p2 = (icmp_ln56_376_fu_30798_p2.read() | icmp_ln56_375_fu_30792_p2.read());
}

void dense_wrapper::thread_or_ln56_80_fu_32016_p2() {
    or_ln56_80_fu_32016_p2 = (icmp_ln56_230_fu_29922_p2.read() | icmp_ln56_229_fu_29916_p2.read());
}

void dense_wrapper::thread_or_ln56_81_fu_32030_p2() {
    or_ln56_81_fu_32030_p2 = (icmp_ln56_228_fu_29910_p2.read() | icmp_ln56_227_fu_29904_p2.read());
}

void dense_wrapper::thread_or_ln56_82_fu_32044_p2() {
    or_ln56_82_fu_32044_p2 = (icmp_ln56_226_fu_29898_p2.read() | icmp_ln56_225_fu_29892_p2.read());
}

void dense_wrapper::thread_or_ln56_83_fu_32058_p2() {
    or_ln56_83_fu_32058_p2 = (icmp_ln56_224_fu_29886_p2.read() | icmp_ln56_223_fu_29880_p2.read());
}

void dense_wrapper::thread_or_ln56_84_fu_32072_p2() {
    or_ln56_84_fu_32072_p2 = (icmp_ln56_222_fu_29874_p2.read() | icmp_ln56_221_fu_29868_p2.read());
}

void dense_wrapper::thread_or_ln56_85_fu_32086_p2() {
    or_ln56_85_fu_32086_p2 = (icmp_ln56_220_fu_29862_p2.read() | icmp_ln56_219_fu_29856_p2.read());
}

void dense_wrapper::thread_or_ln56_86_fu_32100_p2() {
    or_ln56_86_fu_32100_p2 = (icmp_ln56_218_fu_29850_p2.read() | icmp_ln56_217_fu_29844_p2.read());
}

void dense_wrapper::thread_or_ln56_87_fu_32114_p2() {
    or_ln56_87_fu_32114_p2 = (icmp_ln56_216_fu_29838_p2.read() | icmp_ln56_215_fu_29832_p2.read());
}

void dense_wrapper::thread_or_ln56_88_fu_32128_p2() {
    or_ln56_88_fu_32128_p2 = (icmp_ln56_214_fu_29826_p2.read() | icmp_ln56_213_fu_29820_p2.read());
}

void dense_wrapper::thread_or_ln56_89_fu_32142_p2() {
    or_ln56_89_fu_32142_p2 = (icmp_ln56_212_fu_29814_p2.read() | icmp_ln56_211_fu_29808_p2.read());
}

void dense_wrapper::thread_or_ln56_8_fu_31008_p2() {
    or_ln56_8_fu_31008_p2 = (icmp_ln56_374_fu_30786_p2.read() | icmp_ln56_373_fu_30780_p2.read());
}

void dense_wrapper::thread_or_ln56_90_fu_32156_p2() {
    or_ln56_90_fu_32156_p2 = (icmp_ln56_210_fu_29802_p2.read() | icmp_ln56_209_fu_29796_p2.read());
}

void dense_wrapper::thread_or_ln56_91_fu_32170_p2() {
    or_ln56_91_fu_32170_p2 = (icmp_ln56_208_fu_29790_p2.read() | icmp_ln56_207_fu_29784_p2.read());
}

void dense_wrapper::thread_or_ln56_92_fu_32184_p2() {
    or_ln56_92_fu_32184_p2 = (icmp_ln56_206_fu_29778_p2.read() | icmp_ln56_205_fu_29772_p2.read());
}

void dense_wrapper::thread_or_ln56_93_fu_32198_p2() {
    or_ln56_93_fu_32198_p2 = (icmp_ln56_204_fu_29766_p2.read() | icmp_ln56_203_fu_29760_p2.read());
}

void dense_wrapper::thread_or_ln56_94_fu_32212_p2() {
    or_ln56_94_fu_32212_p2 = (icmp_ln56_202_fu_29754_p2.read() | icmp_ln56_201_fu_29748_p2.read());
}

void dense_wrapper::thread_or_ln56_95_fu_32226_p2() {
    or_ln56_95_fu_32226_p2 = (icmp_ln56_200_fu_29742_p2.read() | icmp_ln56_199_fu_29736_p2.read());
}

void dense_wrapper::thread_or_ln56_96_fu_32240_p2() {
    or_ln56_96_fu_32240_p2 = (icmp_ln56_198_fu_29730_p2.read() | icmp_ln56_197_fu_29724_p2.read());
}

void dense_wrapper::thread_or_ln56_97_fu_32254_p2() {
    or_ln56_97_fu_32254_p2 = (icmp_ln56_196_fu_29718_p2.read() | icmp_ln56_195_fu_29712_p2.read());
}

void dense_wrapper::thread_or_ln56_98_fu_32268_p2() {
    or_ln56_98_fu_32268_p2 = (icmp_ln56_194_fu_29706_p2.read() | icmp_ln56_193_fu_29700_p2.read());
}

void dense_wrapper::thread_or_ln56_99_fu_32282_p2() {
    or_ln56_99_fu_32282_p2 = (icmp_ln56_192_fu_29694_p2.read() | icmp_ln56_191_fu_29688_p2.read());
}

void dense_wrapper::thread_or_ln56_9_fu_31022_p2() {
    or_ln56_9_fu_31022_p2 = (icmp_ln56_372_fu_30774_p2.read() | icmp_ln56_371_fu_30768_p2.read());
}

void dense_wrapper::thread_or_ln56_fu_30896_p2() {
    or_ln56_fu_30896_p2 = (icmp_ln56_390_fu_30882_p2.read() | icmp_ln56_389_fu_30876_p2.read());
}

void dense_wrapper::thread_select_ln56_1000_fu_40863_p3() {
    select_ln56_1000_fu_40863_p3 = (!icmp_ln56_219_reg_43572_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_219_reg_43572_pp0_iter8_reg.read()[0].to_bool())? data_219_V_read233_s_reg_20999_pp0_iter8_reg.read(): select_ln56_999_fu_40856_p3.read());
}

void dense_wrapper::thread_select_ln56_1001_fu_40870_p3() {
    select_ln56_1001_fu_40870_p3 = (!icmp_ln56_220_reg_43577_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_220_reg_43577_pp0_iter8_reg.read()[0].to_bool())? data_220_V_read234_s_reg_21012_pp0_iter8_reg.read(): select_ln56_1000_fu_40863_p3.read());
}

void dense_wrapper::thread_select_ln56_1002_fu_40877_p3() {
    select_ln56_1002_fu_40877_p3 = (!icmp_ln56_221_reg_43582_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_221_reg_43582_pp0_iter8_reg.read()[0].to_bool())? data_221_V_read235_s_reg_21025_pp0_iter8_reg.read(): select_ln56_1001_fu_40870_p3.read());
}

void dense_wrapper::thread_select_ln56_1003_fu_40884_p3() {
    select_ln56_1003_fu_40884_p3 = (!icmp_ln56_222_reg_43587_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_222_reg_43587_pp0_iter8_reg.read()[0].to_bool())? data_222_V_read236_s_reg_21038_pp0_iter8_reg.read(): select_ln56_1002_fu_40877_p3.read());
}

void dense_wrapper::thread_select_ln56_1004_fu_40891_p3() {
    select_ln56_1004_fu_40891_p3 = (!icmp_ln56_223_reg_43592_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_223_reg_43592_pp0_iter8_reg.read()[0].to_bool())? data_223_V_read237_s_reg_21051_pp0_iter8_reg.read(): select_ln56_1003_fu_40884_p3.read());
}

void dense_wrapper::thread_select_ln56_1005_fu_40898_p3() {
    select_ln56_1005_fu_40898_p3 = (!icmp_ln56_224_reg_43597_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_224_reg_43597_pp0_iter8_reg.read()[0].to_bool())? data_224_V_read238_s_reg_21064_pp0_iter8_reg.read(): select_ln56_1004_fu_40891_p3.read());
}

void dense_wrapper::thread_select_ln56_1006_fu_40905_p3() {
    select_ln56_1006_fu_40905_p3 = (!icmp_ln56_225_reg_43602_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_225_reg_43602_pp0_iter8_reg.read()[0].to_bool())? data_225_V_read239_s_reg_21077_pp0_iter8_reg.read(): select_ln56_1005_fu_40898_p3.read());
}

void dense_wrapper::thread_select_ln56_1007_fu_40912_p3() {
    select_ln56_1007_fu_40912_p3 = (!icmp_ln56_226_reg_43607_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_226_reg_43607_pp0_iter8_reg.read()[0].to_bool())? data_226_V_read240_s_reg_21090_pp0_iter8_reg.read(): select_ln56_1006_fu_40905_p3.read());
}

void dense_wrapper::thread_select_ln56_1008_fu_40919_p3() {
    select_ln56_1008_fu_40919_p3 = (!icmp_ln56_227_reg_43612_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_227_reg_43612_pp0_iter8_reg.read()[0].to_bool())? data_227_V_read241_s_reg_21103_pp0_iter8_reg.read(): select_ln56_1007_fu_40912_p3.read());
}

void dense_wrapper::thread_select_ln56_1009_fu_40926_p3() {
    select_ln56_1009_fu_40926_p3 = (!icmp_ln56_228_reg_43617_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_228_reg_43617_pp0_iter8_reg.read()[0].to_bool())? data_228_V_read242_s_reg_21116_pp0_iter8_reg.read(): select_ln56_1008_fu_40919_p3.read());
}

void dense_wrapper::thread_select_ln56_100_fu_32288_p3() {
    select_ln56_100_fu_32288_p3 = (!icmp_ln56_190_fu_29682_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_190_fu_29682_p2.read()[0].to_bool())? ap_phi_mux_data_582_V_read596_s_phi_fu_25722_p4.read(): ap_phi_mux_data_581_V_read595_s_phi_fu_25709_p4.read());
}

void dense_wrapper::thread_select_ln56_1010_fu_40933_p3() {
    select_ln56_1010_fu_40933_p3 = (!icmp_ln56_229_reg_43622_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_229_reg_43622_pp0_iter8_reg.read()[0].to_bool())? data_229_V_read243_s_reg_21129_pp0_iter8_reg.read(): select_ln56_1009_fu_40926_p3.read());
}

void dense_wrapper::thread_select_ln56_1011_fu_40940_p3() {
    select_ln56_1011_fu_40940_p3 = (!icmp_ln56_230_reg_43627_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_230_reg_43627_pp0_iter8_reg.read()[0].to_bool())? data_230_V_read244_s_reg_21142_pp0_iter8_reg.read(): select_ln56_1010_fu_40933_p3.read());
}

void dense_wrapper::thread_select_ln56_1012_fu_40947_p3() {
    select_ln56_1012_fu_40947_p3 = (!icmp_ln56_231_reg_43632_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_231_reg_43632_pp0_iter8_reg.read()[0].to_bool())? data_231_V_read245_s_reg_21155_pp0_iter8_reg.read(): select_ln56_1011_fu_40940_p3.read());
}

void dense_wrapper::thread_select_ln56_1013_fu_40954_p3() {
    select_ln56_1013_fu_40954_p3 = (!icmp_ln56_232_reg_43637_pp0_iter8_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_232_reg_43637_pp0_iter8_reg.read()[0].to_bool())? data_232_V_read246_s_reg_21168_pp0_iter8_reg.read(): select_ln56_1012_fu_40947_p3.read());
}

void dense_wrapper::thread_select_ln56_1014_fu_40961_p3() {
    select_ln56_1014_fu_40961_p3 = (!icmp_ln56_233_reg_43642_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_233_reg_43642_pp0_iter9_reg.read()[0].to_bool())? data_233_V_read247_s_reg_21181_pp0_iter9_reg.read(): select_ln56_1013_reg_44486.read());
}

void dense_wrapper::thread_select_ln56_1015_fu_40967_p3() {
    select_ln56_1015_fu_40967_p3 = (!icmp_ln56_234_reg_43647_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_234_reg_43647_pp0_iter9_reg.read()[0].to_bool())? data_234_V_read248_s_reg_21194_pp0_iter9_reg.read(): select_ln56_1014_fu_40961_p3.read());
}

void dense_wrapper::thread_select_ln56_1016_fu_40974_p3() {
    select_ln56_1016_fu_40974_p3 = (!icmp_ln56_235_reg_43652_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_235_reg_43652_pp0_iter9_reg.read()[0].to_bool())? data_235_V_read249_s_reg_21207_pp0_iter9_reg.read(): select_ln56_1015_fu_40967_p3.read());
}

void dense_wrapper::thread_select_ln56_1017_fu_40981_p3() {
    select_ln56_1017_fu_40981_p3 = (!icmp_ln56_236_reg_43657_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_236_reg_43657_pp0_iter9_reg.read()[0].to_bool())? data_236_V_read250_s_reg_21220_pp0_iter9_reg.read(): select_ln56_1016_fu_40974_p3.read());
}

void dense_wrapper::thread_select_ln56_1018_fu_40988_p3() {
    select_ln56_1018_fu_40988_p3 = (!icmp_ln56_237_reg_43662_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_237_reg_43662_pp0_iter9_reg.read()[0].to_bool())? data_237_V_read251_s_reg_21233_pp0_iter9_reg.read(): select_ln56_1017_fu_40981_p3.read());
}

void dense_wrapper::thread_select_ln56_1019_fu_40995_p3() {
    select_ln56_1019_fu_40995_p3 = (!icmp_ln56_238_reg_43667_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_238_reg_43667_pp0_iter9_reg.read()[0].to_bool())? data_238_V_read252_s_reg_21246_pp0_iter9_reg.read(): select_ln56_1018_fu_40988_p3.read());
}

void dense_wrapper::thread_select_ln56_101_fu_32302_p3() {
    select_ln56_101_fu_32302_p3 = (!icmp_ln56_188_fu_29670_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_188_fu_29670_p2.read()[0].to_bool())? ap_phi_mux_data_580_V_read594_s_phi_fu_25696_p4.read(): ap_phi_mux_data_579_V_read593_s_phi_fu_25683_p4.read());
}

void dense_wrapper::thread_select_ln56_1020_fu_41002_p3() {
    select_ln56_1020_fu_41002_p3 = (!icmp_ln56_239_reg_43672_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_239_reg_43672_pp0_iter9_reg.read()[0].to_bool())? data_239_V_read253_s_reg_21259_pp0_iter9_reg.read(): select_ln56_1019_fu_40995_p3.read());
}

void dense_wrapper::thread_select_ln56_1021_fu_41009_p3() {
    select_ln56_1021_fu_41009_p3 = (!icmp_ln56_240_reg_43677_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_240_reg_43677_pp0_iter9_reg.read()[0].to_bool())? data_240_V_read254_s_reg_21272_pp0_iter9_reg.read(): select_ln56_1020_fu_41002_p3.read());
}

void dense_wrapper::thread_select_ln56_1022_fu_41016_p3() {
    select_ln56_1022_fu_41016_p3 = (!icmp_ln56_241_reg_43682_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_241_reg_43682_pp0_iter9_reg.read()[0].to_bool())? data_241_V_read255_s_reg_21285_pp0_iter9_reg.read(): select_ln56_1021_fu_41009_p3.read());
}

void dense_wrapper::thread_select_ln56_1023_fu_41023_p3() {
    select_ln56_1023_fu_41023_p3 = (!icmp_ln56_242_reg_43687_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_242_reg_43687_pp0_iter9_reg.read()[0].to_bool())? data_242_V_read256_s_reg_21298_pp0_iter9_reg.read(): select_ln56_1022_fu_41016_p3.read());
}

void dense_wrapper::thread_select_ln56_1024_fu_41030_p3() {
    select_ln56_1024_fu_41030_p3 = (!icmp_ln56_243_reg_43692_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_243_reg_43692_pp0_iter9_reg.read()[0].to_bool())? data_243_V_read257_s_reg_21311_pp0_iter9_reg.read(): select_ln56_1023_fu_41023_p3.read());
}

void dense_wrapper::thread_select_ln56_1025_fu_41037_p3() {
    select_ln56_1025_fu_41037_p3 = (!icmp_ln56_244_reg_43697_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_244_reg_43697_pp0_iter9_reg.read()[0].to_bool())? data_244_V_read258_s_reg_21324_pp0_iter9_reg.read(): select_ln56_1024_fu_41030_p3.read());
}

void dense_wrapper::thread_select_ln56_1026_fu_41044_p3() {
    select_ln56_1026_fu_41044_p3 = (!icmp_ln56_245_reg_43702_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_245_reg_43702_pp0_iter9_reg.read()[0].to_bool())? data_245_V_read259_s_reg_21337_pp0_iter9_reg.read(): select_ln56_1025_fu_41037_p3.read());
}

void dense_wrapper::thread_select_ln56_1027_fu_41051_p3() {
    select_ln56_1027_fu_41051_p3 = (!icmp_ln56_246_reg_43707_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_246_reg_43707_pp0_iter9_reg.read()[0].to_bool())? data_246_V_read260_s_reg_21350_pp0_iter9_reg.read(): select_ln56_1026_fu_41044_p3.read());
}

void dense_wrapper::thread_select_ln56_1028_fu_41058_p3() {
    select_ln56_1028_fu_41058_p3 = (!icmp_ln56_247_reg_43712_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_247_reg_43712_pp0_iter9_reg.read()[0].to_bool())? data_247_V_read261_s_reg_21363_pp0_iter9_reg.read(): select_ln56_1027_fu_41051_p3.read());
}

void dense_wrapper::thread_select_ln56_1029_fu_41065_p3() {
    select_ln56_1029_fu_41065_p3 = (!icmp_ln56_248_reg_43717_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_248_reg_43717_pp0_iter9_reg.read()[0].to_bool())? data_248_V_read262_s_reg_21376_pp0_iter9_reg.read(): select_ln56_1028_fu_41058_p3.read());
}

void dense_wrapper::thread_select_ln56_102_fu_32316_p3() {
    select_ln56_102_fu_32316_p3 = (!icmp_ln56_186_fu_29658_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_186_fu_29658_p2.read()[0].to_bool())? ap_phi_mux_data_578_V_read592_s_phi_fu_25670_p4.read(): ap_phi_mux_data_577_V_read591_s_phi_fu_25657_p4.read());
}

void dense_wrapper::thread_select_ln56_1030_fu_41072_p3() {
    select_ln56_1030_fu_41072_p3 = (!icmp_ln56_249_reg_43722_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_249_reg_43722_pp0_iter9_reg.read()[0].to_bool())? data_249_V_read263_s_reg_21389_pp0_iter9_reg.read(): select_ln56_1029_fu_41065_p3.read());
}

void dense_wrapper::thread_select_ln56_1031_fu_41079_p3() {
    select_ln56_1031_fu_41079_p3 = (!icmp_ln56_250_reg_43727_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_250_reg_43727_pp0_iter9_reg.read()[0].to_bool())? data_250_V_read264_s_reg_21402_pp0_iter9_reg.read(): select_ln56_1030_fu_41072_p3.read());
}

void dense_wrapper::thread_select_ln56_1032_fu_41086_p3() {
    select_ln56_1032_fu_41086_p3 = (!icmp_ln56_251_reg_43732_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_251_reg_43732_pp0_iter9_reg.read()[0].to_bool())? data_251_V_read265_s_reg_21415_pp0_iter9_reg.read(): select_ln56_1031_fu_41079_p3.read());
}

void dense_wrapper::thread_select_ln56_1033_fu_41093_p3() {
    select_ln56_1033_fu_41093_p3 = (!icmp_ln56_252_reg_43737_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_252_reg_43737_pp0_iter9_reg.read()[0].to_bool())? data_252_V_read266_s_reg_21428_pp0_iter9_reg.read(): select_ln56_1032_fu_41086_p3.read());
}

void dense_wrapper::thread_select_ln56_1034_fu_41100_p3() {
    select_ln56_1034_fu_41100_p3 = (!icmp_ln56_253_reg_43742_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_253_reg_43742_pp0_iter9_reg.read()[0].to_bool())? data_253_V_read267_s_reg_21441_pp0_iter9_reg.read(): select_ln56_1033_fu_41093_p3.read());
}

void dense_wrapper::thread_select_ln56_1035_fu_41107_p3() {
    select_ln56_1035_fu_41107_p3 = (!icmp_ln56_254_reg_43747_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_254_reg_43747_pp0_iter9_reg.read()[0].to_bool())? data_254_V_read268_s_reg_21454_pp0_iter9_reg.read(): select_ln56_1034_fu_41100_p3.read());
}

void dense_wrapper::thread_select_ln56_1036_fu_41114_p3() {
    select_ln56_1036_fu_41114_p3 = (!icmp_ln56_255_reg_43752_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_255_reg_43752_pp0_iter9_reg.read()[0].to_bool())? data_255_V_read269_s_reg_21467_pp0_iter9_reg.read(): select_ln56_1035_fu_41107_p3.read());
}

void dense_wrapper::thread_select_ln56_1037_fu_41121_p3() {
    select_ln56_1037_fu_41121_p3 = (!icmp_ln56_256_reg_43757_pp0_iter9_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_256_reg_43757_pp0_iter9_reg.read()[0].to_bool())? data_256_V_read270_s_reg_21480_pp0_iter9_reg.read(): select_ln56_1036_fu_41114_p3.read());
}

void dense_wrapper::thread_select_ln56_1038_fu_41128_p3() {
    select_ln56_1038_fu_41128_p3 = (!icmp_ln56_257_reg_43762_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_257_reg_43762_pp0_iter10_reg.read()[0].to_bool())? data_257_V_read271_s_reg_21493_pp0_iter10_reg.read(): select_ln56_1037_reg_44491.read());
}

void dense_wrapper::thread_select_ln56_1039_fu_41134_p3() {
    select_ln56_1039_fu_41134_p3 = (!icmp_ln56_258_reg_43767_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_258_reg_43767_pp0_iter10_reg.read()[0].to_bool())? data_258_V_read272_s_reg_21506_pp0_iter10_reg.read(): select_ln56_1038_fu_41128_p3.read());
}

void dense_wrapper::thread_select_ln56_103_fu_32330_p3() {
    select_ln56_103_fu_32330_p3 = (!icmp_ln56_184_fu_29646_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_184_fu_29646_p2.read()[0].to_bool())? ap_phi_mux_data_576_V_read590_s_phi_fu_25644_p4.read(): ap_phi_mux_data_575_V_read589_s_phi_fu_25631_p4.read());
}

void dense_wrapper::thread_select_ln56_1040_fu_41141_p3() {
    select_ln56_1040_fu_41141_p3 = (!icmp_ln56_259_reg_43772_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_259_reg_43772_pp0_iter10_reg.read()[0].to_bool())? data_259_V_read273_s_reg_21519_pp0_iter10_reg.read(): select_ln56_1039_fu_41134_p3.read());
}

void dense_wrapper::thread_select_ln56_1041_fu_41148_p3() {
    select_ln56_1041_fu_41148_p3 = (!icmp_ln56_260_reg_43777_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_260_reg_43777_pp0_iter10_reg.read()[0].to_bool())? data_260_V_read274_s_reg_21532_pp0_iter10_reg.read(): select_ln56_1040_fu_41141_p3.read());
}

void dense_wrapper::thread_select_ln56_1042_fu_41155_p3() {
    select_ln56_1042_fu_41155_p3 = (!icmp_ln56_261_reg_43782_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_261_reg_43782_pp0_iter10_reg.read()[0].to_bool())? data_261_V_read275_s_reg_21545_pp0_iter10_reg.read(): select_ln56_1041_fu_41148_p3.read());
}

void dense_wrapper::thread_select_ln56_1043_fu_41162_p3() {
    select_ln56_1043_fu_41162_p3 = (!icmp_ln56_262_reg_43787_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_262_reg_43787_pp0_iter10_reg.read()[0].to_bool())? data_262_V_read276_s_reg_21558_pp0_iter10_reg.read(): select_ln56_1042_fu_41155_p3.read());
}

void dense_wrapper::thread_select_ln56_1044_fu_41169_p3() {
    select_ln56_1044_fu_41169_p3 = (!icmp_ln56_263_reg_43792_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_263_reg_43792_pp0_iter10_reg.read()[0].to_bool())? data_263_V_read277_s_reg_21571_pp0_iter10_reg.read(): select_ln56_1043_fu_41162_p3.read());
}

void dense_wrapper::thread_select_ln56_1045_fu_41176_p3() {
    select_ln56_1045_fu_41176_p3 = (!icmp_ln56_264_reg_43797_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_264_reg_43797_pp0_iter10_reg.read()[0].to_bool())? data_264_V_read278_s_reg_21584_pp0_iter10_reg.read(): select_ln56_1044_fu_41169_p3.read());
}

void dense_wrapper::thread_select_ln56_1046_fu_41183_p3() {
    select_ln56_1046_fu_41183_p3 = (!icmp_ln56_265_reg_43802_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_265_reg_43802_pp0_iter10_reg.read()[0].to_bool())? data_265_V_read279_s_reg_21597_pp0_iter10_reg.read(): select_ln56_1045_fu_41176_p3.read());
}

void dense_wrapper::thread_select_ln56_1047_fu_41190_p3() {
    select_ln56_1047_fu_41190_p3 = (!icmp_ln56_266_reg_43807_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_266_reg_43807_pp0_iter10_reg.read()[0].to_bool())? data_266_V_read280_s_reg_21610_pp0_iter10_reg.read(): select_ln56_1046_fu_41183_p3.read());
}

void dense_wrapper::thread_select_ln56_1048_fu_41197_p3() {
    select_ln56_1048_fu_41197_p3 = (!icmp_ln56_267_reg_43812_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_267_reg_43812_pp0_iter10_reg.read()[0].to_bool())? data_267_V_read281_s_reg_21623_pp0_iter10_reg.read(): select_ln56_1047_fu_41190_p3.read());
}

void dense_wrapper::thread_select_ln56_1049_fu_41204_p3() {
    select_ln56_1049_fu_41204_p3 = (!icmp_ln56_268_reg_43817_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_268_reg_43817_pp0_iter10_reg.read()[0].to_bool())? data_268_V_read282_s_reg_21636_pp0_iter10_reg.read(): select_ln56_1048_fu_41197_p3.read());
}

void dense_wrapper::thread_select_ln56_104_fu_32344_p3() {
    select_ln56_104_fu_32344_p3 = (!icmp_ln56_182_fu_29634_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_182_fu_29634_p2.read()[0].to_bool())? ap_phi_mux_data_574_V_read588_s_phi_fu_25618_p4.read(): ap_phi_mux_data_573_V_read587_s_phi_fu_25605_p4.read());
}

void dense_wrapper::thread_select_ln56_1050_fu_41211_p3() {
    select_ln56_1050_fu_41211_p3 = (!icmp_ln56_269_reg_43822_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_269_reg_43822_pp0_iter10_reg.read()[0].to_bool())? data_269_V_read283_s_reg_21649_pp0_iter10_reg.read(): select_ln56_1049_fu_41204_p3.read());
}

void dense_wrapper::thread_select_ln56_1051_fu_41218_p3() {
    select_ln56_1051_fu_41218_p3 = (!icmp_ln56_270_reg_43827_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_270_reg_43827_pp0_iter10_reg.read()[0].to_bool())? data_270_V_read284_s_reg_21662_pp0_iter10_reg.read(): select_ln56_1050_fu_41211_p3.read());
}

void dense_wrapper::thread_select_ln56_1052_fu_41225_p3() {
    select_ln56_1052_fu_41225_p3 = (!icmp_ln56_271_reg_43832_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_271_reg_43832_pp0_iter10_reg.read()[0].to_bool())? data_271_V_read285_s_reg_21675_pp0_iter10_reg.read(): select_ln56_1051_fu_41218_p3.read());
}

void dense_wrapper::thread_select_ln56_1053_fu_41232_p3() {
    select_ln56_1053_fu_41232_p3 = (!icmp_ln56_272_reg_43837_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_272_reg_43837_pp0_iter10_reg.read()[0].to_bool())? data_272_V_read286_s_reg_21688_pp0_iter10_reg.read(): select_ln56_1052_fu_41225_p3.read());
}

void dense_wrapper::thread_select_ln56_1054_fu_41239_p3() {
    select_ln56_1054_fu_41239_p3 = (!icmp_ln56_273_reg_43842_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_273_reg_43842_pp0_iter10_reg.read()[0].to_bool())? data_273_V_read287_s_reg_21701_pp0_iter10_reg.read(): select_ln56_1053_fu_41232_p3.read());
}

void dense_wrapper::thread_select_ln56_1055_fu_41246_p3() {
    select_ln56_1055_fu_41246_p3 = (!icmp_ln56_274_reg_43847_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_274_reg_43847_pp0_iter10_reg.read()[0].to_bool())? data_274_V_read288_s_reg_21714_pp0_iter10_reg.read(): select_ln56_1054_fu_41239_p3.read());
}

void dense_wrapper::thread_select_ln56_1056_fu_41253_p3() {
    select_ln56_1056_fu_41253_p3 = (!icmp_ln56_275_reg_43852_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_275_reg_43852_pp0_iter10_reg.read()[0].to_bool())? data_275_V_read289_s_reg_21727_pp0_iter10_reg.read(): select_ln56_1055_fu_41246_p3.read());
}

void dense_wrapper::thread_select_ln56_1057_fu_41260_p3() {
    select_ln56_1057_fu_41260_p3 = (!icmp_ln56_276_reg_43857_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_276_reg_43857_pp0_iter10_reg.read()[0].to_bool())? data_276_V_read290_s_reg_21740_pp0_iter10_reg.read(): select_ln56_1056_fu_41253_p3.read());
}

void dense_wrapper::thread_select_ln56_1058_fu_41267_p3() {
    select_ln56_1058_fu_41267_p3 = (!icmp_ln56_277_reg_43862_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_277_reg_43862_pp0_iter10_reg.read()[0].to_bool())? data_277_V_read291_s_reg_21753_pp0_iter10_reg.read(): select_ln56_1057_fu_41260_p3.read());
}

void dense_wrapper::thread_select_ln56_1059_fu_41274_p3() {
    select_ln56_1059_fu_41274_p3 = (!icmp_ln56_278_reg_43867_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_278_reg_43867_pp0_iter10_reg.read()[0].to_bool())? data_278_V_read292_s_reg_21766_pp0_iter10_reg.read(): select_ln56_1058_fu_41267_p3.read());
}

void dense_wrapper::thread_select_ln56_105_fu_32358_p3() {
    select_ln56_105_fu_32358_p3 = (!icmp_ln56_180_fu_29622_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_180_fu_29622_p2.read()[0].to_bool())? ap_phi_mux_data_572_V_read586_s_phi_fu_25592_p4.read(): ap_phi_mux_data_571_V_read585_s_phi_fu_25579_p4.read());
}

void dense_wrapper::thread_select_ln56_1060_fu_41281_p3() {
    select_ln56_1060_fu_41281_p3 = (!icmp_ln56_279_reg_43872_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_279_reg_43872_pp0_iter10_reg.read()[0].to_bool())? data_279_V_read293_s_reg_21779_pp0_iter10_reg.read(): select_ln56_1059_fu_41274_p3.read());
}

void dense_wrapper::thread_select_ln56_1061_fu_41288_p3() {
    select_ln56_1061_fu_41288_p3 = (!icmp_ln56_280_reg_43877_pp0_iter10_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_280_reg_43877_pp0_iter10_reg.read()[0].to_bool())? data_280_V_read294_s_reg_21792_pp0_iter10_reg.read(): select_ln56_1060_fu_41281_p3.read());
}

void dense_wrapper::thread_select_ln56_1062_fu_41295_p3() {
    select_ln56_1062_fu_41295_p3 = (!icmp_ln56_281_reg_43882_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_281_reg_43882_pp0_iter11_reg.read()[0].to_bool())? data_281_V_read295_s_reg_21805_pp0_iter11_reg.read(): select_ln56_1061_reg_44496.read());
}

void dense_wrapper::thread_select_ln56_1063_fu_41301_p3() {
    select_ln56_1063_fu_41301_p3 = (!icmp_ln56_282_reg_43887_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_282_reg_43887_pp0_iter11_reg.read()[0].to_bool())? data_282_V_read296_s_reg_21818_pp0_iter11_reg.read(): select_ln56_1062_fu_41295_p3.read());
}

void dense_wrapper::thread_select_ln56_1064_fu_41308_p3() {
    select_ln56_1064_fu_41308_p3 = (!icmp_ln56_283_reg_43892_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_283_reg_43892_pp0_iter11_reg.read()[0].to_bool())? data_283_V_read297_s_reg_21831_pp0_iter11_reg.read(): select_ln56_1063_fu_41301_p3.read());
}

void dense_wrapper::thread_select_ln56_1065_fu_41315_p3() {
    select_ln56_1065_fu_41315_p3 = (!icmp_ln56_284_reg_43897_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_284_reg_43897_pp0_iter11_reg.read()[0].to_bool())? data_284_V_read298_s_reg_21844_pp0_iter11_reg.read(): select_ln56_1064_fu_41308_p3.read());
}

void dense_wrapper::thread_select_ln56_1066_fu_41322_p3() {
    select_ln56_1066_fu_41322_p3 = (!icmp_ln56_285_reg_43902_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_285_reg_43902_pp0_iter11_reg.read()[0].to_bool())? data_285_V_read299_s_reg_21857_pp0_iter11_reg.read(): select_ln56_1065_fu_41315_p3.read());
}

void dense_wrapper::thread_select_ln56_1067_fu_41329_p3() {
    select_ln56_1067_fu_41329_p3 = (!icmp_ln56_286_reg_43907_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_286_reg_43907_pp0_iter11_reg.read()[0].to_bool())? data_286_V_read300_s_reg_21870_pp0_iter11_reg.read(): select_ln56_1066_fu_41322_p3.read());
}

void dense_wrapper::thread_select_ln56_1068_fu_41336_p3() {
    select_ln56_1068_fu_41336_p3 = (!icmp_ln56_287_reg_43912_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_287_reg_43912_pp0_iter11_reg.read()[0].to_bool())? data_287_V_read301_s_reg_21883_pp0_iter11_reg.read(): select_ln56_1067_fu_41329_p3.read());
}

void dense_wrapper::thread_select_ln56_1069_fu_41343_p3() {
    select_ln56_1069_fu_41343_p3 = (!icmp_ln56_288_reg_43917_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_288_reg_43917_pp0_iter11_reg.read()[0].to_bool())? data_288_V_read302_s_reg_21896_pp0_iter11_reg.read(): select_ln56_1068_fu_41336_p3.read());
}

void dense_wrapper::thread_select_ln56_106_fu_32372_p3() {
    select_ln56_106_fu_32372_p3 = (!icmp_ln56_178_fu_29610_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_178_fu_29610_p2.read()[0].to_bool())? ap_phi_mux_data_570_V_read584_s_phi_fu_25566_p4.read(): ap_phi_mux_data_569_V_read583_s_phi_fu_25553_p4.read());
}

void dense_wrapper::thread_select_ln56_1070_fu_41350_p3() {
    select_ln56_1070_fu_41350_p3 = (!icmp_ln56_289_reg_43922_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_289_reg_43922_pp0_iter11_reg.read()[0].to_bool())? data_289_V_read303_s_reg_21909_pp0_iter11_reg.read(): select_ln56_1069_fu_41343_p3.read());
}

void dense_wrapper::thread_select_ln56_1071_fu_41357_p3() {
    select_ln56_1071_fu_41357_p3 = (!icmp_ln56_290_reg_43927_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_290_reg_43927_pp0_iter11_reg.read()[0].to_bool())? data_290_V_read304_s_reg_21922_pp0_iter11_reg.read(): select_ln56_1070_fu_41350_p3.read());
}

void dense_wrapper::thread_select_ln56_1072_fu_41364_p3() {
    select_ln56_1072_fu_41364_p3 = (!icmp_ln56_291_reg_43932_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_291_reg_43932_pp0_iter11_reg.read()[0].to_bool())? data_291_V_read305_s_reg_21935_pp0_iter11_reg.read(): select_ln56_1071_fu_41357_p3.read());
}

void dense_wrapper::thread_select_ln56_1073_fu_41371_p3() {
    select_ln56_1073_fu_41371_p3 = (!icmp_ln56_292_reg_43937_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_292_reg_43937_pp0_iter11_reg.read()[0].to_bool())? data_292_V_read306_s_reg_21948_pp0_iter11_reg.read(): select_ln56_1072_fu_41364_p3.read());
}

void dense_wrapper::thread_select_ln56_1074_fu_41378_p3() {
    select_ln56_1074_fu_41378_p3 = (!icmp_ln56_293_reg_43942_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_293_reg_43942_pp0_iter11_reg.read()[0].to_bool())? data_293_V_read307_s_reg_21961_pp0_iter11_reg.read(): select_ln56_1073_fu_41371_p3.read());
}

void dense_wrapper::thread_select_ln56_1075_fu_41385_p3() {
    select_ln56_1075_fu_41385_p3 = (!icmp_ln56_294_reg_43947_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_294_reg_43947_pp0_iter11_reg.read()[0].to_bool())? data_294_V_read308_s_reg_21974_pp0_iter11_reg.read(): select_ln56_1074_fu_41378_p3.read());
}

void dense_wrapper::thread_select_ln56_1076_fu_41392_p3() {
    select_ln56_1076_fu_41392_p3 = (!icmp_ln56_295_reg_43952_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_295_reg_43952_pp0_iter11_reg.read()[0].to_bool())? data_295_V_read309_s_reg_21987_pp0_iter11_reg.read(): select_ln56_1075_fu_41385_p3.read());
}

void dense_wrapper::thread_select_ln56_1077_fu_41399_p3() {
    select_ln56_1077_fu_41399_p3 = (!icmp_ln56_296_reg_43957_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_296_reg_43957_pp0_iter11_reg.read()[0].to_bool())? data_296_V_read310_s_reg_22000_pp0_iter11_reg.read(): select_ln56_1076_fu_41392_p3.read());
}

void dense_wrapper::thread_select_ln56_1078_fu_41406_p3() {
    select_ln56_1078_fu_41406_p3 = (!icmp_ln56_297_reg_43962_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_297_reg_43962_pp0_iter11_reg.read()[0].to_bool())? data_297_V_read311_s_reg_22013_pp0_iter11_reg.read(): select_ln56_1077_fu_41399_p3.read());
}

void dense_wrapper::thread_select_ln56_1079_fu_41413_p3() {
    select_ln56_1079_fu_41413_p3 = (!icmp_ln56_298_reg_43967_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_298_reg_43967_pp0_iter11_reg.read()[0].to_bool())? data_298_V_read312_s_reg_22026_pp0_iter11_reg.read(): select_ln56_1078_fu_41406_p3.read());
}

void dense_wrapper::thread_select_ln56_107_fu_32386_p3() {
    select_ln56_107_fu_32386_p3 = (!icmp_ln56_176_fu_29598_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_176_fu_29598_p2.read()[0].to_bool())? ap_phi_mux_data_568_V_read582_s_phi_fu_25540_p4.read(): ap_phi_mux_data_567_V_read581_s_phi_fu_25527_p4.read());
}

void dense_wrapper::thread_select_ln56_1080_fu_41420_p3() {
    select_ln56_1080_fu_41420_p3 = (!icmp_ln56_299_reg_43972_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_299_reg_43972_pp0_iter11_reg.read()[0].to_bool())? data_299_V_read313_s_reg_22039_pp0_iter11_reg.read(): select_ln56_1079_fu_41413_p3.read());
}

void dense_wrapper::thread_select_ln56_1081_fu_41427_p3() {
    select_ln56_1081_fu_41427_p3 = (!icmp_ln56_300_reg_43977_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_300_reg_43977_pp0_iter11_reg.read()[0].to_bool())? data_300_V_read314_s_reg_22052_pp0_iter11_reg.read(): select_ln56_1080_fu_41420_p3.read());
}

void dense_wrapper::thread_select_ln56_1082_fu_41434_p3() {
    select_ln56_1082_fu_41434_p3 = (!icmp_ln56_301_reg_43982_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_301_reg_43982_pp0_iter11_reg.read()[0].to_bool())? data_301_V_read315_s_reg_22065_pp0_iter11_reg.read(): select_ln56_1081_fu_41427_p3.read());
}

void dense_wrapper::thread_select_ln56_1083_fu_41441_p3() {
    select_ln56_1083_fu_41441_p3 = (!icmp_ln56_302_reg_43987_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_302_reg_43987_pp0_iter11_reg.read()[0].to_bool())? data_302_V_read316_s_reg_22078_pp0_iter11_reg.read(): select_ln56_1082_fu_41434_p3.read());
}

void dense_wrapper::thread_select_ln56_1084_fu_41448_p3() {
    select_ln56_1084_fu_41448_p3 = (!icmp_ln56_303_reg_43992_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_303_reg_43992_pp0_iter11_reg.read()[0].to_bool())? data_303_V_read317_s_reg_22091_pp0_iter11_reg.read(): select_ln56_1083_fu_41441_p3.read());
}

void dense_wrapper::thread_select_ln56_1085_fu_41455_p3() {
    select_ln56_1085_fu_41455_p3 = (!icmp_ln56_304_reg_43997_pp0_iter11_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_304_reg_43997_pp0_iter11_reg.read()[0].to_bool())? data_304_V_read318_s_reg_22104_pp0_iter11_reg.read(): select_ln56_1084_fu_41448_p3.read());
}

void dense_wrapper::thread_select_ln56_1086_fu_41462_p3() {
    select_ln56_1086_fu_41462_p3 = (!icmp_ln56_305_reg_44002_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_305_reg_44002_pp0_iter12_reg.read()[0].to_bool())? data_305_V_read319_s_reg_22117_pp0_iter12_reg.read(): select_ln56_1085_reg_44501.read());
}

void dense_wrapper::thread_select_ln56_1087_fu_41468_p3() {
    select_ln56_1087_fu_41468_p3 = (!icmp_ln56_306_reg_44007_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_306_reg_44007_pp0_iter12_reg.read()[0].to_bool())? data_306_V_read320_s_reg_22130_pp0_iter12_reg.read(): select_ln56_1086_fu_41462_p3.read());
}

void dense_wrapper::thread_select_ln56_1088_fu_41475_p3() {
    select_ln56_1088_fu_41475_p3 = (!icmp_ln56_307_reg_44012_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_307_reg_44012_pp0_iter12_reg.read()[0].to_bool())? data_307_V_read321_s_reg_22143_pp0_iter12_reg.read(): select_ln56_1087_fu_41468_p3.read());
}

void dense_wrapper::thread_select_ln56_1089_fu_41482_p3() {
    select_ln56_1089_fu_41482_p3 = (!icmp_ln56_308_reg_44017_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_308_reg_44017_pp0_iter12_reg.read()[0].to_bool())? data_308_V_read322_s_reg_22156_pp0_iter12_reg.read(): select_ln56_1088_fu_41475_p3.read());
}

void dense_wrapper::thread_select_ln56_108_fu_32400_p3() {
    select_ln56_108_fu_32400_p3 = (!icmp_ln56_174_fu_29586_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_174_fu_29586_p2.read()[0].to_bool())? ap_phi_mux_data_566_V_read580_s_phi_fu_25514_p4.read(): ap_phi_mux_data_565_V_read579_s_phi_fu_25501_p4.read());
}

void dense_wrapper::thread_select_ln56_1090_fu_41489_p3() {
    select_ln56_1090_fu_41489_p3 = (!icmp_ln56_309_reg_44022_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_309_reg_44022_pp0_iter12_reg.read()[0].to_bool())? data_309_V_read323_s_reg_22169_pp0_iter12_reg.read(): select_ln56_1089_fu_41482_p3.read());
}

void dense_wrapper::thread_select_ln56_1091_fu_41496_p3() {
    select_ln56_1091_fu_41496_p3 = (!icmp_ln56_310_reg_44027_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_310_reg_44027_pp0_iter12_reg.read()[0].to_bool())? data_310_V_read324_s_reg_22182_pp0_iter12_reg.read(): select_ln56_1090_fu_41489_p3.read());
}

void dense_wrapper::thread_select_ln56_1092_fu_41503_p3() {
    select_ln56_1092_fu_41503_p3 = (!icmp_ln56_311_reg_44032_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_311_reg_44032_pp0_iter12_reg.read()[0].to_bool())? data_311_V_read325_s_reg_22195_pp0_iter12_reg.read(): select_ln56_1091_fu_41496_p3.read());
}

void dense_wrapper::thread_select_ln56_1093_fu_41510_p3() {
    select_ln56_1093_fu_41510_p3 = (!icmp_ln56_312_reg_44037_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_312_reg_44037_pp0_iter12_reg.read()[0].to_bool())? data_312_V_read326_s_reg_22208_pp0_iter12_reg.read(): select_ln56_1092_fu_41503_p3.read());
}

void dense_wrapper::thread_select_ln56_1094_fu_41517_p3() {
    select_ln56_1094_fu_41517_p3 = (!icmp_ln56_313_reg_44042_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_313_reg_44042_pp0_iter12_reg.read()[0].to_bool())? data_313_V_read327_s_reg_22221_pp0_iter12_reg.read(): select_ln56_1093_fu_41510_p3.read());
}

void dense_wrapper::thread_select_ln56_1095_fu_41524_p3() {
    select_ln56_1095_fu_41524_p3 = (!icmp_ln56_314_reg_44047_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_314_reg_44047_pp0_iter12_reg.read()[0].to_bool())? data_314_V_read328_s_reg_22234_pp0_iter12_reg.read(): select_ln56_1094_fu_41517_p3.read());
}

void dense_wrapper::thread_select_ln56_1096_fu_41531_p3() {
    select_ln56_1096_fu_41531_p3 = (!icmp_ln56_315_reg_44052_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_315_reg_44052_pp0_iter12_reg.read()[0].to_bool())? data_315_V_read329_s_reg_22247_pp0_iter12_reg.read(): select_ln56_1095_fu_41524_p3.read());
}

void dense_wrapper::thread_select_ln56_1097_fu_41538_p3() {
    select_ln56_1097_fu_41538_p3 = (!icmp_ln56_316_reg_44057_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_316_reg_44057_pp0_iter12_reg.read()[0].to_bool())? data_316_V_read330_s_reg_22260_pp0_iter12_reg.read(): select_ln56_1096_fu_41531_p3.read());
}

void dense_wrapper::thread_select_ln56_1098_fu_41545_p3() {
    select_ln56_1098_fu_41545_p3 = (!icmp_ln56_317_reg_44062_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_317_reg_44062_pp0_iter12_reg.read()[0].to_bool())? data_317_V_read331_s_reg_22273_pp0_iter12_reg.read(): select_ln56_1097_fu_41538_p3.read());
}

void dense_wrapper::thread_select_ln56_1099_fu_41552_p3() {
    select_ln56_1099_fu_41552_p3 = (!icmp_ln56_318_reg_44067_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_318_reg_44067_pp0_iter12_reg.read()[0].to_bool())? data_318_V_read332_s_reg_22286_pp0_iter12_reg.read(): select_ln56_1098_fu_41545_p3.read());
}

void dense_wrapper::thread_select_ln56_109_fu_32414_p3() {
    select_ln56_109_fu_32414_p3 = (!icmp_ln56_172_fu_29574_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_172_fu_29574_p2.read()[0].to_bool())? ap_phi_mux_data_564_V_read578_s_phi_fu_25488_p4.read(): ap_phi_mux_data_563_V_read577_s_phi_fu_25475_p4.read());
}

void dense_wrapper::thread_select_ln56_10_fu_31028_p3() {
    select_ln56_10_fu_31028_p3 = (!icmp_ln56_370_fu_30762_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_370_fu_30762_p2.read()[0].to_bool())? ap_phi_mux_data_762_V_read776_s_phi_fu_28062_p4.read(): ap_phi_mux_data_761_V_read775_s_phi_fu_28049_p4.read());
}

void dense_wrapper::thread_select_ln56_1100_fu_41559_p3() {
    select_ln56_1100_fu_41559_p3 = (!icmp_ln56_319_reg_44072_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_319_reg_44072_pp0_iter12_reg.read()[0].to_bool())? data_319_V_read333_s_reg_22299_pp0_iter12_reg.read(): select_ln56_1099_fu_41552_p3.read());
}

void dense_wrapper::thread_select_ln56_1101_fu_41566_p3() {
    select_ln56_1101_fu_41566_p3 = (!icmp_ln56_320_reg_44077_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_320_reg_44077_pp0_iter12_reg.read()[0].to_bool())? data_320_V_read334_s_reg_22312_pp0_iter12_reg.read(): select_ln56_1100_fu_41559_p3.read());
}

void dense_wrapper::thread_select_ln56_1102_fu_41573_p3() {
    select_ln56_1102_fu_41573_p3 = (!icmp_ln56_321_reg_44082_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_321_reg_44082_pp0_iter12_reg.read()[0].to_bool())? data_321_V_read335_s_reg_22325_pp0_iter12_reg.read(): select_ln56_1101_fu_41566_p3.read());
}

void dense_wrapper::thread_select_ln56_1103_fu_41580_p3() {
    select_ln56_1103_fu_41580_p3 = (!icmp_ln56_322_reg_44087_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_322_reg_44087_pp0_iter12_reg.read()[0].to_bool())? data_322_V_read336_s_reg_22338_pp0_iter12_reg.read(): select_ln56_1102_fu_41573_p3.read());
}

void dense_wrapper::thread_select_ln56_1104_fu_41587_p3() {
    select_ln56_1104_fu_41587_p3 = (!icmp_ln56_323_reg_44092_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_323_reg_44092_pp0_iter12_reg.read()[0].to_bool())? data_323_V_read337_s_reg_22351_pp0_iter12_reg.read(): select_ln56_1103_fu_41580_p3.read());
}

void dense_wrapper::thread_select_ln56_1105_fu_41594_p3() {
    select_ln56_1105_fu_41594_p3 = (!icmp_ln56_324_reg_44097_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_324_reg_44097_pp0_iter12_reg.read()[0].to_bool())? data_324_V_read338_s_reg_22364_pp0_iter12_reg.read(): select_ln56_1104_fu_41587_p3.read());
}

void dense_wrapper::thread_select_ln56_1106_fu_41601_p3() {
    select_ln56_1106_fu_41601_p3 = (!icmp_ln56_325_reg_44102_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_325_reg_44102_pp0_iter12_reg.read()[0].to_bool())? data_325_V_read339_s_reg_22377_pp0_iter12_reg.read(): select_ln56_1105_fu_41594_p3.read());
}

void dense_wrapper::thread_select_ln56_1107_fu_41608_p3() {
    select_ln56_1107_fu_41608_p3 = (!icmp_ln56_326_reg_44107_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_326_reg_44107_pp0_iter12_reg.read()[0].to_bool())? data_326_V_read340_s_reg_22390_pp0_iter12_reg.read(): select_ln56_1106_fu_41601_p3.read());
}

void dense_wrapper::thread_select_ln56_1108_fu_41615_p3() {
    select_ln56_1108_fu_41615_p3 = (!icmp_ln56_327_reg_44112_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_327_reg_44112_pp0_iter12_reg.read()[0].to_bool())? data_327_V_read341_s_reg_22403_pp0_iter12_reg.read(): select_ln56_1107_fu_41608_p3.read());
}

void dense_wrapper::thread_select_ln56_1109_fu_41622_p3() {
    select_ln56_1109_fu_41622_p3 = (!icmp_ln56_328_reg_44117_pp0_iter12_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_328_reg_44117_pp0_iter12_reg.read()[0].to_bool())? data_328_V_read342_s_reg_22416_pp0_iter12_reg.read(): select_ln56_1108_fu_41615_p3.read());
}

void dense_wrapper::thread_select_ln56_110_fu_32428_p3() {
    select_ln56_110_fu_32428_p3 = (!icmp_ln56_170_fu_29562_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_170_fu_29562_p2.read()[0].to_bool())? ap_phi_mux_data_562_V_read576_s_phi_fu_25462_p4.read(): ap_phi_mux_data_561_V_read575_s_phi_fu_25449_p4.read());
}

void dense_wrapper::thread_select_ln56_1110_fu_41629_p3() {
    select_ln56_1110_fu_41629_p3 = (!icmp_ln56_329_reg_44122_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_329_reg_44122_pp0_iter13_reg.read()[0].to_bool())? data_329_V_read343_s_reg_22429_pp0_iter13_reg.read(): select_ln56_1109_reg_44506.read());
}

void dense_wrapper::thread_select_ln56_1111_fu_41635_p3() {
    select_ln56_1111_fu_41635_p3 = (!icmp_ln56_330_reg_44127_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_330_reg_44127_pp0_iter13_reg.read()[0].to_bool())? data_330_V_read344_s_reg_22442_pp0_iter13_reg.read(): select_ln56_1110_fu_41629_p3.read());
}

void dense_wrapper::thread_select_ln56_1112_fu_41642_p3() {
    select_ln56_1112_fu_41642_p3 = (!icmp_ln56_331_reg_44132_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_331_reg_44132_pp0_iter13_reg.read()[0].to_bool())? data_331_V_read345_s_reg_22455_pp0_iter13_reg.read(): select_ln56_1111_fu_41635_p3.read());
}

void dense_wrapper::thread_select_ln56_1113_fu_41649_p3() {
    select_ln56_1113_fu_41649_p3 = (!icmp_ln56_332_reg_44137_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_332_reg_44137_pp0_iter13_reg.read()[0].to_bool())? data_332_V_read346_s_reg_22468_pp0_iter13_reg.read(): select_ln56_1112_fu_41642_p3.read());
}

void dense_wrapper::thread_select_ln56_1114_fu_41656_p3() {
    select_ln56_1114_fu_41656_p3 = (!icmp_ln56_333_reg_44142_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_333_reg_44142_pp0_iter13_reg.read()[0].to_bool())? data_333_V_read347_s_reg_22481_pp0_iter13_reg.read(): select_ln56_1113_fu_41649_p3.read());
}

void dense_wrapper::thread_select_ln56_1115_fu_41663_p3() {
    select_ln56_1115_fu_41663_p3 = (!icmp_ln56_334_reg_44147_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_334_reg_44147_pp0_iter13_reg.read()[0].to_bool())? data_334_V_read348_s_reg_22494_pp0_iter13_reg.read(): select_ln56_1114_fu_41656_p3.read());
}

void dense_wrapper::thread_select_ln56_1116_fu_41670_p3() {
    select_ln56_1116_fu_41670_p3 = (!icmp_ln56_335_reg_44152_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_335_reg_44152_pp0_iter13_reg.read()[0].to_bool())? data_335_V_read349_s_reg_22507_pp0_iter13_reg.read(): select_ln56_1115_fu_41663_p3.read());
}

void dense_wrapper::thread_select_ln56_1117_fu_41677_p3() {
    select_ln56_1117_fu_41677_p3 = (!icmp_ln56_336_reg_44157_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_336_reg_44157_pp0_iter13_reg.read()[0].to_bool())? data_336_V_read350_s_reg_22520_pp0_iter13_reg.read(): select_ln56_1116_fu_41670_p3.read());
}

void dense_wrapper::thread_select_ln56_1118_fu_41684_p3() {
    select_ln56_1118_fu_41684_p3 = (!icmp_ln56_337_reg_44162_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_337_reg_44162_pp0_iter13_reg.read()[0].to_bool())? data_337_V_read351_s_reg_22533_pp0_iter13_reg.read(): select_ln56_1117_fu_41677_p3.read());
}

void dense_wrapper::thread_select_ln56_1119_fu_41691_p3() {
    select_ln56_1119_fu_41691_p3 = (!icmp_ln56_338_reg_44167_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_338_reg_44167_pp0_iter13_reg.read()[0].to_bool())? data_338_V_read352_s_reg_22546_pp0_iter13_reg.read(): select_ln56_1118_fu_41684_p3.read());
}

void dense_wrapper::thread_select_ln56_111_fu_32442_p3() {
    select_ln56_111_fu_32442_p3 = (!icmp_ln56_168_fu_29550_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_168_fu_29550_p2.read()[0].to_bool())? ap_phi_mux_data_560_V_read574_s_phi_fu_25436_p4.read(): ap_phi_mux_data_559_V_read573_s_phi_fu_25423_p4.read());
}

void dense_wrapper::thread_select_ln56_1120_fu_41698_p3() {
    select_ln56_1120_fu_41698_p3 = (!icmp_ln56_339_reg_44172_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_339_reg_44172_pp0_iter13_reg.read()[0].to_bool())? data_339_V_read353_s_reg_22559_pp0_iter13_reg.read(): select_ln56_1119_fu_41691_p3.read());
}

void dense_wrapper::thread_select_ln56_1121_fu_41705_p3() {
    select_ln56_1121_fu_41705_p3 = (!icmp_ln56_340_reg_44177_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_340_reg_44177_pp0_iter13_reg.read()[0].to_bool())? data_340_V_read354_s_reg_22572_pp0_iter13_reg.read(): select_ln56_1120_fu_41698_p3.read());
}

void dense_wrapper::thread_select_ln56_1122_fu_41712_p3() {
    select_ln56_1122_fu_41712_p3 = (!icmp_ln56_341_reg_44182_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_341_reg_44182_pp0_iter13_reg.read()[0].to_bool())? data_341_V_read355_s_reg_22585_pp0_iter13_reg.read(): select_ln56_1121_fu_41705_p3.read());
}

void dense_wrapper::thread_select_ln56_1123_fu_41719_p3() {
    select_ln56_1123_fu_41719_p3 = (!icmp_ln56_342_reg_44187_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_342_reg_44187_pp0_iter13_reg.read()[0].to_bool())? data_342_V_read356_s_reg_22598_pp0_iter13_reg.read(): select_ln56_1122_fu_41712_p3.read());
}

void dense_wrapper::thread_select_ln56_1124_fu_41726_p3() {
    select_ln56_1124_fu_41726_p3 = (!icmp_ln56_343_reg_44192_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_343_reg_44192_pp0_iter13_reg.read()[0].to_bool())? data_343_V_read357_s_reg_22611_pp0_iter13_reg.read(): select_ln56_1123_fu_41719_p3.read());
}

void dense_wrapper::thread_select_ln56_1125_fu_41733_p3() {
    select_ln56_1125_fu_41733_p3 = (!icmp_ln56_344_reg_44197_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_344_reg_44197_pp0_iter13_reg.read()[0].to_bool())? data_344_V_read358_s_reg_22624_pp0_iter13_reg.read(): select_ln56_1124_fu_41726_p3.read());
}

void dense_wrapper::thread_select_ln56_1126_fu_41740_p3() {
    select_ln56_1126_fu_41740_p3 = (!icmp_ln56_345_reg_44202_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_345_reg_44202_pp0_iter13_reg.read()[0].to_bool())? data_345_V_read359_s_reg_22637_pp0_iter13_reg.read(): select_ln56_1125_fu_41733_p3.read());
}

void dense_wrapper::thread_select_ln56_1127_fu_41747_p3() {
    select_ln56_1127_fu_41747_p3 = (!icmp_ln56_346_reg_44207_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_346_reg_44207_pp0_iter13_reg.read()[0].to_bool())? data_346_V_read360_s_reg_22650_pp0_iter13_reg.read(): select_ln56_1126_fu_41740_p3.read());
}

void dense_wrapper::thread_select_ln56_1128_fu_41754_p3() {
    select_ln56_1128_fu_41754_p3 = (!icmp_ln56_347_reg_44212_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_347_reg_44212_pp0_iter13_reg.read()[0].to_bool())? data_347_V_read361_s_reg_22663_pp0_iter13_reg.read(): select_ln56_1127_fu_41747_p3.read());
}

void dense_wrapper::thread_select_ln56_1129_fu_41761_p3() {
    select_ln56_1129_fu_41761_p3 = (!icmp_ln56_348_reg_44217_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_348_reg_44217_pp0_iter13_reg.read()[0].to_bool())? data_348_V_read362_s_reg_22676_pp0_iter13_reg.read(): select_ln56_1128_fu_41754_p3.read());
}

void dense_wrapper::thread_select_ln56_112_fu_32456_p3() {
    select_ln56_112_fu_32456_p3 = (!icmp_ln56_166_fu_29538_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_166_fu_29538_p2.read()[0].to_bool())? ap_phi_mux_data_558_V_read572_s_phi_fu_25410_p4.read(): ap_phi_mux_data_557_V_read571_s_phi_fu_25397_p4.read());
}

void dense_wrapper::thread_select_ln56_1130_fu_41768_p3() {
    select_ln56_1130_fu_41768_p3 = (!icmp_ln56_349_reg_44222_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_349_reg_44222_pp0_iter13_reg.read()[0].to_bool())? data_349_V_read363_s_reg_22689_pp0_iter13_reg.read(): select_ln56_1129_fu_41761_p3.read());
}

void dense_wrapper::thread_select_ln56_1131_fu_41775_p3() {
    select_ln56_1131_fu_41775_p3 = (!icmp_ln56_350_reg_44227_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_350_reg_44227_pp0_iter13_reg.read()[0].to_bool())? data_350_V_read364_s_reg_22702_pp0_iter13_reg.read(): select_ln56_1130_fu_41768_p3.read());
}

void dense_wrapper::thread_select_ln56_1132_fu_41782_p3() {
    select_ln56_1132_fu_41782_p3 = (!icmp_ln56_351_reg_44232_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_351_reg_44232_pp0_iter13_reg.read()[0].to_bool())? data_351_V_read365_s_reg_22715_pp0_iter13_reg.read(): select_ln56_1131_fu_41775_p3.read());
}

void dense_wrapper::thread_select_ln56_1133_fu_41789_p3() {
    select_ln56_1133_fu_41789_p3 = (!icmp_ln56_352_reg_44237_pp0_iter13_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_352_reg_44237_pp0_iter13_reg.read()[0].to_bool())? data_352_V_read366_s_reg_22728_pp0_iter13_reg.read(): select_ln56_1132_fu_41782_p3.read());
}

void dense_wrapper::thread_select_ln56_1134_fu_41796_p3() {
    select_ln56_1134_fu_41796_p3 = (!icmp_ln56_353_reg_44242_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_353_reg_44242_pp0_iter14_reg.read()[0].to_bool())? data_353_V_read367_s_reg_22741_pp0_iter14_reg.read(): select_ln56_1133_reg_44511.read());
}

void dense_wrapper::thread_select_ln56_1135_fu_41802_p3() {
    select_ln56_1135_fu_41802_p3 = (!icmp_ln56_354_reg_44247_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_354_reg_44247_pp0_iter14_reg.read()[0].to_bool())? data_354_V_read368_s_reg_22754_pp0_iter14_reg.read(): select_ln56_1134_fu_41796_p3.read());
}

void dense_wrapper::thread_select_ln56_1136_fu_41809_p3() {
    select_ln56_1136_fu_41809_p3 = (!icmp_ln56_355_reg_44252_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_355_reg_44252_pp0_iter14_reg.read()[0].to_bool())? data_355_V_read369_s_reg_22767_pp0_iter14_reg.read(): select_ln56_1135_fu_41802_p3.read());
}

void dense_wrapper::thread_select_ln56_1137_fu_41816_p3() {
    select_ln56_1137_fu_41816_p3 = (!icmp_ln56_356_reg_44257_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_356_reg_44257_pp0_iter14_reg.read()[0].to_bool())? data_356_V_read370_s_reg_22780_pp0_iter14_reg.read(): select_ln56_1136_fu_41809_p3.read());
}

void dense_wrapper::thread_select_ln56_1138_fu_41823_p3() {
    select_ln56_1138_fu_41823_p3 = (!icmp_ln56_357_reg_44262_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_357_reg_44262_pp0_iter14_reg.read()[0].to_bool())? data_357_V_read371_s_reg_22793_pp0_iter14_reg.read(): select_ln56_1137_fu_41816_p3.read());
}

void dense_wrapper::thread_select_ln56_1139_fu_41830_p3() {
    select_ln56_1139_fu_41830_p3 = (!icmp_ln56_358_reg_44267_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_358_reg_44267_pp0_iter14_reg.read()[0].to_bool())? data_358_V_read372_s_reg_22806_pp0_iter14_reg.read(): select_ln56_1138_fu_41823_p3.read());
}

void dense_wrapper::thread_select_ln56_113_fu_32470_p3() {
    select_ln56_113_fu_32470_p3 = (!icmp_ln56_164_fu_29526_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_164_fu_29526_p2.read()[0].to_bool())? ap_phi_mux_data_556_V_read570_s_phi_fu_25384_p4.read(): ap_phi_mux_data_555_V_read569_s_phi_fu_25371_p4.read());
}

void dense_wrapper::thread_select_ln56_1140_fu_41837_p3() {
    select_ln56_1140_fu_41837_p3 = (!icmp_ln56_359_reg_44272_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_359_reg_44272_pp0_iter14_reg.read()[0].to_bool())? data_359_V_read373_s_reg_22819_pp0_iter14_reg.read(): select_ln56_1139_fu_41830_p3.read());
}

void dense_wrapper::thread_select_ln56_1141_fu_41844_p3() {
    select_ln56_1141_fu_41844_p3 = (!icmp_ln56_360_reg_44277_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_360_reg_44277_pp0_iter14_reg.read()[0].to_bool())? data_360_V_read374_s_reg_22832_pp0_iter14_reg.read(): select_ln56_1140_fu_41837_p3.read());
}

void dense_wrapper::thread_select_ln56_1142_fu_41851_p3() {
    select_ln56_1142_fu_41851_p3 = (!icmp_ln56_361_reg_44282_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_361_reg_44282_pp0_iter14_reg.read()[0].to_bool())? data_361_V_read375_s_reg_22845_pp0_iter14_reg.read(): select_ln56_1141_fu_41844_p3.read());
}

void dense_wrapper::thread_select_ln56_1143_fu_41858_p3() {
    select_ln56_1143_fu_41858_p3 = (!icmp_ln56_362_reg_44287_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_362_reg_44287_pp0_iter14_reg.read()[0].to_bool())? data_362_V_read376_s_reg_22858_pp0_iter14_reg.read(): select_ln56_1142_fu_41851_p3.read());
}

void dense_wrapper::thread_select_ln56_1144_fu_41865_p3() {
    select_ln56_1144_fu_41865_p3 = (!icmp_ln56_363_reg_44292_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_363_reg_44292_pp0_iter14_reg.read()[0].to_bool())? data_363_V_read377_s_reg_22871_pp0_iter14_reg.read(): select_ln56_1143_fu_41858_p3.read());
}

void dense_wrapper::thread_select_ln56_1145_fu_41872_p3() {
    select_ln56_1145_fu_41872_p3 = (!icmp_ln56_364_reg_44297_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_364_reg_44297_pp0_iter14_reg.read()[0].to_bool())? data_364_V_read378_s_reg_22884_pp0_iter14_reg.read(): select_ln56_1144_fu_41865_p3.read());
}

void dense_wrapper::thread_select_ln56_1146_fu_41879_p3() {
    select_ln56_1146_fu_41879_p3 = (!icmp_ln56_365_reg_44302_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_365_reg_44302_pp0_iter14_reg.read()[0].to_bool())? data_365_V_read379_s_reg_22897_pp0_iter14_reg.read(): select_ln56_1145_fu_41872_p3.read());
}

void dense_wrapper::thread_select_ln56_1147_fu_41886_p3() {
    select_ln56_1147_fu_41886_p3 = (!icmp_ln56_366_reg_44307_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_366_reg_44307_pp0_iter14_reg.read()[0].to_bool())? data_366_V_read380_s_reg_22910_pp0_iter14_reg.read(): select_ln56_1146_fu_41879_p3.read());
}

void dense_wrapper::thread_select_ln56_1148_fu_41893_p3() {
    select_ln56_1148_fu_41893_p3 = (!icmp_ln56_367_reg_44312_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_367_reg_44312_pp0_iter14_reg.read()[0].to_bool())? data_367_V_read381_s_reg_22923_pp0_iter14_reg.read(): select_ln56_1147_fu_41886_p3.read());
}

void dense_wrapper::thread_select_ln56_1149_fu_41900_p3() {
    select_ln56_1149_fu_41900_p3 = (!icmp_ln56_368_reg_44317_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_368_reg_44317_pp0_iter14_reg.read()[0].to_bool())? data_368_V_read382_s_reg_22936_pp0_iter14_reg.read(): select_ln56_1148_fu_41893_p3.read());
}

void dense_wrapper::thread_select_ln56_114_fu_32484_p3() {
    select_ln56_114_fu_32484_p3 = (!icmp_ln56_162_fu_29514_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_162_fu_29514_p2.read()[0].to_bool())? ap_phi_mux_data_554_V_read568_s_phi_fu_25358_p4.read(): ap_phi_mux_data_553_V_read567_s_phi_fu_25345_p4.read());
}

void dense_wrapper::thread_select_ln56_1150_fu_41907_p3() {
    select_ln56_1150_fu_41907_p3 = (!icmp_ln56_369_reg_44322_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_369_reg_44322_pp0_iter14_reg.read()[0].to_bool())? data_369_V_read383_s_reg_22949_pp0_iter14_reg.read(): select_ln56_1149_fu_41900_p3.read());
}

void dense_wrapper::thread_select_ln56_1151_fu_41914_p3() {
    select_ln56_1151_fu_41914_p3 = (!icmp_ln56_370_reg_44327_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_370_reg_44327_pp0_iter14_reg.read()[0].to_bool())? data_370_V_read384_s_reg_22962_pp0_iter14_reg.read(): select_ln56_1150_fu_41907_p3.read());
}

void dense_wrapper::thread_select_ln56_1152_fu_41921_p3() {
    select_ln56_1152_fu_41921_p3 = (!icmp_ln56_371_reg_44332_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_371_reg_44332_pp0_iter14_reg.read()[0].to_bool())? data_371_V_read385_s_reg_22975_pp0_iter14_reg.read(): select_ln56_1151_fu_41914_p3.read());
}

void dense_wrapper::thread_select_ln56_1153_fu_41928_p3() {
    select_ln56_1153_fu_41928_p3 = (!icmp_ln56_372_reg_44337_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_372_reg_44337_pp0_iter14_reg.read()[0].to_bool())? data_372_V_read386_s_reg_22988_pp0_iter14_reg.read(): select_ln56_1152_fu_41921_p3.read());
}

void dense_wrapper::thread_select_ln56_1154_fu_41935_p3() {
    select_ln56_1154_fu_41935_p3 = (!icmp_ln56_373_reg_44342_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_373_reg_44342_pp0_iter14_reg.read()[0].to_bool())? data_373_V_read387_s_reg_23001_pp0_iter14_reg.read(): select_ln56_1153_fu_41928_p3.read());
}

void dense_wrapper::thread_select_ln56_1155_fu_41942_p3() {
    select_ln56_1155_fu_41942_p3 = (!icmp_ln56_374_reg_44347_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_374_reg_44347_pp0_iter14_reg.read()[0].to_bool())? data_374_V_read388_s_reg_23014_pp0_iter14_reg.read(): select_ln56_1154_fu_41935_p3.read());
}

void dense_wrapper::thread_select_ln56_1156_fu_41949_p3() {
    select_ln56_1156_fu_41949_p3 = (!icmp_ln56_375_reg_44352_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_375_reg_44352_pp0_iter14_reg.read()[0].to_bool())? data_375_V_read389_s_reg_23027_pp0_iter14_reg.read(): select_ln56_1155_fu_41942_p3.read());
}

void dense_wrapper::thread_select_ln56_1157_fu_41956_p3() {
    select_ln56_1157_fu_41956_p3 = (!icmp_ln56_376_reg_44357_pp0_iter14_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_376_reg_44357_pp0_iter14_reg.read()[0].to_bool())? data_376_V_read390_s_reg_23040_pp0_iter14_reg.read(): select_ln56_1156_fu_41949_p3.read());
}

void dense_wrapper::thread_select_ln56_1158_fu_41963_p3() {
    select_ln56_1158_fu_41963_p3 = (!icmp_ln56_377_reg_44362_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_377_reg_44362_pp0_iter15_reg.read()[0].to_bool())? data_377_V_read391_s_reg_23053_pp0_iter15_reg.read(): select_ln56_1157_reg_44516.read());
}

void dense_wrapper::thread_select_ln56_1159_fu_41969_p3() {
    select_ln56_1159_fu_41969_p3 = (!icmp_ln56_378_reg_44367_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_378_reg_44367_pp0_iter15_reg.read()[0].to_bool())? data_378_V_read392_s_reg_23066_pp0_iter15_reg.read(): select_ln56_1158_fu_41963_p3.read());
}

void dense_wrapper::thread_select_ln56_115_fu_32498_p3() {
    select_ln56_115_fu_32498_p3 = (!icmp_ln56_160_fu_29502_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_160_fu_29502_p2.read()[0].to_bool())? ap_phi_mux_data_552_V_read566_s_phi_fu_25332_p4.read(): ap_phi_mux_data_551_V_read565_s_phi_fu_25319_p4.read());
}

void dense_wrapper::thread_select_ln56_1160_fu_41976_p3() {
    select_ln56_1160_fu_41976_p3 = (!icmp_ln56_379_reg_44372_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_379_reg_44372_pp0_iter15_reg.read()[0].to_bool())? data_379_V_read393_s_reg_23079_pp0_iter15_reg.read(): select_ln56_1159_fu_41969_p3.read());
}

void dense_wrapper::thread_select_ln56_1161_fu_41983_p3() {
    select_ln56_1161_fu_41983_p3 = (!icmp_ln56_380_reg_44377_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_380_reg_44377_pp0_iter15_reg.read()[0].to_bool())? data_380_V_read394_s_reg_23092_pp0_iter15_reg.read(): select_ln56_1160_fu_41976_p3.read());
}

void dense_wrapper::thread_select_ln56_1162_fu_41990_p3() {
    select_ln56_1162_fu_41990_p3 = (!icmp_ln56_381_reg_44382_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_381_reg_44382_pp0_iter15_reg.read()[0].to_bool())? data_381_V_read395_s_reg_23105_pp0_iter15_reg.read(): select_ln56_1161_fu_41983_p3.read());
}

void dense_wrapper::thread_select_ln56_1163_fu_41997_p3() {
    select_ln56_1163_fu_41997_p3 = (!icmp_ln56_382_reg_44387_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_382_reg_44387_pp0_iter15_reg.read()[0].to_bool())? data_382_V_read396_s_reg_23118_pp0_iter15_reg.read(): select_ln56_1162_fu_41990_p3.read());
}

void dense_wrapper::thread_select_ln56_1164_fu_42004_p3() {
    select_ln56_1164_fu_42004_p3 = (!icmp_ln56_383_reg_44392_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_383_reg_44392_pp0_iter15_reg.read()[0].to_bool())? data_383_V_read397_s_reg_23131_pp0_iter15_reg.read(): select_ln56_1163_fu_41997_p3.read());
}

void dense_wrapper::thread_select_ln56_1165_fu_42011_p3() {
    select_ln56_1165_fu_42011_p3 = (!icmp_ln56_384_reg_44397_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_384_reg_44397_pp0_iter15_reg.read()[0].to_bool())? data_384_V_read398_s_reg_23144_pp0_iter15_reg.read(): select_ln56_1164_fu_42004_p3.read());
}

void dense_wrapper::thread_select_ln56_1166_fu_42018_p3() {
    select_ln56_1166_fu_42018_p3 = (!icmp_ln56_385_reg_44402_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_385_reg_44402_pp0_iter15_reg.read()[0].to_bool())? data_385_V_read399_s_reg_23157_pp0_iter15_reg.read(): select_ln56_1165_fu_42011_p3.read());
}

void dense_wrapper::thread_select_ln56_1167_fu_42025_p3() {
    select_ln56_1167_fu_42025_p3 = (!icmp_ln56_386_reg_44407_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_386_reg_44407_pp0_iter15_reg.read()[0].to_bool())? data_386_V_read400_s_reg_23170_pp0_iter15_reg.read(): select_ln56_1166_fu_42018_p3.read());
}

void dense_wrapper::thread_select_ln56_1168_fu_42032_p3() {
    select_ln56_1168_fu_42032_p3 = (!icmp_ln56_387_reg_44412_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_387_reg_44412_pp0_iter15_reg.read()[0].to_bool())? data_387_V_read401_s_reg_23183_pp0_iter15_reg.read(): select_ln56_1167_fu_42025_p3.read());
}

void dense_wrapper::thread_select_ln56_1169_fu_42039_p3() {
    select_ln56_1169_fu_42039_p3 = (!icmp_ln56_388_reg_44417_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_388_reg_44417_pp0_iter15_reg.read()[0].to_bool())? data_388_V_read402_s_reg_23196_pp0_iter15_reg.read(): select_ln56_1168_fu_42032_p3.read());
}

void dense_wrapper::thread_select_ln56_116_fu_32512_p3() {
    select_ln56_116_fu_32512_p3 = (!icmp_ln56_158_fu_29490_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_158_fu_29490_p2.read()[0].to_bool())? ap_phi_mux_data_550_V_read564_s_phi_fu_25306_p4.read(): ap_phi_mux_data_549_V_read563_s_phi_fu_25293_p4.read());
}

void dense_wrapper::thread_select_ln56_1170_fu_42046_p3() {
    select_ln56_1170_fu_42046_p3 = (!icmp_ln56_389_reg_44422_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_389_reg_44422_pp0_iter15_reg.read()[0].to_bool())? data_389_V_read403_s_reg_23209_pp0_iter15_reg.read(): select_ln56_1169_fu_42039_p3.read());
}

void dense_wrapper::thread_select_ln56_1171_fu_42053_p3() {
    select_ln56_1171_fu_42053_p3 = (!icmp_ln56_390_reg_44427_pp0_iter15_reg.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_390_reg_44427_pp0_iter15_reg.read()[0].to_bool())? data_390_V_read404_s_reg_23222_pp0_iter15_reg.read(): select_ln56_1170_fu_42046_p3.read());
}

void dense_wrapper::thread_select_ln56_117_fu_32526_p3() {
    select_ln56_117_fu_32526_p3 = (!icmp_ln56_156_fu_29478_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_156_fu_29478_p2.read()[0].to_bool())? ap_phi_mux_data_548_V_read562_s_phi_fu_25280_p4.read(): ap_phi_mux_data_547_V_read561_s_phi_fu_25267_p4.read());
}

void dense_wrapper::thread_select_ln56_118_fu_32540_p3() {
    select_ln56_118_fu_32540_p3 = (!icmp_ln56_154_fu_29466_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_154_fu_29466_p2.read()[0].to_bool())? ap_phi_mux_data_546_V_read560_s_phi_fu_25254_p4.read(): ap_phi_mux_data_545_V_read559_s_phi_fu_25241_p4.read());
}

void dense_wrapper::thread_select_ln56_119_fu_32554_p3() {
    select_ln56_119_fu_32554_p3 = (!icmp_ln56_152_fu_29454_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_152_fu_29454_p2.read()[0].to_bool())? ap_phi_mux_data_544_V_read558_s_phi_fu_25228_p4.read(): ap_phi_mux_data_543_V_read557_s_phi_fu_25215_p4.read());
}

void dense_wrapper::thread_select_ln56_11_fu_31042_p3() {
    select_ln56_11_fu_31042_p3 = (!icmp_ln56_368_fu_30750_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_368_fu_30750_p2.read()[0].to_bool())? ap_phi_mux_data_760_V_read774_s_phi_fu_28036_p4.read(): ap_phi_mux_data_759_V_read773_s_phi_fu_28023_p4.read());
}

void dense_wrapper::thread_select_ln56_120_fu_32568_p3() {
    select_ln56_120_fu_32568_p3 = (!icmp_ln56_150_fu_29442_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_150_fu_29442_p2.read()[0].to_bool())? ap_phi_mux_data_542_V_read556_s_phi_fu_25202_p4.read(): ap_phi_mux_data_541_V_read555_s_phi_fu_25189_p4.read());
}

void dense_wrapper::thread_select_ln56_121_fu_32582_p3() {
    select_ln56_121_fu_32582_p3 = (!icmp_ln56_148_fu_29430_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_148_fu_29430_p2.read()[0].to_bool())? ap_phi_mux_data_540_V_read554_s_phi_fu_25176_p4.read(): ap_phi_mux_data_539_V_read553_s_phi_fu_25163_p4.read());
}

void dense_wrapper::thread_select_ln56_122_fu_32596_p3() {
    select_ln56_122_fu_32596_p3 = (!icmp_ln56_146_fu_29418_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_146_fu_29418_p2.read()[0].to_bool())? ap_phi_mux_data_538_V_read552_s_phi_fu_25150_p4.read(): ap_phi_mux_data_537_V_read551_s_phi_fu_25137_p4.read());
}

void dense_wrapper::thread_select_ln56_123_fu_32610_p3() {
    select_ln56_123_fu_32610_p3 = (!icmp_ln56_144_fu_29406_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_144_fu_29406_p2.read()[0].to_bool())? ap_phi_mux_data_536_V_read550_s_phi_fu_25124_p4.read(): ap_phi_mux_data_535_V_read549_s_phi_fu_25111_p4.read());
}

void dense_wrapper::thread_select_ln56_124_fu_32624_p3() {
    select_ln56_124_fu_32624_p3 = (!icmp_ln56_142_fu_29394_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_142_fu_29394_p2.read()[0].to_bool())? ap_phi_mux_data_534_V_read548_s_phi_fu_25098_p4.read(): ap_phi_mux_data_533_V_read547_s_phi_fu_25085_p4.read());
}

void dense_wrapper::thread_select_ln56_125_fu_32638_p3() {
    select_ln56_125_fu_32638_p3 = (!icmp_ln56_140_fu_29382_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_140_fu_29382_p2.read()[0].to_bool())? ap_phi_mux_data_532_V_read546_s_phi_fu_25072_p4.read(): ap_phi_mux_data_531_V_read545_s_phi_fu_25059_p4.read());
}

void dense_wrapper::thread_select_ln56_126_fu_32652_p3() {
    select_ln56_126_fu_32652_p3 = (!icmp_ln56_138_fu_29370_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_138_fu_29370_p2.read()[0].to_bool())? ap_phi_mux_data_530_V_read544_s_phi_fu_25046_p4.read(): ap_phi_mux_data_529_V_read543_s_phi_fu_25033_p4.read());
}

void dense_wrapper::thread_select_ln56_127_fu_32666_p3() {
    select_ln56_127_fu_32666_p3 = (!icmp_ln56_136_fu_29358_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_136_fu_29358_p2.read()[0].to_bool())? ap_phi_mux_data_528_V_read542_s_phi_fu_25020_p4.read(): ap_phi_mux_data_527_V_read541_s_phi_fu_25007_p4.read());
}

void dense_wrapper::thread_select_ln56_128_fu_32680_p3() {
    select_ln56_128_fu_32680_p3 = (!icmp_ln56_134_fu_29346_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_134_fu_29346_p2.read()[0].to_bool())? ap_phi_mux_data_526_V_read540_s_phi_fu_24994_p4.read(): ap_phi_mux_data_525_V_read539_s_phi_fu_24981_p4.read());
}

void dense_wrapper::thread_select_ln56_129_fu_32694_p3() {
    select_ln56_129_fu_32694_p3 = (!icmp_ln56_132_fu_29334_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_132_fu_29334_p2.read()[0].to_bool())? ap_phi_mux_data_524_V_read538_s_phi_fu_24968_p4.read(): ap_phi_mux_data_523_V_read537_s_phi_fu_24955_p4.read());
}

void dense_wrapper::thread_select_ln56_12_fu_31056_p3() {
    select_ln56_12_fu_31056_p3 = (!icmp_ln56_366_fu_30738_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_366_fu_30738_p2.read()[0].to_bool())? ap_phi_mux_data_758_V_read772_s_phi_fu_28010_p4.read(): ap_phi_mux_data_757_V_read771_s_phi_fu_27997_p4.read());
}

void dense_wrapper::thread_select_ln56_130_fu_32708_p3() {
    select_ln56_130_fu_32708_p3 = (!icmp_ln56_130_fu_29322_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_130_fu_29322_p2.read()[0].to_bool())? ap_phi_mux_data_522_V_read536_s_phi_fu_24942_p4.read(): ap_phi_mux_data_521_V_read535_s_phi_fu_24929_p4.read());
}

void dense_wrapper::thread_select_ln56_131_fu_32722_p3() {
    select_ln56_131_fu_32722_p3 = (!icmp_ln56_128_fu_29310_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_128_fu_29310_p2.read()[0].to_bool())? ap_phi_mux_data_520_V_read534_s_phi_fu_24916_p4.read(): ap_phi_mux_data_519_V_read533_s_phi_fu_24903_p4.read());
}

void dense_wrapper::thread_select_ln56_132_fu_32736_p3() {
    select_ln56_132_fu_32736_p3 = (!icmp_ln56_126_fu_29298_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_126_fu_29298_p2.read()[0].to_bool())? ap_phi_mux_data_518_V_read532_s_phi_fu_24890_p4.read(): ap_phi_mux_data_517_V_read531_s_phi_fu_24877_p4.read());
}

void dense_wrapper::thread_select_ln56_133_fu_32750_p3() {
    select_ln56_133_fu_32750_p3 = (!icmp_ln56_124_fu_29286_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_124_fu_29286_p2.read()[0].to_bool())? ap_phi_mux_data_516_V_read530_s_phi_fu_24864_p4.read(): ap_phi_mux_data_515_V_read529_s_phi_fu_24851_p4.read());
}

void dense_wrapper::thread_select_ln56_134_fu_32764_p3() {
    select_ln56_134_fu_32764_p3 = (!icmp_ln56_122_fu_29274_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_122_fu_29274_p2.read()[0].to_bool())? ap_phi_mux_data_514_V_read528_s_phi_fu_24838_p4.read(): ap_phi_mux_data_513_V_read527_s_phi_fu_24825_p4.read());
}

void dense_wrapper::thread_select_ln56_135_fu_32778_p3() {
    select_ln56_135_fu_32778_p3 = (!icmp_ln56_120_fu_29262_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_120_fu_29262_p2.read()[0].to_bool())? ap_phi_mux_data_512_V_read526_s_phi_fu_24812_p4.read(): ap_phi_mux_data_511_V_read525_s_phi_fu_24799_p4.read());
}

void dense_wrapper::thread_select_ln56_136_fu_32792_p3() {
    select_ln56_136_fu_32792_p3 = (!icmp_ln56_118_fu_29250_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_118_fu_29250_p2.read()[0].to_bool())? ap_phi_mux_data_510_V_read524_s_phi_fu_24786_p4.read(): ap_phi_mux_data_509_V_read523_s_phi_fu_24773_p4.read());
}

void dense_wrapper::thread_select_ln56_137_fu_32806_p3() {
    select_ln56_137_fu_32806_p3 = (!icmp_ln56_116_fu_29238_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_116_fu_29238_p2.read()[0].to_bool())? ap_phi_mux_data_508_V_read522_s_phi_fu_24760_p4.read(): ap_phi_mux_data_507_V_read521_s_phi_fu_24747_p4.read());
}

void dense_wrapper::thread_select_ln56_138_fu_32820_p3() {
    select_ln56_138_fu_32820_p3 = (!icmp_ln56_114_fu_29226_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_114_fu_29226_p2.read()[0].to_bool())? ap_phi_mux_data_506_V_read520_s_phi_fu_24734_p4.read(): ap_phi_mux_data_505_V_read519_s_phi_fu_24721_p4.read());
}

void dense_wrapper::thread_select_ln56_139_fu_32834_p3() {
    select_ln56_139_fu_32834_p3 = (!icmp_ln56_112_fu_29214_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_112_fu_29214_p2.read()[0].to_bool())? ap_phi_mux_data_504_V_read518_s_phi_fu_24708_p4.read(): ap_phi_mux_data_503_V_read517_s_phi_fu_24695_p4.read());
}

void dense_wrapper::thread_select_ln56_13_fu_31070_p3() {
    select_ln56_13_fu_31070_p3 = (!icmp_ln56_364_fu_30726_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_364_fu_30726_p2.read()[0].to_bool())? ap_phi_mux_data_756_V_read770_s_phi_fu_27984_p4.read(): ap_phi_mux_data_755_V_read769_s_phi_fu_27971_p4.read());
}

void dense_wrapper::thread_select_ln56_140_fu_32848_p3() {
    select_ln56_140_fu_32848_p3 = (!icmp_ln56_110_fu_29202_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_110_fu_29202_p2.read()[0].to_bool())? ap_phi_mux_data_502_V_read516_s_phi_fu_24682_p4.read(): ap_phi_mux_data_501_V_read515_s_phi_fu_24669_p4.read());
}

void dense_wrapper::thread_select_ln56_141_fu_32862_p3() {
    select_ln56_141_fu_32862_p3 = (!icmp_ln56_108_fu_29190_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_108_fu_29190_p2.read()[0].to_bool())? ap_phi_mux_data_500_V_read514_s_phi_fu_24656_p4.read(): ap_phi_mux_data_499_V_read513_s_phi_fu_24643_p4.read());
}

void dense_wrapper::thread_select_ln56_142_fu_32876_p3() {
    select_ln56_142_fu_32876_p3 = (!icmp_ln56_106_fu_29178_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_106_fu_29178_p2.read()[0].to_bool())? ap_phi_mux_data_498_V_read512_s_phi_fu_24630_p4.read(): ap_phi_mux_data_497_V_read511_s_phi_fu_24617_p4.read());
}

void dense_wrapper::thread_select_ln56_143_fu_32890_p3() {
    select_ln56_143_fu_32890_p3 = (!icmp_ln56_104_fu_29166_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_104_fu_29166_p2.read()[0].to_bool())? ap_phi_mux_data_496_V_read510_s_phi_fu_24604_p4.read(): ap_phi_mux_data_495_V_read509_s_phi_fu_24591_p4.read());
}

void dense_wrapper::thread_select_ln56_144_fu_32904_p3() {
    select_ln56_144_fu_32904_p3 = (!icmp_ln56_102_fu_29154_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_102_fu_29154_p2.read()[0].to_bool())? ap_phi_mux_data_494_V_read508_s_phi_fu_24578_p4.read(): ap_phi_mux_data_493_V_read507_s_phi_fu_24565_p4.read());
}

void dense_wrapper::thread_select_ln56_145_fu_32918_p3() {
    select_ln56_145_fu_32918_p3 = (!icmp_ln56_100_fu_29142_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_100_fu_29142_p2.read()[0].to_bool())? ap_phi_mux_data_492_V_read506_s_phi_fu_24552_p4.read(): ap_phi_mux_data_491_V_read505_s_phi_fu_24539_p4.read());
}

void dense_wrapper::thread_select_ln56_146_fu_32932_p3() {
    select_ln56_146_fu_32932_p3 = (!icmp_ln56_98_fu_29130_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_98_fu_29130_p2.read()[0].to_bool())? ap_phi_mux_data_490_V_read504_s_phi_fu_24526_p4.read(): ap_phi_mux_data_489_V_read503_s_phi_fu_24513_p4.read());
}

void dense_wrapper::thread_select_ln56_147_fu_32946_p3() {
    select_ln56_147_fu_32946_p3 = (!icmp_ln56_96_fu_29118_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_96_fu_29118_p2.read()[0].to_bool())? ap_phi_mux_data_488_V_read502_s_phi_fu_24500_p4.read(): ap_phi_mux_data_487_V_read501_s_phi_fu_24487_p4.read());
}

void dense_wrapper::thread_select_ln56_148_fu_32960_p3() {
    select_ln56_148_fu_32960_p3 = (!icmp_ln56_94_fu_29106_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_94_fu_29106_p2.read()[0].to_bool())? ap_phi_mux_data_486_V_read500_s_phi_fu_24474_p4.read(): ap_phi_mux_data_485_V_read499_s_phi_fu_24461_p4.read());
}

void dense_wrapper::thread_select_ln56_149_fu_32974_p3() {
    select_ln56_149_fu_32974_p3 = (!icmp_ln56_92_fu_29094_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_92_fu_29094_p2.read()[0].to_bool())? ap_phi_mux_data_484_V_read498_s_phi_fu_24448_p4.read(): ap_phi_mux_data_483_V_read497_s_phi_fu_24435_p4.read());
}

void dense_wrapper::thread_select_ln56_14_fu_31084_p3() {
    select_ln56_14_fu_31084_p3 = (!icmp_ln56_362_fu_30714_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_362_fu_30714_p2.read()[0].to_bool())? ap_phi_mux_data_754_V_read768_s_phi_fu_27958_p4.read(): ap_phi_mux_data_753_V_read767_s_phi_fu_27945_p4.read());
}

void dense_wrapper::thread_select_ln56_150_fu_32988_p3() {
    select_ln56_150_fu_32988_p3 = (!icmp_ln56_90_fu_29082_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_90_fu_29082_p2.read()[0].to_bool())? ap_phi_mux_data_482_V_read496_s_phi_fu_24422_p4.read(): ap_phi_mux_data_481_V_read495_s_phi_fu_24409_p4.read());
}

void dense_wrapper::thread_select_ln56_151_fu_33002_p3() {
    select_ln56_151_fu_33002_p3 = (!icmp_ln56_88_fu_29070_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_88_fu_29070_p2.read()[0].to_bool())? ap_phi_mux_data_480_V_read494_s_phi_fu_24396_p4.read(): ap_phi_mux_data_479_V_read493_s_phi_fu_24383_p4.read());
}

void dense_wrapper::thread_select_ln56_152_fu_33016_p3() {
    select_ln56_152_fu_33016_p3 = (!icmp_ln56_86_fu_29058_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_86_fu_29058_p2.read()[0].to_bool())? ap_phi_mux_data_478_V_read492_s_phi_fu_24370_p4.read(): ap_phi_mux_data_477_V_read491_s_phi_fu_24357_p4.read());
}

void dense_wrapper::thread_select_ln56_153_fu_33030_p3() {
    select_ln56_153_fu_33030_p3 = (!icmp_ln56_84_fu_29046_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_84_fu_29046_p2.read()[0].to_bool())? ap_phi_mux_data_476_V_read490_s_phi_fu_24344_p4.read(): ap_phi_mux_data_475_V_read489_s_phi_fu_24331_p4.read());
}

void dense_wrapper::thread_select_ln56_154_fu_33044_p3() {
    select_ln56_154_fu_33044_p3 = (!icmp_ln56_82_fu_29034_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_82_fu_29034_p2.read()[0].to_bool())? ap_phi_mux_data_474_V_read488_s_phi_fu_24318_p4.read(): ap_phi_mux_data_473_V_read487_s_phi_fu_24305_p4.read());
}

void dense_wrapper::thread_select_ln56_155_fu_33058_p3() {
    select_ln56_155_fu_33058_p3 = (!icmp_ln56_80_fu_29022_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_80_fu_29022_p2.read()[0].to_bool())? ap_phi_mux_data_472_V_read486_s_phi_fu_24292_p4.read(): ap_phi_mux_data_471_V_read485_s_phi_fu_24279_p4.read());
}

void dense_wrapper::thread_select_ln56_156_fu_33072_p3() {
    select_ln56_156_fu_33072_p3 = (!icmp_ln56_78_fu_29010_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_78_fu_29010_p2.read()[0].to_bool())? ap_phi_mux_data_470_V_read484_s_phi_fu_24266_p4.read(): ap_phi_mux_data_469_V_read483_s_phi_fu_24253_p4.read());
}

void dense_wrapper::thread_select_ln56_157_fu_33086_p3() {
    select_ln56_157_fu_33086_p3 = (!icmp_ln56_76_fu_28998_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_76_fu_28998_p2.read()[0].to_bool())? ap_phi_mux_data_468_V_read482_s_phi_fu_24240_p4.read(): ap_phi_mux_data_467_V_read481_s_phi_fu_24227_p4.read());
}

void dense_wrapper::thread_select_ln56_158_fu_33100_p3() {
    select_ln56_158_fu_33100_p3 = (!icmp_ln56_74_fu_28986_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_74_fu_28986_p2.read()[0].to_bool())? ap_phi_mux_data_466_V_read480_s_phi_fu_24214_p4.read(): ap_phi_mux_data_465_V_read479_s_phi_fu_24201_p4.read());
}

void dense_wrapper::thread_select_ln56_159_fu_33114_p3() {
    select_ln56_159_fu_33114_p3 = (!icmp_ln56_72_fu_28974_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_72_fu_28974_p2.read()[0].to_bool())? ap_phi_mux_data_464_V_read478_s_phi_fu_24188_p4.read(): ap_phi_mux_data_463_V_read477_s_phi_fu_24175_p4.read());
}

void dense_wrapper::thread_select_ln56_15_fu_31098_p3() {
    select_ln56_15_fu_31098_p3 = (!icmp_ln56_360_fu_30702_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_360_fu_30702_p2.read()[0].to_bool())? ap_phi_mux_data_752_V_read766_s_phi_fu_27932_p4.read(): ap_phi_mux_data_751_V_read765_s_phi_fu_27919_p4.read());
}

void dense_wrapper::thread_select_ln56_160_fu_33128_p3() {
    select_ln56_160_fu_33128_p3 = (!icmp_ln56_70_fu_28962_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_70_fu_28962_p2.read()[0].to_bool())? ap_phi_mux_data_462_V_read476_s_phi_fu_24162_p4.read(): ap_phi_mux_data_461_V_read475_s_phi_fu_24149_p4.read());
}

void dense_wrapper::thread_select_ln56_161_fu_33142_p3() {
    select_ln56_161_fu_33142_p3 = (!icmp_ln56_68_fu_28950_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_68_fu_28950_p2.read()[0].to_bool())? ap_phi_mux_data_460_V_read474_s_phi_fu_24136_p4.read(): ap_phi_mux_data_459_V_read473_s_phi_fu_24123_p4.read());
}

void dense_wrapper::thread_select_ln56_162_fu_33156_p3() {
    select_ln56_162_fu_33156_p3 = (!icmp_ln56_66_fu_28938_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_66_fu_28938_p2.read()[0].to_bool())? ap_phi_mux_data_458_V_read472_s_phi_fu_24110_p4.read(): ap_phi_mux_data_457_V_read471_s_phi_fu_24097_p4.read());
}

void dense_wrapper::thread_select_ln56_163_fu_33170_p3() {
    select_ln56_163_fu_33170_p3 = (!icmp_ln56_64_fu_28926_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_64_fu_28926_p2.read()[0].to_bool())? ap_phi_mux_data_456_V_read470_s_phi_fu_24084_p4.read(): ap_phi_mux_data_455_V_read469_s_phi_fu_24071_p4.read());
}

void dense_wrapper::thread_select_ln56_164_fu_33184_p3() {
    select_ln56_164_fu_33184_p3 = (!icmp_ln56_62_fu_28914_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_62_fu_28914_p2.read()[0].to_bool())? ap_phi_mux_data_454_V_read468_s_phi_fu_24058_p4.read(): ap_phi_mux_data_453_V_read467_s_phi_fu_24045_p4.read());
}

void dense_wrapper::thread_select_ln56_165_fu_33198_p3() {
    select_ln56_165_fu_33198_p3 = (!icmp_ln56_60_fu_28902_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_60_fu_28902_p2.read()[0].to_bool())? ap_phi_mux_data_452_V_read466_s_phi_fu_24032_p4.read(): ap_phi_mux_data_451_V_read465_s_phi_fu_24019_p4.read());
}

void dense_wrapper::thread_select_ln56_166_fu_33212_p3() {
    select_ln56_166_fu_33212_p3 = (!icmp_ln56_58_fu_28890_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_58_fu_28890_p2.read()[0].to_bool())? ap_phi_mux_data_450_V_read464_s_phi_fu_24006_p4.read(): ap_phi_mux_data_449_V_read463_s_phi_fu_23993_p4.read());
}

void dense_wrapper::thread_select_ln56_167_fu_33226_p3() {
    select_ln56_167_fu_33226_p3 = (!icmp_ln56_56_fu_28878_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_56_fu_28878_p2.read()[0].to_bool())? ap_phi_mux_data_448_V_read462_s_phi_fu_23980_p4.read(): ap_phi_mux_data_447_V_read461_s_phi_fu_23967_p4.read());
}

void dense_wrapper::thread_select_ln56_168_fu_33240_p3() {
    select_ln56_168_fu_33240_p3 = (!icmp_ln56_54_fu_28866_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_54_fu_28866_p2.read()[0].to_bool())? ap_phi_mux_data_446_V_read460_s_phi_fu_23954_p4.read(): ap_phi_mux_data_445_V_read459_s_phi_fu_23941_p4.read());
}

void dense_wrapper::thread_select_ln56_169_fu_33254_p3() {
    select_ln56_169_fu_33254_p3 = (!icmp_ln56_52_fu_28854_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_52_fu_28854_p2.read()[0].to_bool())? ap_phi_mux_data_444_V_read458_s_phi_fu_23928_p4.read(): ap_phi_mux_data_443_V_read457_s_phi_fu_23915_p4.read());
}

void dense_wrapper::thread_select_ln56_16_fu_31112_p3() {
    select_ln56_16_fu_31112_p3 = (!icmp_ln56_358_fu_30690_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_358_fu_30690_p2.read()[0].to_bool())? ap_phi_mux_data_750_V_read764_s_phi_fu_27906_p4.read(): ap_phi_mux_data_749_V_read763_s_phi_fu_27893_p4.read());
}

void dense_wrapper::thread_select_ln56_170_fu_33268_p3() {
    select_ln56_170_fu_33268_p3 = (!icmp_ln56_50_fu_28842_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_50_fu_28842_p2.read()[0].to_bool())? ap_phi_mux_data_442_V_read456_s_phi_fu_23902_p4.read(): ap_phi_mux_data_441_V_read455_s_phi_fu_23889_p4.read());
}

void dense_wrapper::thread_select_ln56_171_fu_33282_p3() {
    select_ln56_171_fu_33282_p3 = (!icmp_ln56_48_fu_28830_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_48_fu_28830_p2.read()[0].to_bool())? ap_phi_mux_data_440_V_read454_s_phi_fu_23876_p4.read(): ap_phi_mux_data_439_V_read453_s_phi_fu_23863_p4.read());
}

void dense_wrapper::thread_select_ln56_172_fu_33296_p3() {
    select_ln56_172_fu_33296_p3 = (!icmp_ln56_46_fu_28818_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_46_fu_28818_p2.read()[0].to_bool())? ap_phi_mux_data_438_V_read452_s_phi_fu_23850_p4.read(): ap_phi_mux_data_437_V_read451_s_phi_fu_23837_p4.read());
}

void dense_wrapper::thread_select_ln56_173_fu_33310_p3() {
    select_ln56_173_fu_33310_p3 = (!icmp_ln56_44_fu_28806_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_44_fu_28806_p2.read()[0].to_bool())? ap_phi_mux_data_436_V_read450_s_phi_fu_23824_p4.read(): ap_phi_mux_data_435_V_read449_s_phi_fu_23811_p4.read());
}

void dense_wrapper::thread_select_ln56_174_fu_33324_p3() {
    select_ln56_174_fu_33324_p3 = (!icmp_ln56_42_fu_28794_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_42_fu_28794_p2.read()[0].to_bool())? ap_phi_mux_data_434_V_read448_s_phi_fu_23798_p4.read(): ap_phi_mux_data_433_V_read447_s_phi_fu_23785_p4.read());
}

void dense_wrapper::thread_select_ln56_175_fu_33338_p3() {
    select_ln56_175_fu_33338_p3 = (!icmp_ln56_40_fu_28782_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_40_fu_28782_p2.read()[0].to_bool())? ap_phi_mux_data_432_V_read446_s_phi_fu_23772_p4.read(): ap_phi_mux_data_431_V_read445_s_phi_fu_23759_p4.read());
}

void dense_wrapper::thread_select_ln56_176_fu_33352_p3() {
    select_ln56_176_fu_33352_p3 = (!icmp_ln56_38_fu_28770_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_38_fu_28770_p2.read()[0].to_bool())? ap_phi_mux_data_430_V_read444_s_phi_fu_23746_p4.read(): ap_phi_mux_data_429_V_read443_s_phi_fu_23733_p4.read());
}

void dense_wrapper::thread_select_ln56_177_fu_33366_p3() {
    select_ln56_177_fu_33366_p3 = (!icmp_ln56_36_fu_28758_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_36_fu_28758_p2.read()[0].to_bool())? ap_phi_mux_data_428_V_read442_s_phi_fu_23720_p4.read(): ap_phi_mux_data_427_V_read441_s_phi_fu_23707_p4.read());
}

void dense_wrapper::thread_select_ln56_178_fu_33380_p3() {
    select_ln56_178_fu_33380_p3 = (!icmp_ln56_34_fu_28746_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_34_fu_28746_p2.read()[0].to_bool())? ap_phi_mux_data_426_V_read440_s_phi_fu_23694_p4.read(): ap_phi_mux_data_425_V_read439_s_phi_fu_23681_p4.read());
}

void dense_wrapper::thread_select_ln56_179_fu_33394_p3() {
    select_ln56_179_fu_33394_p3 = (!icmp_ln56_32_fu_28734_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_32_fu_28734_p2.read()[0].to_bool())? ap_phi_mux_data_424_V_read438_s_phi_fu_23668_p4.read(): ap_phi_mux_data_423_V_read437_s_phi_fu_23655_p4.read());
}

void dense_wrapper::thread_select_ln56_17_fu_31126_p3() {
    select_ln56_17_fu_31126_p3 = (!icmp_ln56_356_fu_30678_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_356_fu_30678_p2.read()[0].to_bool())? ap_phi_mux_data_748_V_read762_s_phi_fu_27880_p4.read(): ap_phi_mux_data_747_V_read761_s_phi_fu_27867_p4.read());
}

void dense_wrapper::thread_select_ln56_180_fu_33408_p3() {
    select_ln56_180_fu_33408_p3 = (!icmp_ln56_30_fu_28722_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_30_fu_28722_p2.read()[0].to_bool())? ap_phi_mux_data_422_V_read436_s_phi_fu_23642_p4.read(): ap_phi_mux_data_421_V_read435_s_phi_fu_23629_p4.read());
}

void dense_wrapper::thread_select_ln56_181_fu_33422_p3() {
    select_ln56_181_fu_33422_p3 = (!icmp_ln56_28_fu_28710_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_28_fu_28710_p2.read()[0].to_bool())? ap_phi_mux_data_420_V_read434_s_phi_fu_23616_p4.read(): ap_phi_mux_data_419_V_read433_s_phi_fu_23603_p4.read());
}

void dense_wrapper::thread_select_ln56_182_fu_33436_p3() {
    select_ln56_182_fu_33436_p3 = (!icmp_ln56_26_fu_28698_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_26_fu_28698_p2.read()[0].to_bool())? ap_phi_mux_data_418_V_read432_s_phi_fu_23590_p4.read(): ap_phi_mux_data_417_V_read431_s_phi_fu_23577_p4.read());
}

void dense_wrapper::thread_select_ln56_183_fu_33450_p3() {
    select_ln56_183_fu_33450_p3 = (!icmp_ln56_24_fu_28686_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_24_fu_28686_p2.read()[0].to_bool())? ap_phi_mux_data_416_V_read430_s_phi_fu_23564_p4.read(): ap_phi_mux_data_415_V_read429_s_phi_fu_23551_p4.read());
}

void dense_wrapper::thread_select_ln56_184_fu_33464_p3() {
    select_ln56_184_fu_33464_p3 = (!icmp_ln56_22_fu_28674_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_22_fu_28674_p2.read()[0].to_bool())? ap_phi_mux_data_414_V_read428_s_phi_fu_23538_p4.read(): ap_phi_mux_data_413_V_read427_s_phi_fu_23525_p4.read());
}

void dense_wrapper::thread_select_ln56_185_fu_33478_p3() {
    select_ln56_185_fu_33478_p3 = (!icmp_ln56_20_fu_28662_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_20_fu_28662_p2.read()[0].to_bool())? ap_phi_mux_data_412_V_read426_s_phi_fu_23512_p4.read(): ap_phi_mux_data_411_V_read425_s_phi_fu_23499_p4.read());
}

void dense_wrapper::thread_select_ln56_186_fu_33492_p3() {
    select_ln56_186_fu_33492_p3 = (!icmp_ln56_18_fu_28650_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_18_fu_28650_p2.read()[0].to_bool())? ap_phi_mux_data_410_V_read424_s_phi_fu_23486_p4.read(): ap_phi_mux_data_409_V_read423_s_phi_fu_23473_p4.read());
}

void dense_wrapper::thread_select_ln56_187_fu_33506_p3() {
    select_ln56_187_fu_33506_p3 = (!icmp_ln56_16_fu_28630_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_16_fu_28630_p2.read()[0].to_bool())? ap_phi_mux_data_408_V_read422_s_phi_fu_23460_p4.read(): ap_phi_mux_data_407_V_read421_s_phi_fu_23447_p4.read());
}

void dense_wrapper::thread_select_ln56_188_fu_33520_p3() {
    select_ln56_188_fu_33520_p3 = (!icmp_ln56_14_fu_28602_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_28602_p2.read()[0].to_bool())? ap_phi_mux_data_406_V_read420_s_phi_fu_23434_p4.read(): ap_phi_mux_data_405_V_read419_s_phi_fu_23421_p4.read());
}

void dense_wrapper::thread_select_ln56_189_fu_33534_p3() {
    select_ln56_189_fu_33534_p3 = (!icmp_ln56_12_fu_28574_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_28574_p2.read()[0].to_bool())? ap_phi_mux_data_404_V_read418_s_phi_fu_23408_p4.read(): ap_phi_mux_data_403_V_read417_s_phi_fu_23395_p4.read());
}

void dense_wrapper::thread_select_ln56_18_fu_31140_p3() {
    select_ln56_18_fu_31140_p3 = (!icmp_ln56_354_fu_30666_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_354_fu_30666_p2.read()[0].to_bool())? ap_phi_mux_data_746_V_read760_s_phi_fu_27854_p4.read(): ap_phi_mux_data_745_V_read759_s_phi_fu_27841_p4.read());
}

void dense_wrapper::thread_select_ln56_190_fu_33548_p3() {
    select_ln56_190_fu_33548_p3 = (!icmp_ln56_10_fu_28546_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_28546_p2.read()[0].to_bool())? ap_phi_mux_data_402_V_read416_s_phi_fu_23382_p4.read(): ap_phi_mux_data_401_V_read415_s_phi_fu_23369_p4.read());
}

void dense_wrapper::thread_select_ln56_191_fu_33562_p3() {
    select_ln56_191_fu_33562_p3 = (!icmp_ln56_8_fu_28518_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_28518_p2.read()[0].to_bool())? ap_phi_mux_data_400_V_read414_s_phi_fu_23356_p4.read(): ap_phi_mux_data_399_V_read413_s_phi_fu_23343_p4.read());
}

void dense_wrapper::thread_select_ln56_192_fu_33576_p3() {
    select_ln56_192_fu_33576_p3 = (!icmp_ln56_6_fu_28490_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_28490_p2.read()[0].to_bool())? ap_phi_mux_data_398_V_read412_s_phi_fu_23330_p4.read(): ap_phi_mux_data_397_V_read411_s_phi_fu_23317_p4.read());
}

void dense_wrapper::thread_select_ln56_193_fu_33590_p3() {
    select_ln56_193_fu_33590_p3 = (!icmp_ln56_4_fu_28462_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_28462_p2.read()[0].to_bool())? ap_phi_mux_data_396_V_read410_s_phi_fu_23304_p4.read(): ap_phi_mux_data_395_V_read409_s_phi_fu_23291_p4.read());
}

void dense_wrapper::thread_select_ln56_194_fu_33604_p3() {
    select_ln56_194_fu_33604_p3 = (!icmp_ln56_2_fu_28434_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_28434_p2.read()[0].to_bool())? ap_phi_mux_data_394_V_read408_s_phi_fu_23278_p4.read(): ap_phi_mux_data_393_V_read407_s_phi_fu_23265_p4.read());
}

void dense_wrapper::thread_select_ln56_195_fu_33618_p3() {
    select_ln56_195_fu_33618_p3 = (!icmp_ln56_fu_28406_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_28406_p2.read()[0].to_bool())? ap_phi_mux_data_392_V_read406_s_phi_fu_23252_p4.read(): ap_phi_mux_data_783_V_read797_s_phi_fu_28335_p4.read());
}

void dense_wrapper::thread_select_ln56_196_fu_33626_p3() {
    select_ln56_196_fu_33626_p3 = (!or_ln56_fu_30896_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_30896_p2.read()[0].to_bool())? select_ln56_fu_30888_p3.read(): select_ln56_1_fu_30902_p3.read());
}

void dense_wrapper::thread_select_ln56_197_fu_33640_p3() {
    select_ln56_197_fu_33640_p3 = (!or_ln56_2_fu_30924_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_30924_p2.read()[0].to_bool())? select_ln56_2_fu_30916_p3.read(): select_ln56_3_fu_30930_p3.read());
}

void dense_wrapper::thread_select_ln56_198_fu_33654_p3() {
    select_ln56_198_fu_33654_p3 = (!or_ln56_4_fu_30952_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_30952_p2.read()[0].to_bool())? select_ln56_4_fu_30944_p3.read(): select_ln56_5_fu_30958_p3.read());
}

void dense_wrapper::thread_select_ln56_199_fu_33668_p3() {
    select_ln56_199_fu_33668_p3 = (!or_ln56_6_fu_30980_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_30980_p2.read()[0].to_bool())? select_ln56_6_fu_30972_p3.read(): select_ln56_7_fu_30986_p3.read());
}

void dense_wrapper::thread_select_ln56_19_fu_31154_p3() {
    select_ln56_19_fu_31154_p3 = (!icmp_ln56_352_fu_30654_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_352_fu_30654_p2.read()[0].to_bool())? ap_phi_mux_data_744_V_read758_s_phi_fu_27828_p4.read(): ap_phi_mux_data_743_V_read757_s_phi_fu_27815_p4.read());
}

void dense_wrapper::thread_select_ln56_1_fu_30902_p3() {
    select_ln56_1_fu_30902_p3 = (!icmp_ln56_388_fu_30870_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_388_fu_30870_p2.read()[0].to_bool())? ap_phi_mux_data_780_V_read794_s_phi_fu_28296_p4.read(): ap_phi_mux_data_779_V_read793_s_phi_fu_28283_p4.read());
}

void dense_wrapper::thread_select_ln56_200_fu_33682_p3() {
    select_ln56_200_fu_33682_p3 = (!or_ln56_8_fu_31008_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_8_fu_31008_p2.read()[0].to_bool())? select_ln56_8_fu_31000_p3.read(): select_ln56_9_fu_31014_p3.read());
}

void dense_wrapper::thread_select_ln56_201_fu_33696_p3() {
    select_ln56_201_fu_33696_p3 = (!or_ln56_10_fu_31036_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_31036_p2.read()[0].to_bool())? select_ln56_10_fu_31028_p3.read(): select_ln56_11_fu_31042_p3.read());
}

void dense_wrapper::thread_select_ln56_202_fu_33710_p3() {
    select_ln56_202_fu_33710_p3 = (!or_ln56_12_fu_31064_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_12_fu_31064_p2.read()[0].to_bool())? select_ln56_12_fu_31056_p3.read(): select_ln56_13_fu_31070_p3.read());
}

void dense_wrapper::thread_select_ln56_203_fu_33724_p3() {
    select_ln56_203_fu_33724_p3 = (!or_ln56_14_fu_31092_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_14_fu_31092_p2.read()[0].to_bool())? select_ln56_14_fu_31084_p3.read(): select_ln56_15_fu_31098_p3.read());
}

void dense_wrapper::thread_select_ln56_204_fu_33738_p3() {
    select_ln56_204_fu_33738_p3 = (!or_ln56_16_fu_31120_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_16_fu_31120_p2.read()[0].to_bool())? select_ln56_16_fu_31112_p3.read(): select_ln56_17_fu_31126_p3.read());
}

void dense_wrapper::thread_select_ln56_205_fu_33752_p3() {
    select_ln56_205_fu_33752_p3 = (!or_ln56_18_fu_31148_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_18_fu_31148_p2.read()[0].to_bool())? select_ln56_18_fu_31140_p3.read(): select_ln56_19_fu_31154_p3.read());
}

void dense_wrapper::thread_select_ln56_206_fu_33766_p3() {
    select_ln56_206_fu_33766_p3 = (!or_ln56_20_fu_31176_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_20_fu_31176_p2.read()[0].to_bool())? select_ln56_20_fu_31168_p3.read(): select_ln56_21_fu_31182_p3.read());
}

void dense_wrapper::thread_select_ln56_207_fu_33780_p3() {
    select_ln56_207_fu_33780_p3 = (!or_ln56_22_fu_31204_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_22_fu_31204_p2.read()[0].to_bool())? select_ln56_22_fu_31196_p3.read(): select_ln56_23_fu_31210_p3.read());
}

void dense_wrapper::thread_select_ln56_208_fu_33794_p3() {
    select_ln56_208_fu_33794_p3 = (!or_ln56_24_fu_31232_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_24_fu_31232_p2.read()[0].to_bool())? select_ln56_24_fu_31224_p3.read(): select_ln56_25_fu_31238_p3.read());
}

void dense_wrapper::thread_select_ln56_209_fu_33808_p3() {
    select_ln56_209_fu_33808_p3 = (!or_ln56_26_fu_31260_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_26_fu_31260_p2.read()[0].to_bool())? select_ln56_26_fu_31252_p3.read(): select_ln56_27_fu_31266_p3.read());
}

void dense_wrapper::thread_select_ln56_20_fu_31168_p3() {
    select_ln56_20_fu_31168_p3 = (!icmp_ln56_350_fu_30642_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_350_fu_30642_p2.read()[0].to_bool())? ap_phi_mux_data_742_V_read756_s_phi_fu_27802_p4.read(): ap_phi_mux_data_741_V_read755_s_phi_fu_27789_p4.read());
}

void dense_wrapper::thread_select_ln56_210_fu_33822_p3() {
    select_ln56_210_fu_33822_p3 = (!or_ln56_28_fu_31288_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_28_fu_31288_p2.read()[0].to_bool())? select_ln56_28_fu_31280_p3.read(): select_ln56_29_fu_31294_p3.read());
}

void dense_wrapper::thread_select_ln56_211_fu_33836_p3() {
    select_ln56_211_fu_33836_p3 = (!or_ln56_30_fu_31316_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_30_fu_31316_p2.read()[0].to_bool())? select_ln56_30_fu_31308_p3.read(): select_ln56_31_fu_31322_p3.read());
}

void dense_wrapper::thread_select_ln56_212_fu_33850_p3() {
    select_ln56_212_fu_33850_p3 = (!or_ln56_32_fu_31344_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_32_fu_31344_p2.read()[0].to_bool())? select_ln56_32_fu_31336_p3.read(): select_ln56_33_fu_31350_p3.read());
}

void dense_wrapper::thread_select_ln56_213_fu_33864_p3() {
    select_ln56_213_fu_33864_p3 = (!or_ln56_34_fu_31372_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_34_fu_31372_p2.read()[0].to_bool())? select_ln56_34_fu_31364_p3.read(): select_ln56_35_fu_31378_p3.read());
}

void dense_wrapper::thread_select_ln56_214_fu_33878_p3() {
    select_ln56_214_fu_33878_p3 = (!or_ln56_36_fu_31400_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_36_fu_31400_p2.read()[0].to_bool())? select_ln56_36_fu_31392_p3.read(): select_ln56_37_fu_31406_p3.read());
}

void dense_wrapper::thread_select_ln56_215_fu_33892_p3() {
    select_ln56_215_fu_33892_p3 = (!or_ln56_38_fu_31428_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_38_fu_31428_p2.read()[0].to_bool())? select_ln56_38_fu_31420_p3.read(): select_ln56_39_fu_31434_p3.read());
}

void dense_wrapper::thread_select_ln56_216_fu_33906_p3() {
    select_ln56_216_fu_33906_p3 = (!or_ln56_40_fu_31456_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_40_fu_31456_p2.read()[0].to_bool())? select_ln56_40_fu_31448_p3.read(): select_ln56_41_fu_31462_p3.read());
}

void dense_wrapper::thread_select_ln56_217_fu_33920_p3() {
    select_ln56_217_fu_33920_p3 = (!or_ln56_42_fu_31484_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_42_fu_31484_p2.read()[0].to_bool())? select_ln56_42_fu_31476_p3.read(): select_ln56_43_fu_31490_p3.read());
}

void dense_wrapper::thread_select_ln56_218_fu_33934_p3() {
    select_ln56_218_fu_33934_p3 = (!or_ln56_44_fu_31512_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_44_fu_31512_p2.read()[0].to_bool())? select_ln56_44_fu_31504_p3.read(): select_ln56_45_fu_31518_p3.read());
}

void dense_wrapper::thread_select_ln56_219_fu_33948_p3() {
    select_ln56_219_fu_33948_p3 = (!or_ln56_46_fu_31540_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_46_fu_31540_p2.read()[0].to_bool())? select_ln56_46_fu_31532_p3.read(): select_ln56_47_fu_31546_p3.read());
}

void dense_wrapper::thread_select_ln56_21_fu_31182_p3() {
    select_ln56_21_fu_31182_p3 = (!icmp_ln56_348_fu_30630_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_348_fu_30630_p2.read()[0].to_bool())? ap_phi_mux_data_740_V_read754_s_phi_fu_27776_p4.read(): ap_phi_mux_data_739_V_read753_s_phi_fu_27763_p4.read());
}

void dense_wrapper::thread_select_ln56_220_fu_33962_p3() {
    select_ln56_220_fu_33962_p3 = (!or_ln56_48_fu_31568_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_48_fu_31568_p2.read()[0].to_bool())? select_ln56_48_fu_31560_p3.read(): select_ln56_49_fu_31574_p3.read());
}

void dense_wrapper::thread_select_ln56_221_fu_33976_p3() {
    select_ln56_221_fu_33976_p3 = (!or_ln56_50_fu_31596_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_50_fu_31596_p2.read()[0].to_bool())? select_ln56_50_fu_31588_p3.read(): select_ln56_51_fu_31602_p3.read());
}

void dense_wrapper::thread_select_ln56_222_fu_33990_p3() {
    select_ln56_222_fu_33990_p3 = (!or_ln56_52_fu_31624_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_52_fu_31624_p2.read()[0].to_bool())? select_ln56_52_fu_31616_p3.read(): select_ln56_53_fu_31630_p3.read());
}

void dense_wrapper::thread_select_ln56_223_fu_34004_p3() {
    select_ln56_223_fu_34004_p3 = (!or_ln56_54_fu_31652_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_54_fu_31652_p2.read()[0].to_bool())? select_ln56_54_fu_31644_p3.read(): select_ln56_55_fu_31658_p3.read());
}

void dense_wrapper::thread_select_ln56_224_fu_34018_p3() {
    select_ln56_224_fu_34018_p3 = (!or_ln56_56_fu_31680_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_56_fu_31680_p2.read()[0].to_bool())? select_ln56_56_fu_31672_p3.read(): select_ln56_57_fu_31686_p3.read());
}

void dense_wrapper::thread_select_ln56_225_fu_34032_p3() {
    select_ln56_225_fu_34032_p3 = (!or_ln56_58_fu_31708_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_58_fu_31708_p2.read()[0].to_bool())? select_ln56_58_fu_31700_p3.read(): select_ln56_59_fu_31714_p3.read());
}

void dense_wrapper::thread_select_ln56_226_fu_34046_p3() {
    select_ln56_226_fu_34046_p3 = (!or_ln56_60_fu_31736_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_60_fu_31736_p2.read()[0].to_bool())? select_ln56_60_fu_31728_p3.read(): select_ln56_61_fu_31742_p3.read());
}

void dense_wrapper::thread_select_ln56_227_fu_34060_p3() {
    select_ln56_227_fu_34060_p3 = (!or_ln56_62_fu_31764_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_62_fu_31764_p2.read()[0].to_bool())? select_ln56_62_fu_31756_p3.read(): select_ln56_63_fu_31770_p3.read());
}

void dense_wrapper::thread_select_ln56_228_fu_34074_p3() {
    select_ln56_228_fu_34074_p3 = (!or_ln56_64_fu_31792_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_64_fu_31792_p2.read()[0].to_bool())? select_ln56_64_fu_31784_p3.read(): select_ln56_65_fu_31798_p3.read());
}

void dense_wrapper::thread_select_ln56_229_fu_34088_p3() {
    select_ln56_229_fu_34088_p3 = (!or_ln56_66_fu_31820_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_66_fu_31820_p2.read()[0].to_bool())? select_ln56_66_fu_31812_p3.read(): select_ln56_67_fu_31826_p3.read());
}

void dense_wrapper::thread_select_ln56_22_fu_31196_p3() {
    select_ln56_22_fu_31196_p3 = (!icmp_ln56_346_fu_30618_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_346_fu_30618_p2.read()[0].to_bool())? ap_phi_mux_data_738_V_read752_s_phi_fu_27750_p4.read(): ap_phi_mux_data_737_V_read751_s_phi_fu_27737_p4.read());
}

void dense_wrapper::thread_select_ln56_230_fu_34102_p3() {
    select_ln56_230_fu_34102_p3 = (!or_ln56_68_fu_31848_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_68_fu_31848_p2.read()[0].to_bool())? select_ln56_68_fu_31840_p3.read(): select_ln56_69_fu_31854_p3.read());
}

void dense_wrapper::thread_select_ln56_231_fu_34116_p3() {
    select_ln56_231_fu_34116_p3 = (!or_ln56_70_fu_31876_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_70_fu_31876_p2.read()[0].to_bool())? select_ln56_70_fu_31868_p3.read(): select_ln56_71_fu_31882_p3.read());
}

void dense_wrapper::thread_select_ln56_232_fu_34130_p3() {
    select_ln56_232_fu_34130_p3 = (!or_ln56_72_fu_31904_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_72_fu_31904_p2.read()[0].to_bool())? select_ln56_72_fu_31896_p3.read(): select_ln56_73_fu_31910_p3.read());
}

void dense_wrapper::thread_select_ln56_233_fu_34144_p3() {
    select_ln56_233_fu_34144_p3 = (!or_ln56_74_fu_31932_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_74_fu_31932_p2.read()[0].to_bool())? select_ln56_74_fu_31924_p3.read(): select_ln56_75_fu_31938_p3.read());
}

void dense_wrapper::thread_select_ln56_234_fu_34158_p3() {
    select_ln56_234_fu_34158_p3 = (!or_ln56_76_fu_31960_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_76_fu_31960_p2.read()[0].to_bool())? select_ln56_76_fu_31952_p3.read(): select_ln56_77_fu_31966_p3.read());
}

void dense_wrapper::thread_select_ln56_235_fu_34172_p3() {
    select_ln56_235_fu_34172_p3 = (!or_ln56_78_fu_31988_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_78_fu_31988_p2.read()[0].to_bool())? select_ln56_78_fu_31980_p3.read(): select_ln56_79_fu_31994_p3.read());
}

void dense_wrapper::thread_select_ln56_236_fu_34186_p3() {
    select_ln56_236_fu_34186_p3 = (!or_ln56_80_fu_32016_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_80_fu_32016_p2.read()[0].to_bool())? select_ln56_80_fu_32008_p3.read(): select_ln56_81_fu_32022_p3.read());
}

void dense_wrapper::thread_select_ln56_237_fu_34200_p3() {
    select_ln56_237_fu_34200_p3 = (!or_ln56_82_fu_32044_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_82_fu_32044_p2.read()[0].to_bool())? select_ln56_82_fu_32036_p3.read(): select_ln56_83_fu_32050_p3.read());
}

void dense_wrapper::thread_select_ln56_238_fu_34214_p3() {
    select_ln56_238_fu_34214_p3 = (!or_ln56_84_fu_32072_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_84_fu_32072_p2.read()[0].to_bool())? select_ln56_84_fu_32064_p3.read(): select_ln56_85_fu_32078_p3.read());
}

void dense_wrapper::thread_select_ln56_239_fu_34228_p3() {
    select_ln56_239_fu_34228_p3 = (!or_ln56_86_fu_32100_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_86_fu_32100_p2.read()[0].to_bool())? select_ln56_86_fu_32092_p3.read(): select_ln56_87_fu_32106_p3.read());
}

void dense_wrapper::thread_select_ln56_23_fu_31210_p3() {
    select_ln56_23_fu_31210_p3 = (!icmp_ln56_344_fu_30606_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_344_fu_30606_p2.read()[0].to_bool())? ap_phi_mux_data_736_V_read750_s_phi_fu_27724_p4.read(): ap_phi_mux_data_735_V_read749_s_phi_fu_27711_p4.read());
}

void dense_wrapper::thread_select_ln56_240_fu_34242_p3() {
    select_ln56_240_fu_34242_p3 = (!or_ln56_88_fu_32128_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_88_fu_32128_p2.read()[0].to_bool())? select_ln56_88_fu_32120_p3.read(): select_ln56_89_fu_32134_p3.read());
}

void dense_wrapper::thread_select_ln56_241_fu_34256_p3() {
    select_ln56_241_fu_34256_p3 = (!or_ln56_90_fu_32156_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_90_fu_32156_p2.read()[0].to_bool())? select_ln56_90_fu_32148_p3.read(): select_ln56_91_fu_32162_p3.read());
}

void dense_wrapper::thread_select_ln56_242_fu_34270_p3() {
    select_ln56_242_fu_34270_p3 = (!or_ln56_92_fu_32184_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_92_fu_32184_p2.read()[0].to_bool())? select_ln56_92_fu_32176_p3.read(): select_ln56_93_fu_32190_p3.read());
}

void dense_wrapper::thread_select_ln56_243_fu_34284_p3() {
    select_ln56_243_fu_34284_p3 = (!or_ln56_94_fu_32212_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_94_fu_32212_p2.read()[0].to_bool())? select_ln56_94_fu_32204_p3.read(): select_ln56_95_fu_32218_p3.read());
}

void dense_wrapper::thread_select_ln56_244_fu_34298_p3() {
    select_ln56_244_fu_34298_p3 = (!or_ln56_96_fu_32240_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_96_fu_32240_p2.read()[0].to_bool())? select_ln56_96_fu_32232_p3.read(): select_ln56_97_fu_32246_p3.read());
}

void dense_wrapper::thread_select_ln56_245_fu_34312_p3() {
    select_ln56_245_fu_34312_p3 = (!or_ln56_98_fu_32268_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_98_fu_32268_p2.read()[0].to_bool())? select_ln56_98_fu_32260_p3.read(): select_ln56_99_fu_32274_p3.read());
}

void dense_wrapper::thread_select_ln56_246_fu_34326_p3() {
    select_ln56_246_fu_34326_p3 = (!or_ln56_100_fu_32296_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_100_fu_32296_p2.read()[0].to_bool())? select_ln56_100_fu_32288_p3.read(): select_ln56_101_fu_32302_p3.read());
}

void dense_wrapper::thread_select_ln56_247_fu_34340_p3() {
    select_ln56_247_fu_34340_p3 = (!or_ln56_102_fu_32324_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_102_fu_32324_p2.read()[0].to_bool())? select_ln56_102_fu_32316_p3.read(): select_ln56_103_fu_32330_p3.read());
}

void dense_wrapper::thread_select_ln56_248_fu_34354_p3() {
    select_ln56_248_fu_34354_p3 = (!or_ln56_104_fu_32352_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_104_fu_32352_p2.read()[0].to_bool())? select_ln56_104_fu_32344_p3.read(): select_ln56_105_fu_32358_p3.read());
}

void dense_wrapper::thread_select_ln56_249_fu_34368_p3() {
    select_ln56_249_fu_34368_p3 = (!or_ln56_106_fu_32380_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_106_fu_32380_p2.read()[0].to_bool())? select_ln56_106_fu_32372_p3.read(): select_ln56_107_fu_32386_p3.read());
}

void dense_wrapper::thread_select_ln56_24_fu_31224_p3() {
    select_ln56_24_fu_31224_p3 = (!icmp_ln56_342_fu_30594_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_342_fu_30594_p2.read()[0].to_bool())? ap_phi_mux_data_734_V_read748_s_phi_fu_27698_p4.read(): ap_phi_mux_data_733_V_read747_s_phi_fu_27685_p4.read());
}

void dense_wrapper::thread_select_ln56_250_fu_34382_p3() {
    select_ln56_250_fu_34382_p3 = (!or_ln56_108_fu_32408_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_108_fu_32408_p2.read()[0].to_bool())? select_ln56_108_fu_32400_p3.read(): select_ln56_109_fu_32414_p3.read());
}

void dense_wrapper::thread_select_ln56_251_fu_34396_p3() {
    select_ln56_251_fu_34396_p3 = (!or_ln56_110_fu_32436_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_110_fu_32436_p2.read()[0].to_bool())? select_ln56_110_fu_32428_p3.read(): select_ln56_111_fu_32442_p3.read());
}

void dense_wrapper::thread_select_ln56_252_fu_34410_p3() {
    select_ln56_252_fu_34410_p3 = (!or_ln56_112_fu_32464_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_112_fu_32464_p2.read()[0].to_bool())? select_ln56_112_fu_32456_p3.read(): select_ln56_113_fu_32470_p3.read());
}

void dense_wrapper::thread_select_ln56_253_fu_34424_p3() {
    select_ln56_253_fu_34424_p3 = (!or_ln56_114_fu_32492_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_114_fu_32492_p2.read()[0].to_bool())? select_ln56_114_fu_32484_p3.read(): select_ln56_115_fu_32498_p3.read());
}

void dense_wrapper::thread_select_ln56_254_fu_34438_p3() {
    select_ln56_254_fu_34438_p3 = (!or_ln56_116_fu_32520_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_116_fu_32520_p2.read()[0].to_bool())? select_ln56_116_fu_32512_p3.read(): select_ln56_117_fu_32526_p3.read());
}

void dense_wrapper::thread_select_ln56_255_fu_34452_p3() {
    select_ln56_255_fu_34452_p3 = (!or_ln56_118_fu_32548_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_118_fu_32548_p2.read()[0].to_bool())? select_ln56_118_fu_32540_p3.read(): select_ln56_119_fu_32554_p3.read());
}

void dense_wrapper::thread_select_ln56_256_fu_34466_p3() {
    select_ln56_256_fu_34466_p3 = (!or_ln56_120_fu_32576_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_120_fu_32576_p2.read()[0].to_bool())? select_ln56_120_fu_32568_p3.read(): select_ln56_121_fu_32582_p3.read());
}

void dense_wrapper::thread_select_ln56_257_fu_34480_p3() {
    select_ln56_257_fu_34480_p3 = (!or_ln56_122_fu_32604_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_122_fu_32604_p2.read()[0].to_bool())? select_ln56_122_fu_32596_p3.read(): select_ln56_123_fu_32610_p3.read());
}

void dense_wrapper::thread_select_ln56_258_fu_34494_p3() {
    select_ln56_258_fu_34494_p3 = (!or_ln56_124_fu_32632_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_124_fu_32632_p2.read()[0].to_bool())? select_ln56_124_fu_32624_p3.read(): select_ln56_125_fu_32638_p3.read());
}

void dense_wrapper::thread_select_ln56_259_fu_34508_p3() {
    select_ln56_259_fu_34508_p3 = (!or_ln56_126_fu_32660_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_126_fu_32660_p2.read()[0].to_bool())? select_ln56_126_fu_32652_p3.read(): select_ln56_127_fu_32666_p3.read());
}

void dense_wrapper::thread_select_ln56_25_fu_31238_p3() {
    select_ln56_25_fu_31238_p3 = (!icmp_ln56_340_fu_30582_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_340_fu_30582_p2.read()[0].to_bool())? ap_phi_mux_data_732_V_read746_s_phi_fu_27672_p4.read(): ap_phi_mux_data_731_V_read745_s_phi_fu_27659_p4.read());
}

void dense_wrapper::thread_select_ln56_260_fu_34522_p3() {
    select_ln56_260_fu_34522_p3 = (!or_ln56_128_fu_32688_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_128_fu_32688_p2.read()[0].to_bool())? select_ln56_128_fu_32680_p3.read(): select_ln56_129_fu_32694_p3.read());
}

void dense_wrapper::thread_select_ln56_261_fu_34536_p3() {
    select_ln56_261_fu_34536_p3 = (!or_ln56_130_fu_32716_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_130_fu_32716_p2.read()[0].to_bool())? select_ln56_130_fu_32708_p3.read(): select_ln56_131_fu_32722_p3.read());
}

void dense_wrapper::thread_select_ln56_262_fu_34550_p3() {
    select_ln56_262_fu_34550_p3 = (!or_ln56_132_fu_32744_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_132_fu_32744_p2.read()[0].to_bool())? select_ln56_132_fu_32736_p3.read(): select_ln56_133_fu_32750_p3.read());
}

void dense_wrapper::thread_select_ln56_263_fu_34564_p3() {
    select_ln56_263_fu_34564_p3 = (!or_ln56_134_fu_32772_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_134_fu_32772_p2.read()[0].to_bool())? select_ln56_134_fu_32764_p3.read(): select_ln56_135_fu_32778_p3.read());
}

void dense_wrapper::thread_select_ln56_264_fu_34578_p3() {
    select_ln56_264_fu_34578_p3 = (!or_ln56_136_fu_32800_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_136_fu_32800_p2.read()[0].to_bool())? select_ln56_136_fu_32792_p3.read(): select_ln56_137_fu_32806_p3.read());
}

void dense_wrapper::thread_select_ln56_265_fu_34592_p3() {
    select_ln56_265_fu_34592_p3 = (!or_ln56_138_fu_32828_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_138_fu_32828_p2.read()[0].to_bool())? select_ln56_138_fu_32820_p3.read(): select_ln56_139_fu_32834_p3.read());
}

void dense_wrapper::thread_select_ln56_266_fu_34606_p3() {
    select_ln56_266_fu_34606_p3 = (!or_ln56_140_fu_32856_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_140_fu_32856_p2.read()[0].to_bool())? select_ln56_140_fu_32848_p3.read(): select_ln56_141_fu_32862_p3.read());
}

void dense_wrapper::thread_select_ln56_267_fu_34620_p3() {
    select_ln56_267_fu_34620_p3 = (!or_ln56_142_fu_32884_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_142_fu_32884_p2.read()[0].to_bool())? select_ln56_142_fu_32876_p3.read(): select_ln56_143_fu_32890_p3.read());
}

void dense_wrapper::thread_select_ln56_268_fu_34634_p3() {
    select_ln56_268_fu_34634_p3 = (!or_ln56_144_fu_32912_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_144_fu_32912_p2.read()[0].to_bool())? select_ln56_144_fu_32904_p3.read(): select_ln56_145_fu_32918_p3.read());
}

void dense_wrapper::thread_select_ln56_269_fu_34648_p3() {
    select_ln56_269_fu_34648_p3 = (!or_ln56_146_fu_32940_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_146_fu_32940_p2.read()[0].to_bool())? select_ln56_146_fu_32932_p3.read(): select_ln56_147_fu_32946_p3.read());
}

void dense_wrapper::thread_select_ln56_26_fu_31252_p3() {
    select_ln56_26_fu_31252_p3 = (!icmp_ln56_338_fu_30570_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_338_fu_30570_p2.read()[0].to_bool())? ap_phi_mux_data_730_V_read744_s_phi_fu_27646_p4.read(): ap_phi_mux_data_729_V_read743_s_phi_fu_27633_p4.read());
}

void dense_wrapper::thread_select_ln56_270_fu_34662_p3() {
    select_ln56_270_fu_34662_p3 = (!or_ln56_148_fu_32968_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_148_fu_32968_p2.read()[0].to_bool())? select_ln56_148_fu_32960_p3.read(): select_ln56_149_fu_32974_p3.read());
}

void dense_wrapper::thread_select_ln56_271_fu_34676_p3() {
    select_ln56_271_fu_34676_p3 = (!or_ln56_150_fu_32996_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_150_fu_32996_p2.read()[0].to_bool())? select_ln56_150_fu_32988_p3.read(): select_ln56_151_fu_33002_p3.read());
}

void dense_wrapper::thread_select_ln56_272_fu_34690_p3() {
    select_ln56_272_fu_34690_p3 = (!or_ln56_152_fu_33024_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_152_fu_33024_p2.read()[0].to_bool())? select_ln56_152_fu_33016_p3.read(): select_ln56_153_fu_33030_p3.read());
}

void dense_wrapper::thread_select_ln56_273_fu_34704_p3() {
    select_ln56_273_fu_34704_p3 = (!or_ln56_154_fu_33052_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_154_fu_33052_p2.read()[0].to_bool())? select_ln56_154_fu_33044_p3.read(): select_ln56_155_fu_33058_p3.read());
}

void dense_wrapper::thread_select_ln56_274_fu_34718_p3() {
    select_ln56_274_fu_34718_p3 = (!or_ln56_156_fu_33080_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_156_fu_33080_p2.read()[0].to_bool())? select_ln56_156_fu_33072_p3.read(): select_ln56_157_fu_33086_p3.read());
}

void dense_wrapper::thread_select_ln56_275_fu_34732_p3() {
    select_ln56_275_fu_34732_p3 = (!or_ln56_158_fu_33108_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_158_fu_33108_p2.read()[0].to_bool())? select_ln56_158_fu_33100_p3.read(): select_ln56_159_fu_33114_p3.read());
}

void dense_wrapper::thread_select_ln56_276_fu_34746_p3() {
    select_ln56_276_fu_34746_p3 = (!or_ln56_160_fu_33136_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_160_fu_33136_p2.read()[0].to_bool())? select_ln56_160_fu_33128_p3.read(): select_ln56_161_fu_33142_p3.read());
}

void dense_wrapper::thread_select_ln56_277_fu_34760_p3() {
    select_ln56_277_fu_34760_p3 = (!or_ln56_162_fu_33164_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_162_fu_33164_p2.read()[0].to_bool())? select_ln56_162_fu_33156_p3.read(): select_ln56_163_fu_33170_p3.read());
}

void dense_wrapper::thread_select_ln56_278_fu_34774_p3() {
    select_ln56_278_fu_34774_p3 = (!or_ln56_164_fu_33192_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_164_fu_33192_p2.read()[0].to_bool())? select_ln56_164_fu_33184_p3.read(): select_ln56_165_fu_33198_p3.read());
}

void dense_wrapper::thread_select_ln56_279_fu_34788_p3() {
    select_ln56_279_fu_34788_p3 = (!or_ln56_166_fu_33220_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_166_fu_33220_p2.read()[0].to_bool())? select_ln56_166_fu_33212_p3.read(): select_ln56_167_fu_33226_p3.read());
}

void dense_wrapper::thread_select_ln56_27_fu_31266_p3() {
    select_ln56_27_fu_31266_p3 = (!icmp_ln56_336_fu_30558_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_336_fu_30558_p2.read()[0].to_bool())? ap_phi_mux_data_728_V_read742_s_phi_fu_27620_p4.read(): ap_phi_mux_data_727_V_read741_s_phi_fu_27607_p4.read());
}

void dense_wrapper::thread_select_ln56_280_fu_34802_p3() {
    select_ln56_280_fu_34802_p3 = (!or_ln56_168_fu_33248_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_168_fu_33248_p2.read()[0].to_bool())? select_ln56_168_fu_33240_p3.read(): select_ln56_169_fu_33254_p3.read());
}

void dense_wrapper::thread_select_ln56_281_fu_34816_p3() {
    select_ln56_281_fu_34816_p3 = (!or_ln56_170_fu_33276_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_170_fu_33276_p2.read()[0].to_bool())? select_ln56_170_fu_33268_p3.read(): select_ln56_171_fu_33282_p3.read());
}

void dense_wrapper::thread_select_ln56_282_fu_34830_p3() {
    select_ln56_282_fu_34830_p3 = (!or_ln56_172_fu_33304_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_172_fu_33304_p2.read()[0].to_bool())? select_ln56_172_fu_33296_p3.read(): select_ln56_173_fu_33310_p3.read());
}

void dense_wrapper::thread_select_ln56_283_fu_34844_p3() {
    select_ln56_283_fu_34844_p3 = (!or_ln56_174_fu_33332_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_174_fu_33332_p2.read()[0].to_bool())? select_ln56_174_fu_33324_p3.read(): select_ln56_175_fu_33338_p3.read());
}

void dense_wrapper::thread_select_ln56_284_fu_34858_p3() {
    select_ln56_284_fu_34858_p3 = (!or_ln56_176_fu_33360_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_176_fu_33360_p2.read()[0].to_bool())? select_ln56_176_fu_33352_p3.read(): select_ln56_177_fu_33366_p3.read());
}

void dense_wrapper::thread_select_ln56_285_fu_34872_p3() {
    select_ln56_285_fu_34872_p3 = (!or_ln56_178_fu_33388_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_178_fu_33388_p2.read()[0].to_bool())? select_ln56_178_fu_33380_p3.read(): select_ln56_179_fu_33394_p3.read());
}

void dense_wrapper::thread_select_ln56_286_fu_34886_p3() {
    select_ln56_286_fu_34886_p3 = (!or_ln56_180_fu_33416_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_180_fu_33416_p2.read()[0].to_bool())? select_ln56_180_fu_33408_p3.read(): select_ln56_181_fu_33422_p3.read());
}

void dense_wrapper::thread_select_ln56_287_fu_34900_p3() {
    select_ln56_287_fu_34900_p3 = (!or_ln56_182_fu_33444_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_182_fu_33444_p2.read()[0].to_bool())? select_ln56_182_fu_33436_p3.read(): select_ln56_183_fu_33450_p3.read());
}

void dense_wrapper::thread_select_ln56_288_fu_34914_p3() {
    select_ln56_288_fu_34914_p3 = (!or_ln56_184_fu_33472_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_184_fu_33472_p2.read()[0].to_bool())? select_ln56_184_fu_33464_p3.read(): select_ln56_185_fu_33478_p3.read());
}

void dense_wrapper::thread_select_ln56_289_fu_34928_p3() {
    select_ln56_289_fu_34928_p3 = (!or_ln56_186_fu_33500_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_186_fu_33500_p2.read()[0].to_bool())? select_ln56_186_fu_33492_p3.read(): select_ln56_187_fu_33506_p3.read());
}

void dense_wrapper::thread_select_ln56_28_fu_31280_p3() {
    select_ln56_28_fu_31280_p3 = (!icmp_ln56_334_fu_30546_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_334_fu_30546_p2.read()[0].to_bool())? ap_phi_mux_data_726_V_read740_s_phi_fu_27594_p4.read(): ap_phi_mux_data_725_V_read739_s_phi_fu_27581_p4.read());
}

void dense_wrapper::thread_select_ln56_290_fu_34942_p3() {
    select_ln56_290_fu_34942_p3 = (!or_ln56_188_fu_33528_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_188_fu_33528_p2.read()[0].to_bool())? select_ln56_188_fu_33520_p3.read(): select_ln56_189_fu_33534_p3.read());
}

void dense_wrapper::thread_select_ln56_291_fu_34956_p3() {
    select_ln56_291_fu_34956_p3 = (!or_ln56_190_fu_33556_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_190_fu_33556_p2.read()[0].to_bool())? select_ln56_190_fu_33548_p3.read(): select_ln56_191_fu_33562_p3.read());
}

void dense_wrapper::thread_select_ln56_292_fu_34970_p3() {
    select_ln56_292_fu_34970_p3 = (!or_ln56_192_fu_33584_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_192_fu_33584_p2.read()[0].to_bool())? select_ln56_192_fu_33576_p3.read(): select_ln56_193_fu_33590_p3.read());
}

void dense_wrapper::thread_select_ln56_293_fu_34984_p3() {
    select_ln56_293_fu_34984_p3 = (!or_ln56_194_fu_33612_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_194_fu_33612_p2.read()[0].to_bool())? select_ln56_194_fu_33604_p3.read(): select_ln56_195_fu_33618_p3.read());
}

void dense_wrapper::thread_select_ln56_294_fu_34992_p3() {
    select_ln56_294_fu_34992_p3 = (!or_ln56_195_fu_33634_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_195_fu_33634_p2.read()[0].to_bool())? select_ln56_196_fu_33626_p3.read(): select_ln56_197_fu_33640_p3.read());
}

void dense_wrapper::thread_select_ln56_295_fu_35006_p3() {
    select_ln56_295_fu_35006_p3 = (!or_ln56_197_fu_33662_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_197_fu_33662_p2.read()[0].to_bool())? select_ln56_198_fu_33654_p3.read(): select_ln56_199_fu_33668_p3.read());
}

void dense_wrapper::thread_select_ln56_296_fu_35020_p3() {
    select_ln56_296_fu_35020_p3 = (!or_ln56_199_fu_33690_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_199_fu_33690_p2.read()[0].to_bool())? select_ln56_200_fu_33682_p3.read(): select_ln56_201_fu_33696_p3.read());
}

void dense_wrapper::thread_select_ln56_297_fu_35034_p3() {
    select_ln56_297_fu_35034_p3 = (!or_ln56_201_fu_33718_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_201_fu_33718_p2.read()[0].to_bool())? select_ln56_202_fu_33710_p3.read(): select_ln56_203_fu_33724_p3.read());
}

void dense_wrapper::thread_select_ln56_298_fu_35048_p3() {
    select_ln56_298_fu_35048_p3 = (!or_ln56_203_fu_33746_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_203_fu_33746_p2.read()[0].to_bool())? select_ln56_204_fu_33738_p3.read(): select_ln56_205_fu_33752_p3.read());
}

void dense_wrapper::thread_select_ln56_299_fu_35062_p3() {
    select_ln56_299_fu_35062_p3 = (!or_ln56_205_fu_33774_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_205_fu_33774_p2.read()[0].to_bool())? select_ln56_206_fu_33766_p3.read(): select_ln56_207_fu_33780_p3.read());
}

void dense_wrapper::thread_select_ln56_29_fu_31294_p3() {
    select_ln56_29_fu_31294_p3 = (!icmp_ln56_332_fu_30534_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_332_fu_30534_p2.read()[0].to_bool())? ap_phi_mux_data_724_V_read738_s_phi_fu_27568_p4.read(): ap_phi_mux_data_723_V_read737_s_phi_fu_27555_p4.read());
}

void dense_wrapper::thread_select_ln56_2_fu_30916_p3() {
    select_ln56_2_fu_30916_p3 = (!icmp_ln56_386_fu_30858_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_386_fu_30858_p2.read()[0].to_bool())? ap_phi_mux_data_778_V_read792_s_phi_fu_28270_p4.read(): ap_phi_mux_data_777_V_read791_s_phi_fu_28257_p4.read());
}

void dense_wrapper::thread_select_ln56_300_fu_35076_p3() {
    select_ln56_300_fu_35076_p3 = (!or_ln56_207_fu_33802_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_207_fu_33802_p2.read()[0].to_bool())? select_ln56_208_fu_33794_p3.read(): select_ln56_209_fu_33808_p3.read());
}

void dense_wrapper::thread_select_ln56_301_fu_35090_p3() {
    select_ln56_301_fu_35090_p3 = (!or_ln56_209_fu_33830_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_209_fu_33830_p2.read()[0].to_bool())? select_ln56_210_fu_33822_p3.read(): select_ln56_211_fu_33836_p3.read());
}

void dense_wrapper::thread_select_ln56_302_fu_35104_p3() {
    select_ln56_302_fu_35104_p3 = (!or_ln56_211_fu_33858_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_211_fu_33858_p2.read()[0].to_bool())? select_ln56_212_fu_33850_p3.read(): select_ln56_213_fu_33864_p3.read());
}

void dense_wrapper::thread_select_ln56_303_fu_35118_p3() {
    select_ln56_303_fu_35118_p3 = (!or_ln56_213_fu_33886_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_213_fu_33886_p2.read()[0].to_bool())? select_ln56_214_fu_33878_p3.read(): select_ln56_215_fu_33892_p3.read());
}

void dense_wrapper::thread_select_ln56_304_fu_35132_p3() {
    select_ln56_304_fu_35132_p3 = (!or_ln56_215_fu_33914_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_215_fu_33914_p2.read()[0].to_bool())? select_ln56_216_fu_33906_p3.read(): select_ln56_217_fu_33920_p3.read());
}

void dense_wrapper::thread_select_ln56_305_fu_35146_p3() {
    select_ln56_305_fu_35146_p3 = (!or_ln56_217_fu_33942_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_217_fu_33942_p2.read()[0].to_bool())? select_ln56_218_fu_33934_p3.read(): select_ln56_219_fu_33948_p3.read());
}

void dense_wrapper::thread_select_ln56_306_fu_35160_p3() {
    select_ln56_306_fu_35160_p3 = (!or_ln56_219_fu_33970_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_219_fu_33970_p2.read()[0].to_bool())? select_ln56_220_fu_33962_p3.read(): select_ln56_221_fu_33976_p3.read());
}

void dense_wrapper::thread_select_ln56_307_fu_35174_p3() {
    select_ln56_307_fu_35174_p3 = (!or_ln56_221_fu_33998_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_221_fu_33998_p2.read()[0].to_bool())? select_ln56_222_fu_33990_p3.read(): select_ln56_223_fu_34004_p3.read());
}

void dense_wrapper::thread_select_ln56_308_fu_35188_p3() {
    select_ln56_308_fu_35188_p3 = (!or_ln56_223_fu_34026_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_223_fu_34026_p2.read()[0].to_bool())? select_ln56_224_fu_34018_p3.read(): select_ln56_225_fu_34032_p3.read());
}

void dense_wrapper::thread_select_ln56_309_fu_35202_p3() {
    select_ln56_309_fu_35202_p3 = (!or_ln56_225_fu_34054_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_225_fu_34054_p2.read()[0].to_bool())? select_ln56_226_fu_34046_p3.read(): select_ln56_227_fu_34060_p3.read());
}

void dense_wrapper::thread_select_ln56_30_fu_31308_p3() {
    select_ln56_30_fu_31308_p3 = (!icmp_ln56_330_fu_30522_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_330_fu_30522_p2.read()[0].to_bool())? ap_phi_mux_data_722_V_read736_s_phi_fu_27542_p4.read(): ap_phi_mux_data_721_V_read735_s_phi_fu_27529_p4.read());
}

void dense_wrapper::thread_select_ln56_310_fu_35216_p3() {
    select_ln56_310_fu_35216_p3 = (!or_ln56_227_fu_34082_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_227_fu_34082_p2.read()[0].to_bool())? select_ln56_228_fu_34074_p3.read(): select_ln56_229_fu_34088_p3.read());
}

void dense_wrapper::thread_select_ln56_311_fu_35230_p3() {
    select_ln56_311_fu_35230_p3 = (!or_ln56_229_fu_34110_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_229_fu_34110_p2.read()[0].to_bool())? select_ln56_230_fu_34102_p3.read(): select_ln56_231_fu_34116_p3.read());
}

void dense_wrapper::thread_select_ln56_312_fu_35244_p3() {
    select_ln56_312_fu_35244_p3 = (!or_ln56_231_fu_34138_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_231_fu_34138_p2.read()[0].to_bool())? select_ln56_232_fu_34130_p3.read(): select_ln56_233_fu_34144_p3.read());
}

void dense_wrapper::thread_select_ln56_313_fu_35258_p3() {
    select_ln56_313_fu_35258_p3 = (!or_ln56_233_fu_34166_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_233_fu_34166_p2.read()[0].to_bool())? select_ln56_234_fu_34158_p3.read(): select_ln56_235_fu_34172_p3.read());
}

void dense_wrapper::thread_select_ln56_314_fu_35272_p3() {
    select_ln56_314_fu_35272_p3 = (!or_ln56_235_fu_34194_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_235_fu_34194_p2.read()[0].to_bool())? select_ln56_236_fu_34186_p3.read(): select_ln56_237_fu_34200_p3.read());
}

void dense_wrapper::thread_select_ln56_315_fu_35286_p3() {
    select_ln56_315_fu_35286_p3 = (!or_ln56_237_fu_34222_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_237_fu_34222_p2.read()[0].to_bool())? select_ln56_238_fu_34214_p3.read(): select_ln56_239_fu_34228_p3.read());
}

void dense_wrapper::thread_select_ln56_316_fu_35300_p3() {
    select_ln56_316_fu_35300_p3 = (!or_ln56_239_fu_34250_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_239_fu_34250_p2.read()[0].to_bool())? select_ln56_240_fu_34242_p3.read(): select_ln56_241_fu_34256_p3.read());
}

void dense_wrapper::thread_select_ln56_317_fu_35314_p3() {
    select_ln56_317_fu_35314_p3 = (!or_ln56_241_fu_34278_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_241_fu_34278_p2.read()[0].to_bool())? select_ln56_242_fu_34270_p3.read(): select_ln56_243_fu_34284_p3.read());
}

void dense_wrapper::thread_select_ln56_318_fu_35328_p3() {
    select_ln56_318_fu_35328_p3 = (!or_ln56_243_fu_34306_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_243_fu_34306_p2.read()[0].to_bool())? select_ln56_244_fu_34298_p3.read(): select_ln56_245_fu_34312_p3.read());
}

void dense_wrapper::thread_select_ln56_319_fu_35342_p3() {
    select_ln56_319_fu_35342_p3 = (!or_ln56_245_fu_34334_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_245_fu_34334_p2.read()[0].to_bool())? select_ln56_246_fu_34326_p3.read(): select_ln56_247_fu_34340_p3.read());
}

void dense_wrapper::thread_select_ln56_31_fu_31322_p3() {
    select_ln56_31_fu_31322_p3 = (!icmp_ln56_328_fu_30510_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_328_fu_30510_p2.read()[0].to_bool())? ap_phi_mux_data_720_V_read734_s_phi_fu_27516_p4.read(): ap_phi_mux_data_719_V_read733_s_phi_fu_27503_p4.read());
}

void dense_wrapper::thread_select_ln56_320_fu_35356_p3() {
    select_ln56_320_fu_35356_p3 = (!or_ln56_247_fu_34362_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_247_fu_34362_p2.read()[0].to_bool())? select_ln56_248_fu_34354_p3.read(): select_ln56_249_fu_34368_p3.read());
}

void dense_wrapper::thread_select_ln56_321_fu_35370_p3() {
    select_ln56_321_fu_35370_p3 = (!or_ln56_249_fu_34390_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_249_fu_34390_p2.read()[0].to_bool())? select_ln56_250_fu_34382_p3.read(): select_ln56_251_fu_34396_p3.read());
}

void dense_wrapper::thread_select_ln56_322_fu_35384_p3() {
    select_ln56_322_fu_35384_p3 = (!or_ln56_251_fu_34418_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_251_fu_34418_p2.read()[0].to_bool())? select_ln56_252_fu_34410_p3.read(): select_ln56_253_fu_34424_p3.read());
}

void dense_wrapper::thread_select_ln56_323_fu_35398_p3() {
    select_ln56_323_fu_35398_p3 = (!or_ln56_253_fu_34446_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_253_fu_34446_p2.read()[0].to_bool())? select_ln56_254_fu_34438_p3.read(): select_ln56_255_fu_34452_p3.read());
}

void dense_wrapper::thread_select_ln56_324_fu_35412_p3() {
    select_ln56_324_fu_35412_p3 = (!or_ln56_255_fu_34474_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_255_fu_34474_p2.read()[0].to_bool())? select_ln56_256_fu_34466_p3.read(): select_ln56_257_fu_34480_p3.read());
}

void dense_wrapper::thread_select_ln56_325_fu_35426_p3() {
    select_ln56_325_fu_35426_p3 = (!or_ln56_257_fu_34502_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_257_fu_34502_p2.read()[0].to_bool())? select_ln56_258_fu_34494_p3.read(): select_ln56_259_fu_34508_p3.read());
}

void dense_wrapper::thread_select_ln56_326_fu_35440_p3() {
    select_ln56_326_fu_35440_p3 = (!or_ln56_259_fu_34530_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_259_fu_34530_p2.read()[0].to_bool())? select_ln56_260_fu_34522_p3.read(): select_ln56_261_fu_34536_p3.read());
}

void dense_wrapper::thread_select_ln56_327_fu_35454_p3() {
    select_ln56_327_fu_35454_p3 = (!or_ln56_261_fu_34558_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_261_fu_34558_p2.read()[0].to_bool())? select_ln56_262_fu_34550_p3.read(): select_ln56_263_fu_34564_p3.read());
}

void dense_wrapper::thread_select_ln56_328_fu_35468_p3() {
    select_ln56_328_fu_35468_p3 = (!or_ln56_263_fu_34586_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_263_fu_34586_p2.read()[0].to_bool())? select_ln56_264_fu_34578_p3.read(): select_ln56_265_fu_34592_p3.read());
}

void dense_wrapper::thread_select_ln56_329_fu_35482_p3() {
    select_ln56_329_fu_35482_p3 = (!or_ln56_265_fu_34614_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_265_fu_34614_p2.read()[0].to_bool())? select_ln56_266_fu_34606_p3.read(): select_ln56_267_fu_34620_p3.read());
}

void dense_wrapper::thread_select_ln56_32_fu_31336_p3() {
    select_ln56_32_fu_31336_p3 = (!icmp_ln56_326_fu_30498_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_326_fu_30498_p2.read()[0].to_bool())? ap_phi_mux_data_718_V_read732_s_phi_fu_27490_p4.read(): ap_phi_mux_data_717_V_read731_s_phi_fu_27477_p4.read());
}

void dense_wrapper::thread_select_ln56_330_fu_35496_p3() {
    select_ln56_330_fu_35496_p3 = (!or_ln56_267_fu_34642_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_267_fu_34642_p2.read()[0].to_bool())? select_ln56_268_fu_34634_p3.read(): select_ln56_269_fu_34648_p3.read());
}

void dense_wrapper::thread_select_ln56_331_fu_35510_p3() {
    select_ln56_331_fu_35510_p3 = (!or_ln56_269_fu_34670_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_269_fu_34670_p2.read()[0].to_bool())? select_ln56_270_fu_34662_p3.read(): select_ln56_271_fu_34676_p3.read());
}

void dense_wrapper::thread_select_ln56_332_fu_35524_p3() {
    select_ln56_332_fu_35524_p3 = (!or_ln56_271_fu_34698_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_271_fu_34698_p2.read()[0].to_bool())? select_ln56_272_fu_34690_p3.read(): select_ln56_273_fu_34704_p3.read());
}

void dense_wrapper::thread_select_ln56_333_fu_35538_p3() {
    select_ln56_333_fu_35538_p3 = (!or_ln56_273_fu_34726_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_273_fu_34726_p2.read()[0].to_bool())? select_ln56_274_fu_34718_p3.read(): select_ln56_275_fu_34732_p3.read());
}

void dense_wrapper::thread_select_ln56_334_fu_35552_p3() {
    select_ln56_334_fu_35552_p3 = (!or_ln56_275_fu_34754_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_275_fu_34754_p2.read()[0].to_bool())? select_ln56_276_fu_34746_p3.read(): select_ln56_277_fu_34760_p3.read());
}

void dense_wrapper::thread_select_ln56_335_fu_35566_p3() {
    select_ln56_335_fu_35566_p3 = (!or_ln56_277_fu_34782_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_277_fu_34782_p2.read()[0].to_bool())? select_ln56_278_fu_34774_p3.read(): select_ln56_279_fu_34788_p3.read());
}

void dense_wrapper::thread_select_ln56_336_fu_35580_p3() {
    select_ln56_336_fu_35580_p3 = (!or_ln56_279_fu_34810_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_279_fu_34810_p2.read()[0].to_bool())? select_ln56_280_fu_34802_p3.read(): select_ln56_281_fu_34816_p3.read());
}

void dense_wrapper::thread_select_ln56_337_fu_35594_p3() {
    select_ln56_337_fu_35594_p3 = (!or_ln56_281_fu_34838_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_281_fu_34838_p2.read()[0].to_bool())? select_ln56_282_fu_34830_p3.read(): select_ln56_283_fu_34844_p3.read());
}

void dense_wrapper::thread_select_ln56_338_fu_35608_p3() {
    select_ln56_338_fu_35608_p3 = (!or_ln56_283_fu_34866_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_283_fu_34866_p2.read()[0].to_bool())? select_ln56_284_fu_34858_p3.read(): select_ln56_285_fu_34872_p3.read());
}

void dense_wrapper::thread_select_ln56_339_fu_35622_p3() {
    select_ln56_339_fu_35622_p3 = (!or_ln56_285_fu_34894_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_285_fu_34894_p2.read()[0].to_bool())? select_ln56_286_fu_34886_p3.read(): select_ln56_287_fu_34900_p3.read());
}

void dense_wrapper::thread_select_ln56_33_fu_31350_p3() {
    select_ln56_33_fu_31350_p3 = (!icmp_ln56_324_fu_30486_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_324_fu_30486_p2.read()[0].to_bool())? ap_phi_mux_data_716_V_read730_s_phi_fu_27464_p4.read(): ap_phi_mux_data_715_V_read729_s_phi_fu_27451_p4.read());
}

void dense_wrapper::thread_select_ln56_340_fu_35636_p3() {
    select_ln56_340_fu_35636_p3 = (!or_ln56_287_fu_34922_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_287_fu_34922_p2.read()[0].to_bool())? select_ln56_288_fu_34914_p3.read(): select_ln56_289_fu_34928_p3.read());
}

void dense_wrapper::thread_select_ln56_341_fu_35650_p3() {
    select_ln56_341_fu_35650_p3 = (!or_ln56_289_fu_34950_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_289_fu_34950_p2.read()[0].to_bool())? select_ln56_290_fu_34942_p3.read(): select_ln56_291_fu_34956_p3.read());
}

void dense_wrapper::thread_select_ln56_342_fu_35664_p3() {
    select_ln56_342_fu_35664_p3 = (!or_ln56_291_fu_34978_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_291_fu_34978_p2.read()[0].to_bool())? select_ln56_292_fu_34970_p3.read(): select_ln56_293_fu_34984_p3.read());
}

void dense_wrapper::thread_select_ln56_343_fu_35672_p3() {
    select_ln56_343_fu_35672_p3 = (!or_ln56_292_fu_35000_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_292_fu_35000_p2.read()[0].to_bool())? select_ln56_294_fu_34992_p3.read(): select_ln56_295_fu_35006_p3.read());
}

void dense_wrapper::thread_select_ln56_344_fu_35686_p3() {
    select_ln56_344_fu_35686_p3 = (!or_ln56_294_fu_35028_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_294_fu_35028_p2.read()[0].to_bool())? select_ln56_296_fu_35020_p3.read(): select_ln56_297_fu_35034_p3.read());
}

void dense_wrapper::thread_select_ln56_345_fu_35700_p3() {
    select_ln56_345_fu_35700_p3 = (!or_ln56_296_fu_35056_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_296_fu_35056_p2.read()[0].to_bool())? select_ln56_298_fu_35048_p3.read(): select_ln56_299_fu_35062_p3.read());
}

void dense_wrapper::thread_select_ln56_346_fu_35714_p3() {
    select_ln56_346_fu_35714_p3 = (!or_ln56_298_fu_35084_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_298_fu_35084_p2.read()[0].to_bool())? select_ln56_300_fu_35076_p3.read(): select_ln56_301_fu_35090_p3.read());
}

void dense_wrapper::thread_select_ln56_347_fu_35728_p3() {
    select_ln56_347_fu_35728_p3 = (!or_ln56_300_fu_35112_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_300_fu_35112_p2.read()[0].to_bool())? select_ln56_302_fu_35104_p3.read(): select_ln56_303_fu_35118_p3.read());
}

void dense_wrapper::thread_select_ln56_348_fu_35742_p3() {
    select_ln56_348_fu_35742_p3 = (!or_ln56_302_fu_35140_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_302_fu_35140_p2.read()[0].to_bool())? select_ln56_304_fu_35132_p3.read(): select_ln56_305_fu_35146_p3.read());
}

void dense_wrapper::thread_select_ln56_349_fu_35756_p3() {
    select_ln56_349_fu_35756_p3 = (!or_ln56_304_fu_35168_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_304_fu_35168_p2.read()[0].to_bool())? select_ln56_306_fu_35160_p3.read(): select_ln56_307_fu_35174_p3.read());
}

void dense_wrapper::thread_select_ln56_34_fu_31364_p3() {
    select_ln56_34_fu_31364_p3 = (!icmp_ln56_322_fu_30474_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_322_fu_30474_p2.read()[0].to_bool())? ap_phi_mux_data_714_V_read728_s_phi_fu_27438_p4.read(): ap_phi_mux_data_713_V_read727_s_phi_fu_27425_p4.read());
}

void dense_wrapper::thread_select_ln56_350_fu_35770_p3() {
    select_ln56_350_fu_35770_p3 = (!or_ln56_306_fu_35196_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_306_fu_35196_p2.read()[0].to_bool())? select_ln56_308_fu_35188_p3.read(): select_ln56_309_fu_35202_p3.read());
}

void dense_wrapper::thread_select_ln56_351_fu_35784_p3() {
    select_ln56_351_fu_35784_p3 = (!or_ln56_308_fu_35224_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_308_fu_35224_p2.read()[0].to_bool())? select_ln56_310_fu_35216_p3.read(): select_ln56_311_fu_35230_p3.read());
}

void dense_wrapper::thread_select_ln56_352_fu_35798_p3() {
    select_ln56_352_fu_35798_p3 = (!or_ln56_310_fu_35252_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_310_fu_35252_p2.read()[0].to_bool())? select_ln56_312_fu_35244_p3.read(): select_ln56_313_fu_35258_p3.read());
}

void dense_wrapper::thread_select_ln56_353_fu_35812_p3() {
    select_ln56_353_fu_35812_p3 = (!or_ln56_312_fu_35280_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_312_fu_35280_p2.read()[0].to_bool())? select_ln56_314_fu_35272_p3.read(): select_ln56_315_fu_35286_p3.read());
}

void dense_wrapper::thread_select_ln56_354_fu_35826_p3() {
    select_ln56_354_fu_35826_p3 = (!or_ln56_314_fu_35308_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_314_fu_35308_p2.read()[0].to_bool())? select_ln56_316_fu_35300_p3.read(): select_ln56_317_fu_35314_p3.read());
}

void dense_wrapper::thread_select_ln56_355_fu_35840_p3() {
    select_ln56_355_fu_35840_p3 = (!or_ln56_316_fu_35336_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_316_fu_35336_p2.read()[0].to_bool())? select_ln56_318_fu_35328_p3.read(): select_ln56_319_fu_35342_p3.read());
}

void dense_wrapper::thread_select_ln56_356_fu_35854_p3() {
    select_ln56_356_fu_35854_p3 = (!or_ln56_318_fu_35364_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_318_fu_35364_p2.read()[0].to_bool())? select_ln56_320_fu_35356_p3.read(): select_ln56_321_fu_35370_p3.read());
}

void dense_wrapper::thread_select_ln56_357_fu_35868_p3() {
    select_ln56_357_fu_35868_p3 = (!or_ln56_320_fu_35392_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_320_fu_35392_p2.read()[0].to_bool())? select_ln56_322_fu_35384_p3.read(): select_ln56_323_fu_35398_p3.read());
}

void dense_wrapper::thread_select_ln56_358_fu_35882_p3() {
    select_ln56_358_fu_35882_p3 = (!or_ln56_322_fu_35420_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_322_fu_35420_p2.read()[0].to_bool())? select_ln56_324_fu_35412_p3.read(): select_ln56_325_fu_35426_p3.read());
}

void dense_wrapper::thread_select_ln56_359_fu_35896_p3() {
    select_ln56_359_fu_35896_p3 = (!or_ln56_324_fu_35448_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_324_fu_35448_p2.read()[0].to_bool())? select_ln56_326_fu_35440_p3.read(): select_ln56_327_fu_35454_p3.read());
}

void dense_wrapper::thread_select_ln56_35_fu_31378_p3() {
    select_ln56_35_fu_31378_p3 = (!icmp_ln56_320_fu_30462_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_320_fu_30462_p2.read()[0].to_bool())? ap_phi_mux_data_712_V_read726_s_phi_fu_27412_p4.read(): ap_phi_mux_data_711_V_read725_s_phi_fu_27399_p4.read());
}

void dense_wrapper::thread_select_ln56_360_fu_35910_p3() {
    select_ln56_360_fu_35910_p3 = (!or_ln56_326_fu_35476_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_326_fu_35476_p2.read()[0].to_bool())? select_ln56_328_fu_35468_p3.read(): select_ln56_329_fu_35482_p3.read());
}

void dense_wrapper::thread_select_ln56_361_fu_35924_p3() {
    select_ln56_361_fu_35924_p3 = (!or_ln56_328_fu_35504_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_328_fu_35504_p2.read()[0].to_bool())? select_ln56_330_fu_35496_p3.read(): select_ln56_331_fu_35510_p3.read());
}

void dense_wrapper::thread_select_ln56_362_fu_35938_p3() {
    select_ln56_362_fu_35938_p3 = (!or_ln56_330_fu_35532_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_330_fu_35532_p2.read()[0].to_bool())? select_ln56_332_fu_35524_p3.read(): select_ln56_333_fu_35538_p3.read());
}

void dense_wrapper::thread_select_ln56_363_fu_35952_p3() {
    select_ln56_363_fu_35952_p3 = (!or_ln56_332_fu_35560_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_332_fu_35560_p2.read()[0].to_bool())? select_ln56_334_fu_35552_p3.read(): select_ln56_335_fu_35566_p3.read());
}

void dense_wrapper::thread_select_ln56_364_fu_35966_p3() {
    select_ln56_364_fu_35966_p3 = (!or_ln56_334_fu_35588_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_334_fu_35588_p2.read()[0].to_bool())? select_ln56_336_fu_35580_p3.read(): select_ln56_337_fu_35594_p3.read());
}

void dense_wrapper::thread_select_ln56_365_fu_35980_p3() {
    select_ln56_365_fu_35980_p3 = (!or_ln56_336_fu_35616_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_336_fu_35616_p2.read()[0].to_bool())? select_ln56_338_fu_35608_p3.read(): select_ln56_339_fu_35622_p3.read());
}

void dense_wrapper::thread_select_ln56_366_fu_35994_p3() {
    select_ln56_366_fu_35994_p3 = (!or_ln56_338_fu_35644_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_338_fu_35644_p2.read()[0].to_bool())? select_ln56_340_fu_35636_p3.read(): select_ln56_341_fu_35650_p3.read());
}

void dense_wrapper::thread_select_ln56_367_fu_36008_p3() {
    select_ln56_367_fu_36008_p3 = (!or_ln56_340_fu_35680_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_340_fu_35680_p2.read()[0].to_bool())? select_ln56_343_fu_35672_p3.read(): select_ln56_344_fu_35686_p3.read());
}

void dense_wrapper::thread_select_ln56_368_fu_36022_p3() {
    select_ln56_368_fu_36022_p3 = (!or_ln56_342_fu_35708_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_342_fu_35708_p2.read()[0].to_bool())? select_ln56_345_fu_35700_p3.read(): select_ln56_346_fu_35714_p3.read());
}

void dense_wrapper::thread_select_ln56_369_fu_36036_p3() {
    select_ln56_369_fu_36036_p3 = (!or_ln56_344_fu_35736_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_344_fu_35736_p2.read()[0].to_bool())? select_ln56_347_fu_35728_p3.read(): select_ln56_348_fu_35742_p3.read());
}

void dense_wrapper::thread_select_ln56_36_fu_31392_p3() {
    select_ln56_36_fu_31392_p3 = (!icmp_ln56_318_fu_30450_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_318_fu_30450_p2.read()[0].to_bool())? ap_phi_mux_data_710_V_read724_s_phi_fu_27386_p4.read(): ap_phi_mux_data_709_V_read723_s_phi_fu_27373_p4.read());
}

void dense_wrapper::thread_select_ln56_370_fu_36050_p3() {
    select_ln56_370_fu_36050_p3 = (!or_ln56_346_fu_35764_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_346_fu_35764_p2.read()[0].to_bool())? select_ln56_349_fu_35756_p3.read(): select_ln56_350_fu_35770_p3.read());
}

void dense_wrapper::thread_select_ln56_371_fu_36064_p3() {
    select_ln56_371_fu_36064_p3 = (!or_ln56_348_fu_35792_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_348_fu_35792_p2.read()[0].to_bool())? select_ln56_351_fu_35784_p3.read(): select_ln56_352_fu_35798_p3.read());
}

void dense_wrapper::thread_select_ln56_372_fu_36078_p3() {
    select_ln56_372_fu_36078_p3 = (!or_ln56_350_fu_35820_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_350_fu_35820_p2.read()[0].to_bool())? select_ln56_353_fu_35812_p3.read(): select_ln56_354_fu_35826_p3.read());
}

void dense_wrapper::thread_select_ln56_373_fu_36092_p3() {
    select_ln56_373_fu_36092_p3 = (!or_ln56_352_fu_35848_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_352_fu_35848_p2.read()[0].to_bool())? select_ln56_355_fu_35840_p3.read(): select_ln56_356_fu_35854_p3.read());
}

void dense_wrapper::thread_select_ln56_374_fu_36106_p3() {
    select_ln56_374_fu_36106_p3 = (!or_ln56_354_fu_35876_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_354_fu_35876_p2.read()[0].to_bool())? select_ln56_357_fu_35868_p3.read(): select_ln56_358_fu_35882_p3.read());
}

void dense_wrapper::thread_select_ln56_375_fu_36120_p3() {
    select_ln56_375_fu_36120_p3 = (!or_ln56_356_fu_35904_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_356_fu_35904_p2.read()[0].to_bool())? select_ln56_359_fu_35896_p3.read(): select_ln56_360_fu_35910_p3.read());
}

void dense_wrapper::thread_select_ln56_376_fu_36134_p3() {
    select_ln56_376_fu_36134_p3 = (!or_ln56_358_fu_35932_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_358_fu_35932_p2.read()[0].to_bool())? select_ln56_361_fu_35924_p3.read(): select_ln56_362_fu_35938_p3.read());
}

void dense_wrapper::thread_select_ln56_377_fu_36148_p3() {
    select_ln56_377_fu_36148_p3 = (!or_ln56_360_fu_35960_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_360_fu_35960_p2.read()[0].to_bool())? select_ln56_363_fu_35952_p3.read(): select_ln56_364_fu_35966_p3.read());
}

void dense_wrapper::thread_select_ln56_378_fu_36162_p3() {
    select_ln56_378_fu_36162_p3 = (!or_ln56_362_fu_35988_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_362_fu_35988_p2.read()[0].to_bool())? select_ln56_365_fu_35980_p3.read(): select_ln56_366_fu_35994_p3.read());
}

void dense_wrapper::thread_select_ln56_379_fu_36176_p3() {
    select_ln56_379_fu_36176_p3 = (!or_ln56_364_fu_36016_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_364_fu_36016_p2.read()[0].to_bool())? select_ln56_367_fu_36008_p3.read(): select_ln56_368_fu_36022_p3.read());
}

void dense_wrapper::thread_select_ln56_37_fu_31406_p3() {
    select_ln56_37_fu_31406_p3 = (!icmp_ln56_316_fu_30438_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_316_fu_30438_p2.read()[0].to_bool())? ap_phi_mux_data_708_V_read722_s_phi_fu_27360_p4.read(): ap_phi_mux_data_707_V_read721_s_phi_fu_27347_p4.read());
}

void dense_wrapper::thread_select_ln56_380_fu_36190_p3() {
    select_ln56_380_fu_36190_p3 = (!or_ln56_366_fu_36044_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_366_fu_36044_p2.read()[0].to_bool())? select_ln56_369_fu_36036_p3.read(): select_ln56_370_fu_36050_p3.read());
}

void dense_wrapper::thread_select_ln56_381_fu_36204_p3() {
    select_ln56_381_fu_36204_p3 = (!or_ln56_368_fu_36072_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_368_fu_36072_p2.read()[0].to_bool())? select_ln56_371_fu_36064_p3.read(): select_ln56_372_fu_36078_p3.read());
}

void dense_wrapper::thread_select_ln56_382_fu_36218_p3() {
    select_ln56_382_fu_36218_p3 = (!or_ln56_370_fu_36100_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_370_fu_36100_p2.read()[0].to_bool())? select_ln56_373_fu_36092_p3.read(): select_ln56_374_fu_36106_p3.read());
}

void dense_wrapper::thread_select_ln56_383_fu_36232_p3() {
    select_ln56_383_fu_36232_p3 = (!or_ln56_372_fu_36128_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_372_fu_36128_p2.read()[0].to_bool())? select_ln56_375_fu_36120_p3.read(): select_ln56_376_fu_36134_p3.read());
}

void dense_wrapper::thread_select_ln56_384_fu_36246_p3() {
    select_ln56_384_fu_36246_p3 = (!or_ln56_374_fu_36156_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_374_fu_36156_p2.read()[0].to_bool())? select_ln56_377_fu_36148_p3.read(): select_ln56_378_fu_36162_p3.read());
}

void dense_wrapper::thread_select_ln56_385_fu_36260_p3() {
    select_ln56_385_fu_36260_p3 = (!or_ln56_376_fu_36184_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_376_fu_36184_p2.read()[0].to_bool())? select_ln56_379_fu_36176_p3.read(): select_ln56_380_fu_36190_p3.read());
}

void dense_wrapper::thread_select_ln56_386_fu_36274_p3() {
    select_ln56_386_fu_36274_p3 = (!or_ln56_378_fu_36212_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_378_fu_36212_p2.read()[0].to_bool())? select_ln56_381_fu_36204_p3.read(): select_ln56_382_fu_36218_p3.read());
}

void dense_wrapper::thread_select_ln56_387_fu_36288_p3() {
    select_ln56_387_fu_36288_p3 = (!or_ln56_380_fu_36240_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_380_fu_36240_p2.read()[0].to_bool())? select_ln56_383_fu_36232_p3.read(): select_ln56_384_fu_36246_p3.read());
}

void dense_wrapper::thread_select_ln56_388_fu_36302_p3() {
    select_ln56_388_fu_36302_p3 = (!or_ln56_382_fu_36268_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_382_fu_36268_p2.read()[0].to_bool())? select_ln56_385_fu_36260_p3.read(): select_ln56_386_fu_36274_p3.read());
}

void dense_wrapper::thread_select_ln56_389_fu_36316_p3() {
    select_ln56_389_fu_36316_p3 = (!or_ln56_384_fu_36296_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_384_fu_36296_p2.read()[0].to_bool())? select_ln56_387_fu_36288_p3.read(): select_ln56_342_fu_35664_p3.read());
}

void dense_wrapper::thread_select_ln56_38_fu_31420_p3() {
    select_ln56_38_fu_31420_p3 = (!icmp_ln56_314_fu_30426_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_314_fu_30426_p2.read()[0].to_bool())? ap_phi_mux_data_706_V_read720_s_phi_fu_27334_p4.read(): ap_phi_mux_data_705_V_read719_s_phi_fu_27321_p4.read());
}

void dense_wrapper::thread_select_ln56_390_fu_36324_p3() {
    select_ln56_390_fu_36324_p3 = (!or_ln56_385_fu_36310_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_385_fu_36310_p2.read()[0].to_bool())? select_ln56_388_fu_36302_p3.read(): select_ln56_389_fu_36316_p3.read());
}

void dense_wrapper::thread_select_ln56_391_fu_36332_p3() {
    select_ln56_391_fu_36332_p3 = (!icmp_ln56_390_fu_30882_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_390_fu_30882_p2.read()[0].to_bool())? ap_phi_mux_data_390_V_read404_s_phi_fu_23226_p4.read(): ap_phi_mux_data_389_V_read403_s_phi_fu_23213_p4.read());
}

void dense_wrapper::thread_select_ln56_392_fu_36340_p3() {
    select_ln56_392_fu_36340_p3 = (!icmp_ln56_388_fu_30870_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_388_fu_30870_p2.read()[0].to_bool())? ap_phi_mux_data_388_V_read402_s_phi_fu_23200_p4.read(): ap_phi_mux_data_387_V_read401_s_phi_fu_23187_p4.read());
}

void dense_wrapper::thread_select_ln56_393_fu_36348_p3() {
    select_ln56_393_fu_36348_p3 = (!icmp_ln56_386_fu_30858_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_386_fu_30858_p2.read()[0].to_bool())? ap_phi_mux_data_386_V_read400_s_phi_fu_23174_p4.read(): ap_phi_mux_data_385_V_read399_s_phi_fu_23161_p4.read());
}

void dense_wrapper::thread_select_ln56_394_fu_36356_p3() {
    select_ln56_394_fu_36356_p3 = (!icmp_ln56_384_fu_30846_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_384_fu_30846_p2.read()[0].to_bool())? ap_phi_mux_data_384_V_read398_s_phi_fu_23148_p4.read(): ap_phi_mux_data_383_V_read397_s_phi_fu_23135_p4.read());
}

void dense_wrapper::thread_select_ln56_395_fu_36364_p3() {
    select_ln56_395_fu_36364_p3 = (!icmp_ln56_382_fu_30834_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_382_fu_30834_p2.read()[0].to_bool())? ap_phi_mux_data_382_V_read396_s_phi_fu_23122_p4.read(): ap_phi_mux_data_381_V_read395_s_phi_fu_23109_p4.read());
}

void dense_wrapper::thread_select_ln56_396_fu_36372_p3() {
    select_ln56_396_fu_36372_p3 = (!icmp_ln56_380_fu_30822_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_380_fu_30822_p2.read()[0].to_bool())? ap_phi_mux_data_380_V_read394_s_phi_fu_23096_p4.read(): ap_phi_mux_data_379_V_read393_s_phi_fu_23083_p4.read());
}

void dense_wrapper::thread_select_ln56_397_fu_36380_p3() {
    select_ln56_397_fu_36380_p3 = (!icmp_ln56_378_fu_30810_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_378_fu_30810_p2.read()[0].to_bool())? ap_phi_mux_data_378_V_read392_s_phi_fu_23070_p4.read(): ap_phi_mux_data_377_V_read391_s_phi_fu_23057_p4.read());
}

void dense_wrapper::thread_select_ln56_398_fu_36388_p3() {
    select_ln56_398_fu_36388_p3 = (!icmp_ln56_376_fu_30798_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_376_fu_30798_p2.read()[0].to_bool())? ap_phi_mux_data_376_V_read390_s_phi_fu_23044_p4.read(): ap_phi_mux_data_375_V_read389_s_phi_fu_23031_p4.read());
}

void dense_wrapper::thread_select_ln56_399_fu_36396_p3() {
    select_ln56_399_fu_36396_p3 = (!icmp_ln56_374_fu_30786_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_374_fu_30786_p2.read()[0].to_bool())? ap_phi_mux_data_374_V_read388_s_phi_fu_23018_p4.read(): ap_phi_mux_data_373_V_read387_s_phi_fu_23005_p4.read());
}

void dense_wrapper::thread_select_ln56_39_fu_31434_p3() {
    select_ln56_39_fu_31434_p3 = (!icmp_ln56_312_fu_30414_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_312_fu_30414_p2.read()[0].to_bool())? ap_phi_mux_data_704_V_read718_s_phi_fu_27308_p4.read(): ap_phi_mux_data_703_V_read717_s_phi_fu_27295_p4.read());
}

void dense_wrapper::thread_select_ln56_3_fu_30930_p3() {
    select_ln56_3_fu_30930_p3 = (!icmp_ln56_384_fu_30846_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_384_fu_30846_p2.read()[0].to_bool())? ap_phi_mux_data_776_V_read790_s_phi_fu_28244_p4.read(): ap_phi_mux_data_775_V_read789_s_phi_fu_28231_p4.read());
}

void dense_wrapper::thread_select_ln56_400_fu_36404_p3() {
    select_ln56_400_fu_36404_p3 = (!icmp_ln56_372_fu_30774_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_372_fu_30774_p2.read()[0].to_bool())? ap_phi_mux_data_372_V_read386_s_phi_fu_22992_p4.read(): ap_phi_mux_data_371_V_read385_s_phi_fu_22979_p4.read());
}

void dense_wrapper::thread_select_ln56_401_fu_36412_p3() {
    select_ln56_401_fu_36412_p3 = (!icmp_ln56_370_fu_30762_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_370_fu_30762_p2.read()[0].to_bool())? ap_phi_mux_data_370_V_read384_s_phi_fu_22966_p4.read(): ap_phi_mux_data_369_V_read383_s_phi_fu_22953_p4.read());
}

void dense_wrapper::thread_select_ln56_402_fu_36420_p3() {
    select_ln56_402_fu_36420_p3 = (!icmp_ln56_368_fu_30750_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_368_fu_30750_p2.read()[0].to_bool())? ap_phi_mux_data_368_V_read382_s_phi_fu_22940_p4.read(): ap_phi_mux_data_367_V_read381_s_phi_fu_22927_p4.read());
}

void dense_wrapper::thread_select_ln56_403_fu_36428_p3() {
    select_ln56_403_fu_36428_p3 = (!icmp_ln56_366_fu_30738_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_366_fu_30738_p2.read()[0].to_bool())? ap_phi_mux_data_366_V_read380_s_phi_fu_22914_p4.read(): ap_phi_mux_data_365_V_read379_s_phi_fu_22901_p4.read());
}

void dense_wrapper::thread_select_ln56_404_fu_36436_p3() {
    select_ln56_404_fu_36436_p3 = (!icmp_ln56_364_fu_30726_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_364_fu_30726_p2.read()[0].to_bool())? ap_phi_mux_data_364_V_read378_s_phi_fu_22888_p4.read(): ap_phi_mux_data_363_V_read377_s_phi_fu_22875_p4.read());
}

void dense_wrapper::thread_select_ln56_405_fu_36444_p3() {
    select_ln56_405_fu_36444_p3 = (!icmp_ln56_362_fu_30714_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_362_fu_30714_p2.read()[0].to_bool())? ap_phi_mux_data_362_V_read376_s_phi_fu_22862_p4.read(): ap_phi_mux_data_361_V_read375_s_phi_fu_22849_p4.read());
}

void dense_wrapper::thread_select_ln56_406_fu_36452_p3() {
    select_ln56_406_fu_36452_p3 = (!icmp_ln56_360_fu_30702_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_360_fu_30702_p2.read()[0].to_bool())? ap_phi_mux_data_360_V_read374_s_phi_fu_22836_p4.read(): ap_phi_mux_data_359_V_read373_s_phi_fu_22823_p4.read());
}

void dense_wrapper::thread_select_ln56_407_fu_36460_p3() {
    select_ln56_407_fu_36460_p3 = (!icmp_ln56_358_fu_30690_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_358_fu_30690_p2.read()[0].to_bool())? ap_phi_mux_data_358_V_read372_s_phi_fu_22810_p4.read(): ap_phi_mux_data_357_V_read371_s_phi_fu_22797_p4.read());
}

void dense_wrapper::thread_select_ln56_408_fu_36468_p3() {
    select_ln56_408_fu_36468_p3 = (!icmp_ln56_356_fu_30678_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_356_fu_30678_p2.read()[0].to_bool())? ap_phi_mux_data_356_V_read370_s_phi_fu_22784_p4.read(): ap_phi_mux_data_355_V_read369_s_phi_fu_22771_p4.read());
}

void dense_wrapper::thread_select_ln56_409_fu_36476_p3() {
    select_ln56_409_fu_36476_p3 = (!icmp_ln56_354_fu_30666_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_354_fu_30666_p2.read()[0].to_bool())? ap_phi_mux_data_354_V_read368_s_phi_fu_22758_p4.read(): ap_phi_mux_data_353_V_read367_s_phi_fu_22745_p4.read());
}

void dense_wrapper::thread_select_ln56_40_fu_31448_p3() {
    select_ln56_40_fu_31448_p3 = (!icmp_ln56_310_fu_30402_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_310_fu_30402_p2.read()[0].to_bool())? ap_phi_mux_data_702_V_read716_s_phi_fu_27282_p4.read(): ap_phi_mux_data_701_V_read715_s_phi_fu_27269_p4.read());
}

void dense_wrapper::thread_select_ln56_410_fu_36484_p3() {
    select_ln56_410_fu_36484_p3 = (!icmp_ln56_352_fu_30654_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_352_fu_30654_p2.read()[0].to_bool())? ap_phi_mux_data_352_V_read366_s_phi_fu_22732_p4.read(): ap_phi_mux_data_351_V_read365_s_phi_fu_22719_p4.read());
}

void dense_wrapper::thread_select_ln56_411_fu_36492_p3() {
    select_ln56_411_fu_36492_p3 = (!icmp_ln56_350_fu_30642_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_350_fu_30642_p2.read()[0].to_bool())? ap_phi_mux_data_350_V_read364_s_phi_fu_22706_p4.read(): ap_phi_mux_data_349_V_read363_s_phi_fu_22693_p4.read());
}

void dense_wrapper::thread_select_ln56_412_fu_36500_p3() {
    select_ln56_412_fu_36500_p3 = (!icmp_ln56_348_fu_30630_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_348_fu_30630_p2.read()[0].to_bool())? ap_phi_mux_data_348_V_read362_s_phi_fu_22680_p4.read(): ap_phi_mux_data_347_V_read361_s_phi_fu_22667_p4.read());
}

void dense_wrapper::thread_select_ln56_413_fu_36508_p3() {
    select_ln56_413_fu_36508_p3 = (!icmp_ln56_346_fu_30618_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_346_fu_30618_p2.read()[0].to_bool())? ap_phi_mux_data_346_V_read360_s_phi_fu_22654_p4.read(): ap_phi_mux_data_345_V_read359_s_phi_fu_22641_p4.read());
}

void dense_wrapper::thread_select_ln56_414_fu_36516_p3() {
    select_ln56_414_fu_36516_p3 = (!icmp_ln56_344_fu_30606_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_344_fu_30606_p2.read()[0].to_bool())? ap_phi_mux_data_344_V_read358_s_phi_fu_22628_p4.read(): ap_phi_mux_data_343_V_read357_s_phi_fu_22615_p4.read());
}

void dense_wrapper::thread_select_ln56_415_fu_36524_p3() {
    select_ln56_415_fu_36524_p3 = (!icmp_ln56_342_fu_30594_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_342_fu_30594_p2.read()[0].to_bool())? ap_phi_mux_data_342_V_read356_s_phi_fu_22602_p4.read(): ap_phi_mux_data_341_V_read355_s_phi_fu_22589_p4.read());
}

void dense_wrapper::thread_select_ln56_416_fu_36532_p3() {
    select_ln56_416_fu_36532_p3 = (!icmp_ln56_340_fu_30582_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_340_fu_30582_p2.read()[0].to_bool())? ap_phi_mux_data_340_V_read354_s_phi_fu_22576_p4.read(): ap_phi_mux_data_339_V_read353_s_phi_fu_22563_p4.read());
}

void dense_wrapper::thread_select_ln56_417_fu_36540_p3() {
    select_ln56_417_fu_36540_p3 = (!icmp_ln56_338_fu_30570_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_338_fu_30570_p2.read()[0].to_bool())? ap_phi_mux_data_338_V_read352_s_phi_fu_22550_p4.read(): ap_phi_mux_data_337_V_read351_s_phi_fu_22537_p4.read());
}

void dense_wrapper::thread_select_ln56_418_fu_36548_p3() {
    select_ln56_418_fu_36548_p3 = (!icmp_ln56_336_fu_30558_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_336_fu_30558_p2.read()[0].to_bool())? ap_phi_mux_data_336_V_read350_s_phi_fu_22524_p4.read(): ap_phi_mux_data_335_V_read349_s_phi_fu_22511_p4.read());
}

void dense_wrapper::thread_select_ln56_419_fu_36556_p3() {
    select_ln56_419_fu_36556_p3 = (!icmp_ln56_334_fu_30546_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_334_fu_30546_p2.read()[0].to_bool())? ap_phi_mux_data_334_V_read348_s_phi_fu_22498_p4.read(): ap_phi_mux_data_333_V_read347_s_phi_fu_22485_p4.read());
}

void dense_wrapper::thread_select_ln56_41_fu_31462_p3() {
    select_ln56_41_fu_31462_p3 = (!icmp_ln56_308_fu_30390_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_308_fu_30390_p2.read()[0].to_bool())? ap_phi_mux_data_700_V_read714_s_phi_fu_27256_p4.read(): ap_phi_mux_data_699_V_read713_s_phi_fu_27243_p4.read());
}

void dense_wrapper::thread_select_ln56_420_fu_36564_p3() {
    select_ln56_420_fu_36564_p3 = (!icmp_ln56_332_fu_30534_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_332_fu_30534_p2.read()[0].to_bool())? ap_phi_mux_data_332_V_read346_s_phi_fu_22472_p4.read(): ap_phi_mux_data_331_V_read345_s_phi_fu_22459_p4.read());
}

void dense_wrapper::thread_select_ln56_421_fu_36572_p3() {
    select_ln56_421_fu_36572_p3 = (!icmp_ln56_330_fu_30522_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_330_fu_30522_p2.read()[0].to_bool())? ap_phi_mux_data_330_V_read344_s_phi_fu_22446_p4.read(): ap_phi_mux_data_329_V_read343_s_phi_fu_22433_p4.read());
}

void dense_wrapper::thread_select_ln56_422_fu_36580_p3() {
    select_ln56_422_fu_36580_p3 = (!icmp_ln56_328_fu_30510_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_328_fu_30510_p2.read()[0].to_bool())? ap_phi_mux_data_328_V_read342_s_phi_fu_22420_p4.read(): ap_phi_mux_data_327_V_read341_s_phi_fu_22407_p4.read());
}

void dense_wrapper::thread_select_ln56_423_fu_36588_p3() {
    select_ln56_423_fu_36588_p3 = (!icmp_ln56_326_fu_30498_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_326_fu_30498_p2.read()[0].to_bool())? ap_phi_mux_data_326_V_read340_s_phi_fu_22394_p4.read(): ap_phi_mux_data_325_V_read339_s_phi_fu_22381_p4.read());
}

void dense_wrapper::thread_select_ln56_424_fu_36596_p3() {
    select_ln56_424_fu_36596_p3 = (!icmp_ln56_324_fu_30486_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_324_fu_30486_p2.read()[0].to_bool())? ap_phi_mux_data_324_V_read338_s_phi_fu_22368_p4.read(): ap_phi_mux_data_323_V_read337_s_phi_fu_22355_p4.read());
}

void dense_wrapper::thread_select_ln56_425_fu_36604_p3() {
    select_ln56_425_fu_36604_p3 = (!icmp_ln56_322_fu_30474_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_322_fu_30474_p2.read()[0].to_bool())? ap_phi_mux_data_322_V_read336_s_phi_fu_22342_p4.read(): ap_phi_mux_data_321_V_read335_s_phi_fu_22329_p4.read());
}

void dense_wrapper::thread_select_ln56_426_fu_36612_p3() {
    select_ln56_426_fu_36612_p3 = (!icmp_ln56_320_fu_30462_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_320_fu_30462_p2.read()[0].to_bool())? ap_phi_mux_data_320_V_read334_s_phi_fu_22316_p4.read(): ap_phi_mux_data_319_V_read333_s_phi_fu_22303_p4.read());
}

void dense_wrapper::thread_select_ln56_427_fu_36620_p3() {
    select_ln56_427_fu_36620_p3 = (!icmp_ln56_318_fu_30450_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_318_fu_30450_p2.read()[0].to_bool())? ap_phi_mux_data_318_V_read332_s_phi_fu_22290_p4.read(): ap_phi_mux_data_317_V_read331_s_phi_fu_22277_p4.read());
}

void dense_wrapper::thread_select_ln56_428_fu_36628_p3() {
    select_ln56_428_fu_36628_p3 = (!icmp_ln56_316_fu_30438_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_316_fu_30438_p2.read()[0].to_bool())? ap_phi_mux_data_316_V_read330_s_phi_fu_22264_p4.read(): ap_phi_mux_data_315_V_read329_s_phi_fu_22251_p4.read());
}

void dense_wrapper::thread_select_ln56_429_fu_36636_p3() {
    select_ln56_429_fu_36636_p3 = (!icmp_ln56_314_fu_30426_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_314_fu_30426_p2.read()[0].to_bool())? ap_phi_mux_data_314_V_read328_s_phi_fu_22238_p4.read(): ap_phi_mux_data_313_V_read327_s_phi_fu_22225_p4.read());
}

void dense_wrapper::thread_select_ln56_42_fu_31476_p3() {
    select_ln56_42_fu_31476_p3 = (!icmp_ln56_306_fu_30378_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_306_fu_30378_p2.read()[0].to_bool())? ap_phi_mux_data_698_V_read712_s_phi_fu_27230_p4.read(): ap_phi_mux_data_697_V_read711_s_phi_fu_27217_p4.read());
}

void dense_wrapper::thread_select_ln56_430_fu_36644_p3() {
    select_ln56_430_fu_36644_p3 = (!icmp_ln56_312_fu_30414_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_312_fu_30414_p2.read()[0].to_bool())? ap_phi_mux_data_312_V_read326_s_phi_fu_22212_p4.read(): ap_phi_mux_data_311_V_read325_s_phi_fu_22199_p4.read());
}

void dense_wrapper::thread_select_ln56_431_fu_36652_p3() {
    select_ln56_431_fu_36652_p3 = (!icmp_ln56_310_fu_30402_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_310_fu_30402_p2.read()[0].to_bool())? ap_phi_mux_data_310_V_read324_s_phi_fu_22186_p4.read(): ap_phi_mux_data_309_V_read323_s_phi_fu_22173_p4.read());
}

void dense_wrapper::thread_select_ln56_432_fu_36660_p3() {
    select_ln56_432_fu_36660_p3 = (!icmp_ln56_308_fu_30390_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_308_fu_30390_p2.read()[0].to_bool())? ap_phi_mux_data_308_V_read322_s_phi_fu_22160_p4.read(): ap_phi_mux_data_307_V_read321_s_phi_fu_22147_p4.read());
}

void dense_wrapper::thread_select_ln56_433_fu_36668_p3() {
    select_ln56_433_fu_36668_p3 = (!icmp_ln56_306_fu_30378_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_306_fu_30378_p2.read()[0].to_bool())? ap_phi_mux_data_306_V_read320_s_phi_fu_22134_p4.read(): ap_phi_mux_data_305_V_read319_s_phi_fu_22121_p4.read());
}

void dense_wrapper::thread_select_ln56_434_fu_36676_p3() {
    select_ln56_434_fu_36676_p3 = (!icmp_ln56_304_fu_30366_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_304_fu_30366_p2.read()[0].to_bool())? ap_phi_mux_data_304_V_read318_s_phi_fu_22108_p4.read(): ap_phi_mux_data_303_V_read317_s_phi_fu_22095_p4.read());
}

void dense_wrapper::thread_select_ln56_435_fu_36684_p3() {
    select_ln56_435_fu_36684_p3 = (!icmp_ln56_302_fu_30354_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_302_fu_30354_p2.read()[0].to_bool())? ap_phi_mux_data_302_V_read316_s_phi_fu_22082_p4.read(): ap_phi_mux_data_301_V_read315_s_phi_fu_22069_p4.read());
}

void dense_wrapper::thread_select_ln56_436_fu_36692_p3() {
    select_ln56_436_fu_36692_p3 = (!icmp_ln56_300_fu_30342_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_300_fu_30342_p2.read()[0].to_bool())? ap_phi_mux_data_300_V_read314_s_phi_fu_22056_p4.read(): ap_phi_mux_data_299_V_read313_s_phi_fu_22043_p4.read());
}

void dense_wrapper::thread_select_ln56_437_fu_36700_p3() {
    select_ln56_437_fu_36700_p3 = (!icmp_ln56_298_fu_30330_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_298_fu_30330_p2.read()[0].to_bool())? ap_phi_mux_data_298_V_read312_s_phi_fu_22030_p4.read(): ap_phi_mux_data_297_V_read311_s_phi_fu_22017_p4.read());
}

void dense_wrapper::thread_select_ln56_438_fu_36708_p3() {
    select_ln56_438_fu_36708_p3 = (!icmp_ln56_296_fu_30318_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_296_fu_30318_p2.read()[0].to_bool())? ap_phi_mux_data_296_V_read310_s_phi_fu_22004_p4.read(): ap_phi_mux_data_295_V_read309_s_phi_fu_21991_p4.read());
}

void dense_wrapper::thread_select_ln56_439_fu_36716_p3() {
    select_ln56_439_fu_36716_p3 = (!icmp_ln56_294_fu_30306_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_294_fu_30306_p2.read()[0].to_bool())? ap_phi_mux_data_294_V_read308_s_phi_fu_21978_p4.read(): ap_phi_mux_data_293_V_read307_s_phi_fu_21965_p4.read());
}

void dense_wrapper::thread_select_ln56_43_fu_31490_p3() {
    select_ln56_43_fu_31490_p3 = (!icmp_ln56_304_fu_30366_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_304_fu_30366_p2.read()[0].to_bool())? ap_phi_mux_data_696_V_read710_s_phi_fu_27204_p4.read(): ap_phi_mux_data_695_V_read709_s_phi_fu_27191_p4.read());
}

void dense_wrapper::thread_select_ln56_440_fu_36724_p3() {
    select_ln56_440_fu_36724_p3 = (!icmp_ln56_292_fu_30294_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_292_fu_30294_p2.read()[0].to_bool())? ap_phi_mux_data_292_V_read306_s_phi_fu_21952_p4.read(): ap_phi_mux_data_291_V_read305_s_phi_fu_21939_p4.read());
}

void dense_wrapper::thread_select_ln56_441_fu_36732_p3() {
    select_ln56_441_fu_36732_p3 = (!icmp_ln56_290_fu_30282_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_290_fu_30282_p2.read()[0].to_bool())? ap_phi_mux_data_290_V_read304_s_phi_fu_21926_p4.read(): ap_phi_mux_data_289_V_read303_s_phi_fu_21913_p4.read());
}

void dense_wrapper::thread_select_ln56_442_fu_36740_p3() {
    select_ln56_442_fu_36740_p3 = (!icmp_ln56_288_fu_30270_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_288_fu_30270_p2.read()[0].to_bool())? ap_phi_mux_data_288_V_read302_s_phi_fu_21900_p4.read(): ap_phi_mux_data_287_V_read301_s_phi_fu_21887_p4.read());
}

void dense_wrapper::thread_select_ln56_443_fu_36748_p3() {
    select_ln56_443_fu_36748_p3 = (!icmp_ln56_286_fu_30258_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_286_fu_30258_p2.read()[0].to_bool())? ap_phi_mux_data_286_V_read300_s_phi_fu_21874_p4.read(): ap_phi_mux_data_285_V_read299_s_phi_fu_21861_p4.read());
}

void dense_wrapper::thread_select_ln56_444_fu_36756_p3() {
    select_ln56_444_fu_36756_p3 = (!icmp_ln56_284_fu_30246_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_284_fu_30246_p2.read()[0].to_bool())? ap_phi_mux_data_284_V_read298_s_phi_fu_21848_p4.read(): ap_phi_mux_data_283_V_read297_s_phi_fu_21835_p4.read());
}

void dense_wrapper::thread_select_ln56_445_fu_36764_p3() {
    select_ln56_445_fu_36764_p3 = (!icmp_ln56_282_fu_30234_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_282_fu_30234_p2.read()[0].to_bool())? ap_phi_mux_data_282_V_read296_s_phi_fu_21822_p4.read(): ap_phi_mux_data_281_V_read295_s_phi_fu_21809_p4.read());
}

void dense_wrapper::thread_select_ln56_446_fu_36772_p3() {
    select_ln56_446_fu_36772_p3 = (!icmp_ln56_280_fu_30222_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_280_fu_30222_p2.read()[0].to_bool())? ap_phi_mux_data_280_V_read294_s_phi_fu_21796_p4.read(): ap_phi_mux_data_279_V_read293_s_phi_fu_21783_p4.read());
}

void dense_wrapper::thread_select_ln56_447_fu_36780_p3() {
    select_ln56_447_fu_36780_p3 = (!icmp_ln56_278_fu_30210_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_278_fu_30210_p2.read()[0].to_bool())? ap_phi_mux_data_278_V_read292_s_phi_fu_21770_p4.read(): ap_phi_mux_data_277_V_read291_s_phi_fu_21757_p4.read());
}

void dense_wrapper::thread_select_ln56_448_fu_36788_p3() {
    select_ln56_448_fu_36788_p3 = (!icmp_ln56_276_fu_30198_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_276_fu_30198_p2.read()[0].to_bool())? ap_phi_mux_data_276_V_read290_s_phi_fu_21744_p4.read(): ap_phi_mux_data_275_V_read289_s_phi_fu_21731_p4.read());
}

void dense_wrapper::thread_select_ln56_449_fu_36796_p3() {
    select_ln56_449_fu_36796_p3 = (!icmp_ln56_274_fu_30186_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_274_fu_30186_p2.read()[0].to_bool())? ap_phi_mux_data_274_V_read288_s_phi_fu_21718_p4.read(): ap_phi_mux_data_273_V_read287_s_phi_fu_21705_p4.read());
}

void dense_wrapper::thread_select_ln56_44_fu_31504_p3() {
    select_ln56_44_fu_31504_p3 = (!icmp_ln56_302_fu_30354_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_302_fu_30354_p2.read()[0].to_bool())? ap_phi_mux_data_694_V_read708_s_phi_fu_27178_p4.read(): ap_phi_mux_data_693_V_read707_s_phi_fu_27165_p4.read());
}

void dense_wrapper::thread_select_ln56_450_fu_36804_p3() {
    select_ln56_450_fu_36804_p3 = (!icmp_ln56_272_fu_30174_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_272_fu_30174_p2.read()[0].to_bool())? ap_phi_mux_data_272_V_read286_s_phi_fu_21692_p4.read(): ap_phi_mux_data_271_V_read285_s_phi_fu_21679_p4.read());
}

void dense_wrapper::thread_select_ln56_451_fu_36812_p3() {
    select_ln56_451_fu_36812_p3 = (!icmp_ln56_270_fu_30162_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_270_fu_30162_p2.read()[0].to_bool())? ap_phi_mux_data_270_V_read284_s_phi_fu_21666_p4.read(): ap_phi_mux_data_269_V_read283_s_phi_fu_21653_p4.read());
}

void dense_wrapper::thread_select_ln56_452_fu_36820_p3() {
    select_ln56_452_fu_36820_p3 = (!icmp_ln56_268_fu_30150_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_268_fu_30150_p2.read()[0].to_bool())? ap_phi_mux_data_268_V_read282_s_phi_fu_21640_p4.read(): ap_phi_mux_data_267_V_read281_s_phi_fu_21627_p4.read());
}

void dense_wrapper::thread_select_ln56_453_fu_36828_p3() {
    select_ln56_453_fu_36828_p3 = (!icmp_ln56_266_fu_30138_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_266_fu_30138_p2.read()[0].to_bool())? ap_phi_mux_data_266_V_read280_s_phi_fu_21614_p4.read(): ap_phi_mux_data_265_V_read279_s_phi_fu_21601_p4.read());
}

void dense_wrapper::thread_select_ln56_454_fu_36836_p3() {
    select_ln56_454_fu_36836_p3 = (!icmp_ln56_264_fu_30126_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_264_fu_30126_p2.read()[0].to_bool())? ap_phi_mux_data_264_V_read278_s_phi_fu_21588_p4.read(): ap_phi_mux_data_263_V_read277_s_phi_fu_21575_p4.read());
}

void dense_wrapper::thread_select_ln56_455_fu_36844_p3() {
    select_ln56_455_fu_36844_p3 = (!icmp_ln56_262_fu_30114_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_262_fu_30114_p2.read()[0].to_bool())? ap_phi_mux_data_262_V_read276_s_phi_fu_21562_p4.read(): ap_phi_mux_data_261_V_read275_s_phi_fu_21549_p4.read());
}

void dense_wrapper::thread_select_ln56_456_fu_36852_p3() {
    select_ln56_456_fu_36852_p3 = (!icmp_ln56_260_fu_30102_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_260_fu_30102_p2.read()[0].to_bool())? ap_phi_mux_data_260_V_read274_s_phi_fu_21536_p4.read(): ap_phi_mux_data_259_V_read273_s_phi_fu_21523_p4.read());
}

void dense_wrapper::thread_select_ln56_457_fu_36860_p3() {
    select_ln56_457_fu_36860_p3 = (!icmp_ln56_258_fu_30090_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_258_fu_30090_p2.read()[0].to_bool())? ap_phi_mux_data_258_V_read272_s_phi_fu_21510_p4.read(): ap_phi_mux_data_257_V_read271_s_phi_fu_21497_p4.read());
}

void dense_wrapper::thread_select_ln56_458_fu_36868_p3() {
    select_ln56_458_fu_36868_p3 = (!icmp_ln56_256_fu_30078_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_256_fu_30078_p2.read()[0].to_bool())? ap_phi_mux_data_256_V_read270_s_phi_fu_21484_p4.read(): ap_phi_mux_data_255_V_read269_s_phi_fu_21471_p4.read());
}

void dense_wrapper::thread_select_ln56_459_fu_36876_p3() {
    select_ln56_459_fu_36876_p3 = (!icmp_ln56_254_fu_30066_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_254_fu_30066_p2.read()[0].to_bool())? ap_phi_mux_data_254_V_read268_s_phi_fu_21458_p4.read(): ap_phi_mux_data_253_V_read267_s_phi_fu_21445_p4.read());
}

void dense_wrapper::thread_select_ln56_45_fu_31518_p3() {
    select_ln56_45_fu_31518_p3 = (!icmp_ln56_300_fu_30342_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_300_fu_30342_p2.read()[0].to_bool())? ap_phi_mux_data_692_V_read706_s_phi_fu_27152_p4.read(): ap_phi_mux_data_691_V_read705_s_phi_fu_27139_p4.read());
}

void dense_wrapper::thread_select_ln56_460_fu_36884_p3() {
    select_ln56_460_fu_36884_p3 = (!icmp_ln56_252_fu_30054_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_252_fu_30054_p2.read()[0].to_bool())? ap_phi_mux_data_252_V_read266_s_phi_fu_21432_p4.read(): ap_phi_mux_data_251_V_read265_s_phi_fu_21419_p4.read());
}

void dense_wrapper::thread_select_ln56_461_fu_36892_p3() {
    select_ln56_461_fu_36892_p3 = (!icmp_ln56_250_fu_30042_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_250_fu_30042_p2.read()[0].to_bool())? ap_phi_mux_data_250_V_read264_s_phi_fu_21406_p4.read(): ap_phi_mux_data_249_V_read263_s_phi_fu_21393_p4.read());
}

void dense_wrapper::thread_select_ln56_462_fu_36900_p3() {
    select_ln56_462_fu_36900_p3 = (!icmp_ln56_248_fu_30030_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_248_fu_30030_p2.read()[0].to_bool())? ap_phi_mux_data_248_V_read262_s_phi_fu_21380_p4.read(): ap_phi_mux_data_247_V_read261_s_phi_fu_21367_p4.read());
}

void dense_wrapper::thread_select_ln56_463_fu_36908_p3() {
    select_ln56_463_fu_36908_p3 = (!icmp_ln56_246_fu_30018_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_246_fu_30018_p2.read()[0].to_bool())? ap_phi_mux_data_246_V_read260_s_phi_fu_21354_p4.read(): ap_phi_mux_data_245_V_read259_s_phi_fu_21341_p4.read());
}

void dense_wrapper::thread_select_ln56_464_fu_36916_p3() {
    select_ln56_464_fu_36916_p3 = (!icmp_ln56_244_fu_30006_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_244_fu_30006_p2.read()[0].to_bool())? ap_phi_mux_data_244_V_read258_s_phi_fu_21328_p4.read(): ap_phi_mux_data_243_V_read257_s_phi_fu_21315_p4.read());
}

void dense_wrapper::thread_select_ln56_465_fu_36924_p3() {
    select_ln56_465_fu_36924_p3 = (!icmp_ln56_242_fu_29994_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_242_fu_29994_p2.read()[0].to_bool())? ap_phi_mux_data_242_V_read256_s_phi_fu_21302_p4.read(): ap_phi_mux_data_241_V_read255_s_phi_fu_21289_p4.read());
}

void dense_wrapper::thread_select_ln56_466_fu_36932_p3() {
    select_ln56_466_fu_36932_p3 = (!icmp_ln56_240_fu_29982_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_240_fu_29982_p2.read()[0].to_bool())? ap_phi_mux_data_240_V_read254_s_phi_fu_21276_p4.read(): ap_phi_mux_data_239_V_read253_s_phi_fu_21263_p4.read());
}

void dense_wrapper::thread_select_ln56_467_fu_36940_p3() {
    select_ln56_467_fu_36940_p3 = (!icmp_ln56_238_fu_29970_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_238_fu_29970_p2.read()[0].to_bool())? ap_phi_mux_data_238_V_read252_s_phi_fu_21250_p4.read(): ap_phi_mux_data_237_V_read251_s_phi_fu_21237_p4.read());
}

void dense_wrapper::thread_select_ln56_468_fu_36948_p3() {
    select_ln56_468_fu_36948_p3 = (!icmp_ln56_236_fu_29958_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_236_fu_29958_p2.read()[0].to_bool())? ap_phi_mux_data_236_V_read250_s_phi_fu_21224_p4.read(): ap_phi_mux_data_235_V_read249_s_phi_fu_21211_p4.read());
}

void dense_wrapper::thread_select_ln56_469_fu_36956_p3() {
    select_ln56_469_fu_36956_p3 = (!icmp_ln56_234_fu_29946_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_234_fu_29946_p2.read()[0].to_bool())? ap_phi_mux_data_234_V_read248_s_phi_fu_21198_p4.read(): ap_phi_mux_data_233_V_read247_s_phi_fu_21185_p4.read());
}

void dense_wrapper::thread_select_ln56_46_fu_31532_p3() {
    select_ln56_46_fu_31532_p3 = (!icmp_ln56_298_fu_30330_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_298_fu_30330_p2.read()[0].to_bool())? ap_phi_mux_data_690_V_read704_s_phi_fu_27126_p4.read(): ap_phi_mux_data_689_V_read703_s_phi_fu_27113_p4.read());
}

void dense_wrapper::thread_select_ln56_470_fu_36964_p3() {
    select_ln56_470_fu_36964_p3 = (!icmp_ln56_232_fu_29934_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_232_fu_29934_p2.read()[0].to_bool())? ap_phi_mux_data_232_V_read246_s_phi_fu_21172_p4.read(): ap_phi_mux_data_231_V_read245_s_phi_fu_21159_p4.read());
}

void dense_wrapper::thread_select_ln56_471_fu_36972_p3() {
    select_ln56_471_fu_36972_p3 = (!icmp_ln56_230_fu_29922_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_230_fu_29922_p2.read()[0].to_bool())? ap_phi_mux_data_230_V_read244_s_phi_fu_21146_p4.read(): ap_phi_mux_data_229_V_read243_s_phi_fu_21133_p4.read());
}

void dense_wrapper::thread_select_ln56_472_fu_36980_p3() {
    select_ln56_472_fu_36980_p3 = (!icmp_ln56_228_fu_29910_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_228_fu_29910_p2.read()[0].to_bool())? ap_phi_mux_data_228_V_read242_s_phi_fu_21120_p4.read(): ap_phi_mux_data_227_V_read241_s_phi_fu_21107_p4.read());
}

void dense_wrapper::thread_select_ln56_473_fu_36988_p3() {
    select_ln56_473_fu_36988_p3 = (!icmp_ln56_226_fu_29898_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_226_fu_29898_p2.read()[0].to_bool())? ap_phi_mux_data_226_V_read240_s_phi_fu_21094_p4.read(): ap_phi_mux_data_225_V_read239_s_phi_fu_21081_p4.read());
}

void dense_wrapper::thread_select_ln56_474_fu_36996_p3() {
    select_ln56_474_fu_36996_p3 = (!icmp_ln56_224_fu_29886_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_224_fu_29886_p2.read()[0].to_bool())? ap_phi_mux_data_224_V_read238_s_phi_fu_21068_p4.read(): ap_phi_mux_data_223_V_read237_s_phi_fu_21055_p4.read());
}

void dense_wrapper::thread_select_ln56_475_fu_37004_p3() {
    select_ln56_475_fu_37004_p3 = (!icmp_ln56_222_fu_29874_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_222_fu_29874_p2.read()[0].to_bool())? ap_phi_mux_data_222_V_read236_s_phi_fu_21042_p4.read(): ap_phi_mux_data_221_V_read235_s_phi_fu_21029_p4.read());
}

void dense_wrapper::thread_select_ln56_476_fu_37012_p3() {
    select_ln56_476_fu_37012_p3 = (!icmp_ln56_220_fu_29862_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_220_fu_29862_p2.read()[0].to_bool())? ap_phi_mux_data_220_V_read234_s_phi_fu_21016_p4.read(): ap_phi_mux_data_219_V_read233_s_phi_fu_21003_p4.read());
}

void dense_wrapper::thread_select_ln56_477_fu_37020_p3() {
    select_ln56_477_fu_37020_p3 = (!icmp_ln56_218_fu_29850_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_218_fu_29850_p2.read()[0].to_bool())? ap_phi_mux_data_218_V_read232_s_phi_fu_20990_p4.read(): ap_phi_mux_data_217_V_read231_s_phi_fu_20977_p4.read());
}

void dense_wrapper::thread_select_ln56_478_fu_37028_p3() {
    select_ln56_478_fu_37028_p3 = (!icmp_ln56_216_fu_29838_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_216_fu_29838_p2.read()[0].to_bool())? ap_phi_mux_data_216_V_read230_s_phi_fu_20964_p4.read(): ap_phi_mux_data_215_V_read229_s_phi_fu_20951_p4.read());
}

void dense_wrapper::thread_select_ln56_479_fu_37036_p3() {
    select_ln56_479_fu_37036_p3 = (!icmp_ln56_214_fu_29826_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_214_fu_29826_p2.read()[0].to_bool())? ap_phi_mux_data_214_V_read228_s_phi_fu_20938_p4.read(): ap_phi_mux_data_213_V_read227_s_phi_fu_20925_p4.read());
}

void dense_wrapper::thread_select_ln56_47_fu_31546_p3() {
    select_ln56_47_fu_31546_p3 = (!icmp_ln56_296_fu_30318_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_296_fu_30318_p2.read()[0].to_bool())? ap_phi_mux_data_688_V_read702_s_phi_fu_27100_p4.read(): ap_phi_mux_data_687_V_read701_s_phi_fu_27087_p4.read());
}

void dense_wrapper::thread_select_ln56_480_fu_37044_p3() {
    select_ln56_480_fu_37044_p3 = (!icmp_ln56_212_fu_29814_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_212_fu_29814_p2.read()[0].to_bool())? ap_phi_mux_data_212_V_read226_s_phi_fu_20912_p4.read(): ap_phi_mux_data_211_V_read225_s_phi_fu_20899_p4.read());
}

void dense_wrapper::thread_select_ln56_481_fu_37052_p3() {
    select_ln56_481_fu_37052_p3 = (!icmp_ln56_210_fu_29802_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_210_fu_29802_p2.read()[0].to_bool())? ap_phi_mux_data_210_V_read224_s_phi_fu_20886_p4.read(): ap_phi_mux_data_209_V_read223_s_phi_fu_20873_p4.read());
}

void dense_wrapper::thread_select_ln56_482_fu_37060_p3() {
    select_ln56_482_fu_37060_p3 = (!icmp_ln56_208_fu_29790_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_208_fu_29790_p2.read()[0].to_bool())? ap_phi_mux_data_208_V_read222_s_phi_fu_20860_p4.read(): ap_phi_mux_data_207_V_read221_s_phi_fu_20847_p4.read());
}

void dense_wrapper::thread_select_ln56_483_fu_37068_p3() {
    select_ln56_483_fu_37068_p3 = (!icmp_ln56_206_fu_29778_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_206_fu_29778_p2.read()[0].to_bool())? ap_phi_mux_data_206_V_read220_s_phi_fu_20834_p4.read(): ap_phi_mux_data_205_V_read219_s_phi_fu_20821_p4.read());
}

void dense_wrapper::thread_select_ln56_484_fu_37076_p3() {
    select_ln56_484_fu_37076_p3 = (!icmp_ln56_204_fu_29766_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_204_fu_29766_p2.read()[0].to_bool())? ap_phi_mux_data_204_V_read218_s_phi_fu_20808_p4.read(): ap_phi_mux_data_203_V_read217_s_phi_fu_20795_p4.read());
}

void dense_wrapper::thread_select_ln56_485_fu_37084_p3() {
    select_ln56_485_fu_37084_p3 = (!icmp_ln56_202_fu_29754_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_202_fu_29754_p2.read()[0].to_bool())? ap_phi_mux_data_202_V_read216_s_phi_fu_20782_p4.read(): ap_phi_mux_data_201_V_read215_s_phi_fu_20769_p4.read());
}

void dense_wrapper::thread_select_ln56_486_fu_37092_p3() {
    select_ln56_486_fu_37092_p3 = (!icmp_ln56_200_fu_29742_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_200_fu_29742_p2.read()[0].to_bool())? ap_phi_mux_data_200_V_read214_s_phi_fu_20756_p4.read(): ap_phi_mux_data_199_V_read213_s_phi_fu_20743_p4.read());
}

void dense_wrapper::thread_select_ln56_487_fu_37100_p3() {
    select_ln56_487_fu_37100_p3 = (!icmp_ln56_198_fu_29730_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_198_fu_29730_p2.read()[0].to_bool())? ap_phi_mux_data_198_V_read212_s_phi_fu_20730_p4.read(): ap_phi_mux_data_197_V_read211_s_phi_fu_20717_p4.read());
}

void dense_wrapper::thread_select_ln56_488_fu_37108_p3() {
    select_ln56_488_fu_37108_p3 = (!icmp_ln56_196_fu_29718_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_196_fu_29718_p2.read()[0].to_bool())? ap_phi_mux_data_196_V_read210_s_phi_fu_20704_p4.read(): ap_phi_mux_data_195_V_read209_s_phi_fu_20691_p4.read());
}

void dense_wrapper::thread_select_ln56_489_fu_37116_p3() {
    select_ln56_489_fu_37116_p3 = (!icmp_ln56_194_fu_29706_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_194_fu_29706_p2.read()[0].to_bool())? ap_phi_mux_data_194_V_read208_s_phi_fu_20678_p4.read(): ap_phi_mux_data_193_V_read207_s_phi_fu_20665_p4.read());
}

void dense_wrapper::thread_select_ln56_48_fu_31560_p3() {
    select_ln56_48_fu_31560_p3 = (!icmp_ln56_294_fu_30306_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_294_fu_30306_p2.read()[0].to_bool())? ap_phi_mux_data_686_V_read700_s_phi_fu_27074_p4.read(): ap_phi_mux_data_685_V_read699_s_phi_fu_27061_p4.read());
}

void dense_wrapper::thread_select_ln56_490_fu_37124_p3() {
    select_ln56_490_fu_37124_p3 = (!icmp_ln56_192_fu_29694_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_192_fu_29694_p2.read()[0].to_bool())? ap_phi_mux_data_192_V_read206_s_phi_fu_20652_p4.read(): ap_phi_mux_data_191_V_read205_s_phi_fu_20639_p4.read());
}

void dense_wrapper::thread_select_ln56_491_fu_37132_p3() {
    select_ln56_491_fu_37132_p3 = (!icmp_ln56_190_fu_29682_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_190_fu_29682_p2.read()[0].to_bool())? ap_phi_mux_data_190_V_read204_s_phi_fu_20626_p4.read(): ap_phi_mux_data_189_V_read203_s_phi_fu_20613_p4.read());
}

void dense_wrapper::thread_select_ln56_492_fu_37140_p3() {
    select_ln56_492_fu_37140_p3 = (!icmp_ln56_188_fu_29670_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_188_fu_29670_p2.read()[0].to_bool())? ap_phi_mux_data_188_V_read202_s_phi_fu_20600_p4.read(): ap_phi_mux_data_187_V_read201_s_phi_fu_20587_p4.read());
}

void dense_wrapper::thread_select_ln56_493_fu_37148_p3() {
    select_ln56_493_fu_37148_p3 = (!icmp_ln56_186_fu_29658_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_186_fu_29658_p2.read()[0].to_bool())? ap_phi_mux_data_186_V_read200_s_phi_fu_20574_p4.read(): ap_phi_mux_data_185_V_read199_s_phi_fu_20561_p4.read());
}

void dense_wrapper::thread_select_ln56_494_fu_37156_p3() {
    select_ln56_494_fu_37156_p3 = (!icmp_ln56_184_fu_29646_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_184_fu_29646_p2.read()[0].to_bool())? ap_phi_mux_data_184_V_read198_s_phi_fu_20548_p4.read(): ap_phi_mux_data_183_V_read197_s_phi_fu_20535_p4.read());
}

void dense_wrapper::thread_select_ln56_495_fu_37164_p3() {
    select_ln56_495_fu_37164_p3 = (!icmp_ln56_182_fu_29634_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_182_fu_29634_p2.read()[0].to_bool())? ap_phi_mux_data_182_V_read196_s_phi_fu_20522_p4.read(): ap_phi_mux_data_181_V_read195_s_phi_fu_20509_p4.read());
}

void dense_wrapper::thread_select_ln56_496_fu_37172_p3() {
    select_ln56_496_fu_37172_p3 = (!icmp_ln56_180_fu_29622_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_180_fu_29622_p2.read()[0].to_bool())? ap_phi_mux_data_180_V_read194_s_phi_fu_20496_p4.read(): ap_phi_mux_data_179_V_read193_s_phi_fu_20483_p4.read());
}

void dense_wrapper::thread_select_ln56_497_fu_37180_p3() {
    select_ln56_497_fu_37180_p3 = (!icmp_ln56_178_fu_29610_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_178_fu_29610_p2.read()[0].to_bool())? ap_phi_mux_data_178_V_read192_s_phi_fu_20470_p4.read(): ap_phi_mux_data_177_V_read191_s_phi_fu_20457_p4.read());
}

void dense_wrapper::thread_select_ln56_498_fu_37188_p3() {
    select_ln56_498_fu_37188_p3 = (!icmp_ln56_176_fu_29598_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_176_fu_29598_p2.read()[0].to_bool())? ap_phi_mux_data_176_V_read190_s_phi_fu_20444_p4.read(): ap_phi_mux_data_175_V_read189_s_phi_fu_20431_p4.read());
}

void dense_wrapper::thread_select_ln56_499_fu_37196_p3() {
    select_ln56_499_fu_37196_p3 = (!icmp_ln56_174_fu_29586_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_174_fu_29586_p2.read()[0].to_bool())? ap_phi_mux_data_174_V_read188_s_phi_fu_20418_p4.read(): ap_phi_mux_data_173_V_read187_s_phi_fu_20405_p4.read());
}

void dense_wrapper::thread_select_ln56_49_fu_31574_p3() {
    select_ln56_49_fu_31574_p3 = (!icmp_ln56_292_fu_30294_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_292_fu_30294_p2.read()[0].to_bool())? ap_phi_mux_data_684_V_read698_s_phi_fu_27048_p4.read(): ap_phi_mux_data_683_V_read697_s_phi_fu_27035_p4.read());
}

void dense_wrapper::thread_select_ln56_4_fu_30944_p3() {
    select_ln56_4_fu_30944_p3 = (!icmp_ln56_382_fu_30834_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_382_fu_30834_p2.read()[0].to_bool())? ap_phi_mux_data_774_V_read788_s_phi_fu_28218_p4.read(): ap_phi_mux_data_773_V_read787_s_phi_fu_28205_p4.read());
}

void dense_wrapper::thread_select_ln56_500_fu_37204_p3() {
    select_ln56_500_fu_37204_p3 = (!icmp_ln56_172_fu_29574_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_172_fu_29574_p2.read()[0].to_bool())? ap_phi_mux_data_172_V_read186_s_phi_fu_20392_p4.read(): ap_phi_mux_data_171_V_read185_s_phi_fu_20379_p4.read());
}

void dense_wrapper::thread_select_ln56_501_fu_37212_p3() {
    select_ln56_501_fu_37212_p3 = (!icmp_ln56_170_fu_29562_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_170_fu_29562_p2.read()[0].to_bool())? ap_phi_mux_data_170_V_read184_s_phi_fu_20366_p4.read(): ap_phi_mux_data_169_V_read183_s_phi_fu_20353_p4.read());
}

void dense_wrapper::thread_select_ln56_502_fu_37220_p3() {
    select_ln56_502_fu_37220_p3 = (!icmp_ln56_168_fu_29550_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_168_fu_29550_p2.read()[0].to_bool())? ap_phi_mux_data_168_V_read182_s_phi_fu_20340_p4.read(): ap_phi_mux_data_167_V_read181_s_phi_fu_20327_p4.read());
}

void dense_wrapper::thread_select_ln56_503_fu_37228_p3() {
    select_ln56_503_fu_37228_p3 = (!icmp_ln56_166_fu_29538_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_166_fu_29538_p2.read()[0].to_bool())? ap_phi_mux_data_166_V_read180_s_phi_fu_20314_p4.read(): ap_phi_mux_data_165_V_read179_s_phi_fu_20301_p4.read());
}

void dense_wrapper::thread_select_ln56_504_fu_37236_p3() {
    select_ln56_504_fu_37236_p3 = (!icmp_ln56_164_fu_29526_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_164_fu_29526_p2.read()[0].to_bool())? ap_phi_mux_data_164_V_read178_s_phi_fu_20288_p4.read(): ap_phi_mux_data_163_V_read177_s_phi_fu_20275_p4.read());
}

void dense_wrapper::thread_select_ln56_505_fu_37244_p3() {
    select_ln56_505_fu_37244_p3 = (!icmp_ln56_162_fu_29514_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_162_fu_29514_p2.read()[0].to_bool())? ap_phi_mux_data_162_V_read176_s_phi_fu_20262_p4.read(): ap_phi_mux_data_161_V_read175_s_phi_fu_20249_p4.read());
}

void dense_wrapper::thread_select_ln56_506_fu_37252_p3() {
    select_ln56_506_fu_37252_p3 = (!icmp_ln56_160_fu_29502_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_160_fu_29502_p2.read()[0].to_bool())? ap_phi_mux_data_160_V_read174_s_phi_fu_20236_p4.read(): ap_phi_mux_data_159_V_read173_s_phi_fu_20223_p4.read());
}

void dense_wrapper::thread_select_ln56_507_fu_37260_p3() {
    select_ln56_507_fu_37260_p3 = (!icmp_ln56_158_fu_29490_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_158_fu_29490_p2.read()[0].to_bool())? ap_phi_mux_data_158_V_read172_s_phi_fu_20210_p4.read(): ap_phi_mux_data_157_V_read171_s_phi_fu_20197_p4.read());
}

void dense_wrapper::thread_select_ln56_508_fu_37268_p3() {
    select_ln56_508_fu_37268_p3 = (!icmp_ln56_156_fu_29478_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_156_fu_29478_p2.read()[0].to_bool())? ap_phi_mux_data_156_V_read170_s_phi_fu_20184_p4.read(): ap_phi_mux_data_155_V_read169_s_phi_fu_20171_p4.read());
}

void dense_wrapper::thread_select_ln56_509_fu_37276_p3() {
    select_ln56_509_fu_37276_p3 = (!icmp_ln56_154_fu_29466_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_154_fu_29466_p2.read()[0].to_bool())? ap_phi_mux_data_154_V_read168_s_phi_fu_20158_p4.read(): ap_phi_mux_data_153_V_read167_s_phi_fu_20145_p4.read());
}

void dense_wrapper::thread_select_ln56_50_fu_31588_p3() {
    select_ln56_50_fu_31588_p3 = (!icmp_ln56_290_fu_30282_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_290_fu_30282_p2.read()[0].to_bool())? ap_phi_mux_data_682_V_read696_s_phi_fu_27022_p4.read(): ap_phi_mux_data_681_V_read695_s_phi_fu_27009_p4.read());
}

void dense_wrapper::thread_select_ln56_510_fu_37284_p3() {
    select_ln56_510_fu_37284_p3 = (!icmp_ln56_152_fu_29454_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_152_fu_29454_p2.read()[0].to_bool())? ap_phi_mux_data_152_V_read166_s_phi_fu_20132_p4.read(): ap_phi_mux_data_151_V_read165_s_phi_fu_20119_p4.read());
}

void dense_wrapper::thread_select_ln56_511_fu_37292_p3() {
    select_ln56_511_fu_37292_p3 = (!icmp_ln56_150_fu_29442_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_150_fu_29442_p2.read()[0].to_bool())? ap_phi_mux_data_150_V_read164_s_phi_fu_20106_p4.read(): ap_phi_mux_data_149_V_read163_s_phi_fu_20093_p4.read());
}

void dense_wrapper::thread_select_ln56_512_fu_37300_p3() {
    select_ln56_512_fu_37300_p3 = (!icmp_ln56_148_fu_29430_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_148_fu_29430_p2.read()[0].to_bool())? ap_phi_mux_data_148_V_read162_s_phi_fu_20080_p4.read(): ap_phi_mux_data_147_V_read161_s_phi_fu_20067_p4.read());
}

void dense_wrapper::thread_select_ln56_513_fu_37308_p3() {
    select_ln56_513_fu_37308_p3 = (!icmp_ln56_146_fu_29418_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_146_fu_29418_p2.read()[0].to_bool())? ap_phi_mux_data_146_V_read160_s_phi_fu_20054_p4.read(): ap_phi_mux_data_145_V_read159_s_phi_fu_20041_p4.read());
}

void dense_wrapper::thread_select_ln56_514_fu_37316_p3() {
    select_ln56_514_fu_37316_p3 = (!icmp_ln56_144_fu_29406_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_144_fu_29406_p2.read()[0].to_bool())? ap_phi_mux_data_144_V_read158_s_phi_fu_20028_p4.read(): ap_phi_mux_data_143_V_read157_s_phi_fu_20015_p4.read());
}

void dense_wrapper::thread_select_ln56_515_fu_37324_p3() {
    select_ln56_515_fu_37324_p3 = (!icmp_ln56_142_fu_29394_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_142_fu_29394_p2.read()[0].to_bool())? ap_phi_mux_data_142_V_read156_s_phi_fu_20002_p4.read(): ap_phi_mux_data_141_V_read155_s_phi_fu_19989_p4.read());
}

void dense_wrapper::thread_select_ln56_516_fu_37332_p3() {
    select_ln56_516_fu_37332_p3 = (!icmp_ln56_140_fu_29382_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_140_fu_29382_p2.read()[0].to_bool())? ap_phi_mux_data_140_V_read154_s_phi_fu_19976_p4.read(): ap_phi_mux_data_139_V_read153_s_phi_fu_19963_p4.read());
}

void dense_wrapper::thread_select_ln56_517_fu_37340_p3() {
    select_ln56_517_fu_37340_p3 = (!icmp_ln56_138_fu_29370_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_138_fu_29370_p2.read()[0].to_bool())? ap_phi_mux_data_138_V_read152_s_phi_fu_19950_p4.read(): ap_phi_mux_data_137_V_read151_s_phi_fu_19937_p4.read());
}

void dense_wrapper::thread_select_ln56_518_fu_37348_p3() {
    select_ln56_518_fu_37348_p3 = (!icmp_ln56_136_fu_29358_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_136_fu_29358_p2.read()[0].to_bool())? ap_phi_mux_data_136_V_read150_s_phi_fu_19924_p4.read(): ap_phi_mux_data_135_V_read149_s_phi_fu_19911_p4.read());
}

void dense_wrapper::thread_select_ln56_519_fu_37356_p3() {
    select_ln56_519_fu_37356_p3 = (!icmp_ln56_134_fu_29346_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_134_fu_29346_p2.read()[0].to_bool())? ap_phi_mux_data_134_V_read148_s_phi_fu_19898_p4.read(): ap_phi_mux_data_133_V_read147_s_phi_fu_19885_p4.read());
}

void dense_wrapper::thread_select_ln56_51_fu_31602_p3() {
    select_ln56_51_fu_31602_p3 = (!icmp_ln56_288_fu_30270_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_288_fu_30270_p2.read()[0].to_bool())? ap_phi_mux_data_680_V_read694_s_phi_fu_26996_p4.read(): ap_phi_mux_data_679_V_read693_s_phi_fu_26983_p4.read());
}

void dense_wrapper::thread_select_ln56_520_fu_37364_p3() {
    select_ln56_520_fu_37364_p3 = (!icmp_ln56_132_fu_29334_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_132_fu_29334_p2.read()[0].to_bool())? ap_phi_mux_data_132_V_read146_s_phi_fu_19872_p4.read(): ap_phi_mux_data_131_V_read145_s_phi_fu_19859_p4.read());
}

void dense_wrapper::thread_select_ln56_521_fu_37372_p3() {
    select_ln56_521_fu_37372_p3 = (!icmp_ln56_130_fu_29322_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_130_fu_29322_p2.read()[0].to_bool())? ap_phi_mux_data_130_V_read144_s_phi_fu_19846_p4.read(): ap_phi_mux_data_129_V_read143_s_phi_fu_19833_p4.read());
}

void dense_wrapper::thread_select_ln56_522_fu_37380_p3() {
    select_ln56_522_fu_37380_p3 = (!icmp_ln56_128_fu_29310_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_128_fu_29310_p2.read()[0].to_bool())? ap_phi_mux_data_128_V_read142_s_phi_fu_19820_p4.read(): ap_phi_mux_data_127_V_read141_s_phi_fu_19807_p4.read());
}

void dense_wrapper::thread_select_ln56_523_fu_37388_p3() {
    select_ln56_523_fu_37388_p3 = (!icmp_ln56_126_fu_29298_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_126_fu_29298_p2.read()[0].to_bool())? ap_phi_mux_data_126_V_read140_s_phi_fu_19794_p4.read(): ap_phi_mux_data_125_V_read139_s_phi_fu_19781_p4.read());
}

void dense_wrapper::thread_select_ln56_524_fu_37396_p3() {
    select_ln56_524_fu_37396_p3 = (!icmp_ln56_124_fu_29286_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_124_fu_29286_p2.read()[0].to_bool())? ap_phi_mux_data_124_V_read138_s_phi_fu_19768_p4.read(): ap_phi_mux_data_123_V_read137_s_phi_fu_19755_p4.read());
}

void dense_wrapper::thread_select_ln56_525_fu_37404_p3() {
    select_ln56_525_fu_37404_p3 = (!icmp_ln56_122_fu_29274_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_122_fu_29274_p2.read()[0].to_bool())? ap_phi_mux_data_122_V_read136_s_phi_fu_19742_p4.read(): ap_phi_mux_data_121_V_read135_s_phi_fu_19729_p4.read());
}

void dense_wrapper::thread_select_ln56_526_fu_37412_p3() {
    select_ln56_526_fu_37412_p3 = (!icmp_ln56_120_fu_29262_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_120_fu_29262_p2.read()[0].to_bool())? ap_phi_mux_data_120_V_read134_s_phi_fu_19716_p4.read(): ap_phi_mux_data_119_V_read133_s_phi_fu_19703_p4.read());
}

void dense_wrapper::thread_select_ln56_527_fu_37420_p3() {
    select_ln56_527_fu_37420_p3 = (!icmp_ln56_118_fu_29250_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_118_fu_29250_p2.read()[0].to_bool())? ap_phi_mux_data_118_V_read132_s_phi_fu_19690_p4.read(): ap_phi_mux_data_117_V_read131_s_phi_fu_19677_p4.read());
}

void dense_wrapper::thread_select_ln56_528_fu_37428_p3() {
    select_ln56_528_fu_37428_p3 = (!icmp_ln56_116_fu_29238_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_116_fu_29238_p2.read()[0].to_bool())? ap_phi_mux_data_116_V_read130_s_phi_fu_19664_p4.read(): ap_phi_mux_data_115_V_read129_s_phi_fu_19651_p4.read());
}

void dense_wrapper::thread_select_ln56_529_fu_37436_p3() {
    select_ln56_529_fu_37436_p3 = (!icmp_ln56_114_fu_29226_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_114_fu_29226_p2.read()[0].to_bool())? ap_phi_mux_data_114_V_read128_s_phi_fu_19638_p4.read(): ap_phi_mux_data_113_V_read127_s_phi_fu_19625_p4.read());
}

void dense_wrapper::thread_select_ln56_52_fu_31616_p3() {
    select_ln56_52_fu_31616_p3 = (!icmp_ln56_286_fu_30258_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_286_fu_30258_p2.read()[0].to_bool())? ap_phi_mux_data_678_V_read692_s_phi_fu_26970_p4.read(): ap_phi_mux_data_677_V_read691_s_phi_fu_26957_p4.read());
}

void dense_wrapper::thread_select_ln56_530_fu_37444_p3() {
    select_ln56_530_fu_37444_p3 = (!icmp_ln56_112_fu_29214_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_112_fu_29214_p2.read()[0].to_bool())? ap_phi_mux_data_112_V_read126_s_phi_fu_19612_p4.read(): ap_phi_mux_data_111_V_read125_s_phi_fu_19599_p4.read());
}

void dense_wrapper::thread_select_ln56_531_fu_37452_p3() {
    select_ln56_531_fu_37452_p3 = (!icmp_ln56_110_fu_29202_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_110_fu_29202_p2.read()[0].to_bool())? ap_phi_mux_data_110_V_read124_s_phi_fu_19586_p4.read(): ap_phi_mux_data_109_V_read123_s_phi_fu_19573_p4.read());
}

void dense_wrapper::thread_select_ln56_532_fu_37460_p3() {
    select_ln56_532_fu_37460_p3 = (!icmp_ln56_108_fu_29190_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_108_fu_29190_p2.read()[0].to_bool())? ap_phi_mux_data_108_V_read122_s_phi_fu_19560_p4.read(): ap_phi_mux_data_107_V_read121_s_phi_fu_19547_p4.read());
}

void dense_wrapper::thread_select_ln56_533_fu_37468_p3() {
    select_ln56_533_fu_37468_p3 = (!icmp_ln56_106_fu_29178_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_106_fu_29178_p2.read()[0].to_bool())? ap_phi_mux_data_106_V_read120_s_phi_fu_19534_p4.read(): ap_phi_mux_data_105_V_read119_s_phi_fu_19521_p4.read());
}

void dense_wrapper::thread_select_ln56_534_fu_37476_p3() {
    select_ln56_534_fu_37476_p3 = (!icmp_ln56_104_fu_29166_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_104_fu_29166_p2.read()[0].to_bool())? ap_phi_mux_data_104_V_read118_s_phi_fu_19508_p4.read(): ap_phi_mux_data_103_V_read117_s_phi_fu_19495_p4.read());
}

void dense_wrapper::thread_select_ln56_535_fu_37484_p3() {
    select_ln56_535_fu_37484_p3 = (!icmp_ln56_102_fu_29154_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_102_fu_29154_p2.read()[0].to_bool())? ap_phi_mux_data_102_V_read116_s_phi_fu_19482_p4.read(): ap_phi_mux_data_101_V_read115_s_phi_fu_19469_p4.read());
}

void dense_wrapper::thread_select_ln56_536_fu_37492_p3() {
    select_ln56_536_fu_37492_p3 = (!icmp_ln56_100_fu_29142_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_100_fu_29142_p2.read()[0].to_bool())? ap_phi_mux_data_100_V_read114_s_phi_fu_19456_p4.read(): ap_phi_mux_data_99_V_read113_p_phi_fu_19443_p4.read());
}

void dense_wrapper::thread_select_ln56_537_fu_37500_p3() {
    select_ln56_537_fu_37500_p3 = (!icmp_ln56_98_fu_29130_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_98_fu_29130_p2.read()[0].to_bool())? ap_phi_mux_data_98_V_read112_p_phi_fu_19430_p4.read(): ap_phi_mux_data_97_V_read111_p_phi_fu_19417_p4.read());
}

void dense_wrapper::thread_select_ln56_538_fu_37508_p3() {
    select_ln56_538_fu_37508_p3 = (!icmp_ln56_96_fu_29118_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_96_fu_29118_p2.read()[0].to_bool())? ap_phi_mux_data_96_V_read110_p_phi_fu_19404_p4.read(): ap_phi_mux_data_95_V_read109_p_phi_fu_19391_p4.read());
}

void dense_wrapper::thread_select_ln56_539_fu_37516_p3() {
    select_ln56_539_fu_37516_p3 = (!icmp_ln56_94_fu_29106_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_94_fu_29106_p2.read()[0].to_bool())? ap_phi_mux_data_94_V_read108_p_phi_fu_19378_p4.read(): ap_phi_mux_data_93_V_read107_p_phi_fu_19365_p4.read());
}

void dense_wrapper::thread_select_ln56_53_fu_31630_p3() {
    select_ln56_53_fu_31630_p3 = (!icmp_ln56_284_fu_30246_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_284_fu_30246_p2.read()[0].to_bool())? ap_phi_mux_data_676_V_read690_s_phi_fu_26944_p4.read(): ap_phi_mux_data_675_V_read689_s_phi_fu_26931_p4.read());
}

void dense_wrapper::thread_select_ln56_540_fu_37524_p3() {
    select_ln56_540_fu_37524_p3 = (!icmp_ln56_92_fu_29094_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_92_fu_29094_p2.read()[0].to_bool())? ap_phi_mux_data_92_V_read106_p_phi_fu_19352_p4.read(): ap_phi_mux_data_91_V_read105_p_phi_fu_19339_p4.read());
}

void dense_wrapper::thread_select_ln56_541_fu_37532_p3() {
    select_ln56_541_fu_37532_p3 = (!icmp_ln56_90_fu_29082_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_90_fu_29082_p2.read()[0].to_bool())? ap_phi_mux_data_90_V_read104_p_phi_fu_19326_p4.read(): ap_phi_mux_data_89_V_read103_p_phi_fu_19313_p4.read());
}

void dense_wrapper::thread_select_ln56_542_fu_37540_p3() {
    select_ln56_542_fu_37540_p3 = (!icmp_ln56_88_fu_29070_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_88_fu_29070_p2.read()[0].to_bool())? ap_phi_mux_data_88_V_read102_p_phi_fu_19300_p4.read(): ap_phi_mux_data_87_V_read101_p_phi_fu_19287_p4.read());
}

void dense_wrapper::thread_select_ln56_543_fu_37548_p3() {
    select_ln56_543_fu_37548_p3 = (!icmp_ln56_86_fu_29058_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_86_fu_29058_p2.read()[0].to_bool())? ap_phi_mux_data_86_V_read100_p_phi_fu_19274_p4.read(): ap_phi_mux_data_85_V_read99_ph_phi_fu_19261_p4.read());
}

void dense_wrapper::thread_select_ln56_544_fu_37556_p3() {
    select_ln56_544_fu_37556_p3 = (!icmp_ln56_84_fu_29046_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_84_fu_29046_p2.read()[0].to_bool())? ap_phi_mux_data_84_V_read98_ph_phi_fu_19248_p4.read(): ap_phi_mux_data_83_V_read97_ph_phi_fu_19235_p4.read());
}

void dense_wrapper::thread_select_ln56_545_fu_37564_p3() {
    select_ln56_545_fu_37564_p3 = (!icmp_ln56_82_fu_29034_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_82_fu_29034_p2.read()[0].to_bool())? ap_phi_mux_data_82_V_read96_ph_phi_fu_19222_p4.read(): ap_phi_mux_data_81_V_read95_ph_phi_fu_19209_p4.read());
}

void dense_wrapper::thread_select_ln56_546_fu_37572_p3() {
    select_ln56_546_fu_37572_p3 = (!icmp_ln56_80_fu_29022_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_80_fu_29022_p2.read()[0].to_bool())? ap_phi_mux_data_80_V_read94_ph_phi_fu_19196_p4.read(): ap_phi_mux_data_79_V_read93_ph_phi_fu_19183_p4.read());
}

void dense_wrapper::thread_select_ln56_547_fu_37580_p3() {
    select_ln56_547_fu_37580_p3 = (!icmp_ln56_78_fu_29010_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_78_fu_29010_p2.read()[0].to_bool())? ap_phi_mux_data_78_V_read92_ph_phi_fu_19170_p4.read(): ap_phi_mux_data_77_V_read91_ph_phi_fu_19157_p4.read());
}

void dense_wrapper::thread_select_ln56_548_fu_37588_p3() {
    select_ln56_548_fu_37588_p3 = (!icmp_ln56_76_fu_28998_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_76_fu_28998_p2.read()[0].to_bool())? ap_phi_mux_data_76_V_read90_ph_phi_fu_19144_p4.read(): ap_phi_mux_data_75_V_read89_ph_phi_fu_19131_p4.read());
}

void dense_wrapper::thread_select_ln56_549_fu_37596_p3() {
    select_ln56_549_fu_37596_p3 = (!icmp_ln56_74_fu_28986_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_74_fu_28986_p2.read()[0].to_bool())? ap_phi_mux_data_74_V_read88_ph_phi_fu_19118_p4.read(): ap_phi_mux_data_73_V_read87_ph_phi_fu_19105_p4.read());
}

void dense_wrapper::thread_select_ln56_54_fu_31644_p3() {
    select_ln56_54_fu_31644_p3 = (!icmp_ln56_282_fu_30234_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_282_fu_30234_p2.read()[0].to_bool())? ap_phi_mux_data_674_V_read688_s_phi_fu_26918_p4.read(): ap_phi_mux_data_673_V_read687_s_phi_fu_26905_p4.read());
}

void dense_wrapper::thread_select_ln56_550_fu_37604_p3() {
    select_ln56_550_fu_37604_p3 = (!icmp_ln56_72_fu_28974_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_72_fu_28974_p2.read()[0].to_bool())? ap_phi_mux_data_72_V_read86_ph_phi_fu_19092_p4.read(): ap_phi_mux_data_71_V_read85_ph_phi_fu_19079_p4.read());
}

void dense_wrapper::thread_select_ln56_551_fu_37612_p3() {
    select_ln56_551_fu_37612_p3 = (!icmp_ln56_70_fu_28962_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_70_fu_28962_p2.read()[0].to_bool())? ap_phi_mux_data_70_V_read84_ph_phi_fu_19066_p4.read(): ap_phi_mux_data_69_V_read83_ph_phi_fu_19053_p4.read());
}

void dense_wrapper::thread_select_ln56_552_fu_37620_p3() {
    select_ln56_552_fu_37620_p3 = (!icmp_ln56_68_fu_28950_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_68_fu_28950_p2.read()[0].to_bool())? ap_phi_mux_data_68_V_read82_ph_phi_fu_19040_p4.read(): ap_phi_mux_data_67_V_read81_ph_phi_fu_19027_p4.read());
}

void dense_wrapper::thread_select_ln56_553_fu_37628_p3() {
    select_ln56_553_fu_37628_p3 = (!icmp_ln56_66_fu_28938_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_66_fu_28938_p2.read()[0].to_bool())? ap_phi_mux_data_66_V_read80_ph_phi_fu_19014_p4.read(): ap_phi_mux_data_65_V_read79_ph_phi_fu_19001_p4.read());
}

void dense_wrapper::thread_select_ln56_554_fu_37636_p3() {
    select_ln56_554_fu_37636_p3 = (!icmp_ln56_64_fu_28926_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_64_fu_28926_p2.read()[0].to_bool())? ap_phi_mux_data_64_V_read78_ph_phi_fu_18988_p4.read(): ap_phi_mux_data_63_V_read77_ph_phi_fu_18975_p4.read());
}

void dense_wrapper::thread_select_ln56_555_fu_37644_p3() {
    select_ln56_555_fu_37644_p3 = (!icmp_ln56_62_fu_28914_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_62_fu_28914_p2.read()[0].to_bool())? ap_phi_mux_data_62_V_read76_ph_phi_fu_18962_p4.read(): ap_phi_mux_data_61_V_read75_ph_phi_fu_18949_p4.read());
}

void dense_wrapper::thread_select_ln56_556_fu_37652_p3() {
    select_ln56_556_fu_37652_p3 = (!icmp_ln56_60_fu_28902_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_60_fu_28902_p2.read()[0].to_bool())? ap_phi_mux_data_60_V_read74_ph_phi_fu_18936_p4.read(): ap_phi_mux_data_59_V_read73_ph_phi_fu_18923_p4.read());
}

void dense_wrapper::thread_select_ln56_557_fu_37660_p3() {
    select_ln56_557_fu_37660_p3 = (!icmp_ln56_58_fu_28890_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_58_fu_28890_p2.read()[0].to_bool())? ap_phi_mux_data_58_V_read72_ph_phi_fu_18910_p4.read(): ap_phi_mux_data_57_V_read71_ph_phi_fu_18897_p4.read());
}

void dense_wrapper::thread_select_ln56_558_fu_37668_p3() {
    select_ln56_558_fu_37668_p3 = (!icmp_ln56_56_fu_28878_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_56_fu_28878_p2.read()[0].to_bool())? ap_phi_mux_data_56_V_read70_ph_phi_fu_18884_p4.read(): ap_phi_mux_data_55_V_read69_ph_phi_fu_18871_p4.read());
}

void dense_wrapper::thread_select_ln56_559_fu_37676_p3() {
    select_ln56_559_fu_37676_p3 = (!icmp_ln56_54_fu_28866_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_54_fu_28866_p2.read()[0].to_bool())? ap_phi_mux_data_54_V_read68_ph_phi_fu_18858_p4.read(): ap_phi_mux_data_53_V_read67_ph_phi_fu_18845_p4.read());
}

void dense_wrapper::thread_select_ln56_55_fu_31658_p3() {
    select_ln56_55_fu_31658_p3 = (!icmp_ln56_280_fu_30222_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_280_fu_30222_p2.read()[0].to_bool())? ap_phi_mux_data_672_V_read686_s_phi_fu_26892_p4.read(): ap_phi_mux_data_671_V_read685_s_phi_fu_26879_p4.read());
}

void dense_wrapper::thread_select_ln56_560_fu_37684_p3() {
    select_ln56_560_fu_37684_p3 = (!icmp_ln56_52_fu_28854_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_52_fu_28854_p2.read()[0].to_bool())? ap_phi_mux_data_52_V_read66_ph_phi_fu_18832_p4.read(): ap_phi_mux_data_51_V_read65_ph_phi_fu_18819_p4.read());
}

void dense_wrapper::thread_select_ln56_561_fu_37692_p3() {
    select_ln56_561_fu_37692_p3 = (!icmp_ln56_50_fu_28842_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_50_fu_28842_p2.read()[0].to_bool())? ap_phi_mux_data_50_V_read64_ph_phi_fu_18806_p4.read(): ap_phi_mux_data_49_V_read63_ph_phi_fu_18793_p4.read());
}

void dense_wrapper::thread_select_ln56_562_fu_37700_p3() {
    select_ln56_562_fu_37700_p3 = (!icmp_ln56_48_fu_28830_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_48_fu_28830_p2.read()[0].to_bool())? ap_phi_mux_data_48_V_read62_ph_phi_fu_18780_p4.read(): ap_phi_mux_data_47_V_read61_ph_phi_fu_18767_p4.read());
}

void dense_wrapper::thread_select_ln56_563_fu_37708_p3() {
    select_ln56_563_fu_37708_p3 = (!icmp_ln56_46_fu_28818_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_46_fu_28818_p2.read()[0].to_bool())? ap_phi_mux_data_46_V_read60_ph_phi_fu_18754_p4.read(): ap_phi_mux_data_45_V_read59_ph_phi_fu_18741_p4.read());
}

void dense_wrapper::thread_select_ln56_564_fu_37716_p3() {
    select_ln56_564_fu_37716_p3 = (!icmp_ln56_44_fu_28806_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_44_fu_28806_p2.read()[0].to_bool())? ap_phi_mux_data_44_V_read58_ph_phi_fu_18728_p4.read(): ap_phi_mux_data_43_V_read57_ph_phi_fu_18715_p4.read());
}

void dense_wrapper::thread_select_ln56_565_fu_37724_p3() {
    select_ln56_565_fu_37724_p3 = (!icmp_ln56_42_fu_28794_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_42_fu_28794_p2.read()[0].to_bool())? ap_phi_mux_data_42_V_read56_ph_phi_fu_18702_p4.read(): ap_phi_mux_data_41_V_read55_ph_phi_fu_18689_p4.read());
}

void dense_wrapper::thread_select_ln56_566_fu_37732_p3() {
    select_ln56_566_fu_37732_p3 = (!icmp_ln56_40_fu_28782_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_40_fu_28782_p2.read()[0].to_bool())? ap_phi_mux_data_40_V_read54_ph_phi_fu_18676_p4.read(): ap_phi_mux_data_39_V_read53_ph_phi_fu_18663_p4.read());
}

void dense_wrapper::thread_select_ln56_567_fu_37740_p3() {
    select_ln56_567_fu_37740_p3 = (!icmp_ln56_38_fu_28770_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_38_fu_28770_p2.read()[0].to_bool())? ap_phi_mux_data_38_V_read52_ph_phi_fu_18650_p4.read(): ap_phi_mux_data_37_V_read51_ph_phi_fu_18637_p4.read());
}

void dense_wrapper::thread_select_ln56_568_fu_37748_p3() {
    select_ln56_568_fu_37748_p3 = (!icmp_ln56_36_fu_28758_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_36_fu_28758_p2.read()[0].to_bool())? ap_phi_mux_data_36_V_read50_ph_phi_fu_18624_p4.read(): ap_phi_mux_data_35_V_read49_ph_phi_fu_18611_p4.read());
}

void dense_wrapper::thread_select_ln56_569_fu_37756_p3() {
    select_ln56_569_fu_37756_p3 = (!icmp_ln56_34_fu_28746_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_34_fu_28746_p2.read()[0].to_bool())? ap_phi_mux_data_34_V_read48_ph_phi_fu_18598_p4.read(): ap_phi_mux_data_33_V_read47_ph_phi_fu_18585_p4.read());
}

void dense_wrapper::thread_select_ln56_56_fu_31672_p3() {
    select_ln56_56_fu_31672_p3 = (!icmp_ln56_278_fu_30210_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_278_fu_30210_p2.read()[0].to_bool())? ap_phi_mux_data_670_V_read684_s_phi_fu_26866_p4.read(): ap_phi_mux_data_669_V_read683_s_phi_fu_26853_p4.read());
}

void dense_wrapper::thread_select_ln56_570_fu_37764_p3() {
    select_ln56_570_fu_37764_p3 = (!icmp_ln56_32_fu_28734_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_32_fu_28734_p2.read()[0].to_bool())? ap_phi_mux_data_32_V_read46_ph_phi_fu_18572_p4.read(): ap_phi_mux_data_31_V_read45_ph_phi_fu_18559_p4.read());
}

void dense_wrapper::thread_select_ln56_571_fu_37772_p3() {
    select_ln56_571_fu_37772_p3 = (!icmp_ln56_30_fu_28722_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_30_fu_28722_p2.read()[0].to_bool())? ap_phi_mux_data_30_V_read44_ph_phi_fu_18546_p4.read(): ap_phi_mux_data_29_V_read43_ph_phi_fu_18533_p4.read());
}

void dense_wrapper::thread_select_ln56_572_fu_37780_p3() {
    select_ln56_572_fu_37780_p3 = (!icmp_ln56_28_fu_28710_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_28_fu_28710_p2.read()[0].to_bool())? ap_phi_mux_data_28_V_read42_ph_phi_fu_18520_p4.read(): ap_phi_mux_data_27_V_read41_ph_phi_fu_18507_p4.read());
}

void dense_wrapper::thread_select_ln56_573_fu_37788_p3() {
    select_ln56_573_fu_37788_p3 = (!icmp_ln56_26_fu_28698_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_26_fu_28698_p2.read()[0].to_bool())? ap_phi_mux_data_26_V_read40_ph_phi_fu_18494_p4.read(): ap_phi_mux_data_25_V_read39_ph_phi_fu_18481_p4.read());
}

void dense_wrapper::thread_select_ln56_574_fu_37796_p3() {
    select_ln56_574_fu_37796_p3 = (!icmp_ln56_24_fu_28686_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_24_fu_28686_p2.read()[0].to_bool())? ap_phi_mux_data_24_V_read38_ph_phi_fu_18468_p4.read(): ap_phi_mux_data_23_V_read37_ph_phi_fu_18455_p4.read());
}

void dense_wrapper::thread_select_ln56_575_fu_37804_p3() {
    select_ln56_575_fu_37804_p3 = (!icmp_ln56_22_fu_28674_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_22_fu_28674_p2.read()[0].to_bool())? ap_phi_mux_data_22_V_read36_ph_phi_fu_18442_p4.read(): ap_phi_mux_data_21_V_read35_ph_phi_fu_18429_p4.read());
}

void dense_wrapper::thread_select_ln56_576_fu_37812_p3() {
    select_ln56_576_fu_37812_p3 = (!icmp_ln56_20_fu_28662_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_20_fu_28662_p2.read()[0].to_bool())? ap_phi_mux_data_20_V_read34_ph_phi_fu_18416_p4.read(): ap_phi_mux_data_19_V_read33_ph_phi_fu_18403_p4.read());
}

void dense_wrapper::thread_select_ln56_577_fu_37820_p3() {
    select_ln56_577_fu_37820_p3 = (!icmp_ln56_18_fu_28650_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_18_fu_28650_p2.read()[0].to_bool())? ap_phi_mux_data_18_V_read32_ph_phi_fu_18390_p4.read(): ap_phi_mux_data_17_V_read31_ph_phi_fu_18377_p4.read());
}

void dense_wrapper::thread_select_ln56_578_fu_37828_p3() {
    select_ln56_578_fu_37828_p3 = (!icmp_ln56_16_fu_28630_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_16_fu_28630_p2.read()[0].to_bool())? ap_phi_mux_data_16_V_read30_ph_phi_fu_18364_p4.read(): ap_phi_mux_data_15_V_read29_ph_phi_fu_18351_p4.read());
}

void dense_wrapper::thread_select_ln56_579_fu_37836_p3() {
    select_ln56_579_fu_37836_p3 = (!icmp_ln56_14_fu_28602_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_28602_p2.read()[0].to_bool())? ap_phi_mux_data_14_V_read28_ph_phi_fu_18338_p4.read(): ap_phi_mux_data_13_V_read27_ph_phi_fu_18325_p4.read());
}

void dense_wrapper::thread_select_ln56_57_fu_31686_p3() {
    select_ln56_57_fu_31686_p3 = (!icmp_ln56_276_fu_30198_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_276_fu_30198_p2.read()[0].to_bool())? ap_phi_mux_data_668_V_read682_s_phi_fu_26840_p4.read(): ap_phi_mux_data_667_V_read681_s_phi_fu_26827_p4.read());
}

void dense_wrapper::thread_select_ln56_580_fu_37844_p3() {
    select_ln56_580_fu_37844_p3 = (!icmp_ln56_12_fu_28574_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_28574_p2.read()[0].to_bool())? ap_phi_mux_data_12_V_read26_ph_phi_fu_18312_p4.read(): ap_phi_mux_data_11_V_read25_ph_phi_fu_18299_p4.read());
}

void dense_wrapper::thread_select_ln56_581_fu_37852_p3() {
    select_ln56_581_fu_37852_p3 = (!icmp_ln56_10_fu_28546_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_28546_p2.read()[0].to_bool())? ap_phi_mux_data_10_V_read24_ph_phi_fu_18286_p4.read(): ap_phi_mux_data_9_V_read23_phi_phi_fu_18273_p4.read());
}

void dense_wrapper::thread_select_ln56_582_fu_37860_p3() {
    select_ln56_582_fu_37860_p3 = (!icmp_ln56_8_fu_28518_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_28518_p2.read()[0].to_bool())? ap_phi_mux_data_8_V_read22_phi_phi_fu_18260_p4.read(): ap_phi_mux_data_7_V_read21_phi_phi_fu_18247_p4.read());
}

void dense_wrapper::thread_select_ln56_583_fu_37868_p3() {
    select_ln56_583_fu_37868_p3 = (!icmp_ln56_6_fu_28490_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_28490_p2.read()[0].to_bool())? ap_phi_mux_data_6_V_read20_phi_phi_fu_18234_p4.read(): ap_phi_mux_data_5_V_read19_phi_phi_fu_18221_p4.read());
}

void dense_wrapper::thread_select_ln56_584_fu_37876_p3() {
    select_ln56_584_fu_37876_p3 = (!icmp_ln56_4_fu_28462_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_28462_p2.read()[0].to_bool())? ap_phi_mux_data_4_V_read18_phi_phi_fu_18208_p4.read(): ap_phi_mux_data_3_V_read17_phi_phi_fu_18195_p4.read());
}

void dense_wrapper::thread_select_ln56_585_fu_37884_p3() {
    select_ln56_585_fu_37884_p3 = (!icmp_ln56_2_fu_28434_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_28434_p2.read()[0].to_bool())? ap_phi_mux_data_2_V_read16_phi_phi_fu_18182_p4.read(): ap_phi_mux_data_1_V_read15_phi_phi_fu_18169_p4.read());
}

void dense_wrapper::thread_select_ln56_586_fu_28412_p3() {
    select_ln56_586_fu_28412_p3 = (!icmp_ln56_fu_28406_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_28406_p2.read()[0].to_bool())? ap_phi_mux_data_0_V_read14_phi_phi_fu_18156_p4.read(): ap_phi_mux_data_391_V_read405_s_phi_fu_23239_p4.read());
}

void dense_wrapper::thread_select_ln56_587_fu_37892_p3() {
    select_ln56_587_fu_37892_p3 = (!or_ln56_fu_30896_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_30896_p2.read()[0].to_bool())? select_ln56_391_fu_36332_p3.read(): select_ln56_392_fu_36340_p3.read());
}

void dense_wrapper::thread_select_ln56_588_fu_37900_p3() {
    select_ln56_588_fu_37900_p3 = (!or_ln56_2_fu_30924_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_30924_p2.read()[0].to_bool())? select_ln56_393_fu_36348_p3.read(): select_ln56_394_fu_36356_p3.read());
}

void dense_wrapper::thread_select_ln56_589_fu_37908_p3() {
    select_ln56_589_fu_37908_p3 = (!or_ln56_4_fu_30952_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_30952_p2.read()[0].to_bool())? select_ln56_395_fu_36364_p3.read(): select_ln56_396_fu_36372_p3.read());
}

void dense_wrapper::thread_select_ln56_58_fu_31700_p3() {
    select_ln56_58_fu_31700_p3 = (!icmp_ln56_274_fu_30186_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_274_fu_30186_p2.read()[0].to_bool())? ap_phi_mux_data_666_V_read680_s_phi_fu_26814_p4.read(): ap_phi_mux_data_665_V_read679_s_phi_fu_26801_p4.read());
}

void dense_wrapper::thread_select_ln56_590_fu_37916_p3() {
    select_ln56_590_fu_37916_p3 = (!or_ln56_6_fu_30980_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_30980_p2.read()[0].to_bool())? select_ln56_397_fu_36380_p3.read(): select_ln56_398_fu_36388_p3.read());
}

void dense_wrapper::thread_select_ln56_591_fu_37924_p3() {
    select_ln56_591_fu_37924_p3 = (!or_ln56_8_fu_31008_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_8_fu_31008_p2.read()[0].to_bool())? select_ln56_399_fu_36396_p3.read(): select_ln56_400_fu_36404_p3.read());
}

void dense_wrapper::thread_select_ln56_592_fu_37932_p3() {
    select_ln56_592_fu_37932_p3 = (!or_ln56_10_fu_31036_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_31036_p2.read()[0].to_bool())? select_ln56_401_fu_36412_p3.read(): select_ln56_402_fu_36420_p3.read());
}

void dense_wrapper::thread_select_ln56_593_fu_37940_p3() {
    select_ln56_593_fu_37940_p3 = (!or_ln56_12_fu_31064_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_12_fu_31064_p2.read()[0].to_bool())? select_ln56_403_fu_36428_p3.read(): select_ln56_404_fu_36436_p3.read());
}

void dense_wrapper::thread_select_ln56_594_fu_37948_p3() {
    select_ln56_594_fu_37948_p3 = (!or_ln56_14_fu_31092_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_14_fu_31092_p2.read()[0].to_bool())? select_ln56_405_fu_36444_p3.read(): select_ln56_406_fu_36452_p3.read());
}

void dense_wrapper::thread_select_ln56_595_fu_37956_p3() {
    select_ln56_595_fu_37956_p3 = (!or_ln56_16_fu_31120_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_16_fu_31120_p2.read()[0].to_bool())? select_ln56_407_fu_36460_p3.read(): select_ln56_408_fu_36468_p3.read());
}

void dense_wrapper::thread_select_ln56_596_fu_37964_p3() {
    select_ln56_596_fu_37964_p3 = (!or_ln56_18_fu_31148_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_18_fu_31148_p2.read()[0].to_bool())? select_ln56_409_fu_36476_p3.read(): select_ln56_410_fu_36484_p3.read());
}

void dense_wrapper::thread_select_ln56_597_fu_37972_p3() {
    select_ln56_597_fu_37972_p3 = (!or_ln56_20_fu_31176_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_20_fu_31176_p2.read()[0].to_bool())? select_ln56_411_fu_36492_p3.read(): select_ln56_412_fu_36500_p3.read());
}

void dense_wrapper::thread_select_ln56_598_fu_37980_p3() {
    select_ln56_598_fu_37980_p3 = (!or_ln56_22_fu_31204_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_22_fu_31204_p2.read()[0].to_bool())? select_ln56_413_fu_36508_p3.read(): select_ln56_414_fu_36516_p3.read());
}

void dense_wrapper::thread_select_ln56_599_fu_37988_p3() {
    select_ln56_599_fu_37988_p3 = (!or_ln56_24_fu_31232_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_24_fu_31232_p2.read()[0].to_bool())? select_ln56_415_fu_36524_p3.read(): select_ln56_416_fu_36532_p3.read());
}

void dense_wrapper::thread_select_ln56_59_fu_31714_p3() {
    select_ln56_59_fu_31714_p3 = (!icmp_ln56_272_fu_30174_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_272_fu_30174_p2.read()[0].to_bool())? ap_phi_mux_data_664_V_read678_s_phi_fu_26788_p4.read(): ap_phi_mux_data_663_V_read677_s_phi_fu_26775_p4.read());
}

void dense_wrapper::thread_select_ln56_5_fu_30958_p3() {
    select_ln56_5_fu_30958_p3 = (!icmp_ln56_380_fu_30822_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_380_fu_30822_p2.read()[0].to_bool())? ap_phi_mux_data_772_V_read786_s_phi_fu_28192_p4.read(): ap_phi_mux_data_771_V_read785_s_phi_fu_28179_p4.read());
}

void dense_wrapper::thread_select_ln56_600_fu_37996_p3() {
    select_ln56_600_fu_37996_p3 = (!or_ln56_26_fu_31260_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_26_fu_31260_p2.read()[0].to_bool())? select_ln56_417_fu_36540_p3.read(): select_ln56_418_fu_36548_p3.read());
}

void dense_wrapper::thread_select_ln56_601_fu_38004_p3() {
    select_ln56_601_fu_38004_p3 = (!or_ln56_28_fu_31288_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_28_fu_31288_p2.read()[0].to_bool())? select_ln56_419_fu_36556_p3.read(): select_ln56_420_fu_36564_p3.read());
}

void dense_wrapper::thread_select_ln56_602_fu_38012_p3() {
    select_ln56_602_fu_38012_p3 = (!or_ln56_30_fu_31316_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_30_fu_31316_p2.read()[0].to_bool())? select_ln56_421_fu_36572_p3.read(): select_ln56_422_fu_36580_p3.read());
}

void dense_wrapper::thread_select_ln56_603_fu_38020_p3() {
    select_ln56_603_fu_38020_p3 = (!or_ln56_32_fu_31344_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_32_fu_31344_p2.read()[0].to_bool())? select_ln56_423_fu_36588_p3.read(): select_ln56_424_fu_36596_p3.read());
}

void dense_wrapper::thread_select_ln56_604_fu_38028_p3() {
    select_ln56_604_fu_38028_p3 = (!or_ln56_34_fu_31372_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_34_fu_31372_p2.read()[0].to_bool())? select_ln56_425_fu_36604_p3.read(): select_ln56_426_fu_36612_p3.read());
}

void dense_wrapper::thread_select_ln56_605_fu_38036_p3() {
    select_ln56_605_fu_38036_p3 = (!or_ln56_36_fu_31400_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_36_fu_31400_p2.read()[0].to_bool())? select_ln56_427_fu_36620_p3.read(): select_ln56_428_fu_36628_p3.read());
}

void dense_wrapper::thread_select_ln56_606_fu_38044_p3() {
    select_ln56_606_fu_38044_p3 = (!or_ln56_38_fu_31428_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_38_fu_31428_p2.read()[0].to_bool())? select_ln56_429_fu_36636_p3.read(): select_ln56_430_fu_36644_p3.read());
}

void dense_wrapper::thread_select_ln56_607_fu_38052_p3() {
    select_ln56_607_fu_38052_p3 = (!or_ln56_40_fu_31456_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_40_fu_31456_p2.read()[0].to_bool())? select_ln56_431_fu_36652_p3.read(): select_ln56_432_fu_36660_p3.read());
}

void dense_wrapper::thread_select_ln56_608_fu_38060_p3() {
    select_ln56_608_fu_38060_p3 = (!or_ln56_42_fu_31484_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_42_fu_31484_p2.read()[0].to_bool())? select_ln56_433_fu_36668_p3.read(): select_ln56_434_fu_36676_p3.read());
}

void dense_wrapper::thread_select_ln56_609_fu_38068_p3() {
    select_ln56_609_fu_38068_p3 = (!or_ln56_44_fu_31512_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_44_fu_31512_p2.read()[0].to_bool())? select_ln56_435_fu_36684_p3.read(): select_ln56_436_fu_36692_p3.read());
}

void dense_wrapper::thread_select_ln56_60_fu_31728_p3() {
    select_ln56_60_fu_31728_p3 = (!icmp_ln56_270_fu_30162_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_270_fu_30162_p2.read()[0].to_bool())? ap_phi_mux_data_662_V_read676_s_phi_fu_26762_p4.read(): ap_phi_mux_data_661_V_read675_s_phi_fu_26749_p4.read());
}

void dense_wrapper::thread_select_ln56_610_fu_38076_p3() {
    select_ln56_610_fu_38076_p3 = (!or_ln56_46_fu_31540_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_46_fu_31540_p2.read()[0].to_bool())? select_ln56_437_fu_36700_p3.read(): select_ln56_438_fu_36708_p3.read());
}

void dense_wrapper::thread_select_ln56_611_fu_38084_p3() {
    select_ln56_611_fu_38084_p3 = (!or_ln56_48_fu_31568_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_48_fu_31568_p2.read()[0].to_bool())? select_ln56_439_fu_36716_p3.read(): select_ln56_440_fu_36724_p3.read());
}

void dense_wrapper::thread_select_ln56_612_fu_38092_p3() {
    select_ln56_612_fu_38092_p3 = (!or_ln56_50_fu_31596_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_50_fu_31596_p2.read()[0].to_bool())? select_ln56_441_fu_36732_p3.read(): select_ln56_442_fu_36740_p3.read());
}

void dense_wrapper::thread_select_ln56_613_fu_38100_p3() {
    select_ln56_613_fu_38100_p3 = (!or_ln56_52_fu_31624_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_52_fu_31624_p2.read()[0].to_bool())? select_ln56_443_fu_36748_p3.read(): select_ln56_444_fu_36756_p3.read());
}

void dense_wrapper::thread_select_ln56_614_fu_38108_p3() {
    select_ln56_614_fu_38108_p3 = (!or_ln56_54_fu_31652_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_54_fu_31652_p2.read()[0].to_bool())? select_ln56_445_fu_36764_p3.read(): select_ln56_446_fu_36772_p3.read());
}

void dense_wrapper::thread_select_ln56_615_fu_38116_p3() {
    select_ln56_615_fu_38116_p3 = (!or_ln56_56_fu_31680_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_56_fu_31680_p2.read()[0].to_bool())? select_ln56_447_fu_36780_p3.read(): select_ln56_448_fu_36788_p3.read());
}

void dense_wrapper::thread_select_ln56_616_fu_38124_p3() {
    select_ln56_616_fu_38124_p3 = (!or_ln56_58_fu_31708_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_58_fu_31708_p2.read()[0].to_bool())? select_ln56_449_fu_36796_p3.read(): select_ln56_450_fu_36804_p3.read());
}

void dense_wrapper::thread_select_ln56_617_fu_38132_p3() {
    select_ln56_617_fu_38132_p3 = (!or_ln56_60_fu_31736_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_60_fu_31736_p2.read()[0].to_bool())? select_ln56_451_fu_36812_p3.read(): select_ln56_452_fu_36820_p3.read());
}

void dense_wrapper::thread_select_ln56_618_fu_38140_p3() {
    select_ln56_618_fu_38140_p3 = (!or_ln56_62_fu_31764_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_62_fu_31764_p2.read()[0].to_bool())? select_ln56_453_fu_36828_p3.read(): select_ln56_454_fu_36836_p3.read());
}

void dense_wrapper::thread_select_ln56_619_fu_38148_p3() {
    select_ln56_619_fu_38148_p3 = (!or_ln56_64_fu_31792_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_64_fu_31792_p2.read()[0].to_bool())? select_ln56_455_fu_36844_p3.read(): select_ln56_456_fu_36852_p3.read());
}

void dense_wrapper::thread_select_ln56_61_fu_31742_p3() {
    select_ln56_61_fu_31742_p3 = (!icmp_ln56_268_fu_30150_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_268_fu_30150_p2.read()[0].to_bool())? ap_phi_mux_data_660_V_read674_s_phi_fu_26736_p4.read(): ap_phi_mux_data_659_V_read673_s_phi_fu_26723_p4.read());
}

void dense_wrapper::thread_select_ln56_620_fu_38156_p3() {
    select_ln56_620_fu_38156_p3 = (!or_ln56_66_fu_31820_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_66_fu_31820_p2.read()[0].to_bool())? select_ln56_457_fu_36860_p3.read(): select_ln56_458_fu_36868_p3.read());
}

void dense_wrapper::thread_select_ln56_621_fu_38164_p3() {
    select_ln56_621_fu_38164_p3 = (!or_ln56_68_fu_31848_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_68_fu_31848_p2.read()[0].to_bool())? select_ln56_459_fu_36876_p3.read(): select_ln56_460_fu_36884_p3.read());
}

void dense_wrapper::thread_select_ln56_622_fu_38172_p3() {
    select_ln56_622_fu_38172_p3 = (!or_ln56_70_fu_31876_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_70_fu_31876_p2.read()[0].to_bool())? select_ln56_461_fu_36892_p3.read(): select_ln56_462_fu_36900_p3.read());
}

void dense_wrapper::thread_select_ln56_623_fu_38180_p3() {
    select_ln56_623_fu_38180_p3 = (!or_ln56_72_fu_31904_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_72_fu_31904_p2.read()[0].to_bool())? select_ln56_463_fu_36908_p3.read(): select_ln56_464_fu_36916_p3.read());
}

void dense_wrapper::thread_select_ln56_624_fu_38188_p3() {
    select_ln56_624_fu_38188_p3 = (!or_ln56_74_fu_31932_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_74_fu_31932_p2.read()[0].to_bool())? select_ln56_465_fu_36924_p3.read(): select_ln56_466_fu_36932_p3.read());
}

void dense_wrapper::thread_select_ln56_625_fu_38196_p3() {
    select_ln56_625_fu_38196_p3 = (!or_ln56_76_fu_31960_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_76_fu_31960_p2.read()[0].to_bool())? select_ln56_467_fu_36940_p3.read(): select_ln56_468_fu_36948_p3.read());
}

void dense_wrapper::thread_select_ln56_626_fu_38204_p3() {
    select_ln56_626_fu_38204_p3 = (!or_ln56_78_fu_31988_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_78_fu_31988_p2.read()[0].to_bool())? select_ln56_469_fu_36956_p3.read(): select_ln56_470_fu_36964_p3.read());
}

void dense_wrapper::thread_select_ln56_627_fu_38212_p3() {
    select_ln56_627_fu_38212_p3 = (!or_ln56_80_fu_32016_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_80_fu_32016_p2.read()[0].to_bool())? select_ln56_471_fu_36972_p3.read(): select_ln56_472_fu_36980_p3.read());
}

void dense_wrapper::thread_select_ln56_628_fu_38220_p3() {
    select_ln56_628_fu_38220_p3 = (!or_ln56_82_fu_32044_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_82_fu_32044_p2.read()[0].to_bool())? select_ln56_473_fu_36988_p3.read(): select_ln56_474_fu_36996_p3.read());
}

void dense_wrapper::thread_select_ln56_629_fu_38228_p3() {
    select_ln56_629_fu_38228_p3 = (!or_ln56_84_fu_32072_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_84_fu_32072_p2.read()[0].to_bool())? select_ln56_475_fu_37004_p3.read(): select_ln56_476_fu_37012_p3.read());
}

void dense_wrapper::thread_select_ln56_62_fu_31756_p3() {
    select_ln56_62_fu_31756_p3 = (!icmp_ln56_266_fu_30138_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_266_fu_30138_p2.read()[0].to_bool())? ap_phi_mux_data_658_V_read672_s_phi_fu_26710_p4.read(): ap_phi_mux_data_657_V_read671_s_phi_fu_26697_p4.read());
}

void dense_wrapper::thread_select_ln56_630_fu_38236_p3() {
    select_ln56_630_fu_38236_p3 = (!or_ln56_86_fu_32100_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_86_fu_32100_p2.read()[0].to_bool())? select_ln56_477_fu_37020_p3.read(): select_ln56_478_fu_37028_p3.read());
}

void dense_wrapper::thread_select_ln56_631_fu_38244_p3() {
    select_ln56_631_fu_38244_p3 = (!or_ln56_88_fu_32128_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_88_fu_32128_p2.read()[0].to_bool())? select_ln56_479_fu_37036_p3.read(): select_ln56_480_fu_37044_p3.read());
}

void dense_wrapper::thread_select_ln56_632_fu_38252_p3() {
    select_ln56_632_fu_38252_p3 = (!or_ln56_90_fu_32156_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_90_fu_32156_p2.read()[0].to_bool())? select_ln56_481_fu_37052_p3.read(): select_ln56_482_fu_37060_p3.read());
}

void dense_wrapper::thread_select_ln56_633_fu_38260_p3() {
    select_ln56_633_fu_38260_p3 = (!or_ln56_92_fu_32184_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_92_fu_32184_p2.read()[0].to_bool())? select_ln56_483_fu_37068_p3.read(): select_ln56_484_fu_37076_p3.read());
}

void dense_wrapper::thread_select_ln56_634_fu_38268_p3() {
    select_ln56_634_fu_38268_p3 = (!or_ln56_94_fu_32212_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_94_fu_32212_p2.read()[0].to_bool())? select_ln56_485_fu_37084_p3.read(): select_ln56_486_fu_37092_p3.read());
}

void dense_wrapper::thread_select_ln56_635_fu_38276_p3() {
    select_ln56_635_fu_38276_p3 = (!or_ln56_96_fu_32240_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_96_fu_32240_p2.read()[0].to_bool())? select_ln56_487_fu_37100_p3.read(): select_ln56_488_fu_37108_p3.read());
}

void dense_wrapper::thread_select_ln56_636_fu_38284_p3() {
    select_ln56_636_fu_38284_p3 = (!or_ln56_98_fu_32268_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_98_fu_32268_p2.read()[0].to_bool())? select_ln56_489_fu_37116_p3.read(): select_ln56_490_fu_37124_p3.read());
}

void dense_wrapper::thread_select_ln56_637_fu_38292_p3() {
    select_ln56_637_fu_38292_p3 = (!or_ln56_100_fu_32296_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_100_fu_32296_p2.read()[0].to_bool())? select_ln56_491_fu_37132_p3.read(): select_ln56_492_fu_37140_p3.read());
}

void dense_wrapper::thread_select_ln56_638_fu_38300_p3() {
    select_ln56_638_fu_38300_p3 = (!or_ln56_102_fu_32324_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_102_fu_32324_p2.read()[0].to_bool())? select_ln56_493_fu_37148_p3.read(): select_ln56_494_fu_37156_p3.read());
}

void dense_wrapper::thread_select_ln56_639_fu_38308_p3() {
    select_ln56_639_fu_38308_p3 = (!or_ln56_104_fu_32352_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_104_fu_32352_p2.read()[0].to_bool())? select_ln56_495_fu_37164_p3.read(): select_ln56_496_fu_37172_p3.read());
}

void dense_wrapper::thread_select_ln56_63_fu_31770_p3() {
    select_ln56_63_fu_31770_p3 = (!icmp_ln56_264_fu_30126_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_264_fu_30126_p2.read()[0].to_bool())? ap_phi_mux_data_656_V_read670_s_phi_fu_26684_p4.read(): ap_phi_mux_data_655_V_read669_s_phi_fu_26671_p4.read());
}

void dense_wrapper::thread_select_ln56_640_fu_38316_p3() {
    select_ln56_640_fu_38316_p3 = (!or_ln56_106_fu_32380_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_106_fu_32380_p2.read()[0].to_bool())? select_ln56_497_fu_37180_p3.read(): select_ln56_498_fu_37188_p3.read());
}

void dense_wrapper::thread_select_ln56_641_fu_38324_p3() {
    select_ln56_641_fu_38324_p3 = (!or_ln56_108_fu_32408_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_108_fu_32408_p2.read()[0].to_bool())? select_ln56_499_fu_37196_p3.read(): select_ln56_500_fu_37204_p3.read());
}

void dense_wrapper::thread_select_ln56_642_fu_38332_p3() {
    select_ln56_642_fu_38332_p3 = (!or_ln56_110_fu_32436_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_110_fu_32436_p2.read()[0].to_bool())? select_ln56_501_fu_37212_p3.read(): select_ln56_502_fu_37220_p3.read());
}

void dense_wrapper::thread_select_ln56_643_fu_38340_p3() {
    select_ln56_643_fu_38340_p3 = (!or_ln56_112_fu_32464_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_112_fu_32464_p2.read()[0].to_bool())? select_ln56_503_fu_37228_p3.read(): select_ln56_504_fu_37236_p3.read());
}

void dense_wrapper::thread_select_ln56_644_fu_38348_p3() {
    select_ln56_644_fu_38348_p3 = (!or_ln56_114_fu_32492_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_114_fu_32492_p2.read()[0].to_bool())? select_ln56_505_fu_37244_p3.read(): select_ln56_506_fu_37252_p3.read());
}

void dense_wrapper::thread_select_ln56_645_fu_38356_p3() {
    select_ln56_645_fu_38356_p3 = (!or_ln56_116_fu_32520_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_116_fu_32520_p2.read()[0].to_bool())? select_ln56_507_fu_37260_p3.read(): select_ln56_508_fu_37268_p3.read());
}

void dense_wrapper::thread_select_ln56_646_fu_38364_p3() {
    select_ln56_646_fu_38364_p3 = (!or_ln56_118_fu_32548_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_118_fu_32548_p2.read()[0].to_bool())? select_ln56_509_fu_37276_p3.read(): select_ln56_510_fu_37284_p3.read());
}

void dense_wrapper::thread_select_ln56_647_fu_38372_p3() {
    select_ln56_647_fu_38372_p3 = (!or_ln56_120_fu_32576_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_120_fu_32576_p2.read()[0].to_bool())? select_ln56_511_fu_37292_p3.read(): select_ln56_512_fu_37300_p3.read());
}

void dense_wrapper::thread_select_ln56_648_fu_38380_p3() {
    select_ln56_648_fu_38380_p3 = (!or_ln56_122_fu_32604_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_122_fu_32604_p2.read()[0].to_bool())? select_ln56_513_fu_37308_p3.read(): select_ln56_514_fu_37316_p3.read());
}

void dense_wrapper::thread_select_ln56_649_fu_38388_p3() {
    select_ln56_649_fu_38388_p3 = (!or_ln56_124_fu_32632_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_124_fu_32632_p2.read()[0].to_bool())? select_ln56_515_fu_37324_p3.read(): select_ln56_516_fu_37332_p3.read());
}

void dense_wrapper::thread_select_ln56_64_fu_31784_p3() {
    select_ln56_64_fu_31784_p3 = (!icmp_ln56_262_fu_30114_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_262_fu_30114_p2.read()[0].to_bool())? ap_phi_mux_data_654_V_read668_s_phi_fu_26658_p4.read(): ap_phi_mux_data_653_V_read667_s_phi_fu_26645_p4.read());
}

void dense_wrapper::thread_select_ln56_650_fu_38396_p3() {
    select_ln56_650_fu_38396_p3 = (!or_ln56_126_fu_32660_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_126_fu_32660_p2.read()[0].to_bool())? select_ln56_517_fu_37340_p3.read(): select_ln56_518_fu_37348_p3.read());
}

void dense_wrapper::thread_select_ln56_651_fu_38404_p3() {
    select_ln56_651_fu_38404_p3 = (!or_ln56_128_fu_32688_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_128_fu_32688_p2.read()[0].to_bool())? select_ln56_519_fu_37356_p3.read(): select_ln56_520_fu_37364_p3.read());
}

void dense_wrapper::thread_select_ln56_652_fu_38412_p3() {
    select_ln56_652_fu_38412_p3 = (!or_ln56_130_fu_32716_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_130_fu_32716_p2.read()[0].to_bool())? select_ln56_521_fu_37372_p3.read(): select_ln56_522_fu_37380_p3.read());
}

void dense_wrapper::thread_select_ln56_653_fu_38420_p3() {
    select_ln56_653_fu_38420_p3 = (!or_ln56_132_fu_32744_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_132_fu_32744_p2.read()[0].to_bool())? select_ln56_523_fu_37388_p3.read(): select_ln56_524_fu_37396_p3.read());
}

void dense_wrapper::thread_select_ln56_654_fu_38428_p3() {
    select_ln56_654_fu_38428_p3 = (!or_ln56_134_fu_32772_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_134_fu_32772_p2.read()[0].to_bool())? select_ln56_525_fu_37404_p3.read(): select_ln56_526_fu_37412_p3.read());
}

void dense_wrapper::thread_select_ln56_655_fu_38436_p3() {
    select_ln56_655_fu_38436_p3 = (!or_ln56_136_fu_32800_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_136_fu_32800_p2.read()[0].to_bool())? select_ln56_527_fu_37420_p3.read(): select_ln56_528_fu_37428_p3.read());
}

void dense_wrapper::thread_select_ln56_656_fu_38444_p3() {
    select_ln56_656_fu_38444_p3 = (!or_ln56_138_fu_32828_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_138_fu_32828_p2.read()[0].to_bool())? select_ln56_529_fu_37436_p3.read(): select_ln56_530_fu_37444_p3.read());
}

void dense_wrapper::thread_select_ln56_657_fu_38452_p3() {
    select_ln56_657_fu_38452_p3 = (!or_ln56_140_fu_32856_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_140_fu_32856_p2.read()[0].to_bool())? select_ln56_531_fu_37452_p3.read(): select_ln56_532_fu_37460_p3.read());
}

void dense_wrapper::thread_select_ln56_658_fu_38460_p3() {
    select_ln56_658_fu_38460_p3 = (!or_ln56_142_fu_32884_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_142_fu_32884_p2.read()[0].to_bool())? select_ln56_533_fu_37468_p3.read(): select_ln56_534_fu_37476_p3.read());
}

void dense_wrapper::thread_select_ln56_659_fu_38468_p3() {
    select_ln56_659_fu_38468_p3 = (!or_ln56_144_fu_32912_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_144_fu_32912_p2.read()[0].to_bool())? select_ln56_535_fu_37484_p3.read(): select_ln56_536_fu_37492_p3.read());
}

void dense_wrapper::thread_select_ln56_65_fu_31798_p3() {
    select_ln56_65_fu_31798_p3 = (!icmp_ln56_260_fu_30102_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_260_fu_30102_p2.read()[0].to_bool())? ap_phi_mux_data_652_V_read666_s_phi_fu_26632_p4.read(): ap_phi_mux_data_651_V_read665_s_phi_fu_26619_p4.read());
}

void dense_wrapper::thread_select_ln56_660_fu_38476_p3() {
    select_ln56_660_fu_38476_p3 = (!or_ln56_146_fu_32940_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_146_fu_32940_p2.read()[0].to_bool())? select_ln56_537_fu_37500_p3.read(): select_ln56_538_fu_37508_p3.read());
}

void dense_wrapper::thread_select_ln56_661_fu_38484_p3() {
    select_ln56_661_fu_38484_p3 = (!or_ln56_148_fu_32968_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_148_fu_32968_p2.read()[0].to_bool())? select_ln56_539_fu_37516_p3.read(): select_ln56_540_fu_37524_p3.read());
}

void dense_wrapper::thread_select_ln56_662_fu_38492_p3() {
    select_ln56_662_fu_38492_p3 = (!or_ln56_150_fu_32996_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_150_fu_32996_p2.read()[0].to_bool())? select_ln56_541_fu_37532_p3.read(): select_ln56_542_fu_37540_p3.read());
}

void dense_wrapper::thread_select_ln56_663_fu_38500_p3() {
    select_ln56_663_fu_38500_p3 = (!or_ln56_152_fu_33024_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_152_fu_33024_p2.read()[0].to_bool())? select_ln56_543_fu_37548_p3.read(): select_ln56_544_fu_37556_p3.read());
}

void dense_wrapper::thread_select_ln56_664_fu_38508_p3() {
    select_ln56_664_fu_38508_p3 = (!or_ln56_154_fu_33052_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_154_fu_33052_p2.read()[0].to_bool())? select_ln56_545_fu_37564_p3.read(): select_ln56_546_fu_37572_p3.read());
}

void dense_wrapper::thread_select_ln56_665_fu_38516_p3() {
    select_ln56_665_fu_38516_p3 = (!or_ln56_156_fu_33080_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_156_fu_33080_p2.read()[0].to_bool())? select_ln56_547_fu_37580_p3.read(): select_ln56_548_fu_37588_p3.read());
}

void dense_wrapper::thread_select_ln56_666_fu_38524_p3() {
    select_ln56_666_fu_38524_p3 = (!or_ln56_158_fu_33108_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_158_fu_33108_p2.read()[0].to_bool())? select_ln56_549_fu_37596_p3.read(): select_ln56_550_fu_37604_p3.read());
}

void dense_wrapper::thread_select_ln56_667_fu_38532_p3() {
    select_ln56_667_fu_38532_p3 = (!or_ln56_160_fu_33136_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_160_fu_33136_p2.read()[0].to_bool())? select_ln56_551_fu_37612_p3.read(): select_ln56_552_fu_37620_p3.read());
}

void dense_wrapper::thread_select_ln56_668_fu_38540_p3() {
    select_ln56_668_fu_38540_p3 = (!or_ln56_162_fu_33164_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_162_fu_33164_p2.read()[0].to_bool())? select_ln56_553_fu_37628_p3.read(): select_ln56_554_fu_37636_p3.read());
}

void dense_wrapper::thread_select_ln56_669_fu_38548_p3() {
    select_ln56_669_fu_38548_p3 = (!or_ln56_164_fu_33192_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_164_fu_33192_p2.read()[0].to_bool())? select_ln56_555_fu_37644_p3.read(): select_ln56_556_fu_37652_p3.read());
}

void dense_wrapper::thread_select_ln56_66_fu_31812_p3() {
    select_ln56_66_fu_31812_p3 = (!icmp_ln56_258_fu_30090_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_258_fu_30090_p2.read()[0].to_bool())? ap_phi_mux_data_650_V_read664_s_phi_fu_26606_p4.read(): ap_phi_mux_data_649_V_read663_s_phi_fu_26593_p4.read());
}

void dense_wrapper::thread_select_ln56_670_fu_38556_p3() {
    select_ln56_670_fu_38556_p3 = (!or_ln56_166_fu_33220_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_166_fu_33220_p2.read()[0].to_bool())? select_ln56_557_fu_37660_p3.read(): select_ln56_558_fu_37668_p3.read());
}

void dense_wrapper::thread_select_ln56_671_fu_38564_p3() {
    select_ln56_671_fu_38564_p3 = (!or_ln56_168_fu_33248_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_168_fu_33248_p2.read()[0].to_bool())? select_ln56_559_fu_37676_p3.read(): select_ln56_560_fu_37684_p3.read());
}

void dense_wrapper::thread_select_ln56_672_fu_38572_p3() {
    select_ln56_672_fu_38572_p3 = (!or_ln56_170_fu_33276_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_170_fu_33276_p2.read()[0].to_bool())? select_ln56_561_fu_37692_p3.read(): select_ln56_562_fu_37700_p3.read());
}

}

