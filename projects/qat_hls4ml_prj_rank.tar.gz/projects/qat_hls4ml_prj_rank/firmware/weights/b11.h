//Numpy array shape [13]
//Min -0.031250000000
//Max 0.062500000000
//Number of zeros 6

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[13];
#else
bias11_t b11[13] = {0.00000, 0.06250, 0.00000, 0.03125, 0.00000, 0.00000, 0.00000, 0.00000, -0.03125, 0.06250, -0.03125, -0.03125, -0.03125};
#endif

#endif
