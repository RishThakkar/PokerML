//Numpy array shape [4]
//Min -0.281250000000
//Max 0.093750000000
//Number of zeros 2

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
bias6_t b6[4];
#else
bias6_t b6[4] = {0.00000, -0.28125, 0.09375, 0.00000};
#endif

#endif
