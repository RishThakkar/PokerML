//Numpy array shape [8]
//Min -0.118949890137
//Max 0.102275505662
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {-0.1145340875, -0.0937227160, 0.1022755057, -0.1019569412, -0.1044956073, 0.0010679517, -0.1189498901, -0.1124757752};
#endif

#endif
