//Numpy array shape [8]
//Min -0.117685608566
//Max 0.233092561364
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {-0.1176856086, -0.0773136094, 0.0714334697, -0.0180388764, -0.1027638391, 0.2330925614, -0.0933561474, -0.0782331079};
#endif

#endif
