//Numpy array shape [4]
//Min 0.063909187913
//Max 0.176888883114
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {0.1768888831, 0.0639091879, 0.0857690573, 0.1479352415};
#endif

#endif
