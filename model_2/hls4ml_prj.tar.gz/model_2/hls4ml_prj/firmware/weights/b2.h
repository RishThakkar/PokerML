//Numpy array shape [4]
//Min -0.086148157716
//Max 0.151325032115
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {0.0644263625, 0.0895091370, 0.1513250321, -0.0861481577};
#endif

#endif
