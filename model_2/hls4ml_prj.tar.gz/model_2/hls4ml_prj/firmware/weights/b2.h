//Numpy array shape [4]
//Min -0.058862939477
//Max 0.134836137295
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
conv1_bias_t b2[4];
#else
conv1_bias_t b2[4] = {0.0788513869, 0.1348361373, 0.0804456249, -0.0588629395};
#endif

#endif
