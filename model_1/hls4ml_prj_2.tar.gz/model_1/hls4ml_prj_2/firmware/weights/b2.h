//Numpy array shape [4]
//Min 0.001331409439
//Max 0.121034696698
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {0.0360421091, 0.0013314094, 0.0473496616, 0.1210346967};
#endif

#endif
