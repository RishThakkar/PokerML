//Numpy array shape [8]
//Min -0.048781998456
//Max 0.087945021689
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {0.0168016013, -0.0159506034, -0.0198594090, -0.0487819985, 0.0417184755, -0.0010574654, 0.0879450217, 0.0503187329};
#endif

#endif
