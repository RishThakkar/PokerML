//Numpy array shape [4]
//Min 0.005976368673
//Max 0.148869574070
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {0.0383592360, 0.0059763687, 0.0618921742, 0.1488695741};
#endif

#endif
