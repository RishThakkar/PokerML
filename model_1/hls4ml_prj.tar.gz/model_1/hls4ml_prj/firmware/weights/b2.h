//Numpy array shape [4]
//Min -0.109079264104
//Max 0.214878082275
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {-0.1090792641, 0.1514767408, 0.2148780823, 0.0862615183};
#endif

#endif
