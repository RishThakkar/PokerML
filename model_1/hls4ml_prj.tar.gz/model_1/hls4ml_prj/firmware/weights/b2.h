//Numpy array shape [4]
//Min -0.185650482774
//Max 0.182820692658
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {-0.0695801303, 0.1828206927, 0.1360774040, -0.1856504828};
#endif

#endif
