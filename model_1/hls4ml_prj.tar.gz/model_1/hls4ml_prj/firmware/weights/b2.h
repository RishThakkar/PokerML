//Numpy array shape [4]
//Min -0.053532846272
//Max 0.136882930994
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {-0.0535328463, 0.1368829310, 0.1059934944, -0.0286172573};
#endif

#endif
