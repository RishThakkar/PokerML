//Numpy array shape [8]
//Min -0.134583532810
//Max 0.122914880514
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {-0.0925312042, -0.1345835328, -0.0287820287, -0.0481214896, 0.0683177263, 0.1229148805, -0.0406434089, -0.0678730533};
#endif

#endif
