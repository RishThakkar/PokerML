//Numpy array shape [8]
//Min -0.002600480104
//Max 0.272826522589
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {0.0244998001, -0.0016181129, 0.2728265226, 0.0152392546, 0.1297640949, 0.0248599201, -0.0026004801, 0.0516372249};
#endif

#endif
