//Numpy array shape [8]
//Min -0.048258148134
//Max 0.106112189591
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {0.0210747756, -0.0189456306, -0.0309381764, -0.0482581481, 0.0451606028, 0.0045003053, 0.1061121896, 0.0598101318};
#endif

#endif
