//Numpy array shape [8]
//Min -0.059262234718
//Max 0.090075708926
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {-0.0349296443, -0.0488343649, 0.0269691609, 0.0045227511, 0.0404530391, -0.0592622347, 0.0099622095, 0.0900757089};
#endif

#endif
