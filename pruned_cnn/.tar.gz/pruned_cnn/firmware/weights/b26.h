//Numpy array shape [10]
//Min -0.052268479019
//Max 0.080548837781
//Number of zeros 0

#ifndef B26_H_
#define B26_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b26[10];
#else
output_dense_bias_t b26[10] = {-0.0421250798, -0.0020485015, 0.0088895662, 0.0751619264, -0.0522684790, 0.0339110307, 0.0805488378, -0.0336558707, -0.0148231396, 0.0793913156};
#endif

#endif
