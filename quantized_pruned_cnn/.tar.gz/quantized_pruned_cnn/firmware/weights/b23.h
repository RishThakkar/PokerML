//Numpy array shape [10]
//Min -0.090050891042
//Max 0.133798032999
//Number of zeros 0

#ifndef B23_H_
#define B23_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b23[10];
#else
output_dense_bias_t b23[10] = {-0.0291783623, -0.0318061523, -0.0361037590, 0.0704882964, 0.0290045440, -0.0016560076, 0.1337980330, -0.0900508910, 0.0693566203, -0.0253325086};
#endif

#endif
