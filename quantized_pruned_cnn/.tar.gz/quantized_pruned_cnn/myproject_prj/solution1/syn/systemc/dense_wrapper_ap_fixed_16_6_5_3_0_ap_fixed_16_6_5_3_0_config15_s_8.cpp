#include "dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_281_fu_2206_p2() {
    sub_ln1118_281_fu_2206_p2 = (!sext_ln1118_157_fu_2190_p1.read().is_01() || !sext_ln1118_159_fu_2202_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_157_fu_2190_p1.read()) - sc_bigint<21>(sext_ln1118_159_fu_2202_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_282_fu_3875_p2() {
    sub_ln1118_282_fu_3875_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_fu_3843_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_fu_3843_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_283_fu_3915_p2() {
    sub_ln1118_283_fu_3915_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_158_fu_3849_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_158_fu_3849_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_284_fu_3921_p2() {
    sub_ln1118_284_fu_3921_p2 = (!sub_ln1118_283_fu_3915_p2.read().is_01() || !sext_ln1118_156_fu_3846_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_283_fu_3915_p2.read()) - sc_bigint<19>(sext_ln1118_156_fu_3846_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_285_fu_3948_p2() {
    sub_ln1118_285_fu_3948_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_160_fu_3944_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_160_fu_3944_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_286_fu_4003_p2() {
    sub_ln1118_286_fu_4003_p2 = (!sext_ln1118_165_fu_3984_p1.read().is_01() || !sext_ln1118_167_fu_3999_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_165_fu_3984_p1.read()) - sc_bigint<21>(sext_ln1118_167_fu_3999_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_287_fu_4019_p2() {
    sub_ln1118_287_fu_4019_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_166_fu_3995_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_166_fu_3995_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_288_fu_4035_p2() {
    sub_ln1118_288_fu_4035_p2 = (!sub_ln1118_287_fu_4019_p2.read().is_01() || !sext_ln1118_162_fu_3971_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_287_fu_4019_p2.read()) - sc_bigint<19>(sext_ln1118_162_fu_3971_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_289_fu_4051_p2() {
    sub_ln1118_289_fu_4051_p2 = (!sext_ln1118_166_fu_3995_p1.read().is_01() || !sext_ln1118_162_fu_3971_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_166_fu_3995_p1.read()) - sc_bigint<19>(sext_ln1118_162_fu_3971_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_290_fu_4086_p2() {
    sub_ln1118_290_fu_4086_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_161_fu_3968_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_161_fu_3968_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_291_fu_2352_p2() {
    sub_ln1118_291_fu_2352_p2 = (!sext_ln1118_170_fu_2348_p1.read().is_01() || !sext_ln1118_168_fu_2332_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_170_fu_2348_p1.read()) - sc_bigint<20>(sext_ln1118_168_fu_2332_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_292_fu_4128_p2() {
    sub_ln1118_292_fu_4128_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_171_fu_4124_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_171_fu_4124_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_293_fu_4134_p2() {
    sub_ln1118_293_fu_4134_p2 = (!sub_ln1118_292_fu_4128_p2.read().is_01() || !sext_ln708_107_fu_4105_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_292_fu_4128_p2.read()) - sc_bigint<19>(sext_ln708_107_fu_4105_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_294_fu_4153_p2() {
    sub_ln1118_294_fu_4153_p2 = (!sext_ln1118_171_fu_4124_p1.read().is_01() || !sext_ln708_107_fu_4105_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_171_fu_4124_p1.read()) - sc_bigint<19>(sext_ln708_107_fu_4105_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_295_fu_4200_p2() {
    sub_ln1118_295_fu_4200_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_106_fu_4102_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_106_fu_4102_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_296_fu_2420_p2() {
    sub_ln1118_296_fu_2420_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_169_fu_2344_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_169_fu_2344_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_297_fu_4282_p2() {
    sub_ln1118_297_fu_4282_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_175_fu_4232_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_175_fu_4232_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_298_fu_4302_p2() {
    sub_ln1118_298_fu_4302_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_176_fu_4242_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_176_fu_4242_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_299_fu_4329_p2() {
    sub_ln1118_299_fu_4329_p2 = (!sext_ln1118_177_fu_4325_p1.read().is_01() || !sext_ln1118_173_fu_4226_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_177_fu_4325_p1.read()) - sc_bigint<20>(sext_ln1118_173_fu_4226_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_300_fu_4366_p2() {
    sub_ln1118_300_fu_4366_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_181_fu_4362_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_181_fu_4362_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_301_fu_4397_p2() {
    sub_ln1118_301_fu_4397_p2 = (!sext_ln1118_182_reg_37349.read().is_01() || !sext_ln1118_184_fu_4393_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_182_reg_37349.read()) - sc_bigint<20>(sext_ln1118_184_fu_4393_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_302_fu_4416_p2() {
    sub_ln1118_302_fu_4416_p2 = (!sext_ln1118_181_fu_4362_p1.read().is_01() || !sext_ln1118_180_fu_4352_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_181_fu_4362_p1.read()) - sc_bigint<19>(sext_ln1118_180_fu_4352_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_303_fu_4458_p2() {
    sub_ln1118_303_fu_4458_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_179_fu_4349_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_179_fu_4349_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_304_fu_2492_p2() {
    sub_ln1118_304_fu_2492_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_182_fu_2468_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_182_fu_2468_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_305_fu_2498_p2() {
    sub_ln1118_305_fu_2498_p2 = (!sub_ln1118_304_fu_2492_p2.read().is_01() || !sext_ln1118_178_fu_2456_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_304_fu_2492_p2.read()) - sc_bigint<20>(sext_ln1118_178_fu_2456_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_306_fu_2524_p2() {
    sub_ln1118_306_fu_2524_p2 = (!sext_ln1118_182_fu_2468_p1.read().is_01() || !sext_ln1118_178_fu_2456_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_182_fu_2468_p1.read()) - sc_bigint<20>(sext_ln1118_178_fu_2456_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_307_fu_4503_p2() {
    sub_ln1118_307_fu_4503_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_183_fu_4389_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_183_fu_4389_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_308_fu_4535_p2() {
    sub_ln1118_308_fu_4535_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_187_fu_4531_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_187_fu_4531_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_309_fu_4571_p2() {
    sub_ln1118_309_fu_4571_p2 = (!sext_ln1118_188_fu_4567_p1.read().is_01() || !sext_ln1118_186_fu_4527_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_188_fu_4567_p1.read()) - sc_bigint<19>(sext_ln1118_186_fu_4527_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_310_fu_4599_p2() {
    sub_ln1118_310_fu_4599_p2 = (!sext_ln1118_189_fu_4595_p1.read().is_01() || !sext_ln1118_185_fu_4523_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_189_fu_4595_p1.read()) - sc_bigint<20>(sext_ln1118_185_fu_4523_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_311_fu_4631_p2() {
    sub_ln1118_311_fu_4631_p2 = (!sext_ln1118_189_fu_4595_p1.read().is_01() || !sext_ln1118_191_fu_4627_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_189_fu_4595_p1.read()) - sc_bigint<20>(sext_ln1118_191_fu_4627_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_312_fu_4651_p2() {
    sub_ln1118_312_fu_4651_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_190_fu_4623_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_190_fu_4623_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_313_fu_4727_p2() {
    sub_ln1118_313_fu_4727_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_196_fu_4723_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_196_fu_4723_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_314_fu_4743_p2() {
    sub_ln1118_314_fu_4743_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_194_fu_4687_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_194_fu_4687_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_315_fu_4763_p2() {
    sub_ln1118_315_fu_4763_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_193_fu_4675_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_193_fu_4675_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_316_fu_4799_p2() {
    sub_ln1118_316_fu_4799_p2 = (!sext_ln1118_197_fu_4795_p1.read().is_01() || !sext_ln1118_195_fu_4719_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_197_fu_4795_p1.read()) - sc_bigint<20>(sext_ln1118_195_fu_4719_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_317_fu_4851_p2() {
    sub_ln1118_317_fu_4851_p2 = (!sext_ln1118_195_fu_4719_p1.read().is_01() || !sext_ln1118_197_fu_4795_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_195_fu_4719_p1.read()) - sc_bigint<20>(sext_ln1118_197_fu_4795_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_318_fu_4905_p2() {
    sub_ln1118_318_fu_4905_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_200_fu_4901_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_200_fu_4901_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_319_fu_4945_p2() {
    sub_ln1118_319_fu_4945_p2 = (!sext_ln1118_202_fu_4941_p1.read().is_01() || !sext_ln1118_201_fu_4929_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_202_fu_4941_p1.read()) - sc_bigint<20>(sext_ln1118_201_fu_4929_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_320_fu_4965_p2() {
    sub_ln1118_320_fu_4965_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_198_fu_4885_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_198_fu_4885_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_321_fu_5045_p2() {
    sub_ln1118_321_fu_5045_p2 = (!sext_ln1118_200_fu_4901_p1.read().is_01() || !sext_ln1118_199_fu_4889_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_200_fu_4901_p1.read()) - sc_bigint<19>(sext_ln1118_199_fu_4889_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_322_fu_5115_p2() {
    sub_ln1118_322_fu_5115_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_123_fu_5079_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_123_fu_5079_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_323_fu_5147_p2() {
    sub_ln1118_323_fu_5147_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_203_fu_5143_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_203_fu_5143_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_324_fu_5179_p2() {
    sub_ln1118_324_fu_5179_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_204_fu_5175_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_204_fu_5175_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_325_fu_5247_p2() {
    sub_ln1118_325_fu_5247_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_208_fu_5223_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_208_fu_5223_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_326_fu_5291_p2() {
    sub_ln1118_326_fu_5291_p2 = (!sext_ln1118_211_fu_5287_p1.read().is_01() || !sext_ln1118_209_fu_5271_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_211_fu_5287_p1.read()) - sc_bigint<20>(sext_ln1118_209_fu_5271_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_327_fu_5307_p2() {
    sub_ln1118_327_fu_5307_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_206_fu_5207_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_206_fu_5207_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_328_fu_5327_p2() {
    sub_ln1118_328_fu_5327_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_210_fu_5283_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_210_fu_5283_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_329_fu_5343_p2() {
    sub_ln1118_329_fu_5343_p2 = (!sub_ln1118_325_fu_5247_p2.read().is_01() || !sext_ln1118_207_fu_5211_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_325_fu_5247_p2.read()) - sc_bigint<19>(sext_ln1118_207_fu_5211_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_330_fu_5369_p2() {
    sub_ln1118_330_fu_5369_p2 = (!sext_ln1118_209_fu_5271_p1.read().is_01() || !sext_ln1118_211_fu_5287_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_209_fu_5271_p1.read()) - sc_bigint<20>(sext_ln1118_211_fu_5287_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_331_fu_5403_p2() {
    sub_ln1118_331_fu_5403_p2 = (!sext_ln1118_208_fu_5223_p1.read().is_01() || !sext_ln1118_207_fu_5211_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_208_fu_5223_p1.read()) - sc_bigint<19>(sext_ln1118_207_fu_5211_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_332_fu_5423_p2() {
    sub_ln1118_332_fu_5423_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_209_fu_5271_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_209_fu_5271_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_333_fu_5443_p2() {
    sub_ln1118_333_fu_5443_p2 = (!sext_ln1118_209_fu_5271_p1.read().is_01() || !sext_ln1118_205_fu_5203_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_209_fu_5271_p1.read()) - sc_bigint<20>(sext_ln1118_205_fu_5203_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_334_fu_5503_p2() {
    sub_ln1118_334_fu_5503_p2 = (!sext_ln1118_215_fu_5499_p1.read().is_01() || !sext_ln1118_214_fu_5487_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_215_fu_5499_p1.read()) - sc_bigint<19>(sext_ln1118_214_fu_5487_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_335_fu_5523_p2() {
    sub_ln1118_335_fu_5523_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_215_fu_5499_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_215_fu_5499_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_336_fu_5557_p2() {
    sub_ln1118_336_fu_5557_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_213_fu_5483_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_213_fu_5483_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_337_fu_5577_p2() {
    sub_ln1118_337_fu_5577_p2 = (!sub_ln1118_335_fu_5523_p2.read().is_01() || !sext_ln1118_214_fu_5487_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_335_fu_5523_p2.read()) - sc_bigint<19>(sext_ln1118_214_fu_5487_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_338_fu_5609_p2() {
    sub_ln1118_338_fu_5609_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_217_fu_5605_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_217_fu_5605_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_339_fu_5671_p2() {
    sub_ln1118_339_fu_5671_p2 = (!sext_ln1118_216_fu_5601_p1.read().is_01() || !sext_ln1118_218_fu_5647_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_216_fu_5601_p1.read()) - sc_bigint<20>(sext_ln1118_218_fu_5647_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_340_fu_5701_p2() {
    sub_ln1118_340_fu_5701_p2 = (!sext_ln1118_218_fu_5647_p1.read().is_01() || !sext_ln1118_212_fu_5479_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_218_fu_5647_p1.read()) - sc_bigint<20>(sext_ln1118_212_fu_5479_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_341_fu_2552_p2() {
    sub_ln1118_341_fu_2552_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_221_fu_2548_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_221_fu_2548_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_342_fu_5743_p2() {
    sub_ln1118_342_fu_5743_p2 = (!sext_ln1118_221_reg_37380.read().is_01() || !sext_ln1118_220_fu_5740_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_221_reg_37380.read()) - sc_bigint<19>(sext_ln1118_220_fu_5740_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_343_fu_2596_p2() {
    sub_ln1118_343_fu_2596_p2 = (!sext_ln1118_224_fu_2592_p1.read().is_01() || !sext_ln1118_222_fu_2576_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_224_fu_2592_p1.read()) - sc_bigint<20>(sext_ln1118_222_fu_2576_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_344_fu_5764_p2() {
    sub_ln1118_344_fu_5764_p2 = (!sub_ln1118_341_reg_37387.read().is_01() || !sext_ln1118_220_fu_5740_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_341_reg_37387.read()) - sc_bigint<19>(sext_ln1118_220_fu_5740_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_345_fu_5789_p2() {
    sub_ln1118_345_fu_5789_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_219_fu_5737_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_219_fu_5737_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_346_fu_2642_p2() {
    sub_ln1118_346_fu_2642_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_223_fu_2588_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_223_fu_2588_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_347_fu_5922_p2() {
    sub_ln1118_347_fu_5922_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_227_fu_5918_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_227_fu_5918_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_348_fu_5950_p2() {
    sub_ln1118_348_fu_5950_p2 = (!sext_ln1118_228_fu_5946_p1.read().is_01() || !sext_ln1118_226_fu_5914_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_228_fu_5946_p1.read()) - sc_bigint<20>(sext_ln1118_226_fu_5914_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_349_fu_6002_p2() {
    sub_ln1118_349_fu_6002_p2 = (!sext_ln1118_230_fu_5998_p1.read().is_01() || !sext_ln1118_229_fu_5994_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_230_fu_5998_p1.read()) - sc_bigint<21>(sext_ln1118_229_fu_5994_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_350_fu_6032_p2() {
    sub_ln1118_350_fu_6032_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_137_fu_5850_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_137_fu_5850_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_351_fu_6055_p2() {
    sub_ln1118_351_fu_6055_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_233_fu_6052_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_233_fu_6052_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_352_fu_6090_p2() {
    sub_ln1118_352_fu_6090_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_236_fu_6086_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_236_fu_6086_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_353_fu_6109_p2() {
    sub_ln1118_353_fu_6109_p2 = (!sext_ln1118_235_fu_6082_p1.read().is_01() || !sext_ln1118_237_reg_37446.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_235_fu_6082_p1.read()) - sc_bigint<20>(sext_ln1118_237_reg_37446.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_354_fu_2714_p2() {
    sub_ln1118_354_fu_2714_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_237_fu_2700_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_237_fu_2700_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_355_fu_2720_p2() {
    sub_ln1118_355_fu_2720_p2 = (!sub_ln1118_354_fu_2714_p2.read().is_01() || !sext_ln1118_231_fu_2668_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_354_fu_2714_p2.read()) - sc_bigint<20>(sext_ln1118_231_fu_2668_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_356_fu_6217_p2() {
    sub_ln1118_356_fu_6217_p2 = (!sext_ln1118_238_fu_6201_p1.read().is_01() || !sext_ln1118_239_fu_6213_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_238_fu_6201_p1.read()) - sc_bigint<20>(sext_ln1118_239_fu_6213_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_357_fu_6249_p2() {
    sub_ln1118_357_fu_6249_p2 = (!sext_ln1118_240_fu_6245_p1.read().is_01() || !sext_ln708_145_fu_6171_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_240_fu_6245_p1.read()) - sc_bigint<19>(sext_ln708_145_fu_6171_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_358_fu_6295_p2() {
    sub_ln1118_358_fu_6295_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_240_fu_6245_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_240_fu_6245_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_359_fu_6325_p2() {
    sub_ln1118_359_fu_6325_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_144_fu_6167_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_144_fu_6167_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_360_fu_6435_p2() {
    sub_ln1118_360_fu_6435_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_245_fu_6431_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_245_fu_6431_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_361_fu_6467_p2() {
    sub_ln1118_361_fu_6467_p2 = (!sext_ln1118_244_fu_6381_p1.read().is_01() || !sext_ln1118_247_fu_6463_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_244_fu_6381_p1.read()) - sc_bigint<20>(sext_ln1118_247_fu_6463_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_362_fu_6503_p2() {
    sub_ln1118_362_fu_6503_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_242_fu_6365_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_242_fu_6365_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_363_fu_6545_p2() {
    sub_ln1118_363_fu_6545_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_246_fu_6459_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_246_fu_6459_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_364_fu_6561_p2() {
    sub_ln1118_364_fu_6561_p2 = (!sext_ln1118_245_fu_6431_p1.read().is_01() || !sext_ln1118_243_fu_6369_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_245_fu_6431_p1.read()) - sc_bigint<19>(sext_ln1118_243_fu_6369_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_365_fu_6641_p2() {
    sub_ln1118_365_fu_6641_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_248_fu_6637_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_248_fu_6637_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_366_fu_6647_p2() {
    sub_ln1118_366_fu_6647_p2 = (!sub_ln1118_365_fu_6641_p2.read().is_01() || !sext_ln708_152_fu_6607_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_365_fu_6641_p2.read()) - sc_bigint<19>(sext_ln708_152_fu_6607_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_367_fu_6679_p2() {
    sub_ln1118_367_fu_6679_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_250_fu_6675_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_250_fu_6675_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_368_fu_6707_p2() {
    sub_ln1118_368_fu_6707_p2 = (!sext_ln1118_251_fu_6703_p1.read().is_01() || !sext_ln1118_249_fu_6671_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_251_fu_6703_p1.read()) - sc_bigint<20>(sext_ln1118_249_fu_6671_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_369_fu_6737_p2() {
    sub_ln1118_369_fu_6737_p2 = (!sext_ln1118_248_fu_6637_p1.read().is_01() || !sext_ln708_152_fu_6607_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_248_fu_6637_p1.read()) - sc_bigint<19>(sext_ln708_152_fu_6607_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_370_fu_6807_p2() {
    sub_ln1118_370_fu_6807_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_157_fu_6785_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_157_fu_6785_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_371_fu_6885_p2() {
    sub_ln1118_371_fu_6885_p2 = (!sext_ln1118_252_fu_6849_p1.read().is_01() || !sext_ln1118_254_fu_6881_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_252_fu_6849_p1.read()) - sc_bigint<20>(sext_ln1118_254_fu_6881_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_372_fu_6917_p2() {
    sub_ln1118_372_fu_6917_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_255_fu_6913_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_255_fu_6913_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_373_fu_6923_p2() {
    sub_ln1118_373_fu_6923_p2 = (!sub_ln1118_372_fu_6917_p2.read().is_01() || !sext_ln708_156_fu_6781_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_372_fu_6917_p2.read()) - sc_bigint<19>(sext_ln708_156_fu_6781_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_374_fu_6939_p2() {
    sub_ln1118_374_fu_6939_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_253_fu_6877_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_253_fu_6877_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_375_fu_6969_p2() {
    sub_ln1118_375_fu_6969_p2 = (!sext_ln1118_255_fu_6913_p1.read().is_01() || !sext_ln708_156_fu_6781_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_255_fu_6913_p1.read()) - sc_bigint<19>(sext_ln708_156_fu_6781_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_376_fu_7087_p2() {
    sub_ln1118_376_fu_7087_p2 = (!sext_ln1118_260_fu_7067_p1.read().is_01() || !sext_ln1118_262_fu_7083_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_260_fu_7067_p1.read()) - sc_bigint<20>(sext_ln1118_262_fu_7083_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_377_fu_7107_p2() {
    sub_ln1118_377_fu_7107_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_257_fu_7023_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_257_fu_7023_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_378_fu_7127_p2() {
    sub_ln1118_378_fu_7127_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_259_fu_7039_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_259_fu_7039_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_379_fu_7161_p2() {
    sub_ln1118_379_fu_7161_p2 = (!sub_ln1118_378_fu_7127_p2.read().is_01() || !sext_ln1118_258_fu_7027_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_378_fu_7127_p2.read()) - sc_bigint<19>(sext_ln1118_258_fu_7027_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_380_fu_7191_p2() {
    sub_ln1118_380_fu_7191_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_261_fu_7079_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_261_fu_7079_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_381_fu_7289_p2() {
    sub_ln1118_381_fu_7289_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_263_fu_7285_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_263_fu_7285_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_382_fu_7323_p2() {
    sub_ln1118_382_fu_7323_p2 = (!sub_ln1118_381_fu_7289_p2.read().is_01() || !sext_ln708_165_fu_7255_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_381_fu_7289_p2.read()) - sc_bigint<19>(sext_ln708_165_fu_7255_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_383_fu_7367_p2() {
    sub_ln1118_383_fu_7367_p2 = (!sext_ln1118_264_fu_7347_p1.read().is_01() || !sext_ln708_164_fu_7251_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_264_fu_7347_p1.read()) - sc_bigint<20>(sext_ln708_164_fu_7251_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_384_fu_7387_p2() {
    sub_ln1118_384_fu_7387_p2 = (!sext_ln1118_263_fu_7285_p1.read().is_01() || !sext_ln708_165_fu_7255_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_263_fu_7285_p1.read()) - sc_bigint<19>(sext_ln708_165_fu_7255_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_385_fu_7403_p2() {
    sub_ln1118_385_fu_7403_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_163_fu_7247_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_163_fu_7247_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_386_fu_7439_p2() {
    sub_ln1118_386_fu_7439_p2 = (!sext_ln1118_266_fu_7435_p1.read().is_01() || !sext_ln1118_264_fu_7347_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_266_fu_7435_p1.read()) - sc_bigint<20>(sext_ln1118_264_fu_7347_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_387_fu_7459_p2() {
    sub_ln1118_387_fu_7459_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_265_fu_7431_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_265_fu_7431_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_388_fu_7553_p2() {
    sub_ln1118_388_fu_7553_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_268_fu_7491_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_268_fu_7491_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_389_fu_7585_p2() {
    sub_ln1118_389_fu_7585_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_270_fu_7581_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_270_fu_7581_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_390_fu_7605_p2() {
    sub_ln1118_390_fu_7605_p2 = (!sub_ln1118_388_fu_7553_p2.read().is_01() || !sext_ln1118_267_fu_7479_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_388_fu_7553_p2.read()) - sc_bigint<19>(sext_ln1118_267_fu_7479_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_391_fu_7633_p2() {
    sub_ln1118_391_fu_7633_p2 = (!sext_ln1118_269_fu_7577_p1.read().is_01() || !sext_ln1118_271_fu_7629_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_269_fu_7577_p1.read()) - sc_bigint<20>(sext_ln1118_271_fu_7629_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_392_fu_7693_p2() {
    sub_ln1118_392_fu_7693_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_274_fu_7661_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_274_fu_7661_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_393_fu_7733_p2() {
    sub_ln1118_393_fu_7733_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_278_fu_7729_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_278_fu_7729_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_394_fu_7765_p2() {
    sub_ln1118_394_fu_7765_p2 = (!sext_ln1118_279_fu_7761_p1.read().is_01() || !sext_ln1118_272_fu_7653_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_279_fu_7761_p1.read()) - sc_bigint<20>(sext_ln1118_272_fu_7653_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_395_fu_7847_p2() {
    sub_ln1118_395_fu_7847_p2 = (!sext_ln1118_279_fu_7761_p1.read().is_01() || !sext_ln1118_277_fu_7725_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_279_fu_7761_p1.read()) - sc_bigint<20>(sext_ln1118_277_fu_7725_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_396_fu_7867_p2() {
    sub_ln1118_396_fu_7867_p2 = (!sext_ln1118_275_fu_7673_p1.read().is_01() || !sext_ln1118_273_fu_7657_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_275_fu_7673_p1.read()) - sc_bigint<19>(sext_ln1118_273_fu_7657_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_397_fu_7887_p2() {
    sub_ln1118_397_fu_7887_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_275_fu_7673_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_275_fu_7673_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_398_fu_7919_p2() {
    sub_ln1118_398_fu_7919_p2 = (!sext_ln1118_276_fu_7721_p1.read().is_01() || !sext_ln1118_280_fu_7915_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_276_fu_7721_p1.read()) - sc_bigint<21>(sext_ln1118_280_fu_7915_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_399_fu_7959_p2() {
    sub_ln1118_399_fu_7959_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_284_fu_7955_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_284_fu_7955_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_400_fu_7965_p2() {
    sub_ln1118_400_fu_7965_p2 = (!sub_ln1118_399_fu_7959_p2.read().is_01() || !sext_ln1118_283_fu_7943_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_399_fu_7959_p2.read()) - sc_bigint<19>(sext_ln1118_283_fu_7943_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_401_fu_7993_p2() {
    sub_ln1118_401_fu_7993_p2 = (!sext_ln1118_285_fu_7989_p1.read().is_01() || !sext_ln1118_282_fu_7939_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_285_fu_7989_p1.read()) - sc_bigint<20>(sext_ln1118_282_fu_7939_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_402_fu_8055_p2() {
    sub_ln1118_402_fu_8055_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_286_fu_8051_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_286_fu_8051_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_403_fu_8089_p2() {
    sub_ln1118_403_fu_8089_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_281_fu_7935_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_281_fu_7935_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_404_fu_8109_p2() {
    sub_ln1118_404_fu_8109_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_285_fu_7989_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_285_fu_7989_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_405_fu_8115_p2() {
    sub_ln1118_405_fu_8115_p2 = (!sub_ln1118_404_fu_8109_p2.read().is_01() || !sext_ln1118_282_fu_7939_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_404_fu_8109_p2.read()) - sc_bigint<20>(sext_ln1118_282_fu_7939_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_406_fu_8131_p2() {
    sub_ln1118_406_fu_8131_p2 = (!sext_ln1118_284_fu_7955_p1.read().is_01() || !sext_ln1118_283_fu_7943_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_284_fu_7955_p1.read()) - sc_bigint<19>(sext_ln1118_283_fu_7943_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_407_fu_8189_p2() {
    sub_ln1118_407_fu_8189_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_290_fu_8185_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_290_fu_8185_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_408_fu_8195_p2() {
    sub_ln1118_408_fu_8195_p2 = (!sub_ln1118_407_fu_8189_p2.read().is_01() || !sext_ln1118_289_fu_8173_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_407_fu_8189_p2.read()) - sc_bigint<19>(sext_ln1118_289_fu_8173_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_409_fu_8247_p2() {
    sub_ln1118_409_fu_8247_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_292_fu_8243_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_292_fu_8243_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_410_fu_8279_p2() {
    sub_ln1118_410_fu_8279_p2 = (!sext_ln1118_293_fu_8275_p1.read().is_01() || !sext_ln1118_287_fu_8165_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_293_fu_8275_p1.read()) - sc_bigint<20>(sext_ln1118_287_fu_8165_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_411_fu_8299_p2() {
    sub_ln1118_411_fu_8299_p2 = (!sext_ln1118_293_fu_8275_p1.read().is_01() || !sext_ln1118_291_fu_8239_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_293_fu_8275_p1.read()) - sc_bigint<20>(sext_ln1118_291_fu_8239_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_412_fu_8325_p2() {
    sub_ln1118_412_fu_8325_p2 = (!sext_ln1118_290_fu_8185_p1.read().is_01() || !sext_ln1118_289_fu_8173_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_290_fu_8185_p1.read()) - sc_bigint<19>(sext_ln1118_289_fu_8173_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_413_fu_8341_p2() {
    sub_ln1118_413_fu_8341_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_288_fu_8169_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_288_fu_8169_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_414_fu_2753_p2() {
    sub_ln1118_414_fu_2753_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_298_fu_2749_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_298_fu_2749_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_415_fu_2774_p2() {
    sub_ln1118_415_fu_2774_p2 = (!sub_ln1118_414_fu_2753_p2.read().is_01() || !sext_ln1118_300_fu_2770_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_414_fu_2753_p2.read()) - sc_bigint<20>(sext_ln1118_300_fu_2770_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_416_fu_2790_p2() {
    sub_ln1118_416_fu_2790_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_296_fu_2739_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_296_fu_2739_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_417_fu_2806_p2() {
    sub_ln1118_417_fu_2806_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_299_fu_2766_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_299_fu_2766_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_418_fu_8409_p2() {
    sub_ln1118_418_fu_8409_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_301_fu_8405_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_301_fu_8405_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_419_fu_2848_p2() {
    sub_ln1118_419_fu_2848_p2 = (!sext_ln1118_298_fu_2749_p1.read().is_01() || !sext_ln1118_300_fu_2770_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_298_fu_2749_p1.read()) - sc_bigint<20>(sext_ln1118_300_fu_2770_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_420_fu_8434_p2() {
    sub_ln1118_420_fu_8434_p2 = (!sext_ln1118_301_fu_8405_p1.read().is_01() || !sext_ln1118_297_fu_8389_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_301_fu_8405_p1.read()) - sc_bigint<19>(sext_ln1118_297_fu_8389_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_421_fu_8514_p2() {
    sub_ln1118_421_fu_8514_p2 = (!sext_ln1118_307_fu_8510_p1.read().is_01() || !sext_ln1118_305_fu_8494_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_307_fu_8510_p1.read()) - sc_bigint<20>(sext_ln1118_305_fu_8494_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_422_fu_8546_p2() {
    sub_ln1118_422_fu_8546_p2 = (!sext_ln1118_308_fu_8542_p1.read().is_01() || !sext_ln1118_304_fu_8482_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_308_fu_8542_p1.read()) - sc_bigint<19>(sext_ln1118_304_fu_8482_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_423_fu_8562_p2() {
    sub_ln1118_423_fu_8562_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_308_fu_8542_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_308_fu_8542_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_424_fu_8582_p2() {
    sub_ln1118_424_fu_8582_p2 = (!sub_ln1118_423_fu_8562_p2.read().is_01() || !sext_ln1118_304_fu_8482_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_423_fu_8562_p2.read()) - sc_bigint<19>(sext_ln1118_304_fu_8482_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_425_fu_8598_p2() {
    sub_ln1118_425_fu_8598_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_305_fu_8494_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_305_fu_8494_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_426_fu_8604_p2() {
    sub_ln1118_426_fu_8604_p2 = (!sub_ln1118_425_fu_8598_p2.read().is_01() || !sext_ln1118_307_fu_8510_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_425_fu_8598_p2.read()) - sc_bigint<20>(sext_ln1118_307_fu_8510_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_427_fu_8638_p2() {
    sub_ln1118_427_fu_8638_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_303_fu_8478_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_303_fu_8478_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_428_fu_8658_p2() {
    sub_ln1118_428_fu_8658_p2 = (!sext_ln1118_305_fu_8494_p1.read().is_01() || !sext_ln1118_302_fu_8474_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_305_fu_8494_p1.read()) - sc_bigint<20>(sext_ln1118_302_fu_8474_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_429_fu_8712_p2() {
    sub_ln1118_429_fu_8712_p2 = (!sext_ln1118_305_fu_8494_p1.read().is_01() || !sext_ln1118_307_fu_8510_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_305_fu_8494_p1.read()) - sc_bigint<20>(sext_ln1118_307_fu_8510_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_430_fu_8750_p2() {
    sub_ln1118_430_fu_8750_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_306_fu_8506_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_306_fu_8506_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_431_fu_8787_p2() {
    sub_ln1118_431_fu_8787_p2 = (!sext_ln1118_312_fu_8783_p1.read().is_01() || !sext_ln1118_311_fu_8773_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_312_fu_8783_p1.read()) - sc_bigint<19>(sext_ln1118_311_fu_8773_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_432_fu_2890_p2() {
    sub_ln1118_432_fu_2890_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_313_fu_2886_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_313_fu_2886_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_433_fu_2896_p2() {
    sub_ln1118_433_fu_2896_p2 = (!sub_ln1118_432_fu_2890_p2.read().is_01() || !sext_ln1118_310_fu_2874_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_432_fu_2890_p2.read()) - sc_bigint<20>(sext_ln1118_310_fu_2874_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_434_fu_8817_p2() {
    sub_ln1118_434_fu_8817_p2 = (!sext_ln1118_314_fu_8813_p1.read().is_01() || !sext_ln1118_313_reg_37504.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_314_fu_8813_p1.read()) - sc_bigint<20>(sext_ln1118_313_reg_37504.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_435_fu_8836_p2() {
    sub_ln1118_435_fu_8836_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_309_fu_8770_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_309_fu_8770_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_436_fu_8856_p2() {
    sub_ln1118_436_fu_8856_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_312_fu_8783_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_312_fu_8783_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_437_fu_8872_p2() {
    sub_ln1118_437_fu_8872_p2 = (!sext_ln1118_313_reg_37504.read().is_01() || !sext_ln1118_310_reg_37498.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_313_reg_37504.read()) - sc_bigint<20>(sext_ln1118_310_reg_37498.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_438_fu_8902_p2() {
    sub_ln1118_438_fu_8902_p2 = (!sext_ln1118_313_reg_37504.read().is_01() || !sext_ln1118_314_fu_8813_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_313_reg_37504.read()) - sc_bigint<20>(sext_ln1118_314_fu_8813_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_439_fu_9009_p2() {
    sub_ln1118_439_fu_9009_p2 = (!sext_ln1118_317_fu_8971_p1.read().is_01() || !sext_ln1118_316_fu_8959_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_317_fu_8971_p1.read()) - sc_bigint<19>(sext_ln1118_316_fu_8959_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_440_fu_9025_p2() {
    sub_ln1118_440_fu_9025_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_315_fu_8955_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_315_fu_8955_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_441_fu_9069_p2() {
    sub_ln1118_441_fu_9069_p2 = (!sext_ln1118_318_fu_9049_p1.read().is_01() || !sext_ln1118_320_fu_9065_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_318_fu_9049_p1.read()) - sc_bigint<20>(sext_ln1118_320_fu_9065_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_442_fu_9099_p2() {
    sub_ln1118_442_fu_9099_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_317_fu_8971_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_317_fu_8971_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_443_fu_9105_p2() {
    sub_ln1118_443_fu_9105_p2 = (!sub_ln1118_442_fu_9099_p2.read().is_01() || !sext_ln1118_316_fu_8959_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_442_fu_9099_p2.read()) - sc_bigint<19>(sext_ln1118_316_fu_8959_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_444_fu_9141_p2() {
    sub_ln1118_444_fu_9141_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_319_fu_9061_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_319_fu_9061_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_445_fu_9192_p2() {
    sub_ln1118_445_fu_9192_p2 = (!sext_ln1118_324_reg_37522.read().is_01() || !sext_ln1118_326_fu_9188_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_324_reg_37522.read()) - sc_bigint<20>(sext_ln1118_326_fu_9188_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_446_fu_9223_p2() {
    sub_ln1118_446_fu_9223_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_325_fu_9184_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_325_fu_9184_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_447_fu_9239_p2() {
    sub_ln1118_447_fu_9239_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_322_fu_9171_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_322_fu_9171_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_448_fu_2968_p2() {
    sub_ln1118_448_fu_2968_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_324_fu_2934_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_324_fu_2934_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_449_fu_2974_p2() {
    sub_ln1118_449_fu_2974_p2 = (!sub_ln1118_448_fu_2968_p2.read().is_01() || !sext_ln1118_321_fu_2922_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_448_fu_2968_p2.read()) - sc_bigint<20>(sext_ln1118_321_fu_2922_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_450_fu_9308_p2() {
    sub_ln1118_450_fu_9308_p2 = (!sext_ln1118_326_fu_9188_p1.read().is_01() || !sext_ln1118_324_reg_37522.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_326_fu_9188_p1.read()) - sc_bigint<20>(sext_ln1118_324_reg_37522.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_451_fu_9327_p2() {
    sub_ln1118_451_fu_9327_p2 = (!sext_ln1118_327_fu_9269_p1.read().is_01() || !sext_ln1118_323_fu_9174_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_327_fu_9269_p1.read()) - sc_bigint<19>(sext_ln1118_323_fu_9174_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_452_fu_3036_p2() {
    sub_ln1118_452_fu_3036_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_329_fu_3032_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_329_fu_3032_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_453_fu_3064_p2() {
    sub_ln1118_453_fu_3064_p2 = (!sext_ln1118_330_fu_3060_p1.read().is_01() || !sext_ln1118_328_fu_3028_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_330_fu_3060_p1.read()) - sc_bigint<20>(sext_ln1118_328_fu_3028_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_454_fu_9392_p2() {
    sub_ln1118_454_fu_9392_p2 = (!sext_ln1118_334_fu_9372_p1.read().is_01() || !sext_ln1118_333_fu_9360_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_334_fu_9372_p1.read()) - sc_bigint<19>(sext_ln1118_333_fu_9360_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_455_fu_9412_p2() {
    sub_ln1118_455_fu_9412_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_332_fu_9356_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_332_fu_9356_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_456_fu_9476_p2() {
    sub_ln1118_456_fu_9476_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_336_fu_9472_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_336_fu_9472_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_457_fu_9528_p2() {
    sub_ln1118_457_fu_9528_p2 = (!sext_ln1118_337_fu_9524_p1.read().is_01() || !sext_ln1118_335_fu_9468_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_337_fu_9524_p1.read()) - sc_bigint<20>(sext_ln1118_335_fu_9468_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_458_fu_9564_p2() {
    sub_ln1118_458_fu_9564_p2 = (!sext_ln1118_340_fu_9560_p1.read().is_01() || !sext_ln1118_339_fu_9548_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_340_fu_9560_p1.read()) - sc_bigint<19>(sext_ln1118_339_fu_9548_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_459_fu_9600_p2() {
    sub_ln1118_459_fu_9600_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_342_fu_9596_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_342_fu_9596_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_460_fu_9616_p2() {
    sub_ln1118_460_fu_9616_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_338_fu_9544_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_338_fu_9544_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_461_fu_9654_p2() {
    sub_ln1118_461_fu_9654_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_340_fu_9560_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_340_fu_9560_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_462_fu_9714_p2() {
    sub_ln1118_462_fu_9714_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_343_fu_9710_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_343_fu_9710_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_463_fu_9720_p2() {
    sub_ln1118_463_fu_9720_p2 = (!sub_ln1118_462_fu_9714_p2.read().is_01() || !sext_ln1118_341_fu_9592_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_462_fu_9714_p2.read()) - sc_bigint<20>(sext_ln1118_341_fu_9592_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_464_fu_9736_p2() {
    sub_ln1118_464_fu_9736_p2 = (!sext_ln1118_343_fu_9710_p1.read().is_01() || !sext_ln1118_341_fu_9592_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_343_fu_9710_p1.read()) - sc_bigint<20>(sext_ln1118_341_fu_9592_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_465_fu_9762_p2() {
    sub_ln1118_465_fu_9762_p2 = (!sub_ln1118_461_fu_9654_p2.read().is_01() || !sext_ln1118_339_fu_9548_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_461_fu_9654_p2.read()) - sc_bigint<19>(sext_ln1118_339_fu_9548_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_466_fu_9812_p2() {
    sub_ln1118_466_fu_9812_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_344_fu_9808_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_344_fu_9808_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_467_fu_9818_p2() {
    sub_ln1118_467_fu_9818_p2 = (!sub_ln1118_466_fu_9812_p2.read().is_01() || !sext_ln708_202_fu_9782_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_466_fu_9812_p2.read()) - sc_bigint<19>(sext_ln708_202_fu_9782_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_468_fu_9834_p2() {
    sub_ln1118_468_fu_9834_p2 = (!sext_ln1118_344_fu_9808_p1.read().is_01() || !sext_ln708_202_fu_9782_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_344_fu_9808_p1.read()) - sc_bigint<19>(sext_ln708_202_fu_9782_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_469_fu_9870_p2() {
    sub_ln1118_469_fu_9870_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_201_fu_9778_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_201_fu_9778_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_470_fu_9908_p2() {
    sub_ln1118_470_fu_9908_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_345_fu_9904_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_345_fu_9904_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_471_fu_9964_p2() {
    sub_ln1118_471_fu_9964_p2 = (!sext_ln1118_348_fu_9944_p1.read().is_01() || !sext_ln1118_350_fu_9960_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_348_fu_9944_p1.read()) - sc_bigint<20>(sext_ln1118_350_fu_9960_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_472_fu_9980_p2() {
    sub_ln1118_472_fu_9980_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_349_fu_9956_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_349_fu_9956_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_473_fu_10048_p2() {
    sub_ln1118_473_fu_10048_p2 = (!sext_ln1118_351_fu_10004_p1.read().is_01() || !sext_ln1118_347_fu_9932_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_351_fu_10004_p1.read()) - sc_bigint<19>(sext_ln1118_347_fu_9932_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_474_fu_10068_p2() {
    sub_ln1118_474_fu_10068_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_351_fu_10004_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_351_fu_10004_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_475_fu_10074_p2() {
    sub_ln1118_475_fu_10074_p2 = (!sub_ln1118_474_fu_10068_p2.read().is_01() || !sext_ln1118_347_fu_9932_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_474_fu_10068_p2.read()) - sc_bigint<19>(sext_ln1118_347_fu_9932_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_476_fu_10100_p2() {
    sub_ln1118_476_fu_10100_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_346_fu_9928_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_346_fu_9928_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_477_fu_10125_p2() {
    sub_ln1118_477_fu_10125_p2 = (!sext_ln1118_355_reg_37579.read().is_01() || !sext_ln1118_353_fu_10119_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_355_reg_37579.read()) - sc_bigint<20>(sext_ln1118_353_fu_10119_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_478_fu_10176_p2() {
    sub_ln1118_478_fu_10176_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_352_fu_10116_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_352_fu_10116_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_479_fu_3176_p2() {
    sub_ln1118_479_fu_3176_p2 = (!sext_ln1118_355_fu_3126_p1.read().is_01() || !sext_ln1118_358_fu_3172_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_355_fu_3126_p1.read()) - sc_bigint<20>(sext_ln1118_358_fu_3172_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_480_fu_10215_p2() {
    sub_ln1118_480_fu_10215_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_355_reg_37579.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_355_reg_37579.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_481_fu_3192_p2() {
    sub_ln1118_481_fu_3192_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_357_fu_3168_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_357_fu_3168_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_482_fu_10240_p2() {
    sub_ln1118_482_fu_10240_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_356_fu_10147_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_356_fu_10147_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_483_fu_10246_p2() {
    sub_ln1118_483_fu_10246_p2 = (!sub_ln1118_482_fu_10240_p2.read().is_01() || !sext_ln1118_354_fu_10122_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_482_fu_10240_p2.read()) - sc_bigint<19>(sext_ln1118_354_fu_10122_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_484_fu_10355_p2() {
    sub_ln1118_484_fu_10355_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_363_fu_10351_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_363_fu_10351_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_485_fu_10383_p2() {
    sub_ln1118_485_fu_10383_p2 = (!sext_ln1118_364_fu_10379_p1.read().is_01() || !sext_ln1118_362_fu_10347_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_364_fu_10379_p1.read()) - sc_bigint<20>(sext_ln1118_362_fu_10347_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_486_fu_10399_p2() {
    sub_ln1118_486_fu_10399_p2 = (!sext_ln1118_361_fu_10315_p1.read().is_01() || !sext_ln1118_359_fu_10299_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_361_fu_10315_p1.read()) - sc_bigint<19>(sext_ln1118_359_fu_10299_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_487_fu_10463_p2() {
    sub_ln1118_487_fu_10463_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_360_fu_10303_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_360_fu_10303_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_488_fu_10555_p2() {
    sub_ln1118_488_fu_10555_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_366_fu_10487_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_366_fu_10487_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_489_fu_10599_p2() {
    sub_ln1118_489_fu_10599_p2 = (!sext_ln1118_368_fu_10583_p1.read().is_01() || !sext_ln1118_369_fu_10595_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_368_fu_10583_p1.read()) - sc_bigint<20>(sext_ln1118_369_fu_10595_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_490_fu_10619_p2() {
    sub_ln1118_490_fu_10619_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_367_fu_10499_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_367_fu_10499_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_491_fu_10625_p2() {
    sub_ln1118_491_fu_10625_p2 = (!sub_ln1118_490_fu_10619_p2.read().is_01() || !sext_ln1118_365_fu_10483_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_490_fu_10619_p2.read()) - sc_bigint<19>(sext_ln1118_365_fu_10483_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_492_fu_10655_p2() {
    sub_ln1118_492_fu_10655_p2 = (!sext_ln1118_367_fu_10499_p1.read().is_01() || !sext_ln1118_365_fu_10483_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_367_fu_10499_p1.read()) - sc_bigint<19>(sext_ln1118_365_fu_10483_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_493_fu_10765_p2() {
    sub_ln1118_493_fu_10765_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_372_fu_10703_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_372_fu_10703_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_494_fu_10813_p2() {
    sub_ln1118_494_fu_10813_p2 = (!sext_ln1118_376_fu_10809_p1.read().is_01() || !sext_ln1118_374_fu_10793_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_376_fu_10809_p1.read()) - sc_bigint<20>(sext_ln1118_374_fu_10793_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_495_fu_10833_p2() {
    sub_ln1118_495_fu_10833_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_373_fu_10715_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_373_fu_10715_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_496_fu_10839_p2() {
    sub_ln1118_496_fu_10839_p2 = (!sub_ln1118_495_fu_10833_p2.read().is_01() || !sext_ln1118_371_fu_10699_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_495_fu_10833_p2.read()) - sc_bigint<19>(sext_ln1118_371_fu_10699_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_497_fu_10855_p2() {
    sub_ln1118_497_fu_10855_p2 = (!sext_ln1118_374_fu_10793_p1.read().is_01() || !sext_ln1118_376_fu_10809_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_374_fu_10793_p1.read()) - sc_bigint<20>(sext_ln1118_376_fu_10809_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_498_fu_10875_p2() {
    sub_ln1118_498_fu_10875_p2 = (!sext_ln1118_373_fu_10715_p1.read().is_01() || !sext_ln1118_371_fu_10699_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_373_fu_10715_p1.read()) - sc_bigint<19>(sext_ln1118_371_fu_10699_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_499_fu_10905_p2() {
    sub_ln1118_499_fu_10905_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_375_fu_10805_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_375_fu_10805_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_500_fu_10931_p2() {
    sub_ln1118_500_fu_10931_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_374_fu_10793_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_374_fu_10793_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_501_fu_10947_p2() {
    sub_ln1118_501_fu_10947_p2 = (!sub_ln1118_500_fu_10931_p2.read().is_01() || !sext_ln1118_370_fu_10695_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_500_fu_10931_p2.read()) - sc_bigint<20>(sext_ln1118_370_fu_10695_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_502_fu_10997_p2() {
    sub_ln1118_502_fu_10997_p2 = (!sext_ln1118_377_fu_10993_p1.read().is_01() || !sext_ln708_223_fu_10980_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_377_fu_10993_p1.read()) - sc_bigint<19>(sext_ln708_223_fu_10980_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_503_fu_11028_p2() {
    sub_ln1118_503_fu_11028_p2 = (!sext_ln1118_378_reg_37623.read().is_01() || !sext_ln1118_380_fu_11024_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_378_reg_37623.read()) - sc_bigint<20>(sext_ln1118_380_fu_11024_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_504_fu_11047_p2() {
    sub_ln1118_504_fu_11047_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_377_fu_10993_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_377_fu_10993_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_505_fu_3266_p2() {
    sub_ln1118_505_fu_3266_p2 = (!sext_ln1118_378_fu_3246_p1.read().is_01() || !sext_ln708_221_fu_3224_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_378_fu_3246_p1.read()) - sc_bigint<20>(sext_ln708_221_fu_3224_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_506_fu_11073_p2() {
    sub_ln1118_506_fu_11073_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_379_fu_11020_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_379_fu_11020_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_507_fu_11112_p2() {
    sub_ln1118_507_fu_11112_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_222_fu_10977_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_222_fu_10977_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_508_fu_11152_p2() {
    sub_ln1118_508_fu_11152_p2 = (!sub_ln1118_504_fu_11047_p2.read().is_01() || !sext_ln708_223_fu_10980_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_504_fu_11047_p2.read()) - sc_bigint<19>(sext_ln708_223_fu_10980_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_509_fu_11168_p2() {
    sub_ln1118_509_fu_11168_p2 = (!sext_ln1118_380_fu_11024_p1.read().is_01() || !sext_ln1118_378_reg_37623.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_380_fu_11024_p1.read()) - sc_bigint<20>(sext_ln1118_378_reg_37623.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_510_fu_11217_p2() {
    sub_ln1118_510_fu_11217_p2 = (!sext_ln1118_385_fu_11202_p1.read().is_01() || !sext_ln1118_386_fu_11213_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_385_fu_11202_p1.read()) - sc_bigint<20>(sext_ln1118_386_fu_11213_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_511_fu_11277_p2() {
    sub_ln1118_511_fu_11277_p2 = (!sext_ln1118_387_fu_11273_p1.read().is_01() || !sext_ln1118_384_fu_11192_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_387_fu_11273_p1.read()) - sc_bigint<19>(sext_ln1118_384_fu_11192_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_512_fu_11293_p2() {
    sub_ln1118_512_fu_11293_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_387_fu_11273_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_387_fu_11273_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_513_fu_11313_p2() {
    sub_ln1118_513_fu_11313_p2 = (!sext_ln1118_386_fu_11213_p1.read().is_01() || !sext_ln1118_385_fu_11202_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_386_fu_11213_p1.read()) - sc_bigint<20>(sext_ln1118_385_fu_11202_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_514_fu_11361_p2() {
    sub_ln1118_514_fu_11361_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_383_fu_11189_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_383_fu_11189_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_515_fu_11381_p2() {
    sub_ln1118_515_fu_11381_p2 = (!sub_ln1118_512_fu_11293_p2.read().is_01() || !sext_ln1118_384_fu_11192_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_512_fu_11293_p2.read()) - sc_bigint<19>(sext_ln1118_384_fu_11192_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_516_fu_11414_p2() {
    sub_ln1118_516_fu_11414_p2 = (!sext_ln1118_388_fu_11410_p1.read().is_01() || !sext_ln708_231_fu_11400_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_388_fu_11410_p1.read()) - sc_bigint<19>(sext_ln708_231_fu_11400_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_517_fu_11430_p2() {
    sub_ln1118_517_fu_11430_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_388_fu_11410_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_388_fu_11410_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_518_fu_11456_p2() {
    sub_ln1118_518_fu_11456_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_230_fu_11397_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_230_fu_11397_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_519_fu_11476_p2() {
    sub_ln1118_519_fu_11476_p2 = (!sub_ln1118_517_fu_11430_p2.read().is_01() || !sext_ln708_231_fu_11400_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_517_fu_11430_p2.read()) - sc_bigint<19>(sext_ln708_231_fu_11400_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_520_fu_3364_p2() {
    sub_ln1118_520_fu_3364_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_389_fu_3344_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_389_fu_3344_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_521_fu_3370_p2() {
    sub_ln1118_521_fu_3370_p2 = (!sub_ln1118_520_fu_3364_p2.read().is_01() || !sext_ln708_229_fu_3312_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_520_fu_3364_p2.read()) - sc_bigint<20>(sext_ln708_229_fu_3312_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_522_fu_3398_p2() {
    sub_ln1118_522_fu_3398_p2 = (!sext_ln1118_390_fu_3394_p1.read().is_01() || !sext_ln1118_389_fu_3344_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_390_fu_3394_p1.read()) - sc_bigint<20>(sext_ln1118_389_fu_3344_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_523_fu_11555_p2() {
    sub_ln1118_523_fu_11555_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_393_fu_11551_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_393_fu_11551_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_524_fu_11593_p2() {
    sub_ln1118_524_fu_11593_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_394_fu_11589_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_394_fu_11589_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_525_fu_11621_p2() {
    sub_ln1118_525_fu_11621_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_395_fu_11617_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_395_fu_11617_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_526_fu_11627_p2() {
    sub_ln1118_526_fu_11627_p2 = (!sub_ln1118_525_fu_11621_p2.read().is_01() || !sext_ln1118_392_fu_11539_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_525_fu_11621_p2.read()) - sc_bigint<19>(sext_ln1118_392_fu_11539_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_527_fu_11643_p2() {
    sub_ln1118_527_fu_11643_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_391_fu_11535_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_391_fu_11535_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_528_fu_11659_p2() {
    sub_ln1118_528_fu_11659_p2 = (!sext_ln1118_395_fu_11617_p1.read().is_01() || !sext_ln1118_392_fu_11539_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_395_fu_11617_p1.read()) - sc_bigint<19>(sext_ln1118_392_fu_11539_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_529_fu_11741_p2() {
    sub_ln1118_529_fu_11741_p2 = (!sext_ln1118_399_fu_11737_p1.read().is_01() || !sext_ln1118_397_fu_11721_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_399_fu_11737_p1.read()) - sc_bigint<20>(sext_ln1118_397_fu_11721_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_530_fu_11761_p2() {
    sub_ln1118_530_fu_11761_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_396_fu_11717_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_396_fu_11717_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_531_fu_11849_p2() {
    sub_ln1118_531_fu_11849_p2 = (!sext_ln1118_399_fu_11737_p1.read().is_01() || !sext_ln1118_401_fu_11845_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_399_fu_11737_p1.read()) - sc_bigint<20>(sext_ln1118_401_fu_11845_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_532_fu_11869_p2() {
    sub_ln1118_532_fu_11869_p2 = (!sext_ln1118_400_fu_11793_p1.read().is_01() || !sext_ln1118_398_fu_11725_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_400_fu_11793_p1.read()) - sc_bigint<19>(sext_ln1118_398_fu_11725_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_533_fu_11885_p2() {
    sub_ln1118_533_fu_11885_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_399_fu_11737_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_399_fu_11737_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_534_fu_11933_p2() {
    sub_ln1118_534_fu_11933_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_400_fu_11793_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_400_fu_11793_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_535_fu_11999_p2() {
    sub_ln1118_535_fu_11999_p2 = (!sext_ln1118_404_fu_11965_p1.read().is_01() || !sext_ln1118_403_fu_11953_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_404_fu_11965_p1.read()) - sc_bigint<19>(sext_ln1118_403_fu_11953_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_536_fu_12025_p2() {
    sub_ln1118_536_fu_12025_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_402_fu_11949_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_402_fu_11949_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_537_fu_12045_p2() {
    sub_ln1118_537_fu_12045_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_404_fu_11965_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_404_fu_11965_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_538_fu_12087_p2() {
    sub_ln1118_538_fu_12087_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_405_fu_12083_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_405_fu_12083_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_539_fu_12103_p2() {
    sub_ln1118_539_fu_12103_p2 = (!sub_ln1118_537_fu_12045_p2.read().is_01() || !sext_ln1118_403_fu_11953_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_537_fu_12045_p2.read()) - sc_bigint<19>(sext_ln1118_403_fu_11953_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_540_fu_12221_p2() {
    sub_ln1118_540_fu_12221_p2 = (!sext_ln1118_409_fu_12139_p1.read().is_01() || !sext_ln1118_408_fu_12127_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_409_fu_12139_p1.read()) - sc_bigint<19>(sext_ln1118_408_fu_12127_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_541_fu_12251_p2() {
    sub_ln1118_541_fu_12251_p2 = (!sext_ln1118_412_fu_12197_p1.read().is_01() || !sext_ln1118_410_fu_12181_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_412_fu_12197_p1.read()) - sc_bigint<20>(sext_ln1118_410_fu_12181_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_542_fu_12271_p2() {
    sub_ln1118_542_fu_12271_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_411_fu_12193_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_411_fu_12193_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_543_fu_12287_p2() {
    sub_ln1118_543_fu_12287_p2 = (!sext_ln1118_410_fu_12181_p1.read().is_01() || !sext_ln1118_412_fu_12197_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_410_fu_12181_p1.read()) - sc_bigint<20>(sext_ln1118_412_fu_12197_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_544_fu_12321_p2() {
    sub_ln1118_544_fu_12321_p2 = (!sext_ln1118_410_fu_12181_p1.read().is_01() || !sext_ln1118_406_fu_12119_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_410_fu_12181_p1.read()) - sc_bigint<20>(sext_ln1118_406_fu_12119_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_545_fu_12357_p2() {
    sub_ln1118_545_fu_12357_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_407_fu_12123_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_407_fu_12123_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_546_fu_12435_p2() {
    sub_ln1118_546_fu_12435_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_413_fu_12393_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_413_fu_12393_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_547_fu_12451_p2() {
    sub_ln1118_547_fu_12451_p2 = (!sext_ln1118_413_fu_12393_p1.read().is_01() || !sext_ln708_244_fu_12377_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_413_fu_12393_p1.read()) - sc_bigint<19>(sext_ln708_244_fu_12377_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_548_fu_12467_p2() {
    sub_ln1118_548_fu_12467_p2 = (!sub_ln1118_546_fu_12435_p2.read().is_01() || !sext_ln708_244_fu_12377_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_546_fu_12435_p2.read()) - sc_bigint<19>(sext_ln708_244_fu_12377_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_549_fu_12509_p2() {
    sub_ln1118_549_fu_12509_p2 = (!sext_ln1118_416_fu_12505_p1.read().is_01() || !sext_ln1118_414_fu_12490_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_416_fu_12505_p1.read()) - sc_bigint<20>(sext_ln1118_414_fu_12490_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_550_fu_12529_p2() {
    sub_ln1118_550_fu_12529_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_415_fu_12501_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_415_fu_12501_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_551_fu_12581_p2() {
    sub_ln1118_551_fu_12581_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_249_fu_12549_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_249_fu_12549_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_552_fu_12613_p2() {
    sub_ln1118_552_fu_12613_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_417_fu_12609_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_417_fu_12609_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_553_fu_12645_p2() {
    sub_ln1118_553_fu_12645_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_418_fu_12641_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_418_fu_12641_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_554_fu_12651_p2() {
    sub_ln1118_554_fu_12651_p2 = (!sub_ln1118_553_fu_12645_p2.read().is_01() || !sext_ln708_248_fu_12545_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_553_fu_12645_p2.read()) - sc_bigint<19>(sext_ln708_248_fu_12545_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_555_fu_12711_p2() {
    sub_ln1118_555_fu_12711_p2 = (!sext_ln1118_419_fu_12707_p1.read().is_01() || !sext_ln1118_417_fu_12609_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_419_fu_12707_p1.read()) - sc_bigint<20>(sext_ln1118_417_fu_12609_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_556_fu_12751_p2() {
    sub_ln1118_556_fu_12751_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_423_fu_12747_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_423_fu_12747_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_557_fu_3448_p2() {
    sub_ln1118_557_fu_3448_p2 = (!sext_ln1118_424_fu_3432_p1.read().is_01() || !sext_ln1118_425_fu_3444_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_424_fu_3432_p1.read()) - sc_bigint<20>(sext_ln1118_425_fu_3444_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_558_fu_12770_p2() {
    sub_ln1118_558_fu_12770_p2 = (!sext_ln1118_424_reg_37685.read().is_01() || !sext_ln1118_420_fu_12731_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_424_reg_37685.read()) - sc_bigint<20>(sext_ln1118_420_fu_12731_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_559_fu_12788_p2() {
    sub_ln1118_559_fu_12788_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_421_fu_12734_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_421_fu_12734_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_560_fu_3484_p2() {
    sub_ln1118_560_fu_3484_p2 = (!sext_ln1118_425_fu_3444_p1.read().is_01() || !sext_ln1118_424_fu_3432_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_425_fu_3444_p1.read()) - sc_bigint<20>(sext_ln1118_424_fu_3432_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_561_fu_12826_p2() {
    sub_ln1118_561_fu_12826_p2 = (!sub_ln1118_556_fu_12751_p2.read().is_01() || !sext_ln1118_422_fu_12737_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_556_fu_12751_p2.read()) - sc_bigint<19>(sext_ln1118_422_fu_12737_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_562_fu_12875_p2() {
    sub_ln1118_562_fu_12875_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_426_fu_12871_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_426_fu_12871_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_563_fu_12897_p2() {
    sub_ln1118_563_fu_12897_p2 = (!sub_ln1118_562_fu_12875_p2.read().is_01() || !sext_ln1118_428_fu_12893_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_562_fu_12875_p2.read()) - sc_bigint<20>(sext_ln1118_428_fu_12893_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_564_fu_12913_p2() {
    sub_ln1118_564_fu_12913_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_427_fu_12889_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_427_fu_12889_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_565_fu_25352_p2() {
    sub_ln1118_565_fu_25352_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_429_fu_25348_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_429_fu_25348_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_566_fu_12943_p2() {
    sub_ln1118_566_fu_12943_p2 = (!sext_ln1118_428_fu_12893_p1.read().is_01() || !sext_ln1118_426_fu_12871_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_428_fu_12893_p1.read()) - sc_bigint<20>(sext_ln1118_426_fu_12871_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_567_fu_13007_p2() {
    sub_ln1118_567_fu_13007_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_434_fu_13003_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_434_fu_13003_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_568_fu_3513_p2() {
    sub_ln1118_568_fu_3513_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_432_fu_3510_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_432_fu_3510_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_569_fu_13071_p2() {
    sub_ln1118_569_fu_13071_p2 = (!sext_ln1118_436_fu_13067_p1.read().is_01() || !sext_ln1118_433_fu_12999_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_436_fu_13067_p1.read()) - sc_bigint<20>(sext_ln1118_433_fu_12999_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_570_fu_13087_p2() {
    sub_ln1118_570_fu_13087_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_435_fu_13037_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_435_fu_13037_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_571_fu_13109_p2() {
    sub_ln1118_571_fu_13109_p2 = (!sub_ln1118_570_fu_13087_p2.read().is_01() || !sext_ln1118_431_fu_12989_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_570_fu_13087_p2.read()) - sc_bigint<19>(sext_ln1118_431_fu_12989_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_572_fu_13145_p2() {
    sub_ln1118_572_fu_13145_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_440_fu_13141_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_440_fu_13141_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_573_fu_25445_p2() {
    sub_ln1118_573_fu_25445_p2 = (!sext_ln1118_441_fu_25441_p1.read().is_01() || !sext_ln1118_437_fu_25425_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_441_fu_25441_p1.read()) - sc_bigint<19>(sext_ln1118_437_fu_25425_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_574_fu_25465_p2() {
    sub_ln1118_574_fu_25465_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_441_fu_25441_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_441_fu_25441_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_575_fu_25471_p2() {
    sub_ln1118_575_fu_25471_p2 = (!sub_ln1118_574_fu_25465_p2.read().is_01() || !sext_ln1118_437_fu_25425_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_574_fu_25465_p2.read()) - sc_bigint<19>(sext_ln1118_437_fu_25425_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_576_fu_13189_p2() {
    sub_ln1118_576_fu_13189_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_438_fu_13125_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_438_fu_13125_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_577_fu_13221_p2() {
    sub_ln1118_577_fu_13221_p2 = (!sext_ln1118_439_fu_13137_p1.read().is_01() || !sext_ln1118_442_fu_13217_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_439_fu_13137_p1.read()) - sc_bigint<20>(sext_ln1118_442_fu_13217_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_578_fu_13237_p2() {
    sub_ln1118_578_fu_13237_p2 = (!sext_ln1118_442_fu_13217_p1.read().is_01() || !sext_ln1118_439_fu_13137_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_442_fu_13217_p1.read()) - sc_bigint<20>(sext_ln1118_439_fu_13137_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_579_fu_13274_p2() {
    sub_ln1118_579_fu_13274_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_446_fu_13270_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_446_fu_13270_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_580_fu_13280_p2() {
    sub_ln1118_580_fu_13280_p2 = (!sub_ln1118_579_fu_13274_p2.read().is_01() || !sext_ln1118_445_fu_13260_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_579_fu_13274_p2.read()) - sc_bigint<19>(sext_ln1118_445_fu_13260_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_581_fu_13296_p2() {
    sub_ln1118_581_fu_13296_p2 = (!sext_ln1118_446_fu_13270_p1.read().is_01() || !sext_ln1118_445_fu_13260_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_446_fu_13270_p1.read()) - sc_bigint<19>(sext_ln1118_445_fu_13260_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_582_fu_13315_p2() {
    sub_ln1118_582_fu_13315_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_444_fu_13257_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_444_fu_13257_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_583_fu_13377_p2() {
    sub_ln1118_583_fu_13377_p2 = (!sext_ln1118_449_fu_13373_p1.read().is_01() || !sext_ln1118_447_fu_13358_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_449_fu_13373_p1.read()) - sc_bigint<20>(sext_ln1118_447_fu_13358_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_584_fu_13397_p2() {
    sub_ln1118_584_fu_13397_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_448_fu_13369_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_448_fu_13369_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_585_fu_13426_p2() {
    sub_ln1118_585_fu_13426_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_447_fu_13358_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_447_fu_13358_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_586_fu_13468_p2() {
    sub_ln1118_586_fu_13468_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_452_fu_13464_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_452_fu_13464_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_587_fu_13532_p2() {
    sub_ln1118_587_fu_13532_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_455_fu_13528_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_455_fu_13528_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_588_fu_13570_p2() {
    sub_ln1118_588_fu_13570_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_456_fu_13566_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_456_fu_13566_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_589_fu_13600_p2() {
    sub_ln1118_589_fu_13600_p2 = (!sext_ln1118_456_fu_13566_p1.read().is_01() || !sext_ln1118_451_fu_13460_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_456_fu_13566_p1.read()) - sc_bigint<19>(sext_ln1118_451_fu_13460_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_590_fu_13632_p2() {
    sub_ln1118_590_fu_13632_p2 = (!sext_ln1118_453_fu_13496_p1.read().is_01() || !sext_ln1118_454_fu_13524_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_453_fu_13496_p1.read()) - sc_bigint<20>(sext_ln1118_454_fu_13524_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_591_fu_13657_p2() {
    sub_ln1118_591_fu_13657_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_272_fu_13651_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_272_fu_13651_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_592_fu_3595_p2() {
    sub_ln1118_592_fu_3595_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_458_fu_3591_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_458_fu_3591_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_593_fu_3633_p2() {
    sub_ln1118_593_fu_3633_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_459_fu_3629_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_459_fu_3629_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_594_fu_3639_p2() {
    sub_ln1118_594_fu_3639_p2 = (!sub_ln1118_593_fu_3633_p2.read().is_01() || !sext_ln1118_457_fu_3587_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_593_fu_3633_p2.read()) - sc_bigint<20>(sext_ln1118_457_fu_3587_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_595_fu_13694_p2() {
    sub_ln1118_595_fu_13694_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_460_fu_13690_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_460_fu_13690_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_596_fu_13717_p2() {
    sub_ln1118_596_fu_13717_p2 = (!sext_ln1118_460_fu_13690_p1.read().is_01() || !sext_ln708_271_fu_13648_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_460_fu_13690_p1.read()) - sc_bigint<19>(sext_ln708_271_fu_13648_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_597_fu_13800_p2() {
    sub_ln1118_597_fu_13800_p2 = (!sext_ln1118_465_fu_13796_p1.read().is_01() || !sext_ln1118_463_fu_13781_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_465_fu_13796_p1.read()) - sc_bigint<20>(sext_ln1118_463_fu_13781_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_598_fu_13816_p2() {
    sub_ln1118_598_fu_13816_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_277_fu_13736_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_277_fu_13736_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_599_fu_13836_p2() {
    sub_ln1118_599_fu_13836_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_464_fu_13792_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_464_fu_13792_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_600_fu_13856_p2() {
    sub_ln1118_600_fu_13856_p2 = (!sext_ln1118_463_fu_13781_p1.read().is_01() || !sext_ln1118_465_fu_13796_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_463_fu_13781_p1.read()) - sc_bigint<20>(sext_ln1118_465_fu_13796_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_601_fu_13896_p2() {
    sub_ln1118_601_fu_13896_p2 = (!sext_ln1118_462_fu_13751_p1.read().is_01() || !sext_ln708_278_fu_13739_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_462_fu_13751_p1.read()) - sc_bigint<19>(sext_ln708_278_fu_13739_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_602_fu_13928_p2() {
    sub_ln1118_602_fu_13928_p2 = (!sext_ln1118_463_fu_13781_p1.read().is_01() || !sext_ln708_276_fu_13733_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_463_fu_13781_p1.read()) - sc_bigint<20>(sext_ln708_276_fu_13733_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_603_fu_13944_p2() {
    sub_ln1118_603_fu_13944_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_463_fu_13781_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_463_fu_13781_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_604_fu_3709_p2() {
    sub_ln1118_604_fu_3709_p2 = (!sext_ln1118_466_fu_3705_p1.read().is_01() || !sext_ln1118_461_fu_3693_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_466_fu_3705_p1.read()) - sc_bigint<21>(sext_ln1118_461_fu_3693_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_605_fu_13960_p2() {
    sub_ln1118_605_fu_13960_p2 = (!sub_ln1118_603_fu_13944_p2.read().is_01() || !sext_ln708_276_fu_13733_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_603_fu_13944_p2.read()) - sc_bigint<20>(sext_ln708_276_fu_13733_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_606_fu_13988_p2() {
    sub_ln1118_606_fu_13988_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_469_fu_13984_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_469_fu_13984_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_607_fu_14016_p2() {
    sub_ln1118_607_fu_14016_p2 = (!sext_ln1118_470_fu_14012_p1.read().is_01() || !sext_ln1118_467_fu_13976_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_470_fu_14012_p1.read()) - sc_bigint<20>(sext_ln1118_467_fu_13976_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_608_fu_14108_p2() {
    sub_ln1118_608_fu_14108_p2 = (!sext_ln1118_471_fu_14040_p1.read().is_01() || !sext_ln1118_468_fu_13980_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_471_fu_14040_p1.read()) - sc_bigint<19>(sext_ln1118_468_fu_13980_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_609_fu_14142_p2() {
    sub_ln1118_609_fu_14142_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_471_fu_14040_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_471_fu_14040_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_610_fu_14148_p2() {
    sub_ln1118_610_fu_14148_p2 = (!sub_ln1118_609_fu_14142_p2.read().is_01() || !sext_ln1118_468_fu_13980_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_609_fu_14142_p2.read()) - sc_bigint<19>(sext_ln1118_468_fu_13980_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_611_fu_14180_p2() {
    sub_ln1118_611_fu_14180_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_475_fu_14176_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_475_fu_14176_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_612_fu_25703_p2() {
    sub_ln1118_612_fu_25703_p2 = (!sext_ln1118_476_fu_25659_p1.read().is_01() || !sext_ln1118_473_fu_25643_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_476_fu_25659_p1.read()) - sc_bigint<19>(sext_ln1118_473_fu_25643_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_613_fu_14196_p2() {
    sub_ln1118_613_fu_14196_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_474_fu_14164_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_474_fu_14164_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_614_fu_14228_p2() {
    sub_ln1118_614_fu_14228_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_479_fu_14224_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_479_fu_14224_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_615_fu_14260_p2() {
    sub_ln1118_615_fu_14260_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_480_fu_14256_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_480_fu_14256_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_616_fu_14266_p2() {
    sub_ln1118_616_fu_14266_p2 = (!sub_ln1118_615_fu_14260_p2.read().is_01() || !sext_ln1118_478_fu_14220_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_615_fu_14260_p2.read()) - sc_bigint<19>(sext_ln1118_478_fu_14220_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_617_fu_14338_p2() {
    sub_ln1118_617_fu_14338_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_481_fu_14334_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_481_fu_14334_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_618_fu_14388_p2() {
    sub_ln1118_618_fu_14388_p2 = (!sext_ln1118_480_fu_14256_p1.read().is_01() || !sext_ln1118_478_fu_14220_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_480_fu_14256_p1.read()) - sc_bigint<19>(sext_ln1118_478_fu_14220_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_619_fu_14404_p2() {
    sub_ln1118_619_fu_14404_p2 = (!sext_ln1118_481_fu_14334_p1.read().is_01() || !sext_ln1118_477_fu_14216_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_481_fu_14334_p1.read()) - sc_bigint<20>(sext_ln1118_477_fu_14216_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_620_fu_14456_p2() {
    sub_ln1118_620_fu_14456_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_484_fu_14436_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_484_fu_14436_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_621_fu_14526_p2() {
    sub_ln1118_621_fu_14526_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_485_fu_14522_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_485_fu_14522_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_622_fu_14552_p2() {
    sub_ln1118_622_fu_14552_p2 = (!sub_ln1118_620_fu_14456_p2.read().is_01() || !sext_ln1118_483_fu_14424_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_620_fu_14456_p2.read()) - sc_bigint<19>(sext_ln1118_483_fu_14424_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_623_fu_14580_p2() {
    sub_ln1118_623_fu_14580_p2 = (!sext_ln1118_485_fu_14522_p1.read().is_01() || !sext_ln1118_486_fu_14576_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_485_fu_14522_p1.read()) - sc_bigint<20>(sext_ln1118_486_fu_14576_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_624_fu_14596_p2() {
    sub_ln1118_624_fu_14596_p2 = (!sext_ln1118_484_fu_14436_p1.read().is_01() || !sext_ln1118_483_fu_14424_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_484_fu_14436_p1.read()) - sc_bigint<19>(sext_ln1118_483_fu_14424_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_625_fu_14676_p2() {
    sub_ln1118_625_fu_14676_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_487_fu_14672_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_487_fu_14672_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_626_fu_14682_p2() {
    sub_ln1118_626_fu_14682_p2 = (!sub_ln1118_625_fu_14676_p2.read().is_01() || !sext_ln708_291_fu_14632_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_625_fu_14676_p2.read()) - sc_bigint<19>(sext_ln708_291_fu_14632_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_627_fu_14710_p2() {
    sub_ln1118_627_fu_14710_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_488_fu_14706_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_488_fu_14706_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_628_fu_14730_p2() {
    sub_ln1118_628_fu_14730_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_290_fu_14628_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_290_fu_14628_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_629_fu_14770_p2() {
    sub_ln1118_629_fu_14770_p2 = (!sext_ln1118_487_fu_14672_p1.read().is_01() || !sext_ln708_291_fu_14632_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_487_fu_14672_p1.read()) - sc_bigint<19>(sext_ln708_291_fu_14632_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_630_fu_14850_p2() {
    sub_ln1118_630_fu_14850_p2 = (!sext_ln1118_491_fu_14830_p1.read().is_01() || !sext_ln1118_490_fu_14818_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_491_fu_14830_p1.read()) - sc_bigint<19>(sext_ln1118_490_fu_14818_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_631_fu_14880_p2() {
    sub_ln1118_631_fu_14880_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_491_fu_14830_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_491_fu_14830_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_632_fu_14886_p2() {
    sub_ln1118_632_fu_14886_p2 = (!sub_ln1118_631_fu_14880_p2.read().is_01() || !sext_ln1118_490_fu_14818_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_631_fu_14880_p2.read()) - sc_bigint<19>(sext_ln1118_490_fu_14818_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_633_fu_14902_p2() {
    sub_ln1118_633_fu_14902_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_489_fu_14814_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_489_fu_14814_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_634_fu_14934_p2() {
    sub_ln1118_634_fu_14934_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_492_fu_14930_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_492_fu_14930_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_635_fu_14990_p2() {
    sub_ln1118_635_fu_14990_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_495_fu_14986_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_495_fu_14986_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_636_fu_15034_p2() {
    sub_ln1118_636_fu_15034_p2 = (!sext_ln1118_497_fu_15030_p1.read().is_01() || !sext_ln1118_496_fu_15018_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_497_fu_15030_p1.read()) - sc_bigint<20>(sext_ln1118_496_fu_15018_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_637_fu_15082_p2() {
    sub_ln1118_637_fu_15082_p2 = (!sext_ln1118_498_fu_15078_p1.read().is_01() || !sext_ln1118_494_fu_14982_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_498_fu_15078_p1.read()) - sc_bigint<19>(sext_ln1118_494_fu_14982_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_638_fu_15168_p2() {
    sub_ln1118_638_fu_15168_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_498_fu_15078_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_498_fu_15078_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_639_fu_15204_p2() {
    sub_ln1118_639_fu_15204_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_503_fu_15200_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_503_fu_15200_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_640_fu_15246_p2() {
    sub_ln1118_640_fu_15246_p2 = (!sext_ln1118_504_fu_15227_p1.read().is_01() || !sext_ln1118_506_fu_15242_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_504_fu_15227_p1.read()) - sc_bigint<20>(sext_ln1118_506_fu_15242_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_641_fu_15262_p2() {
    sub_ln1118_641_fu_15262_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_504_fu_15227_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_504_fu_15227_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_642_fu_15268_p2() {
    sub_ln1118_642_fu_15268_p2 = (!sub_ln1118_641_fu_15262_p2.read().is_01() || !sext_ln1118_500_fu_15184_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_641_fu_15262_p2.read()) - sc_bigint<20>(sext_ln1118_500_fu_15184_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_643_fu_15284_p2() {
    sub_ln1118_643_fu_15284_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_505_fu_15238_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_505_fu_15238_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_644_fu_15300_p2() {
    sub_ln1118_644_fu_15300_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_501_fu_15187_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_501_fu_15187_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_645_fu_25839_p2() {
    sub_ln1118_645_fu_25839_p2 = (!sext_ln1118_503_reg_39504.read().is_01() || !sext_ln1118_502_reg_39497.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_503_reg_39504.read()) - sc_bigint<19>(sext_ln1118_502_reg_39497.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_646_fu_15320_p2() {
    sub_ln1118_646_fu_15320_p2 = (!sub_ln1118_639_fu_15204_p2.read().is_01() || !sext_ln1118_502_fu_15190_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_639_fu_15204_p2.read()) - sc_bigint<19>(sext_ln1118_502_fu_15190_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_647_fu_25884_p2() {
    sub_ln1118_647_fu_25884_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_510_reg_39543.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_510_reg_39543.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_648_fu_25889_p2() {
    sub_ln1118_648_fu_25889_p2 = (!sub_ln1118_647_fu_25884_p2.read().is_01() || !sext_ln1118_509_reg_39536.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_647_fu_25884_p2.read()) - sc_bigint<19>(sext_ln1118_509_reg_39536.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_649_fu_15401_p2() {
    sub_ln1118_649_fu_15401_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_511_fu_15397_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_511_fu_15397_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_650_fu_15417_p2() {
    sub_ln1118_650_fu_15417_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_508_fu_15343_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_508_fu_15343_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_651_fu_25928_p2() {
    sub_ln1118_651_fu_25928_p2 = (!sext_ln1118_510_reg_39543.read().is_01() || !sext_ln1118_509_reg_39536.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_510_reg_39543.read()) - sc_bigint<19>(sext_ln1118_509_reg_39536.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_652_fu_15529_p2() {
    sub_ln1118_652_fu_15529_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_515_fu_15525_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_515_fu_15525_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_653_fu_15589_p2() {
    sub_ln1118_653_fu_15589_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_517_fu_15585_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_517_fu_15585_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_654_fu_15605_p2() {
    sub_ln1118_654_fu_15605_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_516_fu_15557_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_516_fu_15557_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_655_fu_15651_p2() {
    sub_ln1118_655_fu_15651_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_518_fu_15647_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_518_fu_15647_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_656_fu_15671_p2() {
    sub_ln1118_656_fu_15671_p2 = (!sext_ln1118_516_fu_15557_p1.read().is_01() || !sext_ln1118_514_fu_15521_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_516_fu_15557_p1.read()) - sc_bigint<19>(sext_ln1118_514_fu_15521_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_657_fu_15719_p2() {
    sub_ln1118_657_fu_15719_p2 = (!sext_ln1118_518_fu_15647_p1.read().is_01() || !sext_ln1118_513_fu_15517_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_518_fu_15647_p1.read()) - sc_bigint<20>(sext_ln1118_513_fu_15517_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_658_fu_15735_p2() {
    sub_ln1118_658_fu_15735_p2 = (!sub_ln1118_654_fu_15605_p2.read().is_01() || !sext_ln1118_514_fu_15521_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_654_fu_15605_p2.read()) - sc_bigint<19>(sext_ln1118_514_fu_15521_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_659_fu_15827_p2() {
    sub_ln1118_659_fu_15827_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_521_fu_15807_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_521_fu_15807_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_660_fu_15869_p2() {
    sub_ln1118_660_fu_15869_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_522_fu_15865_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_522_fu_15865_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_661_fu_15889_p2() {
    sub_ln1118_661_fu_15889_p2 = (!sext_ln1118_521_fu_15807_p1.read().is_01() || !sext_ln1118_519_fu_15791_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_521_fu_15807_p1.read()) - sc_bigint<19>(sext_ln1118_519_fu_15791_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_662_fu_15905_p2() {
    sub_ln1118_662_fu_15905_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_520_fu_15795_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_520_fu_15795_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_663_fu_15967_p2() {
    sub_ln1118_663_fu_15967_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_526_fu_15963_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_526_fu_15963_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_664_fu_16015_p2() {
    sub_ln1118_664_fu_16015_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_524_fu_15947_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_524_fu_15947_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_665_fu_16035_p2() {
    sub_ln1118_665_fu_16035_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_527_fu_15995_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_527_fu_15995_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_666_fu_16061_p2() {
    sub_ln1118_666_fu_16061_p2 = (!sub_ln1118_665_fu_16035_p2.read().is_01() || !sext_ln1118_525_fu_15951_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_665_fu_16035_p2.read()) - sc_bigint<19>(sext_ln1118_525_fu_15951_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_667_fu_16093_p2() {
    sub_ln1118_667_fu_16093_p2 = (!sext_ln1118_527_fu_15995_p1.read().is_01() || !sext_ln1118_525_fu_15951_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_527_fu_15995_p1.read()) - sc_bigint<19>(sext_ln1118_525_fu_15951_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_668_fu_16121_p2() {
    sub_ln1118_668_fu_16121_p2 = (!sext_ln1118_526_fu_15963_p1.read().is_01() || !sext_ln1118_528_fu_16117_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_526_fu_15963_p1.read()) - sc_bigint<20>(sext_ln1118_528_fu_16117_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_669_fu_16161_p2() {
    sub_ln1118_669_fu_16161_p2 = (!sext_ln1118_528_fu_16117_p1.read().is_01() || !sext_ln1118_526_fu_15963_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_528_fu_16117_p1.read()) - sc_bigint<20>(sext_ln1118_526_fu_15963_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_670_fu_16235_p2() {
    sub_ln1118_670_fu_16235_p2 = (!sext_ln1118_532_fu_16231_p1.read().is_01() || !sext_ln1118_531_fu_16219_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_532_fu_16231_p1.read()) - sc_bigint<19>(sext_ln1118_531_fu_16219_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_671_fu_16267_p2() {
    sub_ln1118_671_fu_16267_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_530_fu_16215_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_530_fu_16215_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_672_fu_16287_p2() {
    sub_ln1118_672_fu_16287_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_532_fu_16231_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_532_fu_16231_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_673_fu_16319_p2() {
    sub_ln1118_673_fu_16319_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_534_fu_16315_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_534_fu_16315_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_674_fu_16347_p2() {
    sub_ln1118_674_fu_16347_p2 = (!sext_ln1118_533_fu_16311_p1.read().is_01() || !sext_ln1118_535_fu_16343_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_533_fu_16311_p1.read()) - sc_bigint<20>(sext_ln1118_535_fu_16343_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_675_fu_16367_p2() {
    sub_ln1118_675_fu_16367_p2 = (!sext_ln1118_535_fu_16343_p1.read().is_01() || !sext_ln1118_529_fu_16211_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_535_fu_16343_p1.read()) - sc_bigint<20>(sext_ln1118_529_fu_16211_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_676_fu_16383_p2() {
    sub_ln1118_676_fu_16383_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_535_fu_16343_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_535_fu_16343_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_677_fu_16441_p2() {
    sub_ln1118_677_fu_16441_p2 = (!sext_ln1118_539_fu_16437_p1.read().is_01() || !sext_ln1118_537_fu_16421_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_539_fu_16437_p1.read()) - sc_bigint<20>(sext_ln1118_537_fu_16421_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_678_fu_16469_p2() {
    sub_ln1118_678_fu_16469_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_540_fu_16465_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_540_fu_16465_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_679_fu_16511_p2() {
    sub_ln1118_679_fu_16511_p2 = (!sext_ln1118_541_fu_16507_p1.read().is_01() || !sext_ln1118_538_fu_16425_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_541_fu_16507_p1.read()) - sc_bigint<19>(sext_ln1118_538_fu_16425_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_680_fu_16551_p2() {
    sub_ln1118_680_fu_16551_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_541_fu_16507_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_541_fu_16507_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_681_fu_16567_p2() {
    sub_ln1118_681_fu_16567_p2 = (!sub_ln1118_680_fu_16551_p2.read().is_01() || !sext_ln1118_538_fu_16425_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_680_fu_16551_p2.read()) - sc_bigint<19>(sext_ln1118_538_fu_16425_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_682_fu_16583_p2() {
    sub_ln1118_682_fu_16583_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_536_fu_16417_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_536_fu_16417_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_683_fu_16657_p2() {
    sub_ln1118_683_fu_16657_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_542_fu_16637_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_542_fu_16637_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_684_fu_16673_p2() {
    sub_ln1118_684_fu_16673_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_318_fu_16603_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_318_fu_16603_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_685_fu_16709_p2() {
    sub_ln1118_685_fu_16709_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_544_fu_16705_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_544_fu_16705_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_686_fu_16729_p2() {
    sub_ln1118_686_fu_16729_p2 = (!sext_ln1118_543_fu_16701_p1.read().is_01() || !sext_ln1118_542_fu_16637_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_543_fu_16701_p1.read()) - sc_bigint<20>(sext_ln1118_542_fu_16637_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_687_fu_16761_p2() {
    sub_ln1118_687_fu_16761_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_545_fu_16757_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_545_fu_16757_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_688_fu_16767_p2() {
    sub_ln1118_688_fu_16767_p2 = (!sub_ln1118_687_fu_16761_p2.read().is_01() || !sext_ln708_319_fu_16607_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_687_fu_16761_p2.read()) - sc_bigint<19>(sext_ln708_319_fu_16607_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_689_fu_16835_p2() {
    sub_ln1118_689_fu_16835_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_547_fu_16831_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_547_fu_16831_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_690_fu_16883_p2() {
    sub_ln1118_690_fu_16883_p2 = (!sext_ln1118_548_fu_16859_p1.read().is_01() || !sext_ln708_321_fu_16793_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_548_fu_16859_p1.read()) - sc_bigint<20>(sext_ln708_321_fu_16793_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_691_fu_16929_p2() {
    sub_ln1118_691_fu_16929_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_549_fu_16925_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_549_fu_16925_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_692_fu_16945_p2() {
    sub_ln1118_692_fu_16945_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_323_fu_16801_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_323_fu_16801_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_693_fu_16965_p2() {
    sub_ln1118_693_fu_16965_p2 = (!sub_ln1118_691_fu_16929_p2.read().is_01() || !sext_ln708_322_fu_16797_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_691_fu_16929_p2.read()) - sc_bigint<19>(sext_ln708_322_fu_16797_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_694_fu_16981_p2() {
    sub_ln1118_694_fu_16981_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_548_fu_16859_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_548_fu_16859_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_695_fu_16987_p2() {
    sub_ln1118_695_fu_16987_p2 = (!sub_ln1118_694_fu_16981_p2.read().is_01() || !sext_ln708_321_fu_16793_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_694_fu_16981_p2.read()) - sc_bigint<20>(sext_ln708_321_fu_16793_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_696_fu_17003_p2() {
    sub_ln1118_696_fu_17003_p2 = (!sext_ln1118_546_fu_16827_p1.read().is_01() || !sext_ln1118_548_fu_16859_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_546_fu_16827_p1.read()) - sc_bigint<20>(sext_ln1118_548_fu_16859_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_697_fu_17047_p2() {
    sub_ln1118_697_fu_17047_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_555_fu_17043_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_555_fu_17043_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_698_fu_17078_p2() {
    sub_ln1118_698_fu_17078_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_556_fu_17074_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_556_fu_17074_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_699_fu_17121_p2() {
    sub_ln1118_699_fu_17121_p2 = (!sext_ln1118_557_fu_17117_p1.read().is_01() || !sext_ln1118_551_fu_17023_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_557_fu_17117_p1.read()) - sc_bigint<20>(sext_ln1118_551_fu_17023_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_700_fu_17141_p2() {
    sub_ln1118_700_fu_17141_p2 = (!sext_ln1118_556_fu_17074_p1.read().is_01() || !sext_ln1118_552_fu_17026_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_556_fu_17074_p1.read()) - sc_bigint<19>(sext_ln1118_552_fu_17026_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_701_fu_17157_p2() {
    sub_ln1118_701_fu_17157_p2 = (!sext_ln1118_554_fu_17039_p1.read().is_01() || !sext_ln1118_557_fu_17117_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_554_fu_17039_p1.read()) - sc_bigint<20>(sext_ln1118_557_fu_17117_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_702_fu_17180_p2() {
    sub_ln1118_702_fu_17180_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_553_fu_17029_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_553_fu_17029_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_703_fu_17231_p2() {
    sub_ln1118_703_fu_17231_p2 = (!sext_ln1118_564_fu_17227_p1.read().is_01() || !sext_ln1118_562_fu_17212_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_564_fu_17227_p1.read()) - sc_bigint<20>(sext_ln1118_562_fu_17212_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_704_fu_17247_p2() {
    sub_ln1118_704_fu_17247_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_562_fu_17212_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_562_fu_17212_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_705_fu_17253_p2() {
    sub_ln1118_705_fu_17253_p2 = (!sub_ln1118_704_fu_17247_p2.read().is_01() || !sext_ln1118_559_fu_17196_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_704_fu_17247_p2.read()) - sc_bigint<20>(sext_ln1118_559_fu_17196_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_706_fu_17269_p2() {
    sub_ln1118_706_fu_17269_p2 = (!sext_ln1118_562_fu_17212_p1.read().is_01() || !sext_ln1118_559_fu_17196_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_562_fu_17212_p1.read()) - sc_bigint<20>(sext_ln1118_559_fu_17196_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_707_fu_17328_p2() {
    sub_ln1118_707_fu_17328_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_565_fu_17292_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_565_fu_17292_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_708_fu_17334_p2() {
    sub_ln1118_708_fu_17334_p2 = (!sub_ln1118_707_fu_17328_p2.read().is_01() || !sext_ln1118_561_fu_17202_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_707_fu_17328_p2.read()) - sc_bigint<19>(sext_ln1118_561_fu_17202_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_709_fu_17350_p2() {
    sub_ln1118_709_fu_17350_p2 = (!sext_ln1118_565_fu_17292_p1.read().is_01() || !sext_ln1118_561_fu_17202_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_565_fu_17292_p1.read()) - sc_bigint<19>(sext_ln1118_561_fu_17202_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_710_fu_17419_p2() {
    sub_ln1118_710_fu_17419_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_560_fu_17199_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_560_fu_17199_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_711_fu_17443_p2() {
    sub_ln1118_711_fu_17443_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_563_fu_17223_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_563_fu_17223_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_712_fu_17503_p2() {
    sub_ln1118_712_fu_17503_p2 = (!sext_ln1118_572_fu_17499_p1.read().is_01() || !sext_ln1118_570_fu_17483_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_572_fu_17499_p1.read()) - sc_bigint<20>(sext_ln1118_570_fu_17483_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_713_fu_17547_p2() {
    sub_ln1118_713_fu_17547_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_573_fu_17527_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_573_fu_17527_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_714_fu_17577_p2() {
    sub_ln1118_714_fu_17577_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_571_fu_17495_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_571_fu_17495_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_715_fu_17617_p2() {
    sub_ln1118_715_fu_17617_p2 = (!sub_ln1118_713_fu_17547_p2.read().is_01() || !sext_ln1118_569_fu_17471_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_713_fu_17547_p2.read()) - sc_bigint<19>(sext_ln1118_569_fu_17471_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_716_fu_17633_p2() {
    sub_ln1118_716_fu_17633_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_568_fu_17467_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_568_fu_17467_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_717_fu_17745_p2() {
    sub_ln1118_717_fu_17745_p2 = (!sext_ln1118_577_fu_17741_p1.read().is_01() || !sext_ln1118_576_fu_17729_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_577_fu_17741_p1.read()) - sc_bigint<19>(sext_ln1118_576_fu_17729_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_718_fu_17795_p2() {
    sub_ln1118_718_fu_17795_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_579_fu_17791_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_579_fu_17791_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_719_fu_17811_p2() {
    sub_ln1118_719_fu_17811_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_577_fu_17741_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_577_fu_17741_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_720_fu_17817_p2() {
    sub_ln1118_720_fu_17817_p2 = (!sub_ln1118_719_fu_17811_p2.read().is_01() || !sext_ln1118_576_fu_17729_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_719_fu_17811_p2.read()) - sc_bigint<19>(sext_ln1118_576_fu_17729_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_721_fu_17873_p2() {
    sub_ln1118_721_fu_17873_p2 = (!sext_ln1118_578_fu_17787_p1.read().is_01() || !sext_ln1118_580_fu_17869_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_578_fu_17787_p1.read()) - sc_bigint<21>(sext_ln1118_580_fu_17869_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_722_fu_17921_p2() {
    sub_ln1118_722_fu_17921_p2 = (!sext_ln1118_581_fu_17917_p1.read().is_01() || !sext_ln1118_575_fu_17725_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_581_fu_17917_p1.read()) - sc_bigint<20>(sext_ln1118_575_fu_17725_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_723_fu_17975_p2() {
    sub_ln1118_723_fu_17975_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_337_fu_17961_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_337_fu_17961_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_724_fu_18035_p2() {
    sub_ln1118_724_fu_18035_p2 = (!sext_ln1118_582_fu_18031_p1.read().is_01() || !sext_ln708_336_fu_17957_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_582_fu_18031_p1.read()) - sc_bigint<19>(sext_ln708_336_fu_17957_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_725_fu_18051_p2() {
    sub_ln1118_725_fu_18051_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_582_fu_18031_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_582_fu_18031_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_726_fu_18057_p2() {
    sub_ln1118_726_fu_18057_p2 = (!sub_ln1118_725_fu_18051_p2.read().is_01() || !sext_ln708_336_fu_17957_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_725_fu_18051_p2.read()) - sc_bigint<19>(sext_ln708_336_fu_17957_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_727_fu_26179_p2() {
    sub_ln1118_727_fu_26179_p2 = (!sext_ln1118_585_reg_39946.read().is_01() || !sext_ln1118_584_reg_39939.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_585_reg_39946.read()) - sc_bigint<19>(sext_ln1118_584_reg_39939.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_728_fu_18093_p2() {
    sub_ln1118_728_fu_18093_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_585_fu_18089_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_585_fu_18089_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_729_fu_18151_p2() {
    sub_ln1118_729_fu_18151_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_586_fu_18127_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_586_fu_18127_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_730_fu_18201_p2() {
    sub_ln1118_730_fu_18201_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_588_fu_18197_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_588_fu_18197_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_731_fu_18217_p2() {
    sub_ln1118_731_fu_18217_p2 = (!sub_ln1118_728_fu_18093_p2.read().is_01() || !sext_ln1118_584_fu_18077_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_728_fu_18093_p2.read()) - sc_bigint<19>(sext_ln1118_584_fu_18077_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_732_fu_18247_p2() {
    sub_ln1118_732_fu_18247_p2 = (!sext_ln1118_587_fu_18193_p1.read().is_01() || !sext_ln1118_586_fu_18127_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_587_fu_18193_p1.read()) - sc_bigint<20>(sext_ln1118_586_fu_18127_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_733_fu_18263_p2() {
    sub_ln1118_733_fu_18263_p2 = (!sext_ln1118_586_fu_18127_p1.read().is_01() || !sext_ln1118_587_fu_18193_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_586_fu_18127_p1.read()) - sc_bigint<20>(sext_ln1118_587_fu_18193_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_734_fu_18321_p2() {
    sub_ln1118_734_fu_18321_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_589_fu_18317_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_589_fu_18317_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_735_fu_18327_p2() {
    sub_ln1118_735_fu_18327_p2 = (!sub_ln1118_734_fu_18321_p2.read().is_01() || !sext_ln708_344_fu_18295_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_734_fu_18321_p2.read()) - sc_bigint<19>(sext_ln708_344_fu_18295_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_736_fu_18343_p2() {
    sub_ln1118_736_fu_18343_p2 = (!sext_ln1118_589_fu_18317_p1.read().is_01() || !sext_ln708_344_fu_18295_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_589_fu_18317_p1.read()) - sc_bigint<19>(sext_ln708_344_fu_18295_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_737_fu_18409_p2() {
    sub_ln1118_737_fu_18409_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_592_fu_18405_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_592_fu_18405_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_738_fu_18415_p2() {
    sub_ln1118_738_fu_18415_p2 = (!sub_ln1118_737_fu_18409_p2.read().is_01() || !sext_ln1118_591_fu_18393_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_737_fu_18409_p2.read()) - sc_bigint<19>(sext_ln1118_591_fu_18393_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_739_fu_18465_p2() {
    sub_ln1118_739_fu_18465_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_590_fu_18389_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_590_fu_18389_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_740_fu_18539_p2() {
    sub_ln1118_740_fu_18539_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_593_fu_18535_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_593_fu_18535_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_741_fu_18571_p2() {
    sub_ln1118_741_fu_18571_p2 = (!sext_ln1118_595_fu_18567_p1.read().is_01() || !sext_ln1118_594_fu_18555_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_595_fu_18567_p1.read()) - sc_bigint<19>(sext_ln1118_594_fu_18555_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_742_fu_18607_p2() {
    sub_ln1118_742_fu_18607_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_595_fu_18567_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_595_fu_18567_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_743_fu_18687_p2() {
    sub_ln1118_743_fu_18687_p2 = (!sext_ln1118_597_fu_18683_p1.read().is_01() || !sext_ln1118_596_fu_18671_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_597_fu_18683_p1.read()) - sc_bigint<20>(sext_ln1118_596_fu_18671_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_744_fu_18725_p2() {
    sub_ln1118_744_fu_18725_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_353_fu_18707_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_353_fu_18707_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_745_fu_26342_p2() {
    sub_ln1118_745_fu_26342_p2 = (!sext_ln1118_598_fu_26315_p1.read().is_01() || !sext_ln708_352_fu_26305_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_598_fu_26315_p1.read()) - sc_bigint<19>(sext_ln708_352_fu_26305_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_746_fu_18801_p2() {
    sub_ln1118_746_fu_18801_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_603_fu_18797_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_603_fu_18797_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_747_fu_18851_p2() {
    sub_ln1118_747_fu_18851_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_602_fu_18765_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_602_fu_18765_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_748_fu_18869_p2() {
    sub_ln1118_748_fu_18869_p2 = (!sub_ln1118_747_fu_18851_p2.read().is_01() || !sext_ln1118_604_fu_18865_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_747_fu_18851_p2.read()) - sc_bigint<20>(sext_ln1118_604_fu_18865_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_749_fu_18929_p2() {
    sub_ln1118_749_fu_18929_p2 = (!sub_ln1118_746_fu_18801_p2.read().is_01() || !sext_ln1118_601_fu_18753_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_746_fu_18801_p2.read()) - sc_bigint<19>(sext_ln1118_601_fu_18753_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_750_fu_18945_p2() {
    sub_ln1118_750_fu_18945_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_600_fu_18749_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_600_fu_18749_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_751_fu_18985_p2() {
    sub_ln1118_751_fu_18985_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_361_fu_18979_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_361_fu_18979_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_752_fu_3781_p2() {
    sub_ln1118_752_fu_3781_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_605_fu_3777_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_605_fu_3777_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_753_fu_3787_p2() {
    sub_ln1118_753_fu_3787_p2 = (!sub_ln1118_752_fu_3781_p2.read().is_01() || !sext_ln708_359_fu_3755_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_752_fu_3781_p2.read()) - sc_bigint<20>(sext_ln708_359_fu_3755_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_754_fu_26391_p2() {
    sub_ln1118_754_fu_26391_p2 = (!sext_ln1118_608_fu_26387_p1.read().is_01() || !sext_ln708_360_fu_26374_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_608_fu_26387_p1.read()) - sc_bigint<19>(sext_ln708_360_fu_26374_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_755_fu_19042_p2() {
    sub_ln1118_755_fu_19042_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_607_fu_19019_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_607_fu_19019_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_756_fu_19065_p2() {
    sub_ln1118_756_fu_19065_p2 = (!sext_ln1118_605_reg_37808.read().is_01() || !sext_ln1118_606_fu_19015_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_605_reg_37808.read()) - sc_bigint<20>(sext_ln1118_606_fu_19015_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_757_fu_19112_p2() {
    sub_ln1118_757_fu_19112_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_365_fu_19084_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_365_fu_19084_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_758_fu_19144_p2() {
    sub_ln1118_758_fu_19144_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_610_fu_19140_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_610_fu_19140_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_759_fu_19172_p2() {
    sub_ln1118_759_fu_19172_p2 = (!sext_ln1118_611_fu_19168_p1.read().is_01() || !sext_ln708_364_fu_19080_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_611_fu_19168_p1.read()) - sc_bigint<19>(sext_ln708_364_fu_19080_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_760_fu_19206_p2() {
    sub_ln1118_760_fu_19206_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_611_fu_19168_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_611_fu_19168_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_761_fu_19212_p2() {
    sub_ln1118_761_fu_19212_p2 = (!sub_ln1118_760_fu_19206_p2.read().is_01() || !sext_ln708_364_fu_19080_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_760_fu_19206_p2.read()) - sc_bigint<19>(sext_ln708_364_fu_19080_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_762_fu_19240_p2() {
    sub_ln1118_762_fu_19240_p2 = (!sext_ln1118_612_fu_19236_p1.read().is_01() || !sext_ln1118_609_fu_19136_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_612_fu_19236_p1.read()) - sc_bigint<20>(sext_ln1118_609_fu_19136_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_763_fu_19256_p2() {
    sub_ln1118_763_fu_19256_p2 = (!sext_ln1118_609_fu_19136_p1.read().is_01() || !sext_ln1118_612_fu_19236_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_609_fu_19136_p1.read()) - sc_bigint<20>(sext_ln1118_612_fu_19236_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_764_fu_19318_p2() {
    sub_ln1118_764_fu_19318_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_613_fu_19314_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_613_fu_19314_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_765_fu_19346_p2() {
    sub_ln1118_765_fu_19346_p2 = (!sext_ln1118_614_fu_19342_p1.read().is_01() || !sext_ln708_371_fu_19284_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_614_fu_19342_p1.read()) - sc_bigint<19>(sext_ln708_371_fu_19284_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_766_fu_19366_p2() {
    sub_ln1118_766_fu_19366_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_370_fu_19280_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_370_fu_19280_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_767_fu_19436_p2() {
    sub_ln1118_767_fu_19436_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_614_fu_19342_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_614_fu_19342_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_768_fu_19464_p2() {
    sub_ln1118_768_fu_19464_p2 = (!sext_ln1118_613_fu_19314_p1.read().is_01() || !sext_ln1118_615_fu_19460_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_613_fu_19314_p1.read()) - sc_bigint<20>(sext_ln1118_615_fu_19460_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_769_fu_19494_p2() {
    sub_ln1118_769_fu_19494_p2 = (!sub_ln1118_767_fu_19436_p2.read().is_01() || !sext_ln708_371_fu_19284_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_767_fu_19436_p2.read()) - sc_bigint<19>(sext_ln708_371_fu_19284_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_770_fu_19536_p2() {
    sub_ln1118_770_fu_19536_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_377_fu_19518_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_377_fu_19518_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_771_fu_19580_p2() {
    sub_ln1118_771_fu_19580_p2 = (!sext_ln1118_617_fu_19576_p1.read().is_01() || !sext_ln1118_616_fu_19564_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_617_fu_19576_p1.read()) - sc_bigint<20>(sext_ln1118_616_fu_19564_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_772_fu_19596_p2() {
    sub_ln1118_772_fu_19596_p2 = (!sext_ln1118_616_fu_19564_p1.read().is_01() || !sext_ln708_375_fu_19510_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_616_fu_19564_p1.read()) - sc_bigint<20>(sext_ln708_375_fu_19510_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_773_fu_19624_p2() {
    sub_ln1118_773_fu_19624_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_618_fu_19620_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_618_fu_19620_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_774_fu_19630_p2() {
    sub_ln1118_774_fu_19630_p2 = (!sub_ln1118_773_fu_19624_p2.read().is_01() || !sext_ln708_376_fu_19514_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_773_fu_19624_p2.read()) - sc_bigint<19>(sext_ln708_376_fu_19514_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_775_fu_19666_p2() {
    sub_ln1118_775_fu_19666_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_616_fu_19564_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_616_fu_19564_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_776_fu_19672_p2() {
    sub_ln1118_776_fu_19672_p2 = (!sub_ln1118_775_fu_19666_p2.read().is_01() || !sext_ln1118_617_fu_19576_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_775_fu_19666_p2.read()) - sc_bigint<20>(sext_ln1118_617_fu_19576_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_777_fu_19728_p2() {
    sub_ln1118_777_fu_19728_p2 = (!sext_ln1118_624_fu_19724_p1.read().is_01() || !sext_ln1118_622_fu_19708_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_624_fu_19724_p1.read()) - sc_bigint<20>(sext_ln1118_622_fu_19708_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_778_fu_19762_p2() {
    sub_ln1118_778_fu_19762_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_620_fu_19692_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_620_fu_19692_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_779_fu_19812_p2() {
    sub_ln1118_779_fu_19812_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_625_fu_19808_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_625_fu_19808_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_780_fu_19818_p2() {
    sub_ln1118_780_fu_19818_p2 = (!sub_ln1118_779_fu_19812_p2.read().is_01() || !sext_ln1118_621_fu_19696_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_779_fu_19812_p2.read()) - sc_bigint<19>(sext_ln1118_621_fu_19696_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_781_fu_19870_p2() {
    sub_ln1118_781_fu_19870_p2 = (!sext_ln1118_622_fu_19708_p1.read().is_01() || !sext_ln1118_624_fu_19724_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_622_fu_19708_p1.read()) - sc_bigint<20>(sext_ln1118_624_fu_19724_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_782_fu_19896_p2() {
    sub_ln1118_782_fu_19896_p2 = (!sext_ln1118_625_fu_19808_p1.read().is_01() || !sext_ln1118_621_fu_19696_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_625_fu_19808_p1.read()) - sc_bigint<19>(sext_ln1118_621_fu_19696_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_783_fu_19916_p2() {
    sub_ln1118_783_fu_19916_p2 = (!sext_ln1118_622_fu_19708_p1.read().is_01() || !sext_ln1118_619_fu_19688_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_622_fu_19708_p1.read()) - sc_bigint<20>(sext_ln1118_619_fu_19688_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_784_fu_19932_p2() {
    sub_ln1118_784_fu_19932_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_623_fu_19720_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_623_fu_19720_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_785_fu_20026_p2() {
    sub_ln1118_785_fu_20026_p2 = (!sext_ln1118_633_fu_20022_p1.read().is_01() || !sext_ln1118_631_fu_20007_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_633_fu_20022_p1.read()) - sc_bigint<20>(sext_ln1118_631_fu_20007_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_786_fu_20046_p2() {
    sub_ln1118_786_fu_20046_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_630_fu_19980_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_630_fu_19980_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_787_fu_20065_p2() {
    sub_ln1118_787_fu_20065_p2 = (!sub_ln1118_786_fu_20046_p2.read().is_01() || !sext_ln1118_629_fu_19970_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_786_fu_20046_p2.read()) - sc_bigint<19>(sext_ln1118_629_fu_19970_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_788_fu_20081_p2() {
    sub_ln1118_788_fu_20081_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_628_fu_19967_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_628_fu_19967_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_789_fu_20101_p2() {
    sub_ln1118_789_fu_20101_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_631_fu_20007_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_631_fu_20007_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_790_fu_20107_p2() {
    sub_ln1118_790_fu_20107_p2 = (!sub_ln1118_789_fu_20101_p2.read().is_01() || !sext_ln1118_627_fu_19964_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_789_fu_20101_p2.read()) - sc_bigint<20>(sext_ln1118_627_fu_19964_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_791_fu_20133_p2() {
    sub_ln1118_791_fu_20133_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_632_fu_20018_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_632_fu_20018_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_792_fu_20152_p2() {
    sub_ln1118_792_fu_20152_p2 = (!sext_ln1118_631_fu_20007_p1.read().is_01() || !sext_ln1118_633_fu_20022_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_631_fu_20007_p1.read()) - sc_bigint<20>(sext_ln1118_633_fu_20022_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_793_fu_20202_p2() {
    sub_ln1118_793_fu_20202_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_634_fu_20198_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_634_fu_20198_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_794_fu_20234_p2() {
    sub_ln1118_794_fu_20234_p2 = (!sext_ln1118_635_fu_20230_p1.read().is_01() || !sext_ln708_386_fu_20172_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_635_fu_20230_p1.read()) - sc_bigint<19>(sext_ln708_386_fu_20172_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_795_fu_20294_p2() {
    sub_ln1118_795_fu_20294_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_640_fu_20291_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_640_fu_20291_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_796_fu_20325_p2() {
    sub_ln1118_796_fu_20325_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_641_fu_20321_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_641_fu_20321_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_797_fu_26565_p2() {
    sub_ln1118_797_fu_26565_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_642_fu_26561_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_642_fu_26561_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_798_fu_26585_p2() {
    sub_ln1118_798_fu_26585_p2 = (!sext_ln1118_642_fu_26561_p1.read().is_01() || !sext_ln1118_639_fu_26545_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_642_fu_26561_p1.read()) - sc_bigint<19>(sext_ln1118_639_fu_26545_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_799_fu_20352_p2() {
    sub_ln1118_799_fu_20352_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_643_fu_20348_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_643_fu_20348_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_800_fu_20358_p2() {
    sub_ln1118_800_fu_20358_p2 = (!sub_ln1118_799_fu_20352_p2.read().is_01() || !sext_ln1118_638_fu_20288_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_799_fu_20352_p2.read()) - sc_bigint<20>(sext_ln1118_638_fu_20288_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_801_fu_26614_p2() {
    sub_ln1118_801_fu_26614_p2 = (!sub_ln1118_797_fu_26565_p2.read().is_01() || !sext_ln1118_639_fu_26545_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_797_fu_26565_p2.read()) - sc_bigint<19>(sext_ln1118_639_fu_26545_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_802_fu_20467_p2() {
    sub_ln1118_802_fu_20467_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_646_fu_20463_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_646_fu_20463_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_803_fu_20487_p2() {
    sub_ln1118_803_fu_20487_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_644_fu_20431_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_644_fu_20431_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_804_fu_20519_p2() {
    sub_ln1118_804_fu_20519_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_647_fu_20515_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_647_fu_20515_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_805_fu_20525_p2() {
    sub_ln1118_805_fu_20525_p2 = (!sub_ln1118_804_fu_20519_p2.read().is_01() || !sext_ln708_394_fu_20405_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_804_fu_20519_p2.read()) - sc_bigint<19>(sext_ln708_394_fu_20405_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_806_fu_20567_p2() {
    sub_ln1118_806_fu_20567_p2 = (!ap_const_lv17_0.is_01() || !sext_ln708_393_fu_20401_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln708_393_fu_20401_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_807_fu_20587_p2() {
    sub_ln1118_807_fu_20587_p2 = (!sext_ln1118_647_fu_20515_p1.read().is_01() || !sext_ln708_394_fu_20405_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_647_fu_20515_p1.read()) - sc_bigint<19>(sext_ln708_394_fu_20405_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_808_fu_20619_p2() {
    sub_ln1118_808_fu_20619_p2 = (!sext_ln1118_644_fu_20431_p1.read().is_01() || !sext_ln1118_645_fu_20459_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_644_fu_20431_p1.read()) - sc_bigint<20>(sext_ln1118_645_fu_20459_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_809_fu_20659_p2() {
    sub_ln1118_809_fu_20659_p2 = (!sext_ln1118_645_fu_20459_p1.read().is_01() || !sext_ln1118_644_fu_20431_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_645_fu_20459_p1.read()) - sc_bigint<20>(sext_ln1118_644_fu_20431_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_810_fu_20699_p2() {
    sub_ln1118_810_fu_20699_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_652_fu_20695_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_652_fu_20695_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_811_fu_26697_p2() {
    sub_ln1118_811_fu_26697_p2 = (!sext_ln1118_653_fu_26693_p1.read().is_01() || !sext_ln1118_649_fu_26680_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_653_fu_26693_p1.read()) - sc_bigint<19>(sext_ln1118_649_fu_26680_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_812_fu_20753_p2() {
    sub_ln1118_812_fu_20753_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_654_fu_20723_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_654_fu_20723_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_813_fu_20759_p2() {
    sub_ln1118_813_fu_20759_p2 = (!sub_ln1118_812_fu_20753_p2.read().is_01() || !sext_ln1118_651_fu_20691_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_812_fu_20753_p2.read()) - sc_bigint<20>(sext_ln1118_651_fu_20691_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_814_fu_26746_p2() {
    sub_ln1118_814_fu_26746_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_653_fu_26693_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_653_fu_26693_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_815_fu_26789_p2() {
    sub_ln1118_815_fu_26789_p2 = (!sub_ln1118_814_fu_26746_p2.read().is_01() || !sext_ln1118_649_fu_26680_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_814_fu_26746_p2.read()) - sc_bigint<19>(sext_ln1118_649_fu_26680_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_816_fu_20823_p2() {
    sub_ln1118_816_fu_20823_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_650_fu_20679_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_650_fu_20679_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_817_fu_20863_p2() {
    sub_ln1118_817_fu_20863_p2 = (!sext_ln1118_657_fu_20859_p1.read().is_01() || !sext_ln1118_656_fu_20847_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_657_fu_20859_p1.read()) - sc_bigint<19>(sext_ln1118_656_fu_20847_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_818_fu_20899_p2() {
    sub_ln1118_818_fu_20899_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_659_fu_20895_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_659_fu_20895_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_819_fu_20945_p2() {
    sub_ln1118_819_fu_20945_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_657_fu_20859_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_657_fu_20859_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_820_fu_20951_p2() {
    sub_ln1118_820_fu_20951_p2 = (!sub_ln1118_819_fu_20945_p2.read().is_01() || !sext_ln1118_656_fu_20847_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_819_fu_20945_p2.read()) - sc_bigint<19>(sext_ln1118_656_fu_20847_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_821_fu_21003_p2() {
    sub_ln1118_821_fu_21003_p2 = (!sext_ln1118_660_fu_20999_p1.read().is_01() || !sext_ln1118_658_fu_20891_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_660_fu_20999_p1.read()) - sc_bigint<20>(sext_ln1118_658_fu_20891_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_822_fu_21037_p2() {
    sub_ln1118_822_fu_21037_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_655_fu_20843_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_655_fu_20843_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_823_fu_21061_p2() {
    sub_ln1118_823_fu_21061_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_663_fu_21057_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_663_fu_21057_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_824_fu_21093_p2() {
    sub_ln1118_824_fu_21093_p2 = (!ap_const_lv18_0.is_01() || !sext_ln1118_665_fu_21089_p1.read().is_01())? sc_lv<18>(): (sc_biguint<18>(ap_const_lv18_0) - sc_bigint<18>(sext_ln1118_665_fu_21089_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_825_fu_26898_p2() {
    sub_ln1118_825_fu_26898_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_664_fu_26836_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_664_fu_26836_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_826_fu_26918_p2() {
    sub_ln1118_826_fu_26918_p2 = (!sext_ln1118_664_fu_26836_p1.read().is_01() || !sext_ln1118_662_fu_26826_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_664_fu_26836_p1.read()) - sc_bigint<19>(sext_ln1118_662_fu_26826_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_827_fu_21147_p2() {
    sub_ln1118_827_fu_21147_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_670_fu_21143_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_670_fu_21143_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_828_fu_21167_p2() {
    sub_ln1118_828_fu_21167_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_669_fu_21131_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_669_fu_21131_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_829_fu_21201_p2() {
    sub_ln1118_829_fu_21201_p2 = (!sub_ln1118_827_fu_21147_p2.read().is_01() || !sext_ln1118_668_fu_21127_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_827_fu_21147_p2.read()) - sc_bigint<19>(sext_ln1118_668_fu_21127_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_830_fu_21271_p2() {
    sub_ln1118_830_fu_21271_p2 = (!sext_ln1118_671_fu_21255_p1.read().is_01() || !sext_ln1118_672_fu_21267_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_671_fu_21255_p1.read()) - sc_bigint<20>(sext_ln1118_672_fu_21267_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_831_fu_21303_p2() {
    sub_ln1118_831_fu_21303_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_671_fu_21255_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_671_fu_21255_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_832_fu_21309_p2() {
    sub_ln1118_832_fu_21309_p2 = (!sub_ln1118_831_fu_21303_p2.read().is_01() || !sext_ln1118_667_fu_21123_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_831_fu_21303_p2.read()) - sc_bigint<20>(sext_ln1118_667_fu_21123_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_833_fu_21325_p2() {
    sub_ln1118_833_fu_21325_p2 = (!sext_ln1118_670_fu_21143_p1.read().is_01() || !sext_ln1118_668_fu_21127_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_670_fu_21143_p1.read()) - sc_bigint<19>(sext_ln1118_668_fu_21127_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_834_fu_21341_p2() {
    sub_ln1118_834_fu_21341_p2 = (!sext_ln1118_672_fu_21267_p1.read().is_01() || !sext_ln1118_671_fu_21255_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_672_fu_21267_p1.read()) - sc_bigint<20>(sext_ln1118_671_fu_21255_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_835_fu_21381_p2() {
    sub_ln1118_835_fu_21381_p2 = (!ap_const_lv19_0.is_01() || !sext_ln1118_675_fu_21377_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(ap_const_lv19_0) - sc_bigint<19>(sext_ln1118_675_fu_21377_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_836_fu_21413_p2() {
    sub_ln1118_836_fu_21413_p2 = (!ap_const_lv17_0.is_01() || !sext_ln1118_674_fu_21365_p1.read().is_01())? sc_lv<17>(): (sc_biguint<17>(ap_const_lv17_0) - sc_bigint<17>(sext_ln1118_674_fu_21365_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_837_fu_21457_p2() {
    sub_ln1118_837_fu_21457_p2 = (!sext_ln1118_676_fu_21441_p1.read().is_01() || !sext_ln1118_677_fu_21453_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_676_fu_21441_p1.read()) - sc_bigint<20>(sext_ln1118_677_fu_21453_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_838_fu_21515_p2() {
    sub_ln1118_838_fu_21515_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_676_fu_21441_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_676_fu_21441_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_839_fu_21521_p2() {
    sub_ln1118_839_fu_21521_p2 = (!sub_ln1118_838_fu_21515_p2.read().is_01() || !sext_ln1118_677_fu_21453_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_838_fu_21515_p2.read()) - sc_bigint<20>(sext_ln1118_677_fu_21453_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_840_fu_21537_p2() {
    sub_ln1118_840_fu_21537_p2 = (!sext_ln1118_675_fu_21377_p1.read().is_01() || !sext_ln1118_673_fu_21361_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_675_fu_21377_p1.read()) - sc_bigint<19>(sext_ln1118_673_fu_21361_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_841_fu_21557_p2() {
    sub_ln1118_841_fu_21557_p2 = (!sub_ln1118_835_fu_21381_p2.read().is_01() || !sext_ln1118_673_fu_21361_p1.read().is_01())? sc_lv<19>(): (sc_biguint<19>(sub_ln1118_835_fu_21381_p2.read()) - sc_bigint<19>(sext_ln1118_673_fu_21361_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_842_fu_3895_p2() {
    sub_ln1118_842_fu_3895_p2 = (!sext_ln1118_156_fu_3846_p1.read().is_01() || !sext_ln1118_158_fu_3849_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_156_fu_3846_p1.read()) - sc_bigint<19>(sext_ln1118_158_fu_3849_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_843_fu_2268_p2() {
    sub_ln1118_843_fu_2268_p2 = (!sext_ln1118_163_fu_2252_p1.read().is_01() || !sext_ln1118_164_fu_2264_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_163_fu_2252_p1.read()) - sc_bigint<20>(sext_ln1118_164_fu_2264_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_844_fu_4070_p2() {
    sub_ln1118_844_fu_4070_p2 = (!sext_ln1118_162_fu_3971_p1.read().is_01() || !sext_ln1118_166_fu_3995_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_162_fu_3971_p1.read()) - sc_bigint<19>(sext_ln1118_166_fu_3995_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_845_fu_2378_p2() {
    sub_ln1118_845_fu_2378_p2 = (!sext_ln708_fu_2310_p1.read().is_01() || !sext_ln1118_168_fu_2332_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_fu_2310_p1.read()) - sc_bigint<20>(sext_ln1118_168_fu_2332_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_846_fu_4246_p2() {
    sub_ln1118_846_fu_4246_p2 = (!sext_ln1118_174_fu_4229_p1.read().is_01() || !sext_ln1118_176_fu_4242_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_174_fu_4229_p1.read()) - sc_bigint<19>(sext_ln1118_176_fu_4242_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_847_fu_4691_p2() {
    sub_ln1118_847_fu_4691_p2 = (!sext_ln1118_192_fu_4671_p1.read().is_01() || !sext_ln1118_194_fu_4687_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_192_fu_4671_p1.read()) - sc_bigint<19>(sext_ln1118_194_fu_4687_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_848_fu_4985_p2() {
    sub_ln1118_848_fu_4985_p2 = (!sext_ln1118_199_fu_4889_p1.read().is_01() || !sext_ln1118_200_fu_4901_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_199_fu_4889_p1.read()) - sc_bigint<19>(sext_ln1118_200_fu_4901_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_849_fu_5227_p2() {
    sub_ln1118_849_fu_5227_p2 = (!sext_ln1118_207_fu_5211_p1.read().is_01() || !sext_ln1118_208_fu_5223_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_207_fu_5211_p1.read()) - sc_bigint<19>(sext_ln1118_208_fu_5223_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_850_fu_5463_p2() {
    sub_ln1118_850_fu_5463_p2 = (!sext_ln1118_205_fu_5203_p1.read().is_01() || !sext_ln1118_209_fu_5271_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_205_fu_5203_p1.read()) - sc_bigint<20>(sext_ln1118_209_fu_5271_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_851_fu_5651_p2() {
    sub_ln1118_851_fu_5651_p2 = (!sext_ln1118_212_fu_5479_p1.read().is_01() || !sext_ln1118_218_fu_5647_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_212_fu_5479_p1.read()) - sc_bigint<20>(sext_ln1118_218_fu_5647_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_852_fu_5721_p2() {
    sub_ln1118_852_fu_5721_p2 = (!sext_ln1118_214_fu_5487_p1.read().is_01() || !sext_ln1118_215_fu_5499_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_214_fu_5487_p1.read()) - sc_bigint<19>(sext_ln1118_215_fu_5499_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_853_fu_5823_p2() {
    sub_ln1118_853_fu_5823_p2 = (!sext_ln1118_220_fu_5740_p1.read().is_01() || !sext_ln1118_221_reg_37380.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_220_fu_5740_p1.read()) - sc_bigint<19>(sext_ln1118_221_reg_37380.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_854_fu_5876_p2() {
    sub_ln1118_854_fu_5876_p2 = (!sext_ln708_136_fu_5846_p1.read().is_01() || !sext_ln1118_225_fu_5872_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_136_fu_5846_p1.read()) - sc_bigint<19>(sext_ln1118_225_fu_5872_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_855_fu_5966_p2() {
    sub_ln1118_855_fu_5966_p2 = (!sext_ln708_135_fu_5842_p1.read().is_01() || !sext_ln1118_228_fu_5946_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_135_fu_5842_p1.read()) - sc_bigint<20>(sext_ln1118_228_fu_5946_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_856_fu_24742_p2() {
    sub_ln1118_856_fu_24742_p2 = (!sext_ln1118_232_fu_24708_p1.read().is_01() || !sext_ln1118_234_fu_24718_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_232_fu_24708_p1.read()) - sc_bigint<19>(sext_ln1118_234_fu_24718_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_857_fu_6146_p2() {
    sub_ln1118_857_fu_6146_p2 = (!sext_ln1118_231_reg_37429.read().is_01() || !sext_ln1118_237_reg_37446.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_231_reg_37429.read()) - sc_bigint<20>(sext_ln1118_237_reg_37446.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_858_fu_6265_p2() {
    sub_ln1118_858_fu_6265_p2 = (!sext_ln708_145_fu_6171_p1.read().is_01() || !sext_ln1118_240_fu_6245_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_145_fu_6171_p1.read()) - sc_bigint<19>(sext_ln1118_240_fu_6245_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_859_fu_6385_p2() {
    sub_ln1118_859_fu_6385_p2 = (!sext_ln1118_241_fu_6361_p1.read().is_01() || !sext_ln1118_244_fu_6381_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_241_fu_6361_p1.read()) - sc_bigint<20>(sext_ln1118_244_fu_6381_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_860_fu_6487_p2() {
    sub_ln1118_860_fu_6487_p2 = (!sext_ln1118_243_fu_6369_p1.read().is_01() || !sext_ln1118_245_fu_6431_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_243_fu_6369_p1.read()) - sc_bigint<19>(sext_ln1118_245_fu_6431_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_861_fu_6757_p2() {
    sub_ln1118_861_fu_6757_p2 = (!sext_ln708_152_fu_6607_p1.read().is_01() || !sext_ln1118_248_fu_6637_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_152_fu_6607_p1.read()) - sc_bigint<19>(sext_ln1118_248_fu_6637_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_862_fu_6853_p2() {
    sub_ln1118_862_fu_6853_p2 = (!sext_ln708_155_fu_6777_p1.read().is_01() || !sext_ln1118_252_fu_6849_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_155_fu_6777_p1.read()) - sc_bigint<20>(sext_ln1118_252_fu_6849_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_863_fu_7207_p2() {
    sub_ln1118_863_fu_7207_p2 = (!sext_ln1118_256_fu_7019_p1.read().is_01() || !sext_ln1118_260_fu_7067_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_256_fu_7019_p1.read()) - sc_bigint<20>(sext_ln1118_260_fu_7067_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_864_fu_7227_p2() {
    sub_ln1118_864_fu_7227_p2 = (!sext_ln1118_258_fu_7027_p1.read().is_01() || !sext_ln1118_259_fu_7039_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_258_fu_7027_p1.read()) - sc_bigint<19>(sext_ln1118_259_fu_7039_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_865_fu_7351_p2() {
    sub_ln1118_865_fu_7351_p2 = (!sext_ln708_164_fu_7251_p1.read().is_01() || !sext_ln1118_264_fu_7347_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_164_fu_7251_p1.read()) - sc_bigint<20>(sext_ln1118_264_fu_7347_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_866_fu_7495_p2() {
    sub_ln1118_866_fu_7495_p2 = (!sext_ln1118_267_fu_7479_p1.read().is_01() || !sext_ln1118_268_fu_7491_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_267_fu_7479_p1.read()) - sc_bigint<19>(sext_ln1118_268_fu_7491_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_867_fu_7677_p2() {
    sub_ln1118_867_fu_7677_p2 = (!sext_ln1118_273_fu_7657_p1.read().is_01() || !sext_ln1118_275_fu_7673_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_273_fu_7657_p1.read()) - sc_bigint<19>(sext_ln1118_275_fu_7673_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_868_fu_2822_p2() {
    sub_ln1118_868_fu_2822_p2 = (!sext_ln1118_294_fu_2736_p1.read().is_01() || !sext_ln1118_298_fu_2749_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_294_fu_2736_p1.read()) - sc_bigint<20>(sext_ln1118_298_fu_2749_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_869_fu_8454_p2() {
    sub_ln1118_869_fu_8454_p2 = (!sext_ln1118_297_fu_8389_p1.read().is_01() || !sext_ln1118_301_fu_8405_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_297_fu_8389_p1.read()) - sc_bigint<19>(sext_ln1118_301_fu_8405_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_870_fu_8921_p2() {
    sub_ln1118_870_fu_8921_p2 = (!sext_ln1118_310_reg_37498.read().is_01() || !sext_ln1118_313_reg_37504.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_310_reg_37498.read()) - sc_bigint<20>(sext_ln1118_313_reg_37504.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_871_fu_8939_p2() {
    sub_ln1118_871_fu_8939_p2 = (!sext_ln1118_311_fu_8773_p1.read().is_01() || !sext_ln1118_312_fu_8783_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_311_fu_8773_p1.read()) - sc_bigint<19>(sext_ln1118_312_fu_8783_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_872_fu_8975_p2() {
    sub_ln1118_872_fu_8975_p2 = (!sext_ln1118_316_fu_8959_p1.read().is_01() || !sext_ln1118_317_fu_8971_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_316_fu_8959_p1.read()) - sc_bigint<19>(sext_ln1118_317_fu_8971_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_873_fu_9289_p2() {
    sub_ln1118_873_fu_9289_p2 = (!sext_ln1118_323_fu_9174_p1.read().is_01() || !sext_ln1118_327_fu_9269_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_323_fu_9174_p1.read()) - sc_bigint<19>(sext_ln1118_327_fu_9269_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_874_fu_2990_p2() {
    sub_ln1118_874_fu_2990_p2 = (!sext_ln1118_321_fu_2922_p1.read().is_01() || !sext_ln1118_324_fu_2934_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_321_fu_2922_p1.read()) - sc_bigint<20>(sext_ln1118_324_fu_2934_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_875_fu_3092_p2() {
    sub_ln1118_875_fu_3092_p2 = (!sext_ln708_192_fu_3006_p1.read().is_01() || !sext_ln1118_331_fu_3088_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_192_fu_3006_p1.read()) - sc_bigint<19>(sext_ln1118_331_fu_3088_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_876_fu_9376_p2() {
    sub_ln1118_876_fu_9376_p2 = (!sext_ln1118_333_fu_9360_p1.read().is_01() || !sext_ln1118_334_fu_9372_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_333_fu_9360_p1.read()) - sc_bigint<19>(sext_ln1118_334_fu_9372_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_877_fu_10196_p2() {
    sub_ln1118_877_fu_10196_p2 = (!sext_ln1118_353_fu_10119_p1.read().is_01() || !sext_ln1118_355_reg_37579.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_353_fu_10119_p1.read()) - sc_bigint<20>(sext_ln1118_355_reg_37579.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_878_fu_10262_p2() {
    sub_ln1118_878_fu_10262_p2 = (!sext_ln1118_354_fu_10122_p1.read().is_01() || !sext_ln1118_356_fu_10147_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_354_fu_10122_p1.read()) - sc_bigint<19>(sext_ln1118_356_fu_10147_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_879_fu_10319_p2() {
    sub_ln1118_879_fu_10319_p2 = (!sext_ln1118_359_fu_10299_p1.read().is_01() || !sext_ln1118_361_fu_10315_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_359_fu_10299_p1.read()) - sc_bigint<19>(sext_ln1118_361_fu_10315_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_880_fu_10503_p2() {
    sub_ln1118_880_fu_10503_p2 = (!sext_ln1118_365_fu_10483_p1.read().is_01() || !sext_ln1118_367_fu_10499_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_365_fu_10483_p1.read()) - sc_bigint<19>(sext_ln1118_367_fu_10499_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_881_fu_10719_p2() {
    sub_ln1118_881_fu_10719_p2 = (!sext_ln1118_371_fu_10699_p1.read().is_01() || !sext_ln1118_373_fu_10715_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_371_fu_10699_p1.read()) - sc_bigint<19>(sext_ln1118_373_fu_10715_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_882_fu_3250_p2() {
    sub_ln1118_882_fu_3250_p2 = (!sext_ln708_221_fu_3224_p1.read().is_01() || !sext_ln1118_378_fu_3246_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_221_fu_3224_p1.read()) - sc_bigint<20>(sext_ln1118_378_fu_3246_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_883_fu_11092_p2() {
    sub_ln1118_883_fu_11092_p2 = (!sext_ln708_223_fu_10980_p1.read().is_01() || !sext_ln1118_377_fu_10993_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_223_fu_10980_p1.read()) - sc_bigint<19>(sext_ln1118_377_fu_10993_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_884_fu_11237_p2() {
    sub_ln1118_884_fu_11237_p2 = (!sext_ln1118_381_fu_11186_p1.read().is_01() || !sext_ln1118_385_fu_11202_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_381_fu_11186_p1.read()) - sc_bigint<20>(sext_ln1118_385_fu_11202_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_885_fu_11329_p2() {
    sub_ln1118_885_fu_11329_p2 = (!sext_ln1118_384_fu_11192_p1.read().is_01() || !sext_ln1118_387_fu_11273_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_384_fu_11192_p1.read()) - sc_bigint<19>(sext_ln1118_387_fu_11273_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_886_fu_3348_p2() {
    sub_ln1118_886_fu_3348_p2 = (!sext_ln708_229_fu_3312_p1.read().is_01() || !sext_ln1118_389_fu_3344_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_229_fu_3312_p1.read()) - sc_bigint<20>(sext_ln1118_389_fu_3344_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_887_fu_11495_p2() {
    sub_ln1118_887_fu_11495_p2 = (!sext_ln708_231_fu_11400_p1.read().is_01() || !sext_ln1118_388_fu_11410_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_231_fu_11400_p1.read()) - sc_bigint<19>(sext_ln1118_388_fu_11410_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_888_fu_11675_p2() {
    sub_ln1118_888_fu_11675_p2 = (!sext_ln1118_392_fu_11539_p1.read().is_01() || !sext_ln1118_395_fu_11617_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_392_fu_11539_p1.read()) - sc_bigint<19>(sext_ln1118_395_fu_11617_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_889_fu_11817_p2() {
    sub_ln1118_889_fu_11817_p2 = (!sext_ln1118_398_fu_11725_p1.read().is_01() || !sext_ln1118_400_fu_11793_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_398_fu_11725_p1.read()) - sc_bigint<19>(sext_ln1118_400_fu_11793_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_890_fu_11969_p2() {
    sub_ln1118_890_fu_11969_p2 = (!sext_ln1118_403_fu_11953_p1.read().is_01() || !sext_ln1118_404_fu_11965_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_403_fu_11953_p1.read()) - sc_bigint<19>(sext_ln1118_404_fu_11965_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_891_fu_12143_p2() {
    sub_ln1118_891_fu_12143_p2 = (!sext_ln1118_408_fu_12127_p1.read().is_01() || !sext_ln1118_409_fu_12139_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_408_fu_12127_p1.read()) - sc_bigint<19>(sext_ln1118_409_fu_12139_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_892_fu_12397_p2() {
    sub_ln1118_892_fu_12397_p2 = (!sext_ln708_244_fu_12377_p1.read().is_01() || !sext_ln1118_413_fu_12393_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_244_fu_12377_p1.read()) - sc_bigint<19>(sext_ln1118_413_fu_12393_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_893_fu_12683_p2() {
    sub_ln1118_893_fu_12683_p2 = (!sext_ln708_248_fu_12545_p1.read().is_01() || !sext_ln1118_418_fu_12641_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_248_fu_12545_p1.read()) - sc_bigint<19>(sext_ln1118_418_fu_12641_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_894_fu_12807_p2() {
    sub_ln1118_894_fu_12807_p2 = (!sext_ln1118_420_fu_12731_p1.read().is_01() || !sext_ln1118_424_reg_37685.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_420_fu_12731_p1.read()) - sc_bigint<20>(sext_ln1118_424_reg_37685.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_895_fu_12973_p2() {
    sub_ln1118_895_fu_12973_p2 = (!sext_ln708_255_fu_12845_p1.read().is_01() || !sext_ln1118_426_fu_12871_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_255_fu_12845_p1.read()) - sc_bigint<20>(sext_ln1118_426_fu_12871_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_896_fu_25527_p2() {
    sub_ln1118_896_fu_25527_p2 = (!sext_ln1118_437_fu_25425_p1.read().is_01() || !sext_ln1118_441_fu_25441_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_437_fu_25425_p1.read()) - sc_bigint<19>(sext_ln1118_441_fu_25441_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_897_fu_13335_p2() {
    sub_ln1118_897_fu_13335_p2 = (!sext_ln1118_445_fu_13260_p1.read().is_01() || !sext_ln1118_446_fu_13270_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_445_fu_13260_p1.read()) - sc_bigint<19>(sext_ln1118_446_fu_13270_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_898_fu_13500_p2() {
    sub_ln1118_898_fu_13500_p2 = (!sext_ln1118_450_fu_13456_p1.read().is_01() || !sext_ln1118_453_fu_13496_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_450_fu_13456_p1.read()) - sc_bigint<20>(sext_ln1118_453_fu_13496_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_899_fu_13876_p2() {
    sub_ln1118_899_fu_13876_p2 = (!sext_ln708_276_fu_13733_p1.read().is_01() || !sext_ln1118_463_fu_13781_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_276_fu_13733_p1.read()) - sc_bigint<20>(sext_ln1118_463_fu_13781_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_900_fu_13912_p2() {
    sub_ln1118_900_fu_13912_p2 = (!sext_ln708_278_fu_13739_p1.read().is_01() || !sext_ln1118_462_fu_13751_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_278_fu_13739_p1.read()) - sc_bigint<19>(sext_ln1118_462_fu_13751_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_901_fu_14044_p2() {
    sub_ln1118_901_fu_14044_p2 = (!sext_ln1118_468_fu_13980_p1.read().is_01() || !sext_ln1118_471_fu_14040_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_468_fu_13980_p1.read()) - sc_bigint<19>(sext_ln1118_471_fu_14040_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_902_fu_25683_p2() {
    sub_ln1118_902_fu_25683_p2 = (!sext_ln1118_473_fu_25643_p1.read().is_01() || !sext_ln1118_476_fu_25659_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_473_fu_25643_p1.read()) - sc_bigint<19>(sext_ln1118_476_fu_25659_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_903_fu_14282_p2() {
    sub_ln1118_903_fu_14282_p2 = (!sext_ln1118_478_fu_14220_p1.read().is_01() || !sext_ln1118_480_fu_14256_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_478_fu_14220_p1.read()) - sc_bigint<19>(sext_ln1118_480_fu_14256_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_904_fu_14372_p2() {
    sub_ln1118_904_fu_14372_p2 = (!sext_ln1118_477_fu_14216_p1.read().is_01() || !sext_ln1118_481_fu_14334_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_477_fu_14216_p1.read()) - sc_bigint<20>(sext_ln1118_481_fu_14334_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_905_fu_14440_p2() {
    sub_ln1118_905_fu_14440_p2 = (!sext_ln1118_483_fu_14424_p1.read().is_01() || !sext_ln1118_484_fu_14436_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_483_fu_14424_p1.read()) - sc_bigint<19>(sext_ln1118_484_fu_14436_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_906_fu_14750_p2() {
    sub_ln1118_906_fu_14750_p2 = (!sext_ln708_291_fu_14632_p1.read().is_01() || !sext_ln1118_487_fu_14672_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_291_fu_14632_p1.read()) - sc_bigint<19>(sext_ln1118_487_fu_14672_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_907_fu_14834_p2() {
    sub_ln1118_907_fu_14834_p2 = (!sext_ln1118_490_fu_14818_p1.read().is_01() || !sext_ln1118_491_fu_14830_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_490_fu_14818_p1.read()) - sc_bigint<19>(sext_ln1118_491_fu_14830_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_908_fu_15102_p2() {
    sub_ln1118_908_fu_15102_p2 = (!sext_ln1118_494_fu_14982_p1.read().is_01() || !sext_ln1118_498_fu_15078_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_494_fu_14982_p1.read()) - sc_bigint<19>(sext_ln1118_498_fu_15078_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_909_fu_15152_p2() {
    sub_ln1118_909_fu_15152_p2 = (!sext_ln1118_493_fu_14978_p1.read().is_01() || !sext_ln1118_496_fu_15018_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_493_fu_14978_p1.read()) - sc_bigint<20>(sext_ln1118_496_fu_15018_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_910_fu_25807_p2() {
    sub_ln1118_910_fu_25807_p2 = (!sext_ln1118_502_reg_39497.read().is_01() || !sext_ln1118_503_reg_39504.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_502_reg_39497.read()) - sc_bigint<19>(sext_ln1118_503_reg_39504.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_911_fu_25904_p2() {
    sub_ln1118_911_fu_25904_p2 = (!sext_ln1118_509_reg_39536.read().is_01() || !sext_ln1118_510_reg_39543.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_509_reg_39536.read()) - sc_bigint<19>(sext_ln1118_510_reg_39543.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_912_fu_15469_p2() {
    sub_ln1118_912_fu_15469_p2 = (!sext_ln1118_507_fu_15339_p1.read().is_01() || !sext_ln1118_512_fu_15445_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_507_fu_15339_p1.read()) - sc_bigint<20>(sext_ln1118_512_fu_15445_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_913_fu_15561_p2() {
    sub_ln1118_913_fu_15561_p2 = (!sext_ln1118_514_fu_15521_p1.read().is_01() || !sext_ln1118_516_fu_15557_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_514_fu_15521_p1.read()) - sc_bigint<19>(sext_ln1118_516_fu_15557_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_914_fu_15751_p2() {
    sub_ln1118_914_fu_15751_p2 = (!sext_ln1118_513_fu_15517_p1.read().is_01() || !sext_ln1118_518_fu_15647_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_513_fu_15517_p1.read()) - sc_bigint<20>(sext_ln1118_518_fu_15647_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_915_fu_15811_p2() {
    sub_ln1118_915_fu_15811_p2 = (!sext_ln1118_519_fu_15791_p1.read().is_01() || !sext_ln1118_521_fu_15807_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_519_fu_15791_p1.read()) - sc_bigint<19>(sext_ln1118_521_fu_15807_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_916_fu_16077_p2() {
    sub_ln1118_916_fu_16077_p2 = (!sext_ln1118_523_fu_15943_p1.read().is_01() || !sext_ln1118_526_fu_15963_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_523_fu_15943_p1.read()) - sc_bigint<20>(sext_ln1118_526_fu_15963_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_917_fu_16177_p2() {
    sub_ln1118_917_fu_16177_p2 = (!sext_ln1118_525_fu_15951_p1.read().is_01() || !sext_ln1118_527_fu_15995_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_525_fu_15951_p1.read()) - sc_bigint<19>(sext_ln1118_527_fu_15995_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_918_fu_16251_p2() {
    sub_ln1118_918_fu_16251_p2 = (!sext_ln1118_531_fu_16219_p1.read().is_01() || !sext_ln1118_532_fu_16231_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_531_fu_16219_p1.read()) - sc_bigint<19>(sext_ln1118_532_fu_16231_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_919_fu_16641_p2() {
    sub_ln1118_919_fu_16641_p2 = (!sext_ln708_317_fu_16599_p1.read().is_01() || !sext_ln1118_542_fu_16637_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_317_fu_16599_p1.read()) - sc_bigint<20>(sext_ln1118_542_fu_16637_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_920_fu_16863_p2() {
    sub_ln1118_920_fu_16863_p2 = (!sext_ln708_321_fu_16793_p1.read().is_01() || !sext_ln1118_548_fu_16859_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_321_fu_16793_p1.read()) - sc_bigint<20>(sext_ln1118_548_fu_16859_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_921_fu_17094_p2() {
    sub_ln1118_921_fu_17094_p2 = (!sext_ln1118_552_fu_17026_p1.read().is_01() || !sext_ln1118_556_fu_17074_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_552_fu_17026_p1.read()) - sc_bigint<19>(sext_ln1118_556_fu_17074_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_922_fu_17296_p2() {
    sub_ln1118_922_fu_17296_p2 = (!sext_ln1118_561_fu_17202_p1.read().is_01() || !sext_ln1118_565_fu_17292_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_561_fu_17202_p1.read()) - sc_bigint<19>(sext_ln1118_565_fu_17292_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_923_fu_17601_p2() {
    sub_ln1118_923_fu_17601_p2 = (!sext_ln1118_569_fu_17471_p1.read().is_01() || !sext_ln1118_573_fu_17527_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_569_fu_17471_p1.read()) - sc_bigint<19>(sext_ln1118_573_fu_17527_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_924_fu_17709_p2() {
    sub_ln1118_924_fu_17709_p2 = (!sext_ln1118_566_fu_17459_p1.read().is_01() || !sext_ln1118_574_fu_17705_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_566_fu_17459_p1.read()) - sc_bigint<21>(sext_ln1118_574_fu_17705_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_925_fu_17937_p2() {
    sub_ln1118_925_fu_17937_p2 = (!sext_ln1118_576_fu_17729_p1.read().is_01() || !sext_ln1118_577_fu_17741_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_576_fu_17729_p1.read()) - sc_bigint<19>(sext_ln1118_577_fu_17741_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_926_fu_26200_p2() {
    sub_ln1118_926_fu_26200_p2 = (!sext_ln1118_584_reg_39939.read().is_01() || !sext_ln1118_585_reg_39946.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_584_reg_39939.read()) - sc_bigint<19>(sext_ln1118_585_reg_39946.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_927_fu_18359_p2() {
    sub_ln1118_927_fu_18359_p2 = (!sext_ln708_344_fu_18295_p1.read().is_01() || !sext_ln1118_589_fu_18317_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_344_fu_18295_p1.read()) - sc_bigint<19>(sext_ln1118_589_fu_18317_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_928_fu_18481_p2() {
    sub_ln1118_928_fu_18481_p2 = (!sext_ln1118_591_fu_18393_p1.read().is_01() || !sext_ln1118_592_fu_18405_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_591_fu_18393_p1.read()) - sc_bigint<19>(sext_ln1118_592_fu_18405_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_929_fu_18591_p2() {
    sub_ln1118_929_fu_18591_p2 = (!sext_ln1118_594_fu_18555_p1.read().is_01() || !sext_ln1118_595_fu_18567_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_594_fu_18555_p1.read()) - sc_bigint<19>(sext_ln1118_595_fu_18567_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_930_fu_26319_p2() {
    sub_ln1118_930_fu_26319_p2 = (!sext_ln708_352_fu_26305_p1.read().is_01() || !sext_ln1118_598_fu_26315_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_352_fu_26305_p1.read()) - sc_bigint<19>(sext_ln1118_598_fu_26315_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_931_fu_18817_p2() {
    sub_ln1118_931_fu_18817_p2 = (!sext_ln1118_599_fu_18745_p1.read().is_01() || !sext_ln1118_602_fu_18765_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_599_fu_18745_p1.read()) - sc_bigint<20>(sext_ln1118_602_fu_18765_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_932_fu_18899_p2() {
    sub_ln1118_932_fu_18899_p2 = (!sext_ln1118_601_fu_18753_p1.read().is_01() || !sext_ln1118_603_fu_18797_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_601_fu_18753_p1.read()) - sc_bigint<19>(sext_ln1118_603_fu_18797_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_933_fu_26411_p2() {
    sub_ln1118_933_fu_26411_p2 = (!sext_ln708_360_fu_26374_p1.read().is_01() || !sext_ln1118_608_fu_26387_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_360_fu_26374_p1.read()) - sc_bigint<19>(sext_ln1118_608_fu_26387_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_934_fu_19416_p2() {
    sub_ln1118_934_fu_19416_p2 = (!sext_ln708_369_fu_19276_p1.read().is_01() || !sext_ln1118_613_fu_19314_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_369_fu_19276_p1.read()) - sc_bigint<20>(sext_ln1118_613_fu_19314_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_935_fu_19646_p2() {
    sub_ln1118_935_fu_19646_p2 = (!sext_ln708_376_fu_19514_p1.read().is_01() || !sext_ln1118_618_fu_19620_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_376_fu_19514_p1.read()) - sc_bigint<19>(sext_ln1118_618_fu_19620_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_936_fu_19948_p2() {
    sub_ln1118_936_fu_19948_p2 = (!sext_ln1118_619_fu_19688_p1.read().is_01() || !sext_ln1118_622_fu_19708_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_619_fu_19688_p1.read()) - sc_bigint<20>(sext_ln1118_622_fu_19708_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_937_fu_19984_p2() {
    sub_ln1118_937_fu_19984_p2 = (!sext_ln1118_629_fu_19970_p1.read().is_01() || !sext_ln1118_630_fu_19980_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_629_fu_19970_p1.read()) - sc_bigint<19>(sext_ln1118_630_fu_19980_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_938_fu_20262_p2() {
    sub_ln1118_938_fu_20262_p2 = (!sext_ln708_385_fu_20168_p1.read().is_01() || !sext_ln1118_636_fu_20258_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln708_385_fu_20168_p1.read()) - sc_bigint<20>(sext_ln1118_636_fu_20258_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_939_fu_26630_p2() {
    sub_ln1118_939_fu_26630_p2 = (!sext_ln1118_639_fu_26545_p1.read().is_01() || !sext_ln1118_642_fu_26561_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_639_fu_26545_p1.read()) - sc_bigint<19>(sext_ln1118_642_fu_26561_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_940_fu_20377_p2() {
    sub_ln1118_940_fu_20377_p2 = (!sext_ln1118_638_fu_20288_p1.read().is_01() || !sext_ln1118_643_fu_20348_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_638_fu_20288_p1.read()) - sc_bigint<20>(sext_ln1118_643_fu_20348_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_941_fu_20541_p2() {
    sub_ln1118_941_fu_20541_p2 = (!sext_ln708_394_fu_20405_p1.read().is_01() || !sext_ln1118_647_fu_20515_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln708_394_fu_20405_p1.read()) - sc_bigint<19>(sext_ln1118_647_fu_20515_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_942_fu_20727_p2() {
    sub_ln1118_942_fu_20727_p2 = (!sext_ln1118_648_fu_20675_p1.read().is_01() || !sext_ln1118_654_fu_20723_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_648_fu_20675_p1.read()) - sc_bigint<20>(sext_ln1118_654_fu_20723_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_943_fu_26726_p2() {
    sub_ln1118_943_fu_26726_p2 = (!sext_ln1118_649_fu_26680_p1.read().is_01() || !sext_ln1118_653_fu_26693_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_649_fu_26680_p1.read()) - sc_bigint<19>(sext_ln1118_653_fu_26693_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_944_fu_26840_p2() {
    sub_ln1118_944_fu_26840_p2 = (!sext_ln1118_662_fu_26826_p1.read().is_01() || !sext_ln1118_664_fu_26836_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_662_fu_26826_p1.read()) - sc_bigint<19>(sext_ln1118_664_fu_26836_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_945_fu_21287_p2() {
    sub_ln1118_945_fu_21287_p2 = (!sext_ln1118_668_fu_21127_p1.read().is_01() || !sext_ln1118_670_fu_21143_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_668_fu_21127_p1.read()) - sc_bigint<19>(sext_ln1118_670_fu_21143_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_946_fu_21397_p2() {
    sub_ln1118_946_fu_21397_p2 = (!sext_ln1118_673_fu_21361_p1.read().is_01() || !sext_ln1118_675_fu_21377_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_673_fu_21361_p1.read()) - sc_bigint<19>(sext_ln1118_675_fu_21377_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_sub_ln1118_fu_3852_p2() {
    sub_ln1118_fu_3852_p2 = (!sext_ln1118_158_fu_3849_p1.read().is_01() || !sext_ln1118_156_fu_3846_p1.read().is_01())? sc_lv<19>(): (sc_bigint<19>(sext_ln1118_158_fu_3849_p1.read()) - sc_bigint<19>(sext_ln1118_156_fu_3846_p1.read()));
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_280_fu_4235_p3() {
    tmp_280_fu_4235_p3 = esl_concat<16,2>(data_3_V_read_3_reg_36914.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_281_fu_4679_p1() {
    tmp_281_fu_4679_p1 = ap_port_reg_data_6_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_281_fu_4679_p3() {
    tmp_281_fu_4679_p3 = esl_concat<16,2>(tmp_281_fu_4679_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_282_fu_5215_p1() {
    tmp_282_fu_5215_p1 = ap_port_reg_data_9_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_282_fu_5215_p3() {
    tmp_282_fu_5215_p3 = esl_concat<16,2>(tmp_282_fu_5215_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_283_fu_5639_p1() {
    tmp_283_fu_5639_p1 = ap_port_reg_data_10_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_283_fu_5639_p3() {
    tmp_283_fu_5639_p3 = esl_concat<16,3>(tmp_283_fu_5639_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_284_fu_5864_p1() {
    tmp_284_fu_5864_p1 = ap_port_reg_data_12_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_284_fu_5864_p3() {
    tmp_284_fu_5864_p3 = esl_concat<16,2>(tmp_284_fu_5864_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_285_fu_6373_p1() {
    tmp_285_fu_6373_p1 = ap_port_reg_data_15_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_285_fu_6373_p3() {
    tmp_285_fu_6373_p3 = esl_concat<16,3>(tmp_285_fu_6373_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_286_fu_6841_p1() {
    tmp_286_fu_6841_p1 = ap_port_reg_data_17_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_286_fu_6841_p3() {
    tmp_286_fu_6841_p3 = esl_concat<16,3>(tmp_286_fu_6841_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_287_fu_7339_p1() {
    tmp_287_fu_7339_p1 = ap_port_reg_data_19_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_287_fu_7339_p3() {
    tmp_287_fu_7339_p3 = esl_concat<16,3>(tmp_287_fu_7339_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_288_fu_7483_p1() {
    tmp_288_fu_7483_p1 = ap_port_reg_data_20_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_288_fu_7483_p3() {
    tmp_288_fu_7483_p3 = esl_concat<16,2>(tmp_288_fu_7483_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_289_fu_7665_p1() {
    tmp_289_fu_7665_p1 = ap_port_reg_data_21_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_289_fu_7665_p3() {
    tmp_289_fu_7665_p3 = esl_concat<16,2>(tmp_289_fu_7665_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_290_fu_8963_p1() {
    tmp_290_fu_8963_p1 = ap_port_reg_data_27_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_290_fu_8963_p3() {
    tmp_290_fu_8963_p3 = esl_concat<16,2>(tmp_290_fu_8963_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_291_fu_3080_p1() {
    tmp_291_fu_3080_p1 = ap_port_reg_data_29_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_291_fu_3080_p3() {
    tmp_291_fu_3080_p3 = esl_concat<16,2>(tmp_291_fu_3080_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_292_fu_9364_p1() {
    tmp_292_fu_9364_p1 = ap_port_reg_data_30_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_292_fu_9364_p3() {
    tmp_292_fu_9364_p3 = esl_concat<16,2>(tmp_292_fu_9364_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_293_fu_10307_p1() {
    tmp_293_fu_10307_p1 = ap_port_reg_data_35_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_293_fu_10307_p3() {
    tmp_293_fu_10307_p3 = esl_concat<16,2>(tmp_293_fu_10307_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_294_fu_10491_p1() {
    tmp_294_fu_10491_p1 = ap_port_reg_data_36_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_294_fu_10491_p3() {
    tmp_294_fu_10491_p3 = esl_concat<16,2>(tmp_294_fu_10491_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_295_fu_10707_p1() {
    tmp_295_fu_10707_p1 = ap_port_reg_data_37_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_295_fu_10707_p3() {
    tmp_295_fu_10707_p3 = esl_concat<16,2>(tmp_295_fu_10707_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_296_fu_3336_p1() {
    tmp_296_fu_3336_p1 = ap_port_reg_data_40_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_296_fu_3336_p3() {
    tmp_296_fu_3336_p3 = esl_concat<16,3>(tmp_296_fu_3336_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_297_fu_11957_p1() {
    tmp_297_fu_11957_p1 = ap_port_reg_data_43_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_297_fu_11957_p3() {
    tmp_297_fu_11957_p3 = esl_concat<16,2>(tmp_297_fu_11957_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_298_fu_12131_p1() {
    tmp_298_fu_12131_p1 = ap_port_reg_data_44_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_298_fu_12131_p3() {
    tmp_298_fu_12131_p3 = esl_concat<16,2>(tmp_298_fu_12131_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_299_fu_12386_p3() {
    tmp_299_fu_12386_p3 = esl_concat<16,2>(data_45_V_read_2_reg_36886.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_300_fu_13488_p1() {
    tmp_300_fu_13488_p1 = ap_port_reg_data_52_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_300_fu_13488_p3() {
    tmp_300_fu_13488_p3 = esl_concat<16,3>(tmp_300_fu_13488_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_301_fu_14032_p1() {
    tmp_301_fu_14032_p1 = ap_port_reg_data_55_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_301_fu_14032_p3() {
    tmp_301_fu_14032_p3 = esl_concat<16,2>(tmp_301_fu_14032_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_302_fu_14428_p1() {
    tmp_302_fu_14428_p1 = ap_port_reg_data_58_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_302_fu_14428_p3() {
    tmp_302_fu_14428_p3 = esl_concat<16,2>(tmp_302_fu_14428_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_303_fu_14822_p1() {
    tmp_303_fu_14822_p1 = ap_port_reg_data_60_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_303_fu_14822_p3() {
    tmp_303_fu_14822_p3 = esl_concat<16,2>(tmp_303_fu_14822_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_304_fu_15193_p3() {
    tmp_304_fu_15193_p3 = esl_concat<16,2>(data_62_V_read_2_reg_36858.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_305_fu_15549_p1() {
    tmp_305_fu_15549_p1 = ap_port_reg_data_64_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_305_fu_15549_p3() {
    tmp_305_fu_15549_p3 = esl_concat<16,2>(tmp_305_fu_15549_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_306_fu_15799_p1() {
    tmp_306_fu_15799_p1 = ap_port_reg_data_65_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_306_fu_15799_p3() {
    tmp_306_fu_15799_p3 = esl_concat<16,2>(tmp_306_fu_15799_p1.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_307_fu_16629_p1() {
    tmp_307_fu_16629_p1 = ap_port_reg_data_69_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_307_fu_16629_p3() {
    tmp_307_fu_16629_p3 = esl_concat<16,3>(tmp_307_fu_16629_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_308_fu_16851_p1() {
    tmp_308_fu_16851_p1 = ap_port_reg_data_70_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_308_fu_16851_p3() {
    tmp_308_fu_16851_p3 = esl_concat<16,3>(tmp_308_fu_16851_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_309_fu_17285_p3() {
    tmp_309_fu_17285_p3 = esl_concat<16,2>(data_72_V_read_1_reg_36838.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_310_fu_17697_p1() {
    tmp_310_fu_17697_p1 = ap_port_reg_data_73_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_310_fu_17697_p3() {
    tmp_310_fu_17697_p3 = esl_concat<16,4>(tmp_310_fu_17697_p1.read(), ap_const_lv4_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_311_fu_26308_p3() {
    tmp_311_fu_26308_p3 = esl_concat<16,2>(data_80_V_read_1_reg_37853.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_312_fu_19973_p3() {
    tmp_312_fu_19973_p3 = esl_concat<16,2>(data_87_V_read_1_reg_36828.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_313_fu_20250_p1() {
    tmp_313_fu_20250_p1 = ap_port_reg_data_88_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_313_fu_20250_p3() {
    tmp_313_fu_20250_p3 = esl_concat<16,3>(tmp_313_fu_20250_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_314_fu_20715_p1() {
    tmp_314_fu_20715_p1 = ap_port_reg_data_91_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_314_fu_20715_p3() {
    tmp_314_fu_20715_p3 = esl_concat<16,3>(tmp_314_fu_20715_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_315_fu_26829_p3() {
    tmp_315_fu_26829_p3 = esl_concat<16,2>(data_93_V_read_1_reg_37839.read(), ap_const_lv2_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_s_fu_2256_p1() {
    tmp_s_fu_2256_p1 = ap_port_reg_data_1_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_tmp_s_fu_2256_p3() {
    tmp_s_fu_2256_p3 = esl_concat<16,3>(tmp_s_fu_2256_p1.read(), ap_const_lv3_0);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1000_fu_6583_p4() {
    trunc_ln708_1000_fu_6583_p4 = add_ln1118_11_fu_6577_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1001_fu_14302_p1() {
    trunc_ln708_1001_fu_14302_p1 = ap_port_reg_data_57_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1001_fu_14302_p4() {
    trunc_ln708_1001_fu_14302_p4 = trunc_ln708_1001_fu_14302_p1.read().range(15, 3);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1004_fu_14358_p1() {
    trunc_ln708_1004_fu_14358_p1 = ap_port_reg_data_57_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1004_fu_14358_p4() {
    trunc_ln708_1004_fu_14358_p4 = trunc_ln708_1004_fu_14358_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1006_fu_6743_p4() {
    trunc_ln708_1006_fu_6743_p4 = sub_ln1118_369_fu_6737_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1007_fu_6763_p4() {
    trunc_ln708_1007_fu_6763_p4 = sub_ln1118_861_fu_6757_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1008_fu_6813_p4() {
    trunc_ln708_1008_fu_6813_p4 = sub_ln1118_370_fu_6807_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1010_fu_14472_p1() {
    trunc_ln708_1010_fu_14472_p1 = ap_port_reg_data_58_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1010_fu_14472_p4() {
    trunc_ln708_1010_fu_14472_p4 = trunc_ln708_1010_fu_14472_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1011_fu_14490_p1() {
    trunc_ln708_1011_fu_14490_p1 = ap_port_reg_data_58_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1011_fu_14490_p4() {
    trunc_ln708_1011_fu_14490_p4 = trunc_ln708_1011_fu_14490_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1012_fu_14504_p1() {
    trunc_ln708_1012_fu_14504_p1 = ap_port_reg_data_58_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1013_fu_6891_p4() {
    trunc_ln708_1013_fu_6891_p4 = sub_ln1118_371_fu_6885_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1014_fu_14542_p1() {
    trunc_ln708_1014_fu_14542_p1 = ap_port_reg_data_58_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1017_fu_6975_p4() {
    trunc_ln708_1017_fu_6975_p4 = sub_ln1118_375_fu_6969_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1018_fu_6995_p4() {
    trunc_ln708_1018_fu_6995_p4 = add_ln1118_12_fu_6989_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1019_fu_14636_p1() {
    trunc_ln708_1019_fu_14636_p1 = ap_port_reg_data_59_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1019_fu_14636_p4() {
    trunc_ln708_1019_fu_14636_p4 = trunc_ln708_1019_fu_14636_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1020_fu_14650_p1() {
    trunc_ln708_1020_fu_14650_p1 = ap_port_reg_data_59_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1020_fu_14650_p4() {
    trunc_ln708_1020_fu_14650_p4 = trunc_ln708_1020_fu_14650_p1.read().range(15, 3);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1023_fu_7093_p4() {
    trunc_ln708_1023_fu_7093_p4 = sub_ln1118_376_fu_7087_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1024_fu_7113_p4() {
    trunc_ln708_1024_fu_7113_p4 = sub_ln1118_377_fu_7107_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1025_fu_7133_p4() {
    trunc_ln708_1025_fu_7133_p4 = sub_ln1118_378_fu_7127_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1027_fu_14800_p1() {
    trunc_ln708_1027_fu_14800_p1 = ap_port_reg_data_59_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1027_fu_14800_p4() {
    trunc_ln708_1027_fu_14800_p4 = trunc_ln708_1027_fu_14800_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1029_fu_7213_p4() {
    trunc_ln708_1029_fu_7213_p4 = sub_ln1118_863_fu_7207_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1030_fu_14866_p1() {
    trunc_ln708_1030_fu_14866_p1 = ap_port_reg_data_60_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1030_fu_14866_p4() {
    trunc_ln708_1030_fu_14866_p4 = trunc_ln708_1030_fu_14866_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1031_fu_7233_p4() {
    trunc_ln708_1031_fu_7233_p4 = sub_ln1118_864_fu_7227_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1032_fu_7295_p4() {
    trunc_ln708_1032_fu_7295_p4 = sub_ln1118_381_fu_7289_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1034_fu_14954_p1() {
    trunc_ln708_1034_fu_14954_p1 = ap_port_reg_data_60_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1034_fu_14954_p4() {
    trunc_ln708_1034_fu_14954_p4 = trunc_ln708_1034_fu_14954_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1036_fu_7373_p4() {
    trunc_ln708_1036_fu_7373_p4 = sub_ln1118_383_fu_7367_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1038_fu_15050_p1() {
    trunc_ln708_1038_fu_15050_p1 = ap_port_reg_data_61_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1039_fu_15060_p1() {
    trunc_ln708_1039_fu_15060_p1 = ap_port_reg_data_61_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1040_fu_7409_p4() {
    trunc_ln708_1040_fu_7409_p4 = sub_ln1118_385_fu_7403_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1041_fu_7445_p4() {
    trunc_ln708_1041_fu_7445_p4 = sub_ln1118_386_fu_7439_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1042_fu_7465_p4() {
    trunc_ln708_1042_fu_7465_p4 = sub_ln1118_387_fu_7459_p2.read().range(17, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1043_fu_15134_p1() {
    trunc_ln708_1043_fu_15134_p1 = ap_port_reg_data_61_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1043_fu_15134_p4() {
    trunc_ln708_1043_fu_15134_p4 = trunc_ln708_1043_fu_15134_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1046_fu_7591_p4() {
    trunc_ln708_1046_fu_7591_p4 = sub_ln1118_389_fu_7585_p2.read().range(17, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1048_fu_2022_p1() {
    trunc_ln708_1048_fu_2022_p1 = data_62_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1049_fu_7639_p4() {
    trunc_ln708_1049_fu_7639_p4 = sub_ln1118_391_fu_7633_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1051_fu_7699_p4() {
    trunc_ln708_1051_fu_7699_p4 = sub_ln1118_392_fu_7693_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1052_fu_7739_p4() {
    trunc_ln708_1052_fu_7739_p4 = sub_ln1118_393_fu_7733_p2.read().range(17, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1053_fu_7771_p4() {
    trunc_ln708_1053_fu_7771_p4 = sub_ln1118_394_fu_7765_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1054_fu_2032_p1() {
    trunc_ln708_1054_fu_2032_p1 = data_62_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1055_fu_7805_p4() {
    trunc_ln708_1055_fu_7805_p4 = add_ln1118_14_fu_7799_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1056_fu_7853_p4() {
    trunc_ln708_1056_fu_7853_p4 = sub_ln1118_395_fu_7847_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1057_fu_2042_p1() {
    trunc_ln708_1057_fu_2042_p1 = data_62_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1058_fu_7873_p4() {
    trunc_ln708_1058_fu_7873_p4 = sub_ln1118_396_fu_7867_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1059_fu_7893_p4() {
    trunc_ln708_1059_fu_7893_p4 = sub_ln1118_397_fu_7887_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1060_fu_15379_p1() {
    trunc_ln708_1060_fu_15379_p1 = ap_port_reg_data_63_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1062_fu_7999_p4() {
    trunc_ln708_1062_fu_7999_p4 = sub_ln1118_401_fu_7993_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1063_fu_8019_p4() {
    trunc_ln708_1063_fu_8019_p4 = add_ln1118_15_fu_8013_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1065_fu_8095_p4() {
    trunc_ln708_1065_fu_8095_p4 = sub_ln1118_403_fu_8089_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1067_fu_8137_p4() {
    trunc_ln708_1067_fu_8137_p4 = sub_ln1118_406_fu_8131_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1068_fu_15489_p1() {
    trunc_ln708_1068_fu_15489_p1 = ap_port_reg_data_63_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1068_fu_15489_p4() {
    trunc_ln708_1068_fu_15489_p4 = trunc_ln708_1068_fu_15489_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1069_fu_15503_p1() {
    trunc_ln708_1069_fu_15503_p1 = ap_port_reg_data_63_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1069_fu_15503_p4() {
    trunc_ln708_1069_fu_15503_p4 = trunc_ln708_1069_fu_15503_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1071_fu_8217_p4() {
    trunc_ln708_1071_fu_8217_p4 = add_ln1118_16_fu_8211_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1072_fu_8253_p4() {
    trunc_ln708_1072_fu_8253_p4 = sub_ln1118_409_fu_8247_p2.read().range(17, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1073_fu_8285_p4() {
    trunc_ln708_1073_fu_8285_p4 = sub_ln1118_410_fu_8279_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1074_fu_15621_p1() {
    trunc_ln708_1074_fu_15621_p1 = ap_port_reg_data_64_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1074_fu_15621_p4() {
    trunc_ln708_1074_fu_15621_p4 = trunc_ln708_1074_fu_15621_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1077_fu_15691_p1() {
    trunc_ln708_1077_fu_15691_p1 = ap_port_reg_data_64_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1077_fu_15691_p4() {
    trunc_ln708_1077_fu_15691_p4 = trunc_ln708_1077_fu_15691_p1.read().range(15, 3);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1078_fu_15705_p1() {
    trunc_ln708_1078_fu_15705_p1 = ap_port_reg_data_64_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1078_fu_15705_p4() {
    trunc_ln708_1078_fu_15705_p4 = trunc_ln708_1078_fu_15705_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1080_fu_8347_p4() {
    trunc_ln708_1080_fu_8347_p4 = sub_ln1118_413_fu_8341_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1085_fu_15843_p1() {
    trunc_ln708_1085_fu_15843_p1 = ap_port_reg_data_65_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1085_fu_15843_p4() {
    trunc_ln708_1085_fu_15843_p4 = trunc_ln708_1085_fu_15843_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1088_fu_8440_p4() {
    trunc_ln708_1088_fu_8440_p4 = sub_ln1118_420_fu_8434_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1089_fu_15929_p1() {
    trunc_ln708_1089_fu_15929_p1 = ap_port_reg_data_65_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1089_fu_15929_p4() {
    trunc_ln708_1089_fu_15929_p4 = trunc_ln708_1089_fu_15929_p1.read().range(15, 3);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1090_fu_8460_p4() {
    trunc_ln708_1090_fu_8460_p4 = sub_ln1118_869_fu_8454_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1091_fu_8520_p4() {
    trunc_ln708_1091_fu_8520_p4 = sub_ln1118_421_fu_8514_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1093_fu_8568_p4() {
    trunc_ln708_1093_fu_8568_p4 = sub_ln1118_423_fu_8562_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1094_fu_16051_p1() {
    trunc_ln708_1094_fu_16051_p1 = ap_port_reg_data_66_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1097_fu_8644_p4() {
    trunc_ln708_1097_fu_8644_p4 = sub_ln1118_427_fu_8638_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1098_fu_8664_p4() {
    trunc_ln708_1098_fu_8664_p4 = sub_ln1118_428_fu_8658_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1099_fu_8684_p4() {
    trunc_ln708_1099_fu_8684_p4 = add_ln1118_17_fu_8678_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1100_fu_8718_p4() {
    trunc_ln708_1100_fu_8718_p4 = sub_ln1118_429_fu_8712_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1101_fu_8756_p4() {
    trunc_ln708_1101_fu_8756_p4 = sub_ln1118_430_fu_8750_p2.read().range(17, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1102_fu_16197_p1() {
    trunc_ln708_1102_fu_16197_p1 = ap_port_reg_data_66_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1102_fu_16197_p4() {
    trunc_ln708_1102_fu_16197_p4 = trunc_ln708_1102_fu_16197_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1105_fu_8822_p4() {
    trunc_ln708_1105_fu_8822_p4 = sub_ln1118_434_fu_8817_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1106_fu_8842_p4() {
    trunc_ln708_1106_fu_8842_p4 = sub_ln1118_435_fu_8836_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1110_fu_8907_p4() {
    trunc_ln708_1110_fu_8907_p4 = sub_ln1118_438_fu_8902_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1111_fu_16403_p1() {
    trunc_ln708_1111_fu_16403_p1 = ap_port_reg_data_67_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1111_fu_16403_p4() {
    trunc_ln708_1111_fu_16403_p4 = trunc_ln708_1111_fu_16403_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1112_fu_8925_p4() {
    trunc_ln708_1112_fu_8925_p4 = sub_ln1118_870_fu_8921_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1114_fu_16485_p1() {
    trunc_ln708_1114_fu_16485_p1 = ap_port_reg_data_68_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1114_fu_16485_p4() {
    trunc_ln708_1114_fu_16485_p4 = trunc_ln708_1114_fu_16485_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1116_fu_16527_p1() {
    trunc_ln708_1116_fu_16527_p1 = ap_port_reg_data_68_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1117_fu_16537_p1() {
    trunc_ln708_1117_fu_16537_p1 = ap_port_reg_data_68_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1117_fu_16537_p4() {
    trunc_ln708_1117_fu_16537_p4 = trunc_ln708_1117_fu_16537_p1.read().range(15, 3);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1120_fu_9075_p4() {
    trunc_ln708_1120_fu_9075_p4 = sub_ln1118_441_fu_9069_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1121_fu_16611_p1() {
    trunc_ln708_1121_fu_16611_p1 = ap_port_reg_data_69_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1121_fu_16611_p4() {
    trunc_ln708_1121_fu_16611_p4 = trunc_ln708_1121_fu_16611_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1123_fu_9127_p4() {
    trunc_ln708_1123_fu_9127_p4 = add_ln1118_19_fu_9121_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1125_fu_9197_p4() {
    trunc_ln708_1125_fu_9197_p4 = sub_ln1118_445_fu_9192_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1127_fu_9245_p4() {
    trunc_ln708_1127_fu_9245_p4 = sub_ln1118_447_fu_9239_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1129_fu_16805_p1() {
    trunc_ln708_1129_fu_16805_p1 = ap_port_reg_data_70_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1129_fu_16805_p4() {
    trunc_ln708_1129_fu_16805_p4 = trunc_ln708_1129_fu_16805_p1.read().range(15, 2);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1133_fu_16903_p1() {
    trunc_ln708_1133_fu_16903_p1 = ap_port_reg_data_70_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1133_fu_16903_p4() {
    trunc_ln708_1133_fu_16903_p4 = trunc_ln708_1133_fu_16903_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1134_fu_9313_p4() {
    trunc_ln708_1134_fu_9313_p4 = sub_ln1118_450_fu_9308_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1135_fu_9333_p4() {
    trunc_ln708_1135_fu_9333_p4 = sub_ln1118_451_fu_9327_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1140_fu_9398_p4() {
    trunc_ln708_1140_fu_9398_p4 = sub_ln1118_454_fu_9392_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1141_fu_9418_p4() {
    trunc_ln708_1141_fu_9418_p4 = sub_ln1118_455_fu_9412_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1142_fu_9482_p4() {
    trunc_ln708_1142_fu_9482_p4 = sub_ln1118_456_fu_9476_p2.read().range(17, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1143_fu_9502_p4() {
    trunc_ln708_1143_fu_9502_p4 = add_ln1118_21_fu_9496_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1145_fu_9570_p4() {
    trunc_ln708_1145_fu_9570_p4 = sub_ln1118_458_fu_9564_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1146_fu_2057_p1() {
    trunc_ln708_1146_fu_2057_p1 = data_71_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1148_fu_9622_p4() {
    trunc_ln708_1148_fu_9622_p4 = sub_ln1118_460_fu_9616_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1149_fu_2072_p1() {
    trunc_ln708_1149_fu_2072_p1 = data_72_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1150_fu_9660_p4() {
    trunc_ln708_1150_fu_9660_p4 = sub_ln1118_461_fu_9654_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1151_fu_2082_p1() {
    trunc_ln708_1151_fu_2082_p1 = data_72_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1157_fu_2092_p1() {
    trunc_ln708_1157_fu_2092_p1 = data_72_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1160_fu_9914_p4() {
    trunc_ln708_1160_fu_9914_p4 = sub_ln1118_470_fu_9908_p2.read().range(17, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1164_fu_10054_p4() {
    trunc_ln708_1164_fu_10054_p4 = sub_ln1118_473_fu_10048_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1167_fu_17563_p1() {
    trunc_ln708_1167_fu_17563_p1 = ap_port_reg_data_73_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1167_fu_17563_p4() {
    trunc_ln708_1167_fu_17563_p4 = trunc_ln708_1167_fu_17563_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1170_fu_10182_p4() {
    trunc_ln708_1170_fu_10182_p4 = sub_ln1118_478_fu_10176_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1171_fu_10201_p4() {
    trunc_ln708_1171_fu_10201_p4 = sub_ln1118_877_fu_10196_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1172_fu_17657_p1() {
    trunc_ln708_1172_fu_17657_p1 = ap_port_reg_data_73_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1173_fu_17667_p1() {
    trunc_ln708_1173_fu_17667_p1 = ap_port_reg_data_73_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1173_fu_17667_p4() {
    trunc_ln708_1173_fu_17667_p4 = trunc_ln708_1173_fu_17667_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1175_fu_10220_p4() {
    trunc_ln708_1175_fu_10220_p4 = sub_ln1118_480_fu_10215_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1177_fu_17765_p1() {
    trunc_ln708_1177_fu_17765_p1 = ap_port_reg_data_74_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1177_fu_17765_p4() {
    trunc_ln708_1177_fu_17765_p4 = trunc_ln708_1177_fu_17765_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1179_fu_10268_p4() {
    trunc_ln708_1179_fu_10268_p4 = sub_ln1118_878_fu_10262_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1180_fu_17833_p1() {
    trunc_ln708_1180_fu_17833_p1 = ap_port_reg_data_74_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1180_fu_17833_p4() {
    trunc_ln708_1180_fu_17833_p4 = trunc_ln708_1180_fu_17833_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1181_fu_17847_p1() {
    trunc_ln708_1181_fu_17847_p1 = ap_port_reg_data_74_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1181_fu_17847_p4() {
    trunc_ln708_1181_fu_17847_p4 = trunc_ln708_1181_fu_17847_p1.read().range(15, 3);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1183_fu_10285_p4() {
    trunc_ln708_1183_fu_10285_p4 = sub_ln1118_482_fu_10240_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1184_fu_10325_p4() {
    trunc_ln708_1184_fu_10325_p4 = sub_ln1118_879_fu_10319_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1186_fu_17965_p1() {
    trunc_ln708_1186_fu_17965_p1 = ap_port_reg_data_75_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1188_fu_17995_p1() {
    trunc_ln708_1188_fu_17995_p1 = ap_port_reg_data_75_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1189_fu_18005_p1() {
    trunc_ln708_1189_fu_18005_p1 = ap_port_reg_data_75_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1189_fu_18005_p4() {
    trunc_ln708_1189_fu_18005_p4 = trunc_ln708_1189_fu_18005_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1191_fu_10435_p4() {
    trunc_ln708_1191_fu_10435_p4 = add_ln1118_25_fu_10429_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1192_fu_10469_p4() {
    trunc_ln708_1192_fu_10469_p4 = sub_ln1118_487_fu_10463_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1193_fu_10509_p4() {
    trunc_ln708_1193_fu_10509_p4 = sub_ln1118_880_fu_10503_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1194_fu_10561_p4() {
    trunc_ln708_1194_fu_10561_p4 = sub_ln1118_488_fu_10555_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1195_fu_18109_p1() {
    trunc_ln708_1195_fu_18109_p1 = ap_port_reg_data_76_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1196_fu_10605_p4() {
    trunc_ln708_1196_fu_10605_p4 = sub_ln1118_489_fu_10599_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1199_fu_18171_p1() {
    trunc_ln708_1199_fu_18171_p1 = ap_port_reg_data_76_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1199_fu_18171_p4() {
    trunc_ln708_1199_fu_18171_p4 = trunc_ln708_1199_fu_18171_p1.read().range(15, 3);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1202_fu_18233_p1() {
    trunc_ln708_1202_fu_18233_p1 = ap_port_reg_data_76_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1202_fu_18233_p4() {
    trunc_ln708_1202_fu_18233_p4 = trunc_ln708_1202_fu_18233_p1.read().range(15, 2);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1204_fu_10771_p4() {
    trunc_ln708_1204_fu_10771_p4 = sub_ln1118_493_fu_10765_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1205_fu_10819_p4() {
    trunc_ln708_1205_fu_10819_p4 = sub_ln1118_494_fu_10813_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1206_fu_18299_p1() {
    trunc_ln708_1206_fu_18299_p1 = ap_port_reg_data_77_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1208_fu_10861_p4() {
    trunc_ln708_1208_fu_10861_p4 = sub_ln1118_497_fu_10855_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1210_fu_18379_p1() {
    trunc_ln708_1210_fu_18379_p1 = ap_port_reg_data_77_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1211_fu_10891_p4() {
    trunc_ln708_1211_fu_10891_p4 = sub_ln1118_495_fu_10833_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1212_fu_18431_p1() {
    trunc_ln708_1212_fu_18431_p1 = ap_port_reg_data_78_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1212_fu_18431_p4() {
    trunc_ln708_1212_fu_18431_p4 = trunc_ln708_1212_fu_18431_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1213_fu_18445_p1() {
    trunc_ln708_1213_fu_18445_p1 = ap_port_reg_data_78_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1218_fu_18513_p1() {
    trunc_ln708_1218_fu_18513_p1 = ap_port_reg_data_78_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1218_fu_18513_p4() {
    trunc_ln708_1218_fu_18513_p4 = trunc_ln708_1218_fu_18513_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1219_fu_11033_p4() {
    trunc_ln708_1219_fu_11033_p4 = sub_ln1118_503_fu_11028_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1220_fu_11053_p4() {
    trunc_ln708_1220_fu_11053_p4 = sub_ln1118_504_fu_11047_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1224_fu_18639_p1() {
    trunc_ln708_1224_fu_18639_p1 = ap_port_reg_data_79_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1224_fu_18639_p4() {
    trunc_ln708_1224_fu_18639_p4 = trunc_ln708_1224_fu_18639_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1225_fu_18653_p1() {
    trunc_ln708_1225_fu_18653_p1 = ap_port_reg_data_79_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1226_fu_11098_p4() {
    trunc_ln708_1226_fu_11098_p4 = sub_ln1118_883_fu_11092_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1227_fu_18711_p1() {
    trunc_ln708_1227_fu_18711_p1 = ap_port_reg_data_80_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1227_fu_18711_p4() {
    trunc_ln708_1227_fu_18711_p4 = trunc_ln708_1227_fu_18711_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1228_fu_11118_p4() {
    trunc_ln708_1228_fu_11118_p4 = sub_ln1118_507_fu_11112_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1229_fu_11138_p4() {
    trunc_ln708_1229_fu_11138_p4 = add_ln1118_27_fu_11132_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1232_fu_11223_p4() {
    trunc_ln708_1232_fu_11223_p4 = sub_ln1118_510_fu_11217_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1233_fu_11243_p4() {
    trunc_ln708_1233_fu_11243_p4 = sub_ln1118_884_fu_11237_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1234_fu_18837_p1() {
    trunc_ln708_1234_fu_18837_p1 = ap_port_reg_data_81_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1234_fu_18837_p4() {
    trunc_ln708_1234_fu_18837_p4 = trunc_ln708_1234_fu_18837_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1236_fu_18885_p1() {
    trunc_ln708_1236_fu_18885_p1 = ap_port_reg_data_81_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1236_fu_18885_p4() {
    trunc_ln708_1236_fu_18885_p4 = trunc_ln708_1236_fu_18885_p1.read().range(15, 2);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1237_fu_11299_p4() {
    trunc_ln708_1237_fu_11299_p4 = sub_ln1118_512_fu_11293_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1238_fu_18919_p1() {
    trunc_ln708_1238_fu_18919_p1 = ap_port_reg_data_81_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1241_fu_18965_p1() {
    trunc_ln708_1241_fu_18965_p1 = ap_port_reg_data_81_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1241_fu_18965_p4() {
    trunc_ln708_1241_fu_18965_p4 = trunc_ln708_1241_fu_18965_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1242_fu_3759_p1() {
    trunc_ln708_1242_fu_3759_p1 = ap_port_reg_data_82_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1244_fu_11367_p4() {
    trunc_ln708_1244_fu_11367_p4 = sub_ln1118_514_fu_11361_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1247_fu_11436_p4() {
    trunc_ln708_1247_fu_11436_p4 = sub_ln1118_517_fu_11430_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1248_fu_11462_p4() {
    trunc_ln708_1248_fu_11462_p4 = sub_ln1118_518_fu_11456_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1250_fu_3813_p1() {
    trunc_ln708_1250_fu_3813_p1 = ap_port_reg_data_82_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1252_fu_19088_p1() {
    trunc_ln708_1252_fu_19088_p1 = ap_port_reg_data_83_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1252_fu_19088_p4() {
    trunc_ln708_1252_fu_19088_p4 = trunc_ln708_1252_fu_19088_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1253_fu_19102_p1() {
    trunc_ln708_1253_fu_19102_p1 = ap_port_reg_data_83_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1255_fu_11501_p4() {
    trunc_ln708_1255_fu_11501_p4 = sub_ln1118_887_fu_11495_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1257_fu_19188_p1() {
    trunc_ln708_1257_fu_19188_p1 = ap_port_reg_data_83_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1257_fu_19188_p4() {
    trunc_ln708_1257_fu_19188_p4 = trunc_ln708_1257_fu_19188_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1258_fu_11521_p4() {
    trunc_ln708_1258_fu_11521_p4 = add_ln1118_29_fu_11515_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1261_fu_19288_p1() {
    trunc_ln708_1261_fu_19288_p1 = ap_port_reg_data_84_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1261_fu_19288_p4() {
    trunc_ln708_1261_fu_19288_p4 = trunc_ln708_1261_fu_19288_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1266_fu_19402_p1() {
    trunc_ln708_1266_fu_19402_p1 = ap_port_reg_data_84_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1266_fu_19402_p4() {
    trunc_ln708_1266_fu_19402_p4 = trunc_ln708_1266_fu_19402_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1269_fu_11747_p4() {
    trunc_ln708_1269_fu_11747_p4 = sub_ln1118_529_fu_11741_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1270_fu_19480_p1() {
    trunc_ln708_1270_fu_19480_p1 = ap_port_reg_data_84_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1270_fu_19480_p4() {
    trunc_ln708_1270_fu_19480_p4 = trunc_ln708_1270_fu_19480_p1.read().range(15, 3);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1271_fu_11767_p4() {
    trunc_ln708_1271_fu_11767_p4 = sub_ln1118_530_fu_11761_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1272_fu_19522_p1() {
    trunc_ln708_1272_fu_19522_p1 = ap_port_reg_data_85_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1272_fu_19522_p4() {
    trunc_ln708_1272_fu_19522_p4 = trunc_ln708_1272_fu_19522_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1273_fu_11803_p4() {
    trunc_ln708_1273_fu_11803_p4 = add_ln1118_31_fu_11797_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1274_fu_11823_p4() {
    trunc_ln708_1274_fu_11823_p4 = sub_ln1118_889_fu_11817_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1275_fu_11855_p4() {
    trunc_ln708_1275_fu_11855_p4 = sub_ln1118_531_fu_11849_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1277_fu_11891_p4() {
    trunc_ln708_1277_fu_11891_p4 = sub_ln1118_533_fu_11885_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1280_fu_19748_p1() {
    trunc_ln708_1280_fu_19748_p1 = ap_port_reg_data_86_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1280_fu_19748_p4() {
    trunc_ln708_1280_fu_19748_p4 = trunc_ln708_1280_fu_19748_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1282_fu_19786_p1() {
    trunc_ln708_1282_fu_19786_p1 = ap_port_reg_data_86_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1282_fu_19786_p4() {
    trunc_ln708_1282_fu_19786_p4 = trunc_ln708_1282_fu_19786_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1283_fu_12031_p4() {
    trunc_ln708_1283_fu_12031_p4 = sub_ln1118_536_fu_12025_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1288_fu_12207_p4() {
    trunc_ln708_1288_fu_12207_p4 = add_ln1118_32_fu_12201_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1290_fu_12257_p4() {
    trunc_ln708_1290_fu_12257_p4 = sub_ln1118_541_fu_12251_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1292_fu_12293_p4() {
    trunc_ln708_1292_fu_12293_p4 = sub_ln1118_543_fu_12287_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1294_fu_12343_p4() {
    trunc_ln708_1294_fu_12343_p4 = add_ln1118_33_fu_12337_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1295_fu_12363_p4() {
    trunc_ln708_1295_fu_12363_p4 = sub_ln1118_545_fu_12357_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1296_fu_2107_p1() {
    trunc_ln708_1296_fu_2107_p1 = data_87_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1302_fu_2117_p1() {
    trunc_ln708_1302_fu_2117_p1 = data_87_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1303_fu_2127_p1() {
    trunc_ln708_1303_fu_2127_p1 = data_87_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1304_fu_2137_p1() {
    trunc_ln708_1304_fu_2137_p1 = data_87_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1305_fu_12515_p4() {
    trunc_ln708_1305_fu_12515_p4 = sub_ln1118_549_fu_12509_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1306_fu_20176_p1() {
    trunc_ln708_1306_fu_20176_p1 = ap_port_reg_data_88_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1306_fu_20176_p4() {
    trunc_ln708_1306_fu_20176_p4 = trunc_ln708_1306_fu_20176_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1308_fu_12587_p4() {
    trunc_ln708_1308_fu_12587_p4 = sub_ln1118_551_fu_12581_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1309_fu_12619_p4() {
    trunc_ln708_1309_fu_12619_p4 = sub_ln1118_552_fu_12613_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1310_fu_20278_p1() {
    trunc_ln708_1310_fu_20278_p1 = ap_port_reg_data_88_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1314_fu_12717_p4() {
    trunc_ln708_1314_fu_12717_p4 = sub_ln1118_555_fu_12711_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1316_fu_2152_p1() {
    trunc_ln708_1316_fu_2152_p1 = data_89_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1320_fu_2162_p1() {
    trunc_ln708_1320_fu_2162_p1 = data_89_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1322_fu_2172_p1() {
    trunc_ln708_1322_fu_2172_p1 = data_89_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1323_fu_20409_p1() {
    trunc_ln708_1323_fu_20409_p1 = ap_port_reg_data_90_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1323_fu_20409_p4() {
    trunc_ln708_1323_fu_20409_p4 = trunc_ln708_1323_fu_20409_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1324_fu_12812_p4() {
    trunc_ln708_1324_fu_12812_p4 = sub_ln1118_894_fu_12807_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1328_fu_25358_p4() {
    trunc_ln708_1328_fu_25358_p4 = sub_ln1118_565_fu_25352_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1329_fu_12949_p4() {
    trunc_ln708_1329_fu_12949_p4 = sub_ln1118_566_fu_12943_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1331_fu_25387_p4() {
    trunc_ln708_1331_fu_25387_p4 = add_ln1118_36_fu_25381_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1332_fu_13013_p4() {
    trunc_ln708_1332_fu_13013_p4 = sub_ln1118_567_fu_13007_p2.read().range(17, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1334_fu_20635_p1() {
    trunc_ln708_1334_fu_20635_p1 = ap_port_reg_data_90_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1335_fu_20645_p1() {
    trunc_ln708_1335_fu_20645_p1 = ap_port_reg_data_90_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1335_fu_20645_p4() {
    trunc_ln708_1335_fu_20645_p4 = trunc_ln708_1335_fu_20645_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1340_fu_20743_p1() {
    trunc_ln708_1340_fu_20743_p1 = ap_port_reg_data_91_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1342_fu_20775_p1() {
    trunc_ln708_1342_fu_20775_p1 = ap_port_reg_data_91_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1342_fu_20775_p4() {
    trunc_ln708_1342_fu_20775_p4 = trunc_ln708_1342_fu_20775_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1343_fu_25451_p4() {
    trunc_ln708_1343_fu_25451_p4 = sub_ln1118_573_fu_25445_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1345_fu_20789_p1() {
    trunc_ln708_1345_fu_20789_p1 = ap_port_reg_data_91_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1346_fu_25493_p4() {
    trunc_ln708_1346_fu_25493_p4 = add_ln1118_38_fu_25487_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1347_fu_13195_p4() {
    trunc_ln708_1347_fu_13195_p4 = sub_ln1118_576_fu_13189_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1349_fu_20809_p1() {
    trunc_ln708_1349_fu_20809_p1 = ap_port_reg_data_91_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1349_fu_20809_p4() {
    trunc_ln708_1349_fu_20809_p4 = trunc_ln708_1349_fu_20809_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1350_fu_25513_p4() {
    trunc_ln708_1350_fu_25513_p4 = sub_ln1118_574_fu_25465_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1351_fu_25533_p4() {
    trunc_ln708_1351_fu_25533_p4 = sub_ln1118_896_fu_25527_p2.read().range(18, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1352_fu_13243_p4() {
    trunc_ln708_1352_fu_13243_p4 = sub_ln1118_578_fu_13237_p2.read().range(19, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1354_fu_20931_p1() {
    trunc_ln708_1354_fu_20931_p1 = ap_port_reg_data_92_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1354_fu_20931_p4() {
    trunc_ln708_1354_fu_20931_p4 = trunc_ln708_1354_fu_20931_p1.read().range(15, 4);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1356_fu_13321_p4() {
    trunc_ln708_1356_fu_13321_p4 = sub_ln1118_582_fu_13315_p2.read().range(16, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1357_fu_20977_p1() {
    trunc_ln708_1357_fu_20977_p1 = ap_port_reg_data_92_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1357_fu_20977_p4() {
    trunc_ln708_1357_fu_20977_p4 = trunc_ln708_1357_fu_20977_p1.read().range(15, 5);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1359_fu_21023_p1() {
    trunc_ln708_1359_fu_21023_p1 = ap_port_reg_data_92_V_read.read();
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1359_fu_21023_p4() {
    trunc_ln708_1359_fu_21023_p4 = trunc_ln708_1359_fu_21023_p1.read().range(15, 3);
}

void dense_wrapper_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config15_s::thread_trunc_ln708_1360_fu_13383_p4() {
    trunc_ln708_1360_fu_13383_p4 = sub_ln1118_583_fu_13377_p2.read().range(19, 5);
}

}

