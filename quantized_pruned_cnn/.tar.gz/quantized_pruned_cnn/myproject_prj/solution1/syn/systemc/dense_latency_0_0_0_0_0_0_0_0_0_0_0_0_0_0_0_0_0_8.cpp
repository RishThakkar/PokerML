#include "dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2587_fu_18222_p4() {
    trunc_ln708_2587_fu_18222_p4 = trunc_ln708_2587_fu_18222_p1.read().range(15, 3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2588_fu_24404_p4() {
    trunc_ln708_2588_fu_24404_p4 = sub_ln1118_1716_fu_24398_p2.read().range(18, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2590_fu_18268_p1() {
    trunc_ln708_2590_fu_18268_p1 = ap_port_reg_data_124_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2590_fu_18268_p4() {
    trunc_ln708_2590_fu_18268_p4 = trunc_ln708_2590_fu_18268_p1.read().range(15, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2591_fu_24427_p4() {
    trunc_ln708_2591_fu_24427_p4 = sub_ln1118_1371_fu_24421_p2.read().range(18, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2592_fu_24447_p4() {
    trunc_ln708_2592_fu_24447_p4 = sub_ln1118_1372_fu_24441_p2.read().range(18, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2593_fu_18286_p1() {
    trunc_ln708_2593_fu_18286_p1 = ap_port_reg_data_125_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2593_fu_18286_p4() {
    trunc_ln708_2593_fu_18286_p4 = trunc_ln708_2593_fu_18286_p1.read().range(15, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2595_fu_18300_p1() {
    trunc_ln708_2595_fu_18300_p1 = ap_port_reg_data_125_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2595_fu_18300_p4() {
    trunc_ln708_2595_fu_18300_p4 = trunc_ln708_2595_fu_18300_p1.read().range(15, 2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2597_fu_18314_p1() {
    trunc_ln708_2597_fu_18314_p1 = ap_port_reg_data_125_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2597_fu_18314_p4() {
    trunc_ln708_2597_fu_18314_p4 = trunc_ln708_2597_fu_18314_p1.read().range(15, 3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2598_fu_18334_p4() {
    trunc_ln708_2598_fu_18334_p4 = sub_ln1118_887_fu_18328_p2.read().range(16, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2599_fu_18358_p4() {
    trunc_ln708_2599_fu_18358_p4 = sub_ln1118_888_fu_18352_p2.read().range(16, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2601_fu_18380_p1() {
    trunc_ln708_2601_fu_18380_p1 = ap_port_reg_data_127_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2601_fu_18380_p4() {
    trunc_ln708_2601_fu_18380_p4 = trunc_ln708_2601_fu_18380_p1.read().range(15, 2);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2604_fu_18450_p1() {
    trunc_ln708_2604_fu_18450_p1 = ap_port_reg_data_127_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2604_fu_18450_p4() {
    trunc_ln708_2604_fu_18450_p4 = trunc_ln708_2604_fu_18450_p1.read().range(15, 4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2608_fu_24474_p1() {
    trunc_ln708_2608_fu_24474_p1 = ap_port_reg_data_128_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2609_fu_24502_p4() {
    trunc_ln708_2609_fu_24502_p4 = add_ln1118_141_fu_24496_p2.read().range(19, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2613_fu_4247_p4() {
    trunc_ln708_2613_fu_4247_p4 = sub_ln1118_1381_fu_4241_p2.read().range(17, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2619_fu_24576_p4() {
    trunc_ln708_2619_fu_24576_p4 = sub_ln1118_1384_fu_24570_p2.read().range(17, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2621_fu_24608_p4() {
    trunc_ln708_2621_fu_24608_p4 = sub_ln1118_1386_fu_24602_p2.read().range(18, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2625_fu_24720_p4() {
    trunc_ln708_2625_fu_24720_p4 = sub_ln1118_1388_fu_24714_p2.read().range(19, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2626_fu_24744_p4() {
    trunc_ln708_2626_fu_24744_p4 = sub_ln1118_1389_fu_24738_p2.read().range(17, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2627_fu_24758_p1() {
    trunc_ln708_2627_fu_24758_p1 = ap_port_reg_data_131_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2627_fu_24758_p4() {
    trunc_ln708_2627_fu_24758_p4 = trunc_ln708_2627_fu_24758_p1.read().range(15, 3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2629_fu_24794_p4() {
    trunc_ln708_2629_fu_24794_p4 = add_ln1118_144_fu_24788_p2.read().range(19, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2630_fu_18575_p4() {
    trunc_ln708_2630_fu_18575_p4 = sub_ln1118_1391_fu_18569_p2.read().range(18, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2631_fu_18589_p1() {
    trunc_ln708_2631_fu_18589_p1 = ap_port_reg_data_132_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2631_fu_18589_p4() {
    trunc_ln708_2631_fu_18589_p4 = trunc_ln708_2631_fu_18589_p1.read().range(15, 3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2634_fu_18671_p4() {
    trunc_ln708_2634_fu_18671_p4 = sub_ln1118_1394_fu_18665_p2.read().range(17, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2636_fu_18719_p4() {
    trunc_ln708_2636_fu_18719_p4 = sub_ln1118_1395_fu_18713_p2.read().range(19, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2637_fu_4310_p1() {
    trunc_ln708_2637_fu_4310_p1 = ap_port_reg_data_133_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2637_fu_4310_p4() {
    trunc_ln708_2637_fu_4310_p4 = trunc_ln708_2637_fu_4310_p1.read().range(15, 3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2639_fu_18777_p4() {
    trunc_ln708_2639_fu_18777_p4 = sub_ln1118_889_fu_18771_p2.read().range(16, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2640_fu_4324_p1() {
    trunc_ln708_2640_fu_4324_p1 = ap_port_reg_data_133_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2643_fu_18842_p4() {
    trunc_ln708_2643_fu_18842_p4 = sub_ln1118_1721_fu_18836_p2.read().range(18, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2644_fu_18856_p1() {
    trunc_ln708_2644_fu_18856_p1 = ap_port_reg_data_134_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2644_fu_18856_p4() {
    trunc_ln708_2644_fu_18856_p4 = trunc_ln708_2644_fu_18856_p1.read().range(15, 3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2647_fu_18924_p4() {
    trunc_ln708_2647_fu_18924_p4 = sub_ln1118_1400_fu_18918_p2.read().range(19, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2648_fu_18938_p1() {
    trunc_ln708_2648_fu_18938_p1 = ap_port_reg_data_135_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2650_fu_18982_p4() {
    trunc_ln708_2650_fu_18982_p4 = sub_ln1118_1401_fu_18976_p2.read().range(17, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2652_fu_4334_p1() {
    trunc_ln708_2652_fu_4334_p1 = ap_port_reg_data_136_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2652_fu_4334_p4() {
    trunc_ln708_2652_fu_4334_p4 = trunc_ln708_2652_fu_4334_p1.read().range(15, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2653_fu_19016_p4() {
    trunc_ln708_2653_fu_19016_p4 = sub_ln1118_1402_fu_19010_p2.read().range(17, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2656_fu_24929_p4() {
    trunc_ln708_2656_fu_24929_p4 = sub_ln1118_1407_fu_24923_p2.read().range(18, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2658_fu_19105_p4() {
    trunc_ln708_2658_fu_19105_p4 = sub_ln1118_1410_fu_19099_p2.read().range(17, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2659_fu_24966_p4() {
    trunc_ln708_2659_fu_24966_p4 = sub_ln1118_1723_fu_24960_p2.read().range(19, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2660_fu_24986_p4() {
    trunc_ln708_2660_fu_24986_p4 = sub_ln1118_1412_fu_24980_p2.read().range(19, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2661_fu_19125_p4() {
    trunc_ln708_2661_fu_19125_p4 = sub_ln1118_890_fu_19119_p2.read().range(16, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2663_fu_4358_p4() {
    trunc_ln708_2663_fu_4358_p4 = sub_ln1118_891_fu_4352_p2.read().range(16, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2664_fu_4372_p1() {
    trunc_ln708_2664_fu_4372_p1 = ap_port_reg_data_138_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2665_fu_4386_p1() {
    trunc_ln708_2665_fu_4386_p1 = ap_port_reg_data_139_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2665_fu_4386_p4() {
    trunc_ln708_2665_fu_4386_p4 = trunc_ln708_2665_fu_4386_p1.read().range(15, 3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2669_fu_19248_p4() {
    trunc_ln708_2669_fu_19248_p4 = add_ln1118_147_fu_19243_p2.read().range(19, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2671_fu_19294_p1() {
    trunc_ln708_2671_fu_19294_p1 = ap_port_reg_data_140_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2671_fu_19294_p4() {
    trunc_ln708_2671_fu_19294_p4 = trunc_ln708_2671_fu_19294_p1.read().range(15, 3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2672_fu_19308_p1() {
    trunc_ln708_2672_fu_19308_p1 = ap_port_reg_data_140_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2672_fu_19308_p4() {
    trunc_ln708_2672_fu_19308_p4 = trunc_ln708_2672_fu_19308_p1.read().range(15, 4);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2673_fu_19352_p4() {
    trunc_ln708_2673_fu_19352_p4 = sub_ln1118_1419_fu_19346_p2.read().range(19, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2674_fu_19366_p1() {
    trunc_ln708_2674_fu_19366_p1 = ap_port_reg_data_140_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2674_fu_19366_p4() {
    trunc_ln708_2674_fu_19366_p4 = trunc_ln708_2674_fu_19366_p1.read().range(15, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2675_fu_4439_p1() {
    trunc_ln708_2675_fu_4439_p1 = ap_port_reg_data_141_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2676_fu_25103_p4() {
    trunc_ln708_2676_fu_25103_p4 = sub_ln1118_1422_fu_25097_p2.read().range(18, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2678_fu_19442_p4() {
    trunc_ln708_2678_fu_19442_p4 = sub_ln1118_1426_fu_19436_p2.read().range(18, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2680_fu_19472_p1() {
    trunc_ln708_2680_fu_19472_p1 = ap_port_reg_data_142_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2680_fu_19472_p4() {
    trunc_ln708_2680_fu_19472_p4 = trunc_ln708_2680_fu_19472_p1.read().range(15, 3);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2683_fu_19527_p4() {
    trunc_ln708_2683_fu_19527_p4 = sub_ln1118_1431_fu_19522_p2.read().range(19, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2684_fu_4477_p1() {
    trunc_ln708_2684_fu_4477_p1 = ap_port_reg_data_143_V_read.read();
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_2684_fu_4477_p4() {
    trunc_ln708_2684_fu_4477_p4 = trunc_ln708_2684_fu_4477_p1.read().range(15, 5);
}

void dense_latency_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_s_fu_19494_p4() {
    trunc_ln708_s_fu_19494_p4 = sub_ln1118_1429_fu_19489_p2.read().range(19, 5);
}

}

