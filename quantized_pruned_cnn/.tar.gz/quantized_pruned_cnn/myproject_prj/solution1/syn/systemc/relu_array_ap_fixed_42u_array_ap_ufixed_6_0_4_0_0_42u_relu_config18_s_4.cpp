#include "relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_71_fu_2678_p2() {
    xor_ln416_71_fu_2678_p2 = (tmp_337_fu_2670_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_72_fu_2760_p2() {
    xor_ln416_72_fu_2760_p2 = (tmp_341_fu_2752_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_73_fu_2842_p2() {
    xor_ln416_73_fu_2842_p2 = (tmp_345_fu_2834_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_74_fu_2924_p2() {
    xor_ln416_74_fu_2924_p2 = (tmp_349_fu_2916_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_75_fu_3006_p2() {
    xor_ln416_75_fu_3006_p2 = (tmp_353_fu_2998_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_76_fu_3088_p2() {
    xor_ln416_76_fu_3088_p2 = (tmp_357_fu_3080_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_77_fu_3170_p2() {
    xor_ln416_77_fu_3170_p2 = (tmp_361_fu_3162_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_78_fu_3252_p2() {
    xor_ln416_78_fu_3252_p2 = (tmp_365_fu_3244_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_79_fu_3334_p2() {
    xor_ln416_79_fu_3334_p2 = (tmp_369_fu_3326_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_80_fu_3416_p2() {
    xor_ln416_80_fu_3416_p2 = (tmp_373_fu_3408_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_81_fu_3498_p2() {
    xor_ln416_81_fu_3498_p2 = (tmp_377_fu_3490_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_82_fu_3580_p2() {
    xor_ln416_82_fu_3580_p2 = (tmp_381_fu_3572_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_83_fu_3662_p2() {
    xor_ln416_83_fu_3662_p2 = (tmp_385_fu_3654_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_84_fu_3744_p2() {
    xor_ln416_84_fu_3744_p2 = (tmp_389_fu_3736_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_85_fu_3826_p2() {
    xor_ln416_85_fu_3826_p2 = (tmp_393_fu_3818_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_86_fu_3908_p2() {
    xor_ln416_86_fu_3908_p2 = (tmp_397_fu_3900_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_87_fu_3990_p2() {
    xor_ln416_87_fu_3990_p2 = (tmp_401_fu_3982_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_88_fu_4072_p2() {
    xor_ln416_88_fu_4072_p2 = (tmp_405_fu_4064_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_89_fu_4154_p2() {
    xor_ln416_89_fu_4154_p2 = (tmp_409_fu_4146_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_90_fu_4236_p2() {
    xor_ln416_90_fu_4236_p2 = (tmp_413_fu_4228_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_91_fu_4318_p2() {
    xor_ln416_91_fu_4318_p2 = (tmp_417_fu_4310_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_92_fu_4400_p2() {
    xor_ln416_92_fu_4400_p2 = (tmp_421_fu_4392_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_93_fu_4482_p2() {
    xor_ln416_93_fu_4482_p2 = (tmp_425_fu_4474_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_94_fu_4564_p2() {
    xor_ln416_94_fu_4564_p2 = (tmp_429_fu_4556_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_95_fu_4646_p2() {
    xor_ln416_95_fu_4646_p2 = (tmp_433_fu_4638_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_96_fu_4728_p2() {
    xor_ln416_96_fu_4728_p2 = (tmp_437_fu_4720_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_97_fu_4810_p2() {
    xor_ln416_97_fu_4810_p2 = (tmp_441_fu_4802_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_98_fu_4892_p2() {
    xor_ln416_98_fu_4892_p2 = (tmp_445_fu_4884_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_99_fu_4974_p2() {
    xor_ln416_99_fu_4974_p2 = (tmp_449_fu_4966_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_xor_ln416_fu_2022_p2() {
    xor_ln416_fu_2022_p2 = (tmp_305_fu_2014_p3.read() ^ ap_const_lv1_1);
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_100_fu_5038_p1() {
    zext_ln415_100_fu_5038_p1 = esl_zext<6,1>(and_ln415_37_fu_5032_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_101_fu_5120_p1() {
    zext_ln415_101_fu_5120_p1 = esl_zext<6,1>(and_ln415_38_fu_5114_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_102_fu_5202_p1() {
    zext_ln415_102_fu_5202_p1 = esl_zext<6,1>(and_ln415_39_fu_5196_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_103_fu_5284_p1() {
    zext_ln415_103_fu_5284_p1 = esl_zext<6,1>(and_ln415_40_fu_5278_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_104_fu_5366_p1() {
    zext_ln415_104_fu_5366_p1 = esl_zext<6,1>(and_ln415_41_fu_5360_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_64_fu_2086_p1() {
    zext_ln415_64_fu_2086_p1 = esl_zext<6,1>(and_ln415_1_fu_2080_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_65_fu_2168_p1() {
    zext_ln415_65_fu_2168_p1 = esl_zext<6,1>(and_ln415_2_fu_2162_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_66_fu_2250_p1() {
    zext_ln415_66_fu_2250_p1 = esl_zext<6,1>(and_ln415_3_fu_2244_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_67_fu_2332_p1() {
    zext_ln415_67_fu_2332_p1 = esl_zext<6,1>(and_ln415_4_fu_2326_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_68_fu_2414_p1() {
    zext_ln415_68_fu_2414_p1 = esl_zext<6,1>(and_ln415_5_fu_2408_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_69_fu_2496_p1() {
    zext_ln415_69_fu_2496_p1 = esl_zext<6,1>(and_ln415_6_fu_2490_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_70_fu_2578_p1() {
    zext_ln415_70_fu_2578_p1 = esl_zext<6,1>(and_ln415_7_fu_2572_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_71_fu_2660_p1() {
    zext_ln415_71_fu_2660_p1 = esl_zext<6,1>(and_ln415_8_fu_2654_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_72_fu_2742_p1() {
    zext_ln415_72_fu_2742_p1 = esl_zext<6,1>(and_ln415_9_fu_2736_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_73_fu_2824_p1() {
    zext_ln415_73_fu_2824_p1 = esl_zext<6,1>(and_ln415_10_fu_2818_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_74_fu_2906_p1() {
    zext_ln415_74_fu_2906_p1 = esl_zext<6,1>(and_ln415_11_fu_2900_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_75_fu_2988_p1() {
    zext_ln415_75_fu_2988_p1 = esl_zext<6,1>(and_ln415_12_fu_2982_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_76_fu_3070_p1() {
    zext_ln415_76_fu_3070_p1 = esl_zext<6,1>(and_ln415_13_fu_3064_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_77_fu_3152_p1() {
    zext_ln415_77_fu_3152_p1 = esl_zext<6,1>(and_ln415_14_fu_3146_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_78_fu_3234_p1() {
    zext_ln415_78_fu_3234_p1 = esl_zext<6,1>(and_ln415_15_fu_3228_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_79_fu_3316_p1() {
    zext_ln415_79_fu_3316_p1 = esl_zext<6,1>(and_ln415_16_fu_3310_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_80_fu_3398_p1() {
    zext_ln415_80_fu_3398_p1 = esl_zext<6,1>(and_ln415_17_fu_3392_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_81_fu_3480_p1() {
    zext_ln415_81_fu_3480_p1 = esl_zext<6,1>(and_ln415_18_fu_3474_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_82_fu_3562_p1() {
    zext_ln415_82_fu_3562_p1 = esl_zext<6,1>(and_ln415_19_fu_3556_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_83_fu_3644_p1() {
    zext_ln415_83_fu_3644_p1 = esl_zext<6,1>(and_ln415_20_fu_3638_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_84_fu_3726_p1() {
    zext_ln415_84_fu_3726_p1 = esl_zext<6,1>(and_ln415_21_fu_3720_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_85_fu_3808_p1() {
    zext_ln415_85_fu_3808_p1 = esl_zext<6,1>(and_ln415_22_fu_3802_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_86_fu_3890_p1() {
    zext_ln415_86_fu_3890_p1 = esl_zext<6,1>(and_ln415_23_fu_3884_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_87_fu_3972_p1() {
    zext_ln415_87_fu_3972_p1 = esl_zext<6,1>(and_ln415_24_fu_3966_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_88_fu_4054_p1() {
    zext_ln415_88_fu_4054_p1 = esl_zext<6,1>(and_ln415_25_fu_4048_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_89_fu_4136_p1() {
    zext_ln415_89_fu_4136_p1 = esl_zext<6,1>(and_ln415_26_fu_4130_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_90_fu_4218_p1() {
    zext_ln415_90_fu_4218_p1 = esl_zext<6,1>(and_ln415_27_fu_4212_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_91_fu_4300_p1() {
    zext_ln415_91_fu_4300_p1 = esl_zext<6,1>(and_ln415_28_fu_4294_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_92_fu_4382_p1() {
    zext_ln415_92_fu_4382_p1 = esl_zext<6,1>(and_ln415_29_fu_4376_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_93_fu_4464_p1() {
    zext_ln415_93_fu_4464_p1 = esl_zext<6,1>(and_ln415_30_fu_4458_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_94_fu_4546_p1() {
    zext_ln415_94_fu_4546_p1 = esl_zext<6,1>(and_ln415_31_fu_4540_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_95_fu_4628_p1() {
    zext_ln415_95_fu_4628_p1 = esl_zext<6,1>(and_ln415_32_fu_4622_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_96_fu_4710_p1() {
    zext_ln415_96_fu_4710_p1 = esl_zext<6,1>(and_ln415_33_fu_4704_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_97_fu_4792_p1() {
    zext_ln415_97_fu_4792_p1 = esl_zext<6,1>(and_ln415_34_fu_4786_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_98_fu_4874_p1() {
    zext_ln415_98_fu_4874_p1 = esl_zext<6,1>(and_ln415_35_fu_4868_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_99_fu_4956_p1() {
    zext_ln415_99_fu_4956_p1 = esl_zext<6,1>(and_ln415_36_fu_4950_p2.read());
}

void relu_array_ap_fixed_42u_array_ap_ufixed_6_0_4_0_0_42u_relu_config18_s::thread_zext_ln415_fu_2004_p1() {
    zext_ln415_fu_2004_p1 = esl_zext<6,1>(and_ln415_fu_1998_p2.read());
}

}

